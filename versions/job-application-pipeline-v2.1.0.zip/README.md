# Job application pipeline

Run from this folder in PowerShell using the project virtual environment.

```powershell
# Default: Agent A (cover letter), B (CV), compilation, C (review)
.venv/Scripts/python -m src.run_job

# A and B, then compile both PDFs; omit Agent C and its review workbook
.venv/Scripts/python -m src.run_job --skip-review

# Choose a provider for this run; all three use the same workflow
.venv/Scripts/python -m src.run_job --provider claude
.venv/Scripts/python -m src.run_job --provider codex
.venv/Scripts/python -m src.run_job --provider gemini

# Explicit job numbers/ranges redo those jobs
.venv/Scripts/python -m src.run_job 327 330 333 --skip-review

# Force the document language instead of following each ad
.venv/Scripts/python -m src.run_job 312 --language en
```

`run_settings.yaml` selects the default provider, model and reasoning effort.
`--provider`, `--model` and `--effort` override those settings for one run. Gemini
CLI has no effort control; use `--effort default` if overriding an old setting.
Without job numbers, finished jobs are skipped; `--force` reruns all jobs.

Jobs completed with `--skip-review` are skipped on later `--skip-review` runs.
A later default run reruns them through A, B and C so they receive a review.
Jobs already completed with a valid review are skipped in either mode.
Successful new runs record PDF hashes and review status in `output/job_X/completion.json`.
Completion records and review copies survive removal of `temp/`. Existing outputs
through job 353 were explicitly accepted during the requested cleanup; their old
review artifacts were already unavailable.

## Languages

German ads get a German CV and cover letter; all other ads get English ones.
Python decides by counting German and English function words in the ad body
(below LinkedIn's English header fields), then prints the result for each job
and records it in `completion.json`. `--language en` or `--language de` overrides
the detection for a run.

`input/cl_de/` and `input/cv_de/` hold only the German files: the letter body,
its preamble (German hyphenation and date), the fill-in parts and the CV content.
They replace their counterparts in `cl/` and `cv/` in the job's build folder; shared files
such as the contact headings and CV layout come from `input/`. Edit a shared file
once, and edit wording in both languages. Every agent is told the language;
agent reports and the hiring review stay in English.

Jobs finished before language support have English documents. Name German jobs
explicitly to redo them in German.

## Shared provider behaviour

Claude's cover-letter and CV tailoring rules are the baseline for all providers.
They use the same instructions, input text, permitted fields, JSON contracts,
local validation, and one repair attempt for invalid responses. Python extracts
the job-ad text once and supplies it to every agent. Agents return proposed
content; Python validates and saves it. They do not need to discover PDF tools,
read local documents or edit files themselves.

Only Agent A can search/fetch the web, for a missing company postal address.
Agents B and C need no tools. Provider adapters restrict tools through each
CLI's available controls. Their underlying models, CLI features, service latency,
and generated wording still differ; identical elapsed times are not guaranteed.
Claude and Codex also support native JSON-schema constraints; Gemini receives
the same schema in its prompt. All replies pass the same local schema checks.

Python checks protected text, numeric facts, company/title identity and one-page
PDF limits. If the CV exceeds one page, Agent B gets one shortening attempt.
Agent C assesses text extracted from the compiled PDFs; it does not visually
inspect page layout. Disabling C keeps the tailoring and compilation checks.

PDFs are published to `output/job_X/` after all selected stages succeed.
Build files and logs are in `temp/build/job_X/`. Completed review workbooks and
review JSON are also preserved alongside the PDFs in `output/job_X/`.
Each agent attempt records its prompt, reply, raw provider logs, timing and
validation result. Batch history is appended to `output/batch_summary.csv`.

## Verification

```powershell
.venv/Scripts/python -m pip install -r requirements.txt
.venv/Scripts/python -m unittest discover -s tests -v

# Optional live checks: consumes provider usage, sends only synthetic text
.venv/Scripts/python tests/smoke_providers.py
```

The pipeline also requires `pdflatex` on PATH and the selected provider's CLI
installed and authenticated. The live checks exercise both web-enabled and
tool-free request configurations without using candidate documents.
