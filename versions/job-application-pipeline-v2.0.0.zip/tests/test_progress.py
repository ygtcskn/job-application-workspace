"""Timing output is local instrumentation, not a live-model benchmark."""
import json
from threading import Event
import pytest
from src import progress
from src.progress import Activity, JobProgress, duration


@pytest.mark.parametrize('seconds,expected', [(0,'0.0s'),(12.34,'12.3s'),(65,'1m 05s'),(3661,'1h 01m 01s')])
def test_readable_durations(seconds,expected):
    assert duration(seconds)==expected


def test_stage_times_use_monotonic_clock_and_retain_failure(monkeypatch):
    current=[100.0]
    monkeypatch.setattr(progress,'perf_counter',lambda:current[0])
    timer=JobProgress('job_synthetic')
    timer.start('snapshot')
    current[0]=102.5
    timer.start('Agent A')
    current[0]=109.0
    timer.finish('FAILED')
    assert timer.elapsed_seconds==9.0
    assert [r['elapsed_seconds'] for r in timer.records]==[2.5,6.5]
    assert [r['status'] for r in timer.records]==['DONE','FAILED']


def test_heartbeat_reports_waiting_and_stops_on_completion(monkeypatch):
    messages=[]; waited=Event()
    def record(message):
        messages.append(message)
        if message.startswith('WAIT'): waited.set()
    monkeypatch.setattr(progress,'emit',record)
    activity=Activity('synthetic provider',timeout=60,heartbeat_seconds=0.01)
    with activity as timing:
        assert waited.wait(1), 'Heartbeat was not emitted'
    assert any('elapsed' in m and 'still running' in m for m in messages)
    assert messages[-1].startswith('DONE')
    assert timing['status']=='DONE' and timing['elapsed_seconds']>=0
    assert not activity.thread.is_alive()


def test_activity_failure_has_elapsed_time_and_no_lingering_thread():
    activity=Activity('synthetic rejection')
    with pytest.raises(RuntimeError,match='failure'):
        with activity as timing:
            raise RuntimeError('failure')
    assert timing['status']=='FAILED' and timing['elapsed_seconds']>=0
    assert not activity.thread.is_alive()
