"""Interactive selection uses one provider and does not call a model."""
from src.main import interactive, parser
from src.input_loader import load_config
from src.providers.base import SUPPORTED_PROVIDERS, resolve_settings
import pytest


def probe_result(**overrides):
    return {'models': [], 'efforts': [], 'availability': 'mocked discovery',
            'schema_enforcement': 'mocked', **overrides}


@pytest.mark.parametrize('answer,expected', [('claude', 'claude'), ('gemini', 'gemini'), ('', 'codex')])
def test_interactive_provider_switch_and_default(monkeypatch, answer, expected):
    config=load_config(); args=parser().parse_args(['--job','example.md','--model','default','--effort','default'])
    monkeypatch.setattr('builtins.input',lambda prompt:answer)
    monkeypatch.setattr('src.main.probe',lambda *a:probe_result())
    interactive(args,config)
    assert args.provider==expected
    assert {s.provider for s in resolve_settings(config,args.provider,args.model,args.effort).values()}=={expected}


def test_interactive_rejects_an_unknown_provider(monkeypatch):
    config=load_config(); args=parser().parse_args(['--job','example.md'])
    monkeypatch.setattr('builtins.input',lambda prompt:'mistral')
    with pytest.raises(ValueError,match='Select'):
        interactive(args,config)


def test_launcher_and_parser_offer_every_supported_provider():
    assert SUPPORTED_PROVIDERS == ('codex', 'claude', 'gemini')
    action = next(a for a in parser()._actions if a.dest == 'provider')
    assert list(action.choices) == list(SUPPORTED_PROVIDERS)
    from src.input_loader import ROOT
    launcher = (ROOT / 'run.ps1').read_text(encoding='utf-8')
    assert "ValidateSet('codex', 'claude', 'gemini')" in launcher


def test_interactive_selection_never_asks_for_job(monkeypatch):
    config=load_config(); args=parser().parse_args([])
    answers=iter(['claude','opus','medium']); prompts=[]
    def respond(prompt): prompts.append(prompt); return next(answers)
    monkeypatch.setattr('builtins.input',respond)
    monkeypatch.setattr('src.main.probe',lambda *a:probe_result(efforts=['medium']))
    interactive(args,config)
    assert args.job is None
    assert len(prompts)==3 and all('Job number' not in p for p in prompts)


def test_gemini_selection_states_that_effort_is_unavailable(monkeypatch, capsys):
    config=load_config(); args=parser().parse_args([])
    answers=iter(['gemini','gemini-2.5-pro',''])
    monkeypatch.setattr('builtins.input',lambda prompt:next(answers))
    monkeypatch.setattr('src.main.probe',lambda *a:probe_result(models=['gemini-2.5-pro']))
    interactive(args,config)
    output=capsys.readouterr().out
    assert 'no reasoning-effort control' in output
    assert args.provider=='gemini' and args.model=='gemini-2.5-pro' and args.effort is None
