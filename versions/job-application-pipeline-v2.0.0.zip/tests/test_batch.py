"""Batch control uses mocked model execution; no provider calls in these tests."""
import json
from pathlib import Path
import pytest
from src.batch import run_batch
from src.input_loader import load_config
from src.providers.base import resolve_settings, ProviderFailure


def fixture(tmp_path, names=('a.md','b.md','c.md')):
    config=load_config()
    config['paths'].update(job_descriptions=tmp_path/'jobs',temporary=tmp_path/'temp',final=tmp_path/'final')
    config['paths']['job_descriptions'].mkdir()
    for name in names:
        p=config['paths']['job_descriptions']/name
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text('Synthetic job',encoding='utf-8')
    return config


def report(config):
    p=next((config['paths']['temporary']/'batches').glob('*.json'))
    return json.loads(p.read_text(encoding='utf-8'))


def test_all_jobs_share_settings_and_continue_after_review_or_input_failure(tmp_path):
    config=fixture(tmp_path); calls=[]
    def execute(config,job,identifier,settings,requested):
        calls.append(job.name)
        assert {s.provider for s in settings.values()}=={'claude'}
        assert {s.model for s in settings.values()}=={'opus'}
        assert {s.effort for s in settings.values()}=={'medium'}
        assert requested['job']==job.name
        if job.name=='a.md': return 2
        if job.name=='b.md': raise ValueError('empty input')
        return 0
    code=run_batch(config,resolve_settings(config,'claude','opus','medium'),{},execute)
    assert calls==['a.md','b.md','c.md'] and code==1
    assert [r['status'] for r in report(config)['jobs']]==['NEEDS_USER_REVIEW','FAILED','PASS']


def test_provider_rejection_stops_remaining_jobs(tmp_path):
    config=fixture(tmp_path); calls=[]
    def execute(*args):
        calls.append(1)
        raise ProviderFailure('session limit')
    assert run_batch(config,resolve_settings(config),{},execute)==1
    assert len(calls)==1
    assert [r['status'] for r in report(config)['jobs']]==['FAILED','NOT_RUN','NOT_RUN']


def test_batch_processes_only_postings_without_output(tmp_path):
    """The whole point of a batch: pick up what is new, leave finished work alone."""
    config=fixture(tmp_path); old=config['paths']['temporary']/'job_a'
    old.mkdir(parents=True); (old/'evidence.txt').write_text('preserved')
    ids=[]
    def execute(config,job,identifier,*args): ids.append(identifier); return 0
    assert run_batch(config,resolve_settings(config),{},execute)==0
    assert ids==['job_b','job_c']
    assert (old/'evidence.txt').read_text()=='preserved'
    assert [r['status'] for r in report(config)['jobs']]==['SKIPPED','PASS','PASS']


def test_a_batch_with_nothing_new_succeeds_quietly(tmp_path):
    config=fixture(tmp_path)
    for name in ('job_a','job_b','job_c'):
        (config['paths']['final']/name).mkdir(parents=True)
    assert run_batch(config,resolve_settings(config),{},lambda *a:pytest.fail('nothing should run'))==0
    assert {r['status'] for r in report(config)['jobs']}=={'SKIPPED'}


def test_duplicate_stems_in_one_batch_run_once(tmp_path):
    config=fixture(tmp_path,('a.md','folder/a.md')); ids=[]
    def execute(config,job,identifier,*args): ids.append(identifier); return 0
    assert run_batch(config,resolve_settings(config),{},execute)==0
    assert ids==['job_a']


def test_all_review_required_returns_two(tmp_path):
    config=fixture(tmp_path)
    assert run_batch(config,resolve_settings(config),{},lambda *a:2)==2


def test_published_with_findings_is_a_distinct_outcome(tmp_path):
    config=fixture(tmp_path)
    assert run_batch(config,resolve_settings(config),{},lambda *a:3)==3
    rows=report(config)['jobs']
    assert [r['status'] for r in rows]==['PUBLISHED_WITH_FINDINGS']*3
    assert all(r['output'].endswith(str(Path('final')/r['job_id'])) for r in rows)
    assert report(config)['status']=='PUBLISHED_WITH_FINDINGS'


def test_review_required_outranks_published_with_findings(tmp_path):
    config=fixture(tmp_path)
    assert run_batch(config,resolve_settings(config),{},lambda c,job,*a:2 if job.name=='a.md' else 3)==2


def test_empty_batch_fails_before_execution(tmp_path):
    config=fixture(tmp_path,())
    with pytest.raises(ValueError,match='No supported'):
        run_batch(config,resolve_settings(config),{},lambda *a:pytest.fail('Must not execute'))


def test_explicit_settings_do_not_prompt_and_default_to_batch(tmp_path,monkeypatch):
    from src.main import main
    config=fixture(tmp_path)
    monkeypatch.setattr('src.main.load_config',lambda *a:config)
    monkeypatch.setattr('builtins.input',lambda *a:pytest.fail('Unexpected prompt'))
    calls=[]
    def batch(config,settings,requested): calls.append(requested); return 0
    monkeypatch.setattr('src.batch.run_batch',batch)
    assert main(['--provider','claude','--model','opus','--effort','medium'])==0
    assert len(calls)==1 and calls[0]['job'] is None


def test_explicit_job_still_uses_single_workflow(tmp_path,monkeypatch):
    from src.main import main
    config=fixture(tmp_path)
    monkeypatch.setattr('src.main.load_config',lambda *a:config)
    monkeypatch.setattr('src.batch.run_batch',lambda *a:pytest.fail('Unexpected batch'))
    calls=[]
    def execute(config,job,*args): calls.append(job.name); return 0
    monkeypatch.setattr('src.workflow.execute',execute)
    assert main(['--job','b.md','--non-interactive'])==0
    assert calls==['b.md']


def test_custom_job_id_requires_single_job(tmp_path,monkeypatch):
    from src.main import main
    config=fixture(tmp_path)
    monkeypatch.setattr('src.main.load_config',lambda *a:config)
    assert main(['--job-id','ambiguous','--non-interactive'])==1
