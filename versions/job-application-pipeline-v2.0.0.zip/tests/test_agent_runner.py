"""Mocked format-repair and provenance checks; no live provider use."""
import pytest
import json
from src.agent_runner import invoke_role
from src.providers.base import Settings
from src.input_loader import load_sources
from src.providers import codex_cli, gemini_cli
from tests.test_workflow import synthetic_config


def test_format_repair_has_independent_bound(tmp_path,monkeypatch):
    c,j,d=synthetic_config(tmp_path)
    s=load_sources(c,j); calls=[]
    def fake(*args):
        calls.append(args)
        return 'not json' if len(calls)==1 else d.model_dump_json()
    monkeypatch.setattr(codex_cli,'invoke',fake)
    result=invoke_role('agent_a',Settings('codex','fake',None,None,10),s,c['rules'],c['rubric'],{},tmp_path/'attempts',1)
    assert result.cv is not None and len(calls)==2
    assert (tmp_path/'attempts/attempt_0/raw_response.txt').exists()
    assert (tmp_path/'attempts/attempt_1/normalized.json').exists()
    for attempt in (0,1):
        metadata=json.loads((tmp_path/f'attempts/attempt_{attempt}/metadata.json').read_text(encoding='utf-8'))
        assert metadata['elapsed_seconds']>=metadata['provider_elapsed_seconds']>=0


def test_format_repair_exhaustion(tmp_path,monkeypatch):
    c,j,d=synthetic_config(tmp_path); s=load_sources(c,j); calls=[]
    def fake(*args): calls.append(1); return '{}'
    monkeypatch.setattr(codex_cli,'invoke',fake)
    with pytest.raises(ValueError,match='after 2 attempts'):
        invoke_role('agent_a',Settings('codex','fake',None,None,10),s,c['rules'],c['rubric'],{},tmp_path/'attempts',1)
    assert len(calls)==2


def test_provider_failure_is_not_a_format_retry(tmp_path,monkeypatch):
    c,j,d=synthetic_config(tmp_path); s=load_sources(c,j); calls=[]
    def fake(*args): calls.append(1); raise RuntimeError('unsupported model')
    monkeypatch.setattr(codex_cli,'invoke',fake)
    with pytest.raises(RuntimeError,match='unsupported model'):
        invoke_role('agent_a',Settings('codex','fake',None,None,10),s,c['rules'],c['rubric'],{},tmp_path/'attempts',1)
    assert len(calls)==1


def test_source_mutation_fails_after_provider(tmp_path,monkeypatch):
    c,j,d=synthetic_config(tmp_path); s=load_sources(c,j)
    def fake(*args):
        j.write_text('changed')
        return d.model_dump_json()
    monkeypatch.setattr(codex_cli,'invoke',fake)
    with pytest.raises(ValueError,match='Source changed'):
        invoke_role('agent_a',Settings('codex','fake',None,None,10),s,c['rules'],c['rubric'],{},tmp_path/'attempts',1)


def gemini_envelope(text):
    return json.dumps({'response': text, 'stats': {'tools': {'totalCalls': 0}}})


def test_gemini_dispatch_and_local_schema_repair(tmp_path, monkeypatch):
    """Gemini has no response-schema flag, so the contract is enforced by local repair."""
    c, j, d = synthetic_config(tmp_path)
    s = load_sources(c, j)
    calls = []
    def fake(args, cwd, timeout, stdin=None):
        calls.append(args)
        # First reply wraps the object in prose and a fence; the second is clean.
        body = d.model_dump_json()
        return (gemini_envelope(f'Sure, here it is:\n```json\n{body}\n```' if len(calls) == 1 else body), '')
    monkeypatch.setattr(gemini_cli, 'run_process', fake)
    result = invoke_role('agent_a', Settings('gemini', 'gemini.exe', None, None, 10), s, c['rules'], c['rubric'], {}, tmp_path / 'attempts', 1)
    assert result.cv is not None
    # Fenced prose still validated, so no repair attempt was needed.
    assert len(calls) == 1
    assert '--approval-mode' in calls[0] and '--yolo' not in calls[0]
    assert (tmp_path / 'attempts/attempt_0/normalized.json').exists()


def test_gemini_prompt_travels_by_stdin_not_argv(tmp_path, monkeypatch):
    """Personal source content must never reach the command line."""
    c, j, d = synthetic_config(tmp_path)
    s = load_sources(c, j)
    seen = {}
    def fake(args, cwd, timeout, stdin=None):
        seen['args'], seen['stdin'] = args, stdin
        return (gemini_envelope(d.model_dump_json()), '')
    monkeypatch.setattr(gemini_cli, 'run_process', fake)
    invoke_role('agent_a', Settings('gemini', 'gemini.exe', None, None, 10), s, c['rules'], c['rubric'], {}, tmp_path / 'attempts', 1)
    assert 'Synthetic candidate uses Python' in seen['stdin']
    assert not any('Synthetic candidate' in a for a in seen['args'])
