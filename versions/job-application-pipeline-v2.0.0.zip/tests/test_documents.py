import pytest
from src.input_loader import load_config
from src.template_renderer import render, validate_rendered, boundaries, escape
from src.validator import validate_draft
from tests.helpers import sample

CV = b"PREAMBLE\r\n% AI_EDIT_START: SUMMARY\r\nold\r\n% AI_EDIT_END: SUMMARY\r\nPROTECTED PERSON\r\n% AI_EDIT_START: SKILLS\r\nold\r\n% AI_EDIT_END: SKILLS\r\nEND\r\n"


@pytest.mark.parametrize('expected,text,accepted', [
    ('developing tests', 'de-\nveloping tests', True),
    ('developing tests', 'de-\r\n  veloping tests', True),
    ('developing tests', 'de\u00ad\nveloping tests', True),
    ('cross-functional developing', 'cross-\nfunctional de-\nveloping', True),
    ('developing', 'de-veloping', False),
    ('developing tests', 'de-\nveloping', False),
    ('27000', '270-\n00', False),
    ('cross-functional', 'crossfunctional', False),
])
def test_pdf_line_break_hyphenation(expected, text, accepted):
    from src.document_builder import contains_replacement
    assert contains_replacement(expected, text) is accepted


def setup():
    rules = load_config()["rules"]
    cl = ("\\begin{document}\r\n" + " ".join(rules["cl_tokens"]) + " {{JOB-TITLE}} END").encode()
    return rules, cl, sample(rules)


def test_protected_bytes_and_repeated_tokens():
    rules, cl, draft = setup()
    out = render(CV, cl, draft, rules)
    validate_rendered({"cv": CV, "cl": cl}, out, draft, rules)
    assert b"PROTECTED PERSON\r\n" in out["cv"]
    assert b"Python \\& SQL" in out["cv"]
    assert b"{{JOB-TITLE}}" not in out["cl"]
    out["cv"] = out["cv"].replace(b"PROTECTED PERSON", b"OTHER PERSON")
    with pytest.raises(ValueError, match="Protected"):
        validate_rendered({"cv": CV, "cl": cl}, out, draft, rules)


@pytest.mark.parametrize("source", [CV.replace(b"START: SUMMARY", b"START: SKILLS"), CV.replace(b"END: SUMMARY", b"END: OTHER"), CV.replace(b"START: SKILLS", b"START: SUMMARY")])
def test_ambiguous_boundaries(source):
    with pytest.raises(ValueError):
        boundaries(source)


def test_escaping_and_injection():
    assert escape("$5_#%{}~^\\") == r"\$5\_\#\%\{\}\textasciitilde{}\textasciicircum{}\textbackslash{}"
    with pytest.raises(ValueError):
        escape("{{INJECTED}}")


def test_inventory_language_and_r_gate():
    rules, _, draft = setup()
    draft.cv.skills[0].items.remove("TensorFlow/Keras")
    draft.cv.skills[0].items += ["ggplot2", "Invented skill"]
    draft.cv.skills[-1].items = ["German (Native)"]
    codes = {f.code for f in validate_draft(draft, rules, {"job/example.txt": "Python analyst"})}
    assert {"SKILLS_MANDATORY_MISSING", "SKILLS_UNAPPROVED", "LANGUAGES_EXACT", "R_PACKAGE_GATE"} <= codes


def test_exact_token_keys():
    rules, cl, draft = setup()
    draft.cl_tokens["{{UNAUTHORIZED}}"] = "x"
    with pytest.raises(ValueError):
        render(CV, cl, draft, rules)


def test_python_packages_print_in_brackets_after_python():
    from src.template_renderer import skill_text
    rules, cl, draft = setup()
    packages = rules["python_packages"]
    items = ["Python", "pandas", "NumPy", "scikit-learn", "TensorFlow/Keras", "R", "SQL (PostgreSQL)", "Matplotlib"]
    assert skill_text(items, packages) == "Python (pandas, NumPy, scikit-learn, TensorFlow/Keras, Matplotlib), R, SQL (PostgreSQL)"
    assert skill_text(["LaTeX", "Git"], packages) == "LaTeX, Git"
    assert b"Python (pandas, NumPy, scikit-learn, TensorFlow/Keras), R" in render(CV, cl, draft, rules)["cv"]


def test_cover_letter_has_no_recipient_address_block():
    """Removed on 2026-09-16: the letter carries the sender block only, and the two
    address tokens left the template and the configuration together."""
    from src.input_loader import load_config
    config = load_config()
    cl = (config['paths']['input'] / 'cl_template.tex').read_text(encoding='utf-8')
    assert '{{COMPANY-ADDRESS}}' not in cl and '{{COMPANY-CITY}}' not in cl
    assert '{{COMPANY-ADDRESS}}' not in config['rules']['cl_tokens']
    assert config['rules']['optional_empty_tokens'] == []
    assert cl.count('{{COMPANY-NAME}}') == 2
