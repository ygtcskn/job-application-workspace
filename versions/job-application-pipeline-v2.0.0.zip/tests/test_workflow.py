"""Mocked AI/compiler integration only; no live model or real PDFs in these tests."""
import copy
import json
from pathlib import Path
import pytest
from src.findings import ADVISORY, CRITICAL, MAJOR, Finding
from src.input_loader import load_config, write_json, sha256
from src.schemas import Evidence
from src.validator import decision, review_findings, score_findings, source_findings
from src.template_renderer import skill_text
from src.workflow import execute, publish
from src.providers.base import resolve_settings
from tests.helpers import sample, review
from tests.test_documents import CV


def critical(message='broken'):
    return [Finding('TEST_CRITICAL', CRITICAL, message, 'test', False)]


def major(message='needs a look'):
    return [Finding('TEST_MAJOR', MAJOR, message, 'test', True)]


@pytest.mark.parametrize('cv,cl,expected', [(75, 75, 'PASS'), (74, 100, 'REVISE'), (100, 74, 'REVISE')])
def test_separate_thresholds(cv, cl, expected):
    rubric = load_config()['rubric']['criteria']
    r = review(rubric, cv, cl)
    findings = score_findings(r.totals(rubric), 75)
    assert decision(r, rubric, findings, 0, 3)[0] == expected


def test_gate_overrides_pass():
    rubric = load_config()['rubric']['criteria']
    r = review(rubric)
    assert decision(r, rubric, major('bad parsing'), 0, 3)[0] == 'REVISE'
    r.cv_scores['evidence_fit'].maximum = 99
    with pytest.raises(ValueError):
        r.totals(rubric)


def test_findings_publish_unless_critical():
    """The reported problem decides; only a critical defect withholds documents."""
    rubric = load_config()['rubric']['criteria']
    r = review(rubric)
    assert decision(r, rubric, [], 0, 3)[0] == 'PASS'
    # A major finding uses the remaining rounds, then publishes with the report.
    assert decision(r, rubric, major(), 0, 3)[0] == 'REVISE'
    assert decision(r, rubric, major(), 3, 3)[0] == 'PUBLISH'
    # An unfixable major finding cannot be revised away, so it publishes immediately.
    assert decision(r, rubric, [Finding('X', MAJOR, 'protected defect', 'test', False)], 0, 3)[0] == 'PUBLISH'
    # Critical always withholds, and so does the opt-out policy.
    assert decision(r, rubric, critical(), 3, 3)[0] == 'NEEDS_USER_REVIEW'
    assert decision(r, rubric, major(), 3, 3, publish_policy='pass_only')[0] == 'NEEDS_USER_REVIEW'


def test_advisory_notes_do_not_block_a_pass():
    """Source ambiguities and informational notes are recorded, not treated as blockers."""
    rubric = load_config()['rubric']['criteria']
    notes = [Finding('SOURCE_PROFILE_ORDER', ADVISORY, 'ordering ambiguity', 'source', False),
             Finding('OVERFLOW_PROTECTED', ADVISORY, 'cv: 3.10pt in protected layout', 'builder', False)]
    assert decision(review(rubric), rubric, notes, 0, 3)[0] == 'PASS'


def test_reviewer_user_review_request_is_recorded_not_obeyed():
    rubric = load_config()['rubric']['criteria']
    r = review(rubric, decision='NEEDS_USER_REVIEW')
    findings = review_findings(r)
    assert {f.code for f in findings} == {'REVIEW_DECISION_USER_REVIEW'}
    assert decision(r, rubric, findings, 3, 3)[0] == 'PUBLISH'


def test_configured_source_severity_and_override():
    rules = {'source_issues': [{'id': 'PROFILE_ORDER', 'severity': 'advisory', 'reason': 'ambiguous', 'resolution': 'precedence'}]}
    finding, = source_findings(rules)
    assert finding.code == 'SOURCE_PROFILE_ORDER' and finding.severity == ADVISORY
    assert 'precedence' in finding.message
    promoted, = source_findings(rules, {'SOURCE_PROFILE_ORDER': CRITICAL})
    assert promoted.severity == CRITICAL


def synthetic_config(tmp_path):
    config = copy.deepcopy(load_config())
    config['root'] = tmp_path
    for key in ['input', 'temporary', 'final']:
        config['paths'][key] = tmp_path / key
    config['rules']['source_issues'] = []
    (tmp_path / 'input').mkdir(); (tmp_path / 'config').mkdir(); (tmp_path / 'agents').mkdir()
    for name in ('pipeline', 'editing_rules', 'scoring_rubric'):
        (tmp_path / f'config/{name}.yaml').write_text('synthetic: true')
    d = sample(config['rules'])
    fields = {'cv.summary': d.cv.summary, **{f'cv.skills.{s.label}': skill_text(s.items, config['rules'].get('python_packages', ())) for s in d.cv.skills}, **{f'cl_tokens.{k}': v for k, v in d.cl_tokens.items()}}
    text = '\n'.join(fields.values())
    (tmp_path / 'input/cv_template.tex').write_bytes(CV + text.encode())
    (tmp_path / 'input/cl_template.tex').write_text('\\begin{document}\n' + ' '.join(d.cl_tokens))
    (tmp_path / 'input/skills_profile.md').write_text(text)
    for role, spec in config['agents'].items():
        spec['prompt'] = f'agents/{role}.md'; (tmp_path / spec['prompt']).write_text('Synthetic role')
    job = tmp_path / 'example.md'; job.write_text('Synthetic Python analyst vacancy')
    d.evidence = [Evidence(claim_id=str(i), field=k, claim=v, claim_type='applicant_fact', source='skills_profile.md', excerpt=v, location='synthetic fixture') for i, (k, v) in enumerate(fields.items()) if v]
    return config, job, d


def fake_builder(candidate, draft, path, config, overrides=None):
    path.mkdir(parents=True)
    for name in ('cv', 'cl'):
        (path / f'{name}.tex').write_bytes(candidate[name])
        (path / f'{name}.pdf').write_bytes(b'MOCK PDF - not a real document')
    return {'documents': {'cv': {}, 'cl': {}}, 'findings': []}


def broken_builder(candidate, draft, path, config, overrides=None):
    path.mkdir(parents=True)
    (path / 'cv.tex').write_bytes(candidate['cv'])
    return {'documents': {}, 'findings': [Finding('COMPILE_FAILED', CRITICAL, 'cl: compilation failed', 'builder', False)]}


def run(config, job, identifier, draft, verdict, builder=fake_builder, monkeypatch=None):
    monkeypatch.setattr('src.workflow.probe', lambda *a: {'auth': 'signed in', 'help': 'mock'})
    def runner(role, settings, sources, rules, rubric, context, path, retries):
        return verdict(rubric['criteria']) if role == 'agent_c' else draft
    return execute(config, job, identifier, resolve_settings(config), {}, runner, builder)


def test_low_scores_still_publish_with_a_validation_report(tmp_path, monkeypatch):
    """The user's requirement: finish the PDFs, record the problems, never withhold silently."""
    c, j, d = synthetic_config(tmp_path)
    code = run(c, j, 'job_findings', d, lambda rb: review(rb, 74, 80, 'REVISE'), monkeypatch=monkeypatch)
    assert code == 3
    final = c['paths']['final'] / 'job_findings'
    assert {p.name for p in final.iterdir()} == {'cv.tex', 'cl.tex', 'yigit_coskun_cv.pdf', 'yigit_coskun_cl.pdf', 'validation_report.md', 'validation_report.json'}
    saved = json.loads((final / 'validation_report.json').read_text(encoding='utf-8'))
    assert saved['status'] == 'PUBLISHED_WITH_FINDINGS'
    assert saved['counts']['critical'] == 0 and saved['counts']['major'] >= 1
    assert any(f['code'] == 'SCORE_BELOW_THRESHOLD' for f in saved['findings'])
    assert 'Validation report' in (final / 'validation_report.md').read_text(encoding='utf-8')
    # All four rounds were still used before finalizing.
    assert json.loads((c['paths']['temporary'] / 'job_findings/run_log.json').read_text(encoding='utf-8'))['round'] == 3


def test_critical_finding_withholds_publication(tmp_path, monkeypatch):
    c, j, d = synthetic_config(tmp_path)
    code = run(c, j, 'job_broken', d, lambda rb: review(rb), builder=broken_builder, monkeypatch=monkeypatch)
    assert code == 2
    assert not (c['paths']['final'] / 'job_broken').exists()
    saved = json.loads((c['paths']['temporary'] / 'job_broken/validation_report.json').read_text(encoding='utf-8'))
    assert saved['status'] == 'NEEDS_USER_REVIEW'
    assert any(f['code'] == 'COMPILE_FAILED' for f in saved['findings'])


def half_builder(candidate, draft, path, config, overrides=None):
    path.mkdir(parents=True)
    (path / 'cv.tex').write_bytes(candidate['cv']); (path / 'cv.pdf').write_bytes(b'PDF')
    # Deliberately demoted: publication must refuse cleanly rather than crash on a partial set.
    return {'documents': {'cv': {}}, 'findings': [Finding('DOCUMENT_SET_INCOMPLETE', ADVISORY, 'demoted by config', 'builder', False)]}


def test_partial_candidate_set_is_refused_even_when_demoted(tmp_path, monkeypatch):
    c, j, d = synthetic_config(tmp_path)
    assert run(c, j, 'job_partial', d, lambda rb: review(rb), builder=half_builder, monkeypatch=monkeypatch) == 2
    assert not (c['paths']['final'] / 'job_partial').exists()
    saved = json.loads((c['paths']['temporary'] / 'job_partial/validation_report.json').read_text(encoding='utf-8'))
    assert any(f['code'] == 'PUBLICATION_INTEGRITY' for f in saved['findings'])


def test_pass_publishes_exact_reviewed_set_and_collision(tmp_path, monkeypatch):
    c, j, d = synthetic_config(tmp_path)
    assert run(c, j, 'job_pass', d, lambda rb: review(rb), monkeypatch=monkeypatch) == 0
    final = c['paths']['final'] / 'job_pass'; built = c['paths']['temporary'] / 'job_pass/build/round_0'
    assert {p.name for p in final.iterdir() if p.suffix in ('.tex', '.pdf')} == {'cv.tex', 'cl.tex', 'yigit_coskun_cv.pdf', 'yigit_coskun_cl.pdf'}
    assert all(sha256(p) == sha256(built / {'yigit_coskun_cv.pdf': 'cv.pdf', 'yigit_coskun_cl.pdf': 'cl.pdf'}.get(p.name, p.name)) for p in final.iterdir() if p.suffix in ('.tex', '.pdf'))
    log = json.loads((c['paths']['temporary'] / 'job_pass/run_log.json').read_text(encoding='utf-8'))
    assert log['elapsed_seconds'] >= 0
    assert log['stage_timings'][0]['stage'] == 'load and validate inputs'
    assert log['stage_timings'][-1]['stage'] == 'publish reviewed documents'
    assert all(r['elapsed_seconds'] >= 0 and r['status'] != 'RUNNING' for r in log['stage_timings'])
    with pytest.raises(ValueError, match='collision'):
        run(c, j, 'job_pass', d, lambda rb: review(rb), monkeypatch=monkeypatch)


def test_mutated_reviewed_pdf_cannot_publish(tmp_path):
    build = tmp_path / 'build'; build.mkdir()
    hashes = {}
    for name in ('cv.tex', 'cv.pdf', 'cl.tex', 'cl.pdf'):
        (build / name).write_bytes(b'original'); hashes[name] = sha256(build / name)
    (build / 'cv.pdf').write_bytes(b'mutated')
    with pytest.raises(ValueError, match='changed'):
        publish(build, tmp_path / 'final/job_mutated', hashes)
    assert not (tmp_path / 'final/job_mutated').exists()


def test_mixed_provider_execution_rejected_before_any_work(tmp_path):
    c, j, d = synthetic_config(tmp_path); settings = resolve_settings(c)
    settings['agent_b'].provider = 'claude'
    with pytest.raises(ValueError, match='same provider'):
        execute(c, j, 'job_mixed_rejected', settings, {})
    assert not (c['paths']['temporary'] / 'job_mixed_rejected').exists()
