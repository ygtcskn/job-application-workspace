"""Real PowerShell argument forwarding to a synthetic Python entry point."""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
import pytest
from src.input_loader import ROOT

BLOCKED = 'running scripts is disabled'


def powershell():
    """Skip rather than fail when local policy forbids .ps1; run.ps1 never changes it."""
    shell = shutil.which('pwsh') or shutil.which('powershell')
    if not shell:
        pytest.skip('PowerShell unavailable')
    return shell


def check_policy(result):
    if BLOCKED in (result.stderr or ''):
        pytest.skip('PowerShell execution policy forbids running .ps1 on this machine')


def test_launcher_arguments_spaces_utf8_and_exit(tmp_path):
    shell=powershell()
    shutil.copyfile(ROOT/'run.ps1',tmp_path/'run.ps1')
    (tmp_path/'src').mkdir(); (tmp_path/'src/__init__.py').write_text('')
    (tmp_path/'src/main.py').write_text('import sys,json\nprint(json.dumps(sys.argv[1:]))\nraise SystemExit(7)\n')
    env=os.environ.copy(); env['CV_PIPELINE_PYTHON']=sys.executable
    result=subprocess.run([shell,'-NoProfile','-File',str(tmp_path/'run.ps1'),'-Provider','codex','-Model','test-model','-Effort','high','-Job','old/Job München & spaces.pdf','-JobId','sample','-NonInteractive','-DryRun'],capture_output=True,text=True,encoding='utf-8',env=env)
    check_policy(result)
    assert result.returncode==7,result.stderr
    args=json.loads(result.stdout)
    for flag,value in [('--provider','codex'),('--model','test-model'),('--effort','high'),('--job','old/Job München & spaces.pdf'),('--job-id','sample')]:
        assert args[args.index(flag)+1]==value
    assert '--non-interactive' in args and '--dry-run' in args


def test_real_launcher_batches_every_job_in_dry_run(tmp_path):
    import yaml
    from tests.test_workflow import synthetic_config
    shell=powershell()
    config,job,draft=synthetic_config(tmp_path)
    jobs=tmp_path/'jobs'; jobs.mkdir()
    for name in ('Role 1.md','Role München 2.md'):
        (jobs/name).write_text('Synthetic job description for Python analysis.',encoding='utf-8')
    config['paths']['job_descriptions']=jobs
    wire={k:v for k,v in config.items() if k not in {'root','rules','rubric'}}
    wire['paths']={k:str(v) for k,v in wire['paths'].items()}
    (tmp_path/'config/pipeline.yaml').write_text(yaml.safe_dump(wire),encoding='utf-8')
    (tmp_path/'config/editing_rules.yaml').write_text(yaml.safe_dump(config['rules']),encoding='utf-8')
    (tmp_path/'config/scoring_rubric.yaml').write_text(yaml.safe_dump(config['rubric'],sort_keys=False),encoding='utf-8')
    shutil.copytree(ROOT/'src',tmp_path/'src',ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copyfile(ROOT/'run.ps1',tmp_path/'run.ps1')
    env=os.environ.copy(); env['CV_PIPELINE_PYTHON']=sys.executable
    result=subprocess.run([shell,'-NoProfile','-File',str(tmp_path/'run.ps1'),'-Provider','claude','-Model','opus','-Effort','medium','-DryRun'],capture_output=True,text=True,encoding='utf-8',env=env,timeout=30)
    check_policy(result)
    assert result.returncode==0,result.stdout+result.stderr
    assert 'Processing all 2 job descriptions' in result.stdout
    assert 'Job number' not in result.stdout
    assert 'batch elapsed' in result.stdout and 'Total batch time:' in result.stdout
    reports=list((config['paths']['temporary']/'batches').glob('*.json'))
    report=json.loads(reports[0].read_text(encoding='utf-8'))
    assert report['elapsed_seconds']>=0
    assert all(row['elapsed_seconds']>=0 for row in report['jobs'])
    assert [row['status'] for row in report['jobs']]==['DRY_RUN','DRY_RUN']
    for row in report['jobs']:
        log=json.loads((config['paths']['temporary']/row['job_id']/'run_log.json').read_text(encoding='utf-8'))
        assert {s['provider'] for s in log['settings']['agents'].values()}=={'claude'}
        assert {s['model'] for s in log['settings']['agents'].values()}=={'opus'}
        assert {s['effort'] for s in log['settings']['agents'].values()}=={'medium'}
    assert not config['paths']['final'].exists()
