from src.schemas import Draft, CV, SkillLine, Review, Criterion


def sample(rules):
    skills = [SkillLine(label=k, items=list(v)) for k, v in rules["mandatory"].items()]
    skills.append(SkillLine(label="Languages", items=[rules["languages"]]))
    return Draft(status="READY", cv=CV(summary="Synthetic candidate uses Python & SQL for analysis. Seeking a synthetic analyst role.", skills=skills), cl_tokens={t: ("" if t in rules["optional_empty_tokens"] else "Synthetic text") for t in rules["cl_tokens"]}, evidence=[], change_log=[], source_conflicts=[], qualification_gaps=[], feedback_resolutions=[], input_issues=[])


def review(rubric, cv=80, cl=80, decision="PASS"):
    def scores(total):
        return {k: Criterion(points=v if i else total-60, maximum=v, reason="Synthetic test score") for i, (k, v) in enumerate(rubric.items())}
    return Review(decision=decision, cv_scores=scores(cv), cl_scores=scores(cl), findings=[], parsing_status="Verified", parsing_evidence="Synthetic extractor results", blocking_issues=[], revision_instructions=["Improve supported wording"], qualification_gaps=[])
