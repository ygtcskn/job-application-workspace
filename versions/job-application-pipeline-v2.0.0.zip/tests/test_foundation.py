from pathlib import Path
import pytest
from src.input_loader import extract_text, job_id, select_job, load_config, load_sources
from src.validator import validate_draft
from tests.test_documents import setup
from src.schemas import Draft


def test_real_sources_load_and_hash():
    s = load_sources(load_config())
    s.verify()
    assert len(s.files) == 9


def test_real_template_nested_braces_are_not_tokens():
    from src.template_renderer import render
    from tests.helpers import sample
    c=load_config(); s=load_sources(c)
    out=render(s.files['cv_template.tex'].read_bytes(),s.files['cl_template.tex'].read_bytes(),sample(c['rules']),c['rules'])
    assert b'\\textbf{{\\LARGE Yigit Coskun}}' in out['cv']


def test_user_confirmed_thesis_count_is_consistent():
    """The Projects section was removed on 2026-09-12, so the cover letter is now the only
    template stating the series count. The superseded 3,540 must appear nowhere."""
    c=load_config(); s=load_sources(c)
    assert 'collection of 27,000 data series' in s.texts['cl_template.tex']
    assert '27,000' not in s.texts['cv_template.tex']
    assert all('3,540' not in text for text in s.texts.values())
    assert 'THESIS_SERIES' not in {x['id'] for x in c['rules']['source_issues']}


def test_cv_section_headings_match_configuration():
    """document_builder checks reading order against document.cv_sections; drift there
    would fire SECTION_ORDER on every single run."""
    import re
    c = load_config()
    cv = (c['paths']['input'] / 'cv_template.tex').read_text(encoding='utf-8')
    assert re.findall(r'\\section\{([^}]+)\}', cv) == c['document']['cv_sections']


@pytest.mark.parametrize("value", ["../oops", "a/b", "CON", "", "x.y", "a b"])
def test_unsafe_id(value):
    with pytest.raises(ValueError):
        job_id(value, "unused")


def test_paths_and_utf8(tmp_path):
    p = tmp_path / "Job ü.md"
    p.write_text("# Job\n- Python\n", encoding="utf-8")
    assert select_job(tmp_path, p.name) == p
    assert "Python" in extract_text(p)
    with pytest.raises(ValueError):
        select_job(tmp_path, "../outside.md")
    p.write_text("", encoding="utf-8")
    with pytest.raises(ValueError, match="empty"):
        extract_text(p)


def test_scanned_pdf(tmp_path):
    import fitz
    p = tmp_path / "scan.pdf"
    doc = fitz.open()
    doc.new_page()
    doc.save(p)
    doc.close()
    with pytest.raises(ValueError, match="OCR"):
        extract_text(p)


def test_malformed_schema():
    with pytest.raises(ValueError):
        Draft.model_validate_json('{"status":"PASS","arbitrary":"edit"}')


def test_docx_preserves_paragraph_table_order(tmp_path):
    from docx import Document
    doc=Document(); doc.add_heading('Synthetic role',1)
    table=doc.add_table(rows=1,cols=2); table.cell(0,0).text='Requirement'; table.cell(0,1).text='Python'
    doc.add_paragraph('After the table')
    path=tmp_path/'job.docx'; doc.save(path)
    text=extract_text(path)
    assert text.index('Synthetic role') < text.index('Requirement | Python') < text.index('After the table')


# --- Supplied sources after the 2026-09-10 legacy cleanup --------------------

LEGACY_TERMS = ('CV_RULES', 'bullet_library', 'bullet library')


def test_no_legacy_reference_survives_in_anything_an_agent_reads():
    """The two provenance documents were never supplied and no longer governed anything."""
    c = load_config()
    sources = load_sources(c)
    for name, text in sources.texts.items():
        assert not any(term in text for term in LEGACY_TERMS), name


def test_sources_no_longer_contradict_the_editable_scope():
    """SOURCE_LEGACY_SCOPE was a permanent advisory; it is now fixed at source."""
    c = load_config()
    cv = (c['paths']['input'] / 'cv_template.tex').read_text(encoding='utf-8')
    profile = (c['paths']['input'] / 'skills_profile.md').read_text(encoding='utf-8')
    # The summary is an editable region, and no comment demands a literal token any more.
    assert 'THE ONLY EDITABLE REGION' not in cv
    assert 'EDITABLE REGION 1 of 2' in cv and 'EDITABLE REGION 2 of 2' in cv
    assert '{{JOB-TITLE}}' not in cv
    assert 'governs only the ninth AI_EDIT body' not in profile
    assert 'Only SKILLS differs' not in profile


def test_every_known_source_issue_is_resolved_rather_than_carried():
    c = load_config()
    assert c['rules']['source_issues'] == []
    resolved = {r['id'] for r in c['rules']['source_resolutions']}
    assert {'LEGACY_SCOPE', 'PROFILE_ORDER', 'MISSING_REFERENCES'} <= resolved


def test_cover_letter_template_carries_no_inert_edit_markers():
    """render() substitutes tokens across the whole CL; boundaries() is CV-only."""
    c = load_config()
    cl = (c['paths']['input'] / 'cl_template.tex').read_text(encoding='utf-8')
    assert 'AI_EDIT' not in cl
    assert 'EDIT ZONES' not in cl
    # Token guidance moved to configuration, which agents actually receive.
    assert set(c['rules']['cl_token_guidance']) == set(c['rules']['cl_tokens'])


def test_office_skills_are_approved_and_mutually_exclusive():
    c = load_config()
    tools = c['rules']['optional']['Tools & Platforms']
    assert 'Excel' in tools and 'Microsoft Office (Word, Excel, PowerPoint)' in tools
    rules, _, draft = setup()
    programming = next(l for l in draft.cv.skills if l.label == 'Tools & Platforms')
    programming.items = programming.items + ['Excel']
    assert 'SKILLS_REDUNDANT' not in {f.code for f in validate_draft(draft, rules, {})}
    programming.items = programming.items + ['Microsoft Office (Word, Excel, PowerPoint)']
    assert 'SKILLS_REDUNDANT' in {f.code for f in validate_draft(draft, rules, {})}


def test_agents_receive_the_page_budget_they_cannot_read_from_pipeline_yaml():
    c = load_config()
    assert (c['rules']['limits']['cv_pages'], c['rules']['limits']['cl_pages']) == (
        c['document']['page_limits']['cv'], c['document']['page_limits']['cl'])


@pytest.mark.parametrize('mutation,message', [
    ({'limits': {'cv_pages': 9}}, 'must match document.page_limits'),
    ({'cl_token_guidance': {'{{JOB-TITLE}}': 'x'}}, 'exactly the configured cl_tokens'),
    ({'mutually_exclusive': [['Excel', 'Invented Tool']]}, 'mutually_exclusive'),
])
def test_configuration_drift_is_rejected(tmp_path, mutation, message):
    import shutil
    import yaml
    shutil.copytree(Path('config'), tmp_path / 'config')
    shutil.copytree(Path('input'), tmp_path / 'input')
    shutil.copytree(Path('agents'), tmp_path / 'agents')
    rules = yaml.safe_load((tmp_path / 'config/editing_rules.yaml').read_text(encoding='utf-8'))
    for key, value in mutation.items():
        rules[key] = {**rules[key], **value} if isinstance(value, dict) and key == 'limits' else value
    (tmp_path / 'config/editing_rules.yaml').write_text(yaml.safe_dump(rules), encoding='utf-8')
    with pytest.raises(ValueError, match=message):
        load_config(tmp_path)


def test_advanced_excel_and_power_bi_are_evidenced():
    """A posting asking for advanced Excel or Power BI must not read as a qualification gap."""
    c = load_config()
    profile = load_sources(c).texts['skills_profile.md']
    assert 'the applicant has an advanced level in Excel and Power BI' in profile
    assert 'EXCEL_POWER_BI_PROFICIENCY' in {r['id'] for r in c['rules']['source_resolutions']}


def test_unique_job_id_walks_past_existing_output(tmp_path):
    from src.input_loader import unique_job_id
    paths = {'temporary': tmp_path / 'temp', 'final': tmp_path / 'final'}
    for key in paths:
        paths[key].mkdir()
    assert unique_job_id(paths, 'job_x') == 'job_x'
    (paths['temporary'] / 'job_x').mkdir()
    assert unique_job_id(paths, 'job_x') == 'job_x_r2'
    (paths['final'] / 'job_x_r2').mkdir()            # either directory counts
    assert unique_job_id(paths, 'job_x') == 'job_x_r3'
    assert unique_job_id(paths, 'job_y', taken=['JOB_Y']) == 'job_y_r2'   # case-insensitive
    assert len(unique_job_id(paths, 'j' * 64, taken=['j' * 64])) <= 64
