import copy
import json
import sys
import pytest
from src.input_loader import load_config, write_json
from src.providers.base import resolve_settings, Settings
from src.providers.codex_cli import command as codex_command
from src.providers.claude_cli import command as claude_command, invoke as claude_invoke
from src.providers.gemini_cli import command as gemini_command, extract_json, invoke as gemini_invoke
from src.process import run_process, ProcessFailure


@pytest.mark.parametrize('layout', ['nested', 'hoisted', 'legacy'])
def test_npm_codex_native_layouts(tmp_path, monkeypatch, layout):
    from src.providers import base
    monkeypatch.setattr(base.platform, 'machine', lambda: 'AMD64')
    roots = {
        'nested': 'node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor',
        'hoisted': 'node_modules/@openai/codex-win32-x64/vendor',
        'legacy': 'node_modules/@openai/codex/vendor',
    }
    folder = 'codex' if layout == 'legacy' else 'bin'
    binary = tmp_path / roots[layout] / 'x86_64-pc-windows-msvc' / folder / 'codex.exe'
    binary.parent.mkdir(parents=True)
    binary.touch()
    assert base.npm_codex_executable(tmp_path) == binary.resolve()


def test_override_precedence_and_provider_defaults():
    config = copy.deepcopy(load_config())
    config['providers']['codex'].update(model='synthetic-codex', effort='low')
    config['providers']['claude'].update(model='synthetic-claude', effort='high')
    config['providers']['gemini'].update(model='synthetic-gemini')
    assert all(s.model == 'synthetic-codex' for s in resolve_settings(config).values())
    resolved = resolve_settings(config, 'codex')
    assert all(s.model == 'synthetic-codex' and s.effort == 'low' for s in resolved.values())
    assert all(s.model == 'explicit' for s in resolve_settings(config, 'codex', 'explicit').values())
    config['execution']['provider'] = 'claude'
    assert all(s.model == 'synthetic-claude' and s.effort == 'high' for s in resolve_settings(config).values())
    config['execution']['provider'] = 'gemini'
    assert all(s.model == 'synthetic-gemini' and s.effort is None for s in resolve_settings(config).values())


def test_unsupported_provider_is_named_clearly():
    config = copy.deepcopy(load_config())
    with pytest.raises(ValueError, match='codex, claude, gemini'):
        resolve_settings(config, 'mistral')


@pytest.mark.parametrize('provider', ['codex', 'claude', 'gemini'])
def test_one_provider_for_every_role_without_config_mutation(provider):
    config=load_config(); original=copy.deepcopy(config)
    resolved=resolve_settings(config,provider)
    assert set(resolved)=={'agent_a','agent_b','agent_c'}
    assert {s.provider for s in resolved.values()}=={provider}
    assert config==original


def test_defaults_omit_flags_and_commands_are_lists(tmp_path):
    s = Settings('codex', 'codex.exe', None, None, 10)
    args = codex_command(s, tmp_path/'schema.json', tmp_path/'response.json', tmp_path)
    assert '--model' not in args and not any('model_reasoning_effort' in x for x in args)
    assert args[-1] == '-' and 'read-only' in args
    assert not any('bypass' in x for x in args)
    schema = tmp_path/'schema.json'; write_json(schema, {'type':'object'})
    s = Settings('claude','claude.exe','explicit','high',10)
    args = claude_command(s,schema)
    assert args[args.index('--tools')+1] == ''
    assert args[args.index('--model')+1] == 'explicit'
    assert '--effort' in args


def test_mocked_claude_envelope(monkeypatch, tmp_path):
    from src.providers import claude_cli
    monkeypatch.setattr(claude_cli, 'run_process', lambda *a: (json.dumps({'subtype':'success','structured_output':{'value':1}}),''))
    schema=tmp_path/'schema.json'; write_json(schema, {})
    assert json.loads(claude_invoke(Settings('claude','fake',None,None,10),'prompt',schema,tmp_path,tmp_path)) == {'value':1}
    monkeypatch.setattr(claude_cli, 'run_process', lambda *a: ('{"is_error":true,"result":"unsupported model"}',''))
    with pytest.raises(RuntimeError,match='unsupported model'):
        claude_invoke(Settings('claude','fake',None,None,10),'prompt',schema,tmp_path,tmp_path)


def test_real_local_process_utf8_timeout_and_failure(tmp_path):
    out,_=run_process([sys.executable,'-c','import sys; print(sys.stdin.read())'],tmp_path,5,'München & spaces')
    assert 'München & spaces' in out
    with pytest.raises(ProcessFailure,match='timed out'):
        run_process([sys.executable,'-c','import time; time.sleep(20)'],tmp_path,0.1)
    with pytest.raises(ProcessFailure,match='exited 7'):
        run_process([sys.executable,'-c','raise SystemExit(7)'],tmp_path,5)


def test_mocked_unsupported_effort_fails_preflight(monkeypatch,tmp_path):
    from src.providers import base
    monkeypatch.setattr(base,'find_executable',lambda *a:'fake')
    monkeypatch.setattr(base,'run_process',lambda *a: ('--json-schema --tools --safe-mode --no-session-persistence --permission-mode --effort Effort level for session (low, medium, high)',''))
    with pytest.raises(ValueError,match='not advertised'):
        base.probe(Settings('claude','fake','opus','invented',10),tmp_path)


def test_native_default_explicitly_resets_configured_model():
    c=load_config(); c['providers']['codex']['model']='configured-model'
    resolved=resolve_settings(c,'codex','default','default')
    assert all(s.model is None and s.effort is None for s in resolved.values())


# Verbatim excerpt of `gemini --help` from the installed @google/gemini-cli 0.59.0.
GEMINI_HELP = """Usage: gemini [options] [command]

Gemini CLI - Defaults to interactive mode. Use -p/--prompt for non-interactive (headless) mode.

Options:
  -d, --debug                     Run in debug mode (open debug console with F12)  [boolean] [default: false]
  -m, --model                     Model  [string]
  -p, --prompt                    Run in non-interactive (headless) mode with the given prompt. Appended to input on stdin (if any).  [string]
      --skip-trust                Trust the current workspace for this session.  [boolean] [default: false]
  -s, --sandbox                   Run in sandbox?  [boolean]
  -y, --yolo                      Automatically accept all actions  [boolean] [default: false]
      --approval-mode             Set the approval mode: default (prompt for approval), auto_edit (auto-approve edit tools), yolo (auto-approve all tools), plan (read-only mode)  [string] [choices: "default", "auto_edit", "yolo", "plan"]
  -o, --output-format             The format of the CLI output.  [string] [choices: "text", "json", "stream-json"]
      --raw-output                Disable sanitization of model output  [boolean]
  -v, --version                   Show version number  [boolean]
"""


def test_gemini_command_is_restricted_and_omits_defaults(tmp_path):
    s = Settings('gemini', 'gemini.exe', None, None, 10)
    args = gemini_command(s)
    assert args[0] == 'gemini.exe'
    assert args[args.index('--output-format') + 1] == 'json'
    assert args[args.index('--approval-mode') + 1] == 'default'
    # 0.59.0 defaults to interactive mode; -p is what selects headless.
    assert '--prompt' in args
    # The CLI refuses to run headless in an untrusted folder; the agent's cwd is an empty
    # per-invocation temp directory, so this trusts nothing that holds sources or config.
    assert '--skip-trust' in args
    # Nothing that would let the model act on the machine or read the workspace.
    assert not any(flag in args for flag in ('--yolo', '-y', '--all-files', '-a', '--sandbox', '--raw-output'))
    assert '--model' not in args
    assert gemini_command(Settings('gemini', 'gemini.exe', 'gemini-2.5-flash', None, 10))[-1] == 'gemini-2.5-flash'


def test_gemini_command_flags_all_exist_in_installed_help():
    """Guards against the 0.59.0 mismatch that stopped a live batch: no invented flags."""
    from src.providers.base import REQUIRED_FLAGS
    used = [a for a in gemini_command(Settings('gemini', 'gemini.exe', 'm', None, 10)) if a.startswith('--')]
    for flag in used + list(REQUIRED_FLAGS['gemini']):
        assert flag in GEMINI_HELP, flag


def test_gemini_node_script_is_launched_through_the_interpreter(monkeypatch, tmp_path):
    from src.providers import base
    script = tmp_path / 'index.js'
    script.write_text('// entry')
    monkeypatch.setattr(base, 'node_executable', lambda: 'C:/node/node.exe')
    args = gemini_command(Settings('gemini', str(script), None, None, 10))
    assert args[:2] == ['C:/node/node.exe', str(script)]


def test_gemini_package_entry_resolves_bin_instead_of_cmd_shim(tmp_path):
    from src.providers.base import package_entry
    package = tmp_path / 'node_modules/@google/gemini-cli'
    (package / 'dist').mkdir(parents=True)
    (package / 'dist/index.js').write_text('// entry')
    (package / 'package.json').write_text(json.dumps({'bin': {'gemini': 'dist/index.js'}}))
    assert package_entry(tmp_path, '@google/gemini-cli') == (package / 'dist/index.js').resolve()
    assert package_entry(tmp_path, '@google/absent') is None


@pytest.mark.parametrize('text,expected', [
    ('{"status":"READY"}', '{"status":"READY"}'),
    ('```json\n{"status":"READY"}\n```', '{"status":"READY"}'),
    ('Here you go:\n{"status":"READY"}\nHope that helps.', '{"status":"READY"}'),
    ('no object here', 'no object here'),
])
def test_gemini_json_extraction_survives_prose_and_fences(text, expected):
    assert extract_json(text) == expected


def test_mocked_gemini_envelope(monkeypatch, tmp_path):
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    envelope = {'response': '```json\n{"value": 1}\n```', 'stats': {'tools': {'totalCalls': 0}, 'models': {'gemini-2.5-pro': {}}}}
    monkeypatch.setattr(gemini_cli, 'run_process', lambda *a: (json.dumps(envelope), ''))
    settings = Settings('gemini', 'fake', None, None, 10)
    assert json.loads(gemini_invoke(settings, 'prompt', schema, tmp_path, tmp_path)) == {'value': 1}
    assert settings.resolved_model == 'gemini-2.5-pro'


def test_gemini_rejects_errors_and_unexpected_tool_use(monkeypatch, tmp_path):
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    monkeypatch.setattr(gemini_cli, 'run_process', lambda *a: (json.dumps({'error': {'message': 'quota exhausted'}}), ''))
    with pytest.raises(RuntimeError, match='quota exhausted'):
        gemini_invoke(Settings('gemini', 'fake', None, None, 10), 'prompt', schema, tmp_path, tmp_path)
    used = {'response': '{}', 'stats': {'tools': {'totalCalls': 2}}}
    monkeypatch.setattr(gemini_cli, 'run_process', lambda *a: (json.dumps(used), ''))
    with pytest.raises(ValueError, match='Unexpected Gemini tool use'):
        gemini_invoke(Settings('gemini', 'fake', None, None, 10), 'prompt', schema, tmp_path, tmp_path)


def test_gemini_non_json_envelope_falls_through_to_format_repair(monkeypatch, tmp_path):
    """A stray banner must not be reported as a provider failure; validation rejects it."""
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    monkeypatch.setattr(gemini_cli, 'run_process', lambda *a: ('Loaded cached credentials.\n{"value": 2}', ''))
    assert json.loads(gemini_invoke(Settings('gemini', 'fake', None, None, 10), 'prompt', schema, tmp_path, tmp_path)) == {'value': 2}


def test_gemini_preflight_requires_flags_and_refuses_effort(monkeypatch, tmp_path):
    from src.providers import base
    monkeypatch.setattr(base, 'find_executable', lambda *a: 'fake')
    monkeypatch.setattr(base, 'run_process', lambda *a: (GEMINI_HELP, ''))
    monkeypatch.setattr(base, 'gemini_auth', lambda: 'signed in')
    info = base.probe(Settings('gemini', 'fake', None, None, 10), tmp_path)
    # 0.59.0 discloses no model default, so hints are honestly empty rather than invented.
    assert info['models'] == [] and info['efforts'] == []
    assert info['schema_enforcement'] == 'prompt only; validated locally with format repair'
    with pytest.raises(ValueError, match='no reasoning effort'):
        base.probe(Settings('gemini', 'fake', None, 'high', 10), tmp_path)
    monkeypatch.setattr(base, 'run_process', lambda *a: ('-m, --model  Model\n', ''))
    with pytest.raises(ValueError, match='lacks required safe/structured flags'):
        base.probe(Settings('gemini', 'fake', None, None, 10), tmp_path)


def test_gemini_model_hint_is_read_when_help_discloses_a_default(monkeypatch, tmp_path):
    from src.providers import base
    monkeypatch.setattr(base, 'find_executable', lambda *a: 'fake')
    monkeypatch.setattr(base, 'gemini_auth', lambda *a: 'signed in')
    disclosed = GEMINI_HELP.replace('-m, --model                     Model  [string]',
                                    '-m, --model                     Model  [string] [default: "gemini-3.1-pro"]')
    monkeypatch.setattr(base, 'run_process', lambda *a: (disclosed, ''))
    assert base.probe(Settings('gemini', 'fake', None, None, 10), tmp_path)['models'] == ['gemini-3.1-pro']


def test_gemini_auth_checks_presence_without_reading_credentials(monkeypatch, tmp_path):
    from src.providers import base
    for name in base.GEMINI_AUTH_VARIABLES:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv('GEMINI_HOME', str(tmp_path))
    # Matches the state that stopped the live batch: installed, never authenticated.
    assert base.gemini_auth() == 'not signed in'
    monkeypatch.setenv('GEMINI_API_KEY', 'unread-value')
    assert base.gemini_auth() == 'signed in'
    monkeypatch.delenv('GEMINI_API_KEY')
    monkeypatch.setenv('GOOGLE_GENAI_USE_GCA', 'true')
    assert base.gemini_auth() == 'signed in'
    monkeypatch.delenv('GOOGLE_GENAI_USE_GCA')
    (tmp_path / 'settings.json').write_text('{"security": {"auth": {"selectedType": "oauth-personal"}}}')
    assert base.gemini_auth() == 'signed in'
    (tmp_path / 'settings.json').write_text('{"theme": "Default"}')
    assert base.gemini_auth() == 'not signed in'
    (tmp_path / 'oauth_creds.json').write_text('{}')
    assert base.gemini_auth() == 'signed in'


def test_unauthenticated_gemini_stops_the_batch_with_a_clear_reason(monkeypatch, tmp_path):
    """The real failure mode: preflight must name authentication, not a flag problem."""
    from src.providers import base
    monkeypatch.setattr(base, 'find_executable', lambda *a: 'fake')
    monkeypatch.setattr(base, 'run_process', lambda *a: (GEMINI_HELP, ''))
    monkeypatch.setattr(base, 'gemini_auth', lambda *a: 'not signed in')
    assert base.probe(Settings('gemini', 'fake', None, None, 10), tmp_path)['auth'] == 'not signed in'

# Verbatim stderr from installed 0.59.0 when a model identifier is rejected: a stack trace,
# then the JSON envelope, then a libuv assertion. stdout is empty and the exit code is non-zero.
GEMINI_MODEL_ERROR_STDERR = """Warning: True color (24-bit) support not detected.
Ripgrep is not available. Falling back to GrepTool.
Error when talking to Gemini API ModelNotFoundError: models/gemini-3.1-pro is not found
    at classifyGoogleError (file:///C:/x/chunk.js:306626:12) {
  code: 404
}
{
  "session_id": "c54801ea-4724-4846-9d83-07497f52bab8",
  "error": {
    "type": "Error",
    "message": "models/gemini-3.1-pro is not found for API version v1beta, or is not supported for generateContent.",
    "code": 1
  }
}
Assertion failed: !(handle->flags & UV_HANDLE_CLOSING), file src\\win\\async.c, line 76
"""


def test_gemini_reports_a_clean_reason_when_the_run_exits_non_zero(monkeypatch, tmp_path):
    """Real 0.59.0 failures put the envelope on stderr and exit non-zero, not on stdout."""
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    def fail(*a, **k):
        raise ProcessFailure('Process exited 1: ...', '', GEMINI_MODEL_ERROR_STDERR)
    monkeypatch.setattr(gemini_cli, 'run_process', fail)
    with pytest.raises(RuntimeError, match='models/gemini-3.1-pro is not found'):
        gemini_invoke(Settings('gemini', 'fake', 'gemini-3.1-pro', None, 10), 'prompt', schema, tmp_path, tmp_path)
    # Provider logs are still written for the audit trail.
    assert 'ModelNotFoundError' in (tmp_path / 'stderr.txt').read_text(encoding='utf-8')


def test_gemini_untrusted_directory_failure_is_reraised_unchanged(monkeypatch, tmp_path):
    """No JSON envelope means no invented explanation; the original failure survives."""
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    def fail(*a, **k):
        raise ProcessFailure('Process exited 55: Gemini CLI is not running in a trusted directory.', '', 'no envelope here')
    monkeypatch.setattr(gemini_cli, 'run_process', fail)
    with pytest.raises(ProcessFailure, match='trusted directory'):
        gemini_invoke(Settings('gemini', 'fake', None, None, 10), 'prompt', schema, tmp_path, tmp_path)


def test_gemini_records_the_model_that_answered(monkeypatch, tmp_path):
    """0.59.0 routes roles to different models; the 'main' role produced the reply."""
    from src.providers import gemini_cli
    schema = tmp_path / 'schema.json'
    write_json(schema, {})
    envelope = {'response': '{"value": 3}', 'stats': {'tools': {'totalCalls': 0}, 'models': {
        'gemini-3.1-flash-lite': {'roles': {'utility_router': {}}},
        'gemini-3.5-flash': {'roles': {'main': {}}}}}}
    monkeypatch.setattr(gemini_cli, 'run_process', lambda *a: (json.dumps(envelope), ''))
    settings = Settings('gemini', 'fake', None, None, 10)
    assert json.loads(gemini_invoke(settings, 'prompt', schema, tmp_path, tmp_path)) == {'value': 3}
    assert settings.resolved_model == 'gemini-3.5-flash'
    assert settings.metadata()['effective_model'] == 'gemini-3.5-flash'
