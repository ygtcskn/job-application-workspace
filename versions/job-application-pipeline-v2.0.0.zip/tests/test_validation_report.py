"""Severity classification, overflow attribution and the red PowerShell report."""
import io
import json
import pytest
from src.document_builder import editable_lines, overflow_findings
from src.findings import ADVISORY, CRITICAL, MAJOR, Finding, counts, dedupe, messages, ordered
from src.input_loader import load_config
from src.report import STYLES, console_report, markdown_report, report_payload
from src.schemas import Evidence
from src.validator import validate_draft
from tests.test_documents import CV, setup

# Two real MiKTeX log lines: the first sits in the protected thesis heading of the live CV.
TEXLOG = ("Overfull \\hbox (3.09859pt too wide) in alignment at lines 262--262\n"
          "Overfull \\hbox (11.5pt too wide) in paragraph at lines 3--3\n"
          "Overfull \\hbox (1.2pt too wide) in paragraph at lines 3--3\n")


def test_editable_lines_cover_only_the_two_editable_regions():
    lines = editable_lines(CV)
    # CV fixture: line 1 preamble, 2 START SUMMARY, 3 body, 4 END, 5 protected...
    assert 3 in lines and 7 in lines
    assert 1 not in lines and 5 not in lines


def test_overflow_is_attributed_to_editable_text_or_protected_layout():
    found, sizes = overflow_findings('cv', TEXLOG, editable_lines(CV), 2.0, None)
    assert sizes == [3.09859, 11.5, 1.2]
    # Under tolerance is not reported at all.
    assert len(found) == 2
    protected = next(f for f in found if f.code == 'OVERFLOW_PROTECTED')
    editable = next(f for f in found if f.code == 'OVERFLOW_EDITABLE')
    assert protected.severity == ADVISORY and not protected.fixable and '3.10pt' in protected.message
    assert editable.severity == MAJOR and editable.fixable


def test_overflow_without_line_numbers_is_treated_as_template_layout():
    found, _ = overflow_findings('cl', 'Overfull \\vbox (9.0pt too high) has occurred while \\output is active\n', {1, 2}, 2.0, None)
    assert [f.code for f in found] == ['OVERFLOW_PROTECTED']


def evidence(**kwargs):
    base = dict(claim_id='S6', field='cv.summary', claim='Seeking a Quality Data Analyst position',
                claim_type='role_target', source='job/posting.pdf',
                excerpt='Quality Data Analyst', location='job posting title')
    return Evidence(**{**base, **kwargs})


def draft_with(evidence_items):
    rules, _, draft = setup()
    draft.cv.summary = 'Seeking a Quality Data Analyst position to apply my analytical skills.'
    draft.evidence = [evidence_items] if isinstance(evidence_items, Evidence) else evidence_items
    return rules, draft


def texts(rules, draft):
    return {'skills_profile.md': draft.cv.summary + '\n' + '\n'.join(', '.join(s.items) for s in draft.cv.skills),
            'job/posting.pdf': 'Quality Data Analyst wanted for process data.'}


def codes_for(rules, draft):
    return {f.code for f in validate_draft(draft, rules, texts(rules, draft))}


@pytest.mark.parametrize('quote,valid', [
    ('Quality Data Analyst', True),
    ('Quality\tData\nAnalyst', True),
    ('Quality Senior Data Analyst', False),
    ('QualityData Analyst', False),
    ('Quality Data Analyst!', False),
    ('   ', False),
])
def test_evidence_ignores_only_whitespace(quote, valid):
    rules, draft = draft_with(evidence(excerpt=quote))
    source = {'job/posting.pdf': 'Wanted: Quality\r\n Data\tAnalyst position'}
    codes = {f.code for f in validate_draft(draft, rules, source)}
    assert ('EVIDENCE_SOURCE' not in codes) is valid


def test_role_target_evidence_from_the_vacancy_is_accepted():
    """Targeting the advertised role is not a claim about the applicant's qualifications."""
    rules, draft = draft_with(evidence())
    assert 'EVIDENCE_VACANCY_FACT' not in codes_for(rules, draft)
    assert 'EVIDENCE_ROLE_TARGET_SCOPE' not in codes_for(rules, draft)


def test_applicant_facts_still_cannot_come_from_the_vacancy():
    rules, draft = draft_with(evidence(claim_type='applicant_fact'))
    assert 'EVIDENCE_VACANCY_FACT' in codes_for(rules, draft)


def test_role_target_cannot_smuggle_a_qualification_claim():
    rules, draft = draft_with(evidence(claim='apply my analytical skills'))
    assert 'EVIDENCE_ROLE_TARGET_SCOPE' in codes_for(rules, draft)


def test_role_target_is_confined_to_the_configured_fields():
    rules, draft = draft_with(evidence(field='cv.skills.Programming', claim='Python'))
    assert 'EVIDENCE_ROLE_TARGET_SCOPE' in codes_for(rules, draft)


def test_universal_ordering_is_enforced_after_precedence_resolution():
    rules, _, draft = setup()
    programming = draft.cv.skills[0]
    assert 'SKILLS_ORDER' not in {f.code for f in validate_draft(draft, rules, {})}
    programming.items = ['Matplotlib'] + programming.items
    assert 'SKILLS_ORDER' in {f.code for f in validate_draft(draft, rules, {})}


def test_skills_line_is_exempt_from_mandatory_first_ordering():
    """Section 4 puts posting-named practices first on that line."""
    rules = load_config()['rules']
    assert 'Skills' not in rules['ordering']['mandatory_first']
    assert set(rules['ordering']['mandatory_first']) == {'Programming', 'Methods', 'Tools & Platforms'}


def test_findings_are_deduplicated_and_ranked():
    duplicated = [Finding('A', ADVISORY, 'note', 'source', False),
                  Finding('A', ADVISORY, 'note', 'source', False),
                  Finding('B', CRITICAL, 'broken', 'builder', False),
                  Finding('C', MAJOR, 'attention', 'agent_c')]
    assert [f.code for f in ordered(duplicated)] == ['B', 'C', 'A']
    assert len(dedupe(duplicated)) == 3
    assert counts(ordered(duplicated)) == {'critical': 1, 'major': 1, 'advisory': 1}
    assert messages(ordered(duplicated))[0] == '[CRITICAL] B: broken'


def test_unknown_severity_is_rejected():
    with pytest.raises(ValueError, match='Unknown severity'):
        Finding('X', 'catastrophic', 'msg', 'test')


def sample_findings():
    return [Finding('COMPILE_FAILED', CRITICAL, 'cl: compilation failed', 'builder', False),
            Finding('SCORE_BELOW_THRESHOLD', MAJOR, 'cv: 74/100 below 75', 'review'),
            Finding('SOURCE_PROFILE_ORDER', ADVISORY, 'ordering ambiguity', 'source', False)]


def test_console_report_paints_crucial_problems_red():
    stream = io.StringIO()
    console_report(sample_findings(), 'NEEDS_USER_REVIEW', 'out/temp/job_1', colour=True, stream=stream)
    text = stream.getvalue()
    assert 'CRUCIAL VALIDATION PROBLEMS (2)' in text
    assert STYLES[CRITICAL] + '  CRITICAL' in text
    for line in text.splitlines():
        if 'COMPILE_FAILED' in line or 'SCORE_BELOW_THRESHOLD' in line:
            assert line.startswith(STYLES[CRITICAL]) or line.startswith(STYLES[MAJOR])
        if 'SOURCE_PROFILE_ORDER' in line:
            assert line.startswith(STYLES[ADVISORY])
    assert 'not fixable within the permitted edit scope' in text


def test_console_report_stays_plain_when_colour_is_off():
    stream = io.StringIO()
    console_report(sample_findings(), 'PUBLISHED_WITH_FINDINGS', 'out/final/job_1', colour=False, stream=stream)
    assert '\033[' not in stream.getvalue()


def test_console_report_says_so_when_nothing_was_found():
    stream = io.StringIO()
    console_report([], 'PASS', 'out/final/job_1', colour=False, stream=stream)
    assert 'No validation findings.' in stream.getvalue()
    assert 'CRUCIAL' not in stream.getvalue()


def test_colour_env_overrides(monkeypatch):
    from src.report import enable_ansi

    class Console:
        def isatty(self):
            return True

    monkeypatch.delenv('NO_COLOR', raising=False)
    monkeypatch.setenv('FORCE_COLOR', '1')
    assert enable_ansi(io.StringIO()) is True
    monkeypatch.setenv('NO_COLOR', '1')
    assert enable_ansi(Console()) is False


def test_report_is_written_beside_published_documents(tmp_path):
    """A published set carries its own report, so findings never live only in the console."""
    from src.workflow import publish
    from src.input_loader import sha256
    build = tmp_path / 'build'
    build.mkdir()
    hashes = {}
    for name in ('cv.tex', 'cv.pdf', 'cl.tex', 'cl.pdf'):
        (build / name).write_bytes(b'document')
        hashes[name] = sha256(build / name)
    final = tmp_path / 'final/job_x'
    publish(build, final, hashes, {'validation_report.md': '# Validation report'})
    assert (final / 'validation_report.md').read_text(encoding='utf-8') == '# Validation report'
    names = {'cv.pdf': 'yigit_coskun_cv.pdf', 'cl.pdf': 'yigit_coskun_cl.pdf'}
    assert all(sha256(final / names.get(n, n)) == hashes[n] for n in hashes)


def test_saved_report_carries_counts_context_and_every_finding():
    context = {'job_id': 'job_1', 'status': 'PUBLISHED_WITH_FINDINGS', 'scores': {'cv': 78, 'cl': 79},
               'round': 1, 'max_rounds': 3, 'destination': 'out/final/job_1'}
    payload = report_payload(sample_findings(), context)
    assert payload['counts'] == {'critical': 1, 'major': 1, 'advisory': 1}
    assert [f['code'] for f in payload['findings']][0] == 'COMPILE_FAILED'
    assert json.dumps(payload)  # serializable for run artefacts
    text = markdown_report(sample_findings(), context)
    assert 'CV 78/100, CL 79/100' in text and 'not an employer ATS score' in text
    assert all(f.code in text for f in sample_findings())
