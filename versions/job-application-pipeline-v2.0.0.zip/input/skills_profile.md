# Skills profile

## Current pipeline scope

This is the maintained working copy of the Skills Evidence Profile, revised from the uploaded Version 3.1. The pipeline may change the CV summary, the CV skills section, and the explicitly authorized cover letter tokens; everything else in both templates is fixed. The uploaded original is preserved outside the pipeline and its hash is recorded in `docs/source_mapping.json`.

The inventory, evidence tiers, mandatory inclusions, conditional inclusions, five-line Skills structure, and fixed Languages line remain applicable. No skills, proficiency levels, or evidence were added during conversion.

## Revisions from Version 3.1

- **Editing scope.** The pipeline edits the CV summary, the CV Skills region, and the authorized cover letter tokens. The former skills-only wording in sections 1 and 5 is corrected in place, so nothing here contradicts the current scope.
- **Skills ordering.** Section 4's universal Data Scientist ordering applies to every vacancy, and mandatory TensorFlow/Keras keeps its section 3 position after scikit-learn. Section 3's vacancy-first wording governs only which optional items are selected, never the order of the mandatory core.
- **Excel and Microsoft Office** moved from Tier 3 to Tier 2: state them confidently whenever the posting makes them relevant.
- **Advanced Excel and Power BI.** The applicant confirmed on 2026-09-14 an advanced level in both tools; see the proficiency note in section 2.
- **Legacy references removed.** Two provenance documents named by Version 3.1 were never supplied and never governed this pipeline; every mention of them is gone. The removal is recorded in `docs/source_mapping.json`.

## Profile content

### Skills Evidence Profile

AI agent reference for the fixed CV  |  British English

#### 1. Authority and editing scope

- This file governs the active skills inventory, evidence tiers, and inclusion rules. Job titles, dates, section order, markers, and all education, experience, project, thesis, and publication bullets remain unchanged.

- The vacancy controls relevance, not evidence. Select and order only approved active skills; mirror a vacancy term only when it names the identical evidenced concept. Flag a weak fit rather than stretching a claim.

- Where this file and `config/editing_rules.yaml` disagree, editing_rules.yaml wins: it carries the machine-checked inventory, limits, and ordering.

- Use British English and official product/package casing. Never add metrics, employers, responsibilities, internal paths, individual-level data, or unsupported technologies to Skills.

#### 2. Standardised inventory and evidence tiers

Tier 1 - mandatory; always include in the CV. Python; pandas; NumPy; scikit-learn; TensorFlow/Keras; R; SQL (PostgreSQL); machine learning (XGBoost, LightGBM); deep learning (LSTM); LaTeX; AI/LLM Tools (Codex, Claude Code); Git; Power BI; automation; reporting; stakeholder communication; cross-functional collaboration. Select additional Python packages according to the vacancy. Add R packages only when the job posting explicitly mentions R; a Python mention does not trigger R packages.

Tier 2 - state confidently. AWS; CUDA; Docker; Excel; Microsoft Office (Word, Excel, PowerPoint); ARIMA and VAR; A/B testing; data visualisation; Matplotlib; ggplot2; feature engineering; model evaluation/validation; hypothesis testing; data cleaning/wrangling; presenting findings. Include when relevant and state without a familiarity qualifier; apply the R-package rule to ggplot2.

Proficiency: the applicant has an advanced level in Excel and Power BI. When a posting asks for advanced or strong Excel or Power BI skills, state that level in the summary or cover letter and cite this sentence as evidence. The Skills line keeps the plain inventory names Excel and Power BI.

Tier 3 - add only after a matching job description and job title. PyTorch; statistics; mathematics; SHAP; Diebold-Mariano testing; out-of-sample analysis; random forest; LASSO; MATLAB; Dynare; web scraping; data preprocessing; forecasting/nowcasting; time-series analysis; Tableau; exploratory data analysis (EDA).

#### 3. Required Skills output

Produce exactly five labelled lines in this order. Order within each line follows section 4; use the vacancy to decide which optional items are selected, and omit irrelevant inventory. Do not add narrative, metrics, or experience wording.

Programming: Always include Python, pandas, NumPy, scikit-learn, TensorFlow/Keras, R, and SQL (PostgreSQL). Select additional Python packages by vacancy. Add R packages, including ggplot2, only when the posting explicitly mentions R; Python alone is not sufficient. Add Matplotlib when relevant, and PyTorch, MATLAB, or Dynare only under the Tier 3 rule. Python packages are always written in brackets after Python, for example Python (pandas, NumPy, scikit-learn, TensorFlow/Keras).

Methods: Always include machine learning (XGBoost, LightGBM) and deep learning (LSTM). Add relevant Tier 2 methods confidently, followed by Tier 3 methods, including EDA, only after the required dual match.

Tools & Platforms: Always include LaTeX, AI/LLM Tools (Codex, Claude Code), Git, and Power BI. Add AWS, CUDA, Docker, Excel, or Microsoft Office (Word, Excel, PowerPoint) confidently when relevant; add Tableau only under the Tier 3 rule. List either Excel or Microsoft Office, never both.

Skills: Always include automation, reporting, stakeholder communication, and cross-functional collaboration. These are working practices, not tools; never repeat a tool, package, or method name on this line. Add a further approved practice only when the posting names it.

Languages: Turkish (Native), English (Fluent), German (Intermediate). This line never changes.

#### 4. Universal Data Scientist ordering

All vacancies. Use the same Data Scientist ordering regardless of job title. Within Programming, order Python, pandas, NumPy, scikit-learn, R, SQL, relevant Tier 2 packages, then qualifying Tier 3 additions; enforce the R-package rule. Within Methods, order machine learning, deep learning, relevant Tier 2 methods, then qualifying Tier 3 methods. Within Tools & Platforms, order LaTeX, AI/LLM Tools, Git, Power BI, relevant Tier 2 tools, then qualifying Tier 3 tools. Within Skills, put the practices the posting names first, then the remaining always-include practices.

#### 5. Pre-flight checks

- Only the summary, the Skills region, and the authorized cover letter tokens differ from the fixed templates; all markers and protected regions remain unchanged.

- Exactly five labelled lines exist in the required order, with Languages reproduced exactly.

- Every Tier 1 skill is present, including pandas, NumPy, and scikit-learn; additional Python packages reflect the vacancy.

- R packages appear only when the job posting explicitly mentions R; a Python mention never triggers them.

- Tier 2 skills are stated confidently when included; no familiarity qualifier is added.

- Every Tier 3 skill has a matching job description and job title; otherwise it is omitted.

- The universal Data Scientist ordering is preserved for every vacancy.

- No unlisted skill, metric, employer, responsibility, internal path, or individual-level data appears.
