# Build progress

Master specification: docs/BUILD_PROJECT.md, read completely before implementation.
Project: job_py; prior versions preserved without changes. No applicant source is fabricated.

## Stage 1 — Foundation (complete)
Requirements: preserve all six supplied files; root-relative YAML configuration; TXT/MD/PDF/DOCX loading; strict schemas; safe IDs; source snapshots and hashes.
Decisions: source copies retain exact bytes. No older applications or legacy baseline code supplies applicant facts. Job_ad/old files can be selected explicitly, never batch-selected implicitly. Empty address tokens preserve surrounding LaTeX (no unauthorized line deletion).
Source blockers: conflicting skills ordering and unspecified mandatory TensorFlow/Keras position; CV 3,540 versus CL >27,000 thesis series needs clarification. Legacy references are absent and are not mandatory dependencies. No substantive conflict is silently resolved.
Environment inspected: Codex 0.149.0, Claude Code 2.1.238; both report signed-in status. MiKTeX pdfTeX 4.27 installed outside PATH. No model calls yet.
Verification: 10 foundation tests passed; all six source copies match source SHA-256. Installed project-local Python 3.12 environment and dependencies.

## Stage 2 — Document handling (complete; source layout blocker retained)
Requirements: only SUMMARY/SKILLS and exact CL tokens; protected bytes including line endings; safe plain-text escaping; mandatory five-line inventory; evidence excerpts; PDF build, extraction, warnings, page limits.
Decisions: arbitrary generated LaTeX is escaped. Existing CV comment tokens remain immutable and are excluded from visible-token checking. CL tokens also replace their repeated comment occurrences. Unknown address values are empty tokens without deleting protected line-break commands. Three CV pages and one CL page are configured limits; no font/layout changes. Human visual inspection remains distinct from text extraction.
Verification: 17 foundation/document tests pass. Live MiKTeX compiled the CV to two pages and caught a 3.09859pt overflow in the protected thesis heading. Initial empty-address CL rendering exposed a LaTeX empty-line error; fixed with a code-owned invisible `\mbox{}` token replacement, preserving the original line-break bytes. Placeholder detection was corrected to distinguish actual uppercase tokens from nested LaTeX groups. These were local compilation checks with test text, not live AI integration.

## Stage 3 — CLI integration (complete; live model testing pending Stage 5)
Requirements: verify installed versions/help; stdin prompts; fresh restricted invocations; explicit UTF-8, timeout/tree termination and logs; global setting precedence; interactive and noninteractive launcher; reject unsupported options without fallback.
Evidence: Codex exec supports stdin, output-schema, read-only, ephemeral and ignore-user-config. Installed model cache supplies model/effort hints; availability still depends on a live request. Claude 2.1.238 help advertises model aliases fable/opus/sonnet, effort low/medium/high/xhigh/max, JSON schema, safe-mode and disabled tools. Its npm wrapper forwards directly to a native executable; adapter resolves that executable without shell concatenation.
Verification: 21 tests pass including mocked Claude envelopes, setting precedence, safe argument lists, plus real local UTF-8 subprocess/timeout/exit tests. PowerShell preflight detects both signed-in providers, MiKTeX and 283 archived jobs. Fixed discovery of Unix npm shims on Windows. Preflight runtime_ready=true, approval_ready=false due to unresolved source issues. No provider/model identity is guessed for native defaults.

## Stage 4 — Agent workflow (complete)
Requirements: sequential fresh A/B/C calls; independent original evidence for C; round 0 plus at most rounds 1–3; format repairs separate; exact score arithmetic and independent 75 thresholds; retain failed candidates under temp; atomic same-filesystem publication of reviewed files only.
Decisions: source-rule conflicts remain hard finalization gates while useful candidates can still be generated for review. Each invocation has separate attempt folders and sources are checked before/after it. C receives complete rendered LaTeX, actual extracted PDF text and build findings; no claim of model visual inspection. Native tools are disabled where supported, source files remain outside fresh CLI working directories, and source hashes are checked at finalization.
Verification: 29 tests passed. Mocked workflow reaches round 3 without round 4, rejects weak individual scores, keeps failures out of final, and publishes exact bytes on a synthetic pass. Actual PowerShell forwards Unicode filenames with spaces and ampersands and propagates exit code 7 from a synthetic Python entry point. Real-job dry-run completed using old/job_description_275.pdf, constructing all role requests without a provider call.

## Stage 5 — Full verification (implemented; live approval blocked by sources/provider quota)
Requirements: real supplied job through installed authenticated providers, actual PDFs/extraction and visual inspection, complete README, accurate live-versus-mocked report.
Selected job: Job_ad/old/job_description_275.pdf, DeepRec.ai Junior Research Engineer / Deep Learning Research Engineer (both title forms occur in the source). All source content is sent as document data. Running configured Codex → Claude → Codex with native model/effort defaults.
Live result: launcher selected a second native Codex installation, 0.143.0, and checked its required flags; A returned schema-valid BLOCKED with the profile-order/mandatory TensorFlow-position conflict and the protected thesis-series discrepancy. Run correctly returned NEEDS_USER_REVIEW and did not proceed to B/C or publish. Removed a feature override that the older CLI warned was unknown. Desktop 0.149.0 help inspection and live 0.143.0 execution are distinct evidence.
Independent Claude live check: native 2.1.238, requested opus/high, reached the service but returned HTTP 429 / session limit before inference (reported reset 14:30 Europe/Berlin, 2026-09-09). Help supports those flag values; model/effort inference availability is not verified. This is not a successful model call.
Local document check: both preserved templates compiled with clearly marked test replacements. CV = 2 pages, CL = 1 page; actual PDF text extracted, replacements and section order checked. Inspected all three PNG pages directly: text readable, skills labels and multilingual names intact; CL signature close to the lower edge. Protected thesis heading still reports 3.09859pt overfull box and is not waived. No real AI-authored candidate was compiled or approved.
Expanded checks: source mutation detection, independent format retry bounds, provider failures stopping immediately, explicit native-default reset, unsupported-effort rejection and DOCX table ordering added. One indentation regression during final cleanup was detected by pytest collection, corrected immediately, and the full suite rerun successfully.
README completed with setup, configuration, exact observed provider versions/commands, authentication prerequisites, launcher behavior, verification scope and troubleshooting. Final test count and source-hash checks recorded below.

## Required user input / external change
- Resolve vacancy-first versus universal Skills ordering and mandatory TensorFlow/Keras position. No agent is authorized to silently settle the source contradiction.
- Thesis-series discrepancy resolved by the user's 27,000 instruction; see the follow-up below.
- Review the CV's protected-heading overflow or authorize a template/tolerance change. CL may need an authorized layout change if real replacements cannot fit one page.
- The selected provider must have available session access. All roles now share that provider; source gates apply to either provider.
- B/C live document review and final real publication remain unverified because A's structured source block was respected. All independently implementable code is complete.

## Final verification record — 2026-09-09
- Final suite: **37 passed**, no skipped tests, in 1.87 seconds. AI/compiler workflow tests are mocked; subprocess and PowerShell forwarding tests execute locally.
- All six preserved source copies still match their originals by SHA-256; mapping recorded in docs/source_mapping.json.
- Existing v1.2.0 baseline ZIP matches its pre-build checksum; versions were not modified.
- Final user-facing Codex preflight: runtime_ready=true, approval_ready=false. Saved under output/temp/final_preflight.json.
- output/final is empty, as required for the real run's NEEDS_USER_REVIEW result.
- Stages 1–4 are complete. Stage 5 local checks and documentation are complete; successful live B/C review and real publication await the concrete source/access resolutions above.

## Follow-up — 27,000 series and one provider per run
User authorized the 27,000 figure and required every agent to use the same provider, selectable when launching. This supersedes the original mixed-provider example.
Changes: active CV uses 27,000; active CL uses exactly 27,000. Only those count/qualifier bytes changed; premade originals, skills profile, prompts and versions are preserved. THESIS_SERIES is now a documented resolution rather than a blocking issue.
Provider configuration: execution.provider is the single default (codex). Agent entries contain prompts only. -Provider codex / -Provider claude overrides all three roles for that run; interactive mode asks for one shared provider. Noninteractive mode uses the configured shared default. Mixed-provider execution is explicitly rejected before source loading or output creation. Model/effort overrides still resolve from the selected provider and never rewrite configuration.
The profile-order conflict and protected-heading overflow remain unresolved; this follow-up does not authorize changing either rule.
Verification: 43 tests passed with no skips. Actual run.ps1 dry runs for both Codex and Claude recorded the selected provider for A/B/C and did not rewrite YAML. Verified all six premade originals retain their recorded hashes and the active copies differ only by the two authorized count/qualifier replacements. No new model call was needed for provider selection checks.

## Follow-up — process all jobs by default
User requested processing everything without selecting a job number. This supersedes the master specification's one-job default. Omitting -Job now enumerates every supported job file and processes them sequentially; -Job retains explicit single-file execution and -JobId requires it. Explicit provider/model/effort settings require no interactive input. All jobs retain the shared provider/settings for A/B/C.
Batch summaries are persisted under output/temp/batches and updated after each job. Input failures and NEEDS_USER_REVIEW results do not stop subsequent jobs. Provider rejection/timeout stops the queue and records remaining jobs as NOT_RUN. Existing or duplicate output IDs are reported without overwriting evidence; other jobs continue. No approval/source/layout gates were relaxed.
Current Job_ad inspection found 16 PDFs (job_description_276.pdf through job_description_291.pdf). Verification uses mocked providers and an isolated real PowerShell dry run; no live 16-job generation was launched by this code change.
Verification result: 54 tests passed, no skips. The real launcher processed both synthetic jobs in sequence with Claude/opus/medium settings, emitted no job prompt, created per-job dry-run logs plus a batch summary, and left final output absent. Provider errors and collisions were separately tested with mocked execution.

## Follow-up — detailed console timings
User requested detailed process timing in PowerShell. Added local timestamped output, monotonic duration measurement, stage starts/completions, per-agent attempt/provider/round details, 15-second elapsed heartbeats while provider/compiler calls block, PDF compilation/extraction timing, job stage breakdowns and a final per-job/batch timing table. Long waits display elapsed time and timeout without guessing model completion percentage. Launcher uses Python unbuffered output.
Persisted duration fields in job run logs, agent-attempt metadata, document build reports and batch reports. Failures and user interruptions retain their duration/status. Source content, provider choices, scoring and output gates are unchanged.
Verification: 61 tests pass, including deterministic monotonic-clock checks, real short heartbeat scheduling and thread cleanup, error timing, saved attempt/stage/batch fields, and the real PowerShell batch dry run. Provider/compiler workflows in tests are mocked; no live model requests or new application PDFs were generated for this instrumentation change.

## Follow-up — always finish the documents, report instead of blocking (2026-09-09)

User requirement: the pipeline must not stop before finishing the PDFs. Remaining problems belong
in a validation report, and crucial ones must be stated in red in PowerShell. The job_description_276
run exposed the underlying implementation problem: `nonfixable` collected every agent conflict and
informational note, so a single advisory sentence forced NEEDS_USER_REVIEW at round 0, withheld two
otherwise sound documents (CV 78, CL 79) and consumed none of the remaining three correction rounds.

### What changed

- **`src/findings.py` (new).** Every gate now returns a coded `Finding` with a severity of
  `critical`, `major` or `advisory`, plus origin and a `fixable` flag. Findings are deduplicated by
  code and message and ranked by severity, so a warning repeated by two agents is reported once.
- **`src/report.py` (new).** Writes `validation_report.md` and `validation_report.json`, and prints
  a console report that paints critical findings bright red, major findings red and advisory notes
  yellow. Windows virtual-terminal processing is enabled through `ctypes` when stdout is a console;
  output stays plain when redirected. `NO_COLOR` and `FORCE_COLOR` override the detection.
- **Publication policy.** `review.publish_policy: always` compiles, reviews and publishes every
  runnable candidate. Only a critical finding withholds documents, meaning no trustworthy artefact
  exists: compilation failure, missing PDF, missing or corrupt extracted replacement text, token or
  control-character injection, or a final integrity mismatch. `pass_only` restores the old behaviour.
- **Exit codes.** 0 PASS, 3 PUBLISHED_WITH_FINDINGS, 2 NEEDS_USER_REVIEW, 1 failure. Batches report
  the most serious outcome across jobs. Published sets carry their report in `output/final/job_<id>/`,
  and the same report is refreshed in temp every round, so a withheld run still leaves a full account.
- **Agent notes are no longer vetoes.** Source conflicts and input notes accompanying a usable
  candidate are advisory; reviewer blocking issues and blocking findings are major; a reviewer
  `NEEDS_USER_REVIEW` decision is recorded as a major finding. Fixable major findings still drive
  revision rounds, so the correction budget is actually used before finalizing.
- **Overflow attribution.** `editable_lines` maps SUMMARY/SKILLS to source line numbers and the
  overfull-box parser reads the reported line range. Overflow inside editable text stays a major,
  fixable finding at the configured 2pt tolerance; overflow in protected layout, such as the
  3.09859pt box at `cv.tex` line 262 in the thesis heading, is advisory and marked not fixable.
- **Evidence.** `Evidence.claim_type` is now required and is `applicant_fact` or `role_target`.
  Applicant facts still may not cite the vacancy. `role_target` may, but only in the fields listed in
  `role_target.allowed_fields` and only when the claim matches `role_target.pattern`, so "Seeking a
  Quality Data Analyst position" is accepted while a qualification claim from the posting is rejected.
- **Instruction precedence.** `editing_rules.instruction_precedence` states the authority order once
  and is supplied to all three agents and repeated in the transport instruction. Section 4's universal
  ordering wins for every vacancy, which the profile itself asserts in section 4 and re-checks in
  section 5, and the configured mandatory Programming sequence fixes TensorFlow/Keras after
  scikit-learn. `ordering.mandatory_first` enforces this deterministically for Programming, Methods
  and Tools & Platforms; the Skills line is exempt because section 4 puts posting-named practices
  first. The legacy skills-only scope and the protected summary comment demanding a literal
  `{{JOB-TITLE}}` token are declared superseded; the wording stays in the sources for provenance and
  is reported as an advisory note. PROFILE_ORDER, LEGACY_SCOPE and MISSING_REFERENCES are now advisory
  source issues carrying their resolutions; no source or template byte was changed.
- **Score visibility.** A document published below the 75-point threshold records
  `SCORE_BELOW_THRESHOLD` in its own report, so a below-bar publication always states its reason.

### Verification

- Suite: **83 passed**, 2 skipped. The skips are the real-PowerShell launcher tests; this machine has
  every execution-policy scope Undefined, so `.ps1` files cannot run and the tests now skip with that
  reason instead of failing. That also means `.\run.ps1` will not run here until the policy is set;
  the direct `python -m src.main` commands are unaffected.
- `--check` now reports `approval_ready: true` with three advisory source issues and their resolutions.
- Offline replay of job_description_276, using its recorded Agent A/B/C responses and real MiKTeX
  pdfLaTeX: 0 validation issues, 0 critical, 6 major, 20 advisory. All four rounds ran, and the run
  finished PUBLISHED_WITH_FINDINGS (exit 3) with cv.tex, cv.pdf, cl.tex, cl.pdf and both report files.
  Under the previous code the identical inputs stopped at round 0 and published nothing.
- A replay with a stubbed compile failure withheld publication (exit 2) and recorded COMPILE_FAILED
  style critical findings, confirming the integrity gates still hold.
- No live provider call was made for this change. The published replay output was written to a
  throwaway sandbox and deleted; `output/final` and the recorded job_description_276 evidence in
  `output/temp` are untouched.

## Follow-up — Gemini CLI as a third provider (2026-09-09)

User asked for Gemini CLI alongside Codex and Claude Code. Added as a peer provider under the
existing one-provider-per-run rule; mixed-provider execution is still rejected.

### What changed

- **`src/providers/gemini_cli.py` (new).** Headless invocation with `--output-format json
  --approval-mode default --telemetry=false`, plus `--model` only when explicitly selected. Prompt
  content enters through stdin, never argv. `--yolo`, `--all-files` and `--sandbox` are deliberately
  absent. The adapter strips code fences and surrounding prose, raises `ProviderFailure` on an
  `error` envelope, rejects any reply whose stats report tool calls, and records the resolved model
  when the envelope discloses exactly one.
- **`src/providers/base.py`.** `SUPPORTED_PROVIDERS`, `REQUIRED_FLAGS` and `SCHEMA_ENFORCEMENT`
  registries replace the scattered two-way conditionals. New `launcher()` runs a `.js` entry point
  through `node`, and `package_entry()` resolves an npm package's own `bin` script so the Windows
  `gemini.cmd` shim is never executed. `gemini_auth()` checks presence of
  `~/.gemini/oauth_creds.json` or a set `GEMINI_API_KEY`/`GOOGLE_API_KEY`/`GOOGLE_GENAI_USE_VERTEXAI`
  variable without opening the file or recording any value.
- **Two honest differences, recorded rather than hidden.** Gemini CLI exposes no per-request
  response-schema flag, so the schema travels in the prompt and the reply is validated locally
  against the same contract, with the existing format-repair attempt as the fallback. Every probe now
  reports `schema_enforcement`, so a run log states which mode produced its documents. Gemini also
  exposes no reasoning-effort control, so an explicit effort other than `default` is refused at
  preflight instead of being silently dropped.
- **Wiring.** Provider dispatch in `agent_runner.ADAPTERS`, `--provider` choices, the interactive
  prompt, `run.ps1 -Provider` ValidateSet, `execution.provider` validation and a `providers.gemini`
  block in `config/pipeline.yaml`. `load_config` now also fails if any supported provider is missing
  from the `providers` map.

### Verification and its limits

- Suite: **104 passed**, 2 skipped (the PowerShell launcher tests, execution policy as before).
- Codex and Claude preflights still succeed unchanged after the `launcher()` refactor: `--check`
  reports codex-cli 0.143.0 and Claude Code 2.1.238, both `signed in`, `runtime_ready: true`.
- Gemini coverage is mocked: restricted argument list, Node-script launch, `package_entry`
  resolution, fenced/prose JSON extraction, error and tool-use rejection, preflight flag refusal,
  effort refusal, presence-only auth, and a full `invoke_role` dispatch that validates a real Draft
  through the adapter and confirms the prompt travels by stdin rather than argv.
- **Gemini CLI is not installed on this machine, so no local `--help` output was inspected and the
  flag set is unverified against a real installation.** `--check --provider gemini` currently exits 1
  with `gemini executable unavailable: gemini`. This is contained by design rather than assumed away:
  the preflight requires `--output-format`, `--approval-mode`, `--model` and `--telemetry` to appear
  in the installed help and stops the run otherwise, so a flag mismatch is a loud, actionable error
  and never a silently looser invocation. Install `@google/gemini-cli`, run `--check`, and reconcile
  the adapter against the real help output before the first live Gemini run.
- No live provider call was made for this change.

## Correction — Gemini flag set verified against the installed CLI (2026-09-09)

The first live Gemini batch stopped at job 1 with `gemini: installed CLI lacks required safe/structured
flags`, and the remaining 15 jobs were correctly marked NOT_RUN. Cause: the adapter had been written
against documented behaviour without a local installation to check, and it required a `--telemetry`
flag that `@google/gemini-cli` 0.59.0 does not have. The preflight did its job — it refused rather
than running a looser invocation — but the required list itself was wrong.

### Corrected against the installed CLI

- Inspected `gemini --version` (0.59.0) and the complete `--help` on this machine.
- `--telemetry` does not exist in 0.59.0; removed from both the required flags and the command.
  Telemetry now follows the user's own `~/.gemini/settings.json`, which is documented.
- Help states the CLI "Defaults to interactive mode. Use -p/--prompt for non-interactive (headless)
  mode", and that `-p` is "Appended to input on stdin (if any)". The command now passes `--prompt`
  with a short closing instruction while the assembled prompt still travels on stdin, so headless
  mode is actually selected and no personal content reaches argv.
- Required flags are now `--output-format`, `--approval-mode`, `--model`, `--prompt`, all verified
  present in the installed help. `--approval-mode default` retained; `--yolo`, `--sandbox`,
  `--raw-output` and `--skip-trust` remain absent.
- 0.59.0 discloses no model default in help, so model hints are honestly empty rather than invented.
- Executable resolution confirmed on a real install: `gemini.ps1` shim on PATH resolves through
  `package.json` `bin` to `bundle/gemini.js`, launched as `node <script>`.
- A smoke call with a trivial non-personal prompt confirmed the error envelope shape
  (`{"session_id", "error": {"type", "message", "code"}}`), which the adapter already handled.
- `gemini_auth` now matches the CLI's own error text: `GEMINI_API_KEY`, `GOOGLE_GENAI_USE_VERTEXAI`
  or `GOOGLE_GENAI_USE_GCA`, an existing `oauth_creds.json`, or a declared auth type in
  `settings.json`. `GOOGLE_API_KEY` was dropped because the CLI does not name it.
- New regression test asserts every `--` flag the adapter uses, and every required flag, appears in a
  verbatim copy of the installed 0.59.0 help. That is the check that would have caught this.

### Remaining blocker, which is not a code problem

Gemini CLI on this machine has **no auth method configured**: no `settings.json`, no
`oauth_creds.json`, and none of the three environment variables set. Preflight now reports
`auth: not signed in` and a run stops with `gemini: sign in manually before running`. The application
does not initiate login or handle keys; sign in by running `gemini` once interactively and choosing an
auth method, then rerun `--check`. Inference through Gemini therefore remains unverified.

### Verification

- Suite: **107 passed**, 2 skipped (PowerShell execution policy, unchanged).
- `--check --provider gemini` now resolves `bundle/gemini.js`, reports version 0.59.0, passes the
  flag check and exits 1 solely on authentication.
- Codex and Claude preflights unaffected; both still report `signed in` with `runtime_ready: true`.

## Correction — Gemini headless workspace trust and error reporting (2026-09-09)

After signing in, preflight passed and Agent A launched, then the batch stopped with
`Process exited 55: Gemini CLI is not running in a trusted directory`. Agents deliberately run in a
fresh empty OS temporary directory, and 0.59.0 refuses to run headless in an untrusted folder.

### Corrected, each item confirmed against the live CLI

- Added `--skip-trust` to the command and to the required-flag set. It is scoped to the empty
  per-invocation temporary directory only: that folder holds no project configuration, no
  extensions, no context files and none of the applicant's sources, so nothing that could carry
  instructions is being trusted. `--approval-mode default`, the absent `--yolo`/`--sandbox`/
  `--raw-output`, the empty working directory, the no-tools prompt instruction and the tool-call
  rejection all remain in place.
- Captured the real success envelope from a live headless call: `{"session_id", "response", "stats"}`
  with `response` a plain JSON string, and `stats.tools.totalCalls` exactly as the adapter reads it.
  Warnings such as the true-colour and ripgrep notices go to stderr, so stdout stays parseable.
- Captured the real failure shape: a rejected request writes **nothing to stdout**, exits non-zero,
  and prints a stack trace followed by its JSON error envelope to stderr. The previous adapter would
  have surfaced a raw process failure, so `invoke` now recovers the envelope from either stream and
  raises `Gemini rejected request: <message>`; with no recognisable envelope the original failure is
  re-raised unchanged rather than given an invented explanation.
- 0.59.0 routes roles to different models. A default call used `gemini-3.5-flash` for `main` and
  `gemini-3.1-flash-lite` for `utility_router`, so `resolved_model` now records the model that
  served `main` instead of giving up whenever more than one appears.

### Model availability, which is an account fact rather than a code issue

`gemini-3.1-pro` (the identifier used in both attempted batches) and `gemini-3.5-pro` are both
rejected by the API on this account: `not found for API version v1beta, or is not supported for
generateContent`. `gemini-3.5-flash` is accepted. Omitting `-Model` lets the CLI route models itself.

### Verification

- Suite: **110 passed**, 2 skipped.
- Three live headless smoke calls with trivial non-personal prompts confirmed the trust fix, the
  success envelope, the tools-stats shape and two model rejections. No applicant data was sent.
- Codex and Claude adapters untouched by this change.

## Codex npm executable selection fix
- Fixed default Windows Codex discovery to prefer the npm native payload over the older desktop-bundled executable; explicit configured paths remain respected.
- Supports nested/hoisted platform packages and legacy vendor layouts.
- Verification: 31 provider tests passed (includes synthetic package-layout tests). Real local preflight selected npm Codex 0.153.4 and confirmed required flags, medium effort catalog support, and signed-in status. No live inference was run.


## PDF line-break hyphenation
- Accept discretionary hyphenation between letters across PDF line breaks, while retaining checks for missing text, numeric changes and ordinary hyphens. Agent transport also explicitly excludes normal hyphenation as a reason for revision.
- Verification: 15 document tests passed; replayed saved real job 276 PDF extraction reports: all three earlier false missing-text items now pass. No PDF regeneration or live AI call; current running process unchanged.
- Review-count reduction discussed as a recommendation; configuration unchanged pending user choice.


## User-settled degree wording
- User instructed reviewers to ignore the alleged conflict between Recent Master's graduate and October 2023--September 2026; recorded narrow source resolution and instructed agents to honor resolutions.
- Active CL now says During my studies at FAU, I worked; aligned the following task verbs to past tense. Updated source mapping hash and authorization record. CV wording/dates and premade originals preserved.
- Local foundation, agent-runner and document checks passed; no live AI call or PDF regeneration for this wording change.


## Evidence whitespace and final PDF names
- Evidence quotes now compare after collapsing whitespace; empty excerpts and changed words/punctuation still fail. Updated agent transport accordingly.
- Published PDFs now use yigit_coskun_cv.pdf and yigit_coskun_cl.pdf within each job directory. Internal build filenames remain stable; renamed copies are checked against reviewed hashes.
- 43 affected regression tests passed, including publication byte integrity and whitespace mismatch cases. Existing outputs were not renamed. Restart required for a running process to load changes.


## Empty address row correction
- Renderer omits standalone empty optional address/city rows, preventing blank space between company and city in future letters.
- Jobs 292-295: backed up old cover-letter TeX/PDF under tmp/address_repair_20260910, removed only blank recipient row, recompiled and replaced published CL files. CVs unchanged.
- Verification: 17 document tests passed; all four PDFs remain one page with identical whitespace-normalized visible text. Poppler previews visually inspected for all four; corrected recipient spacing and no clipping. Published file hashes verified against staged PDFs; repair notes distinguish this layout correction from original AI review.

## Follow-up — legacy source cleanup and template comment audit (2026-09-10)

User asked to remove the CV_RULES.md / bullet_library.docx references, make Excel and MS
Office easy to state, fix the legacy wording behind the recurring SOURCE_LEGACY_SCOPE
advisory, and then audit every comment in both templates.

### Legacy references removed

Every mention of the two provenance documents is gone from `input/skills_profile.md`,
`input/cv_template.tex` (two `See CV_RULES.md R-xx` pointers), `input/cl_template.tex`
(three "bullet library" references), `config/editing_rules.yaml`, `README.md` and
`docs/BUILD_PROJECT.md`. Neither file was ever supplied and neither governed anything.
The removal itself is recorded in `docs/source_mapping.json`; the profile notes it without
naming the files, so the names no longer reach an agent and cannot be re-flagged.

### Excel and Microsoft Office

Both moved from Tier 3 to Tier 2 in the profile, so they are stated confidently when the
posting makes them relevant instead of needing the Tier 3 dual match.
`Microsoft Office (Word, Excel, PowerPoint)` joined `optional['Tools & Platforms']`. A new
`mutually_exclusive` config group and a `SKILLS_REDUNDANT` check stop a line reading
"Excel, Microsoft Office (Word, Excel, PowerPoint)", which would look like padding.

### Legacy wording fixed at source, not papered over

The recurring advisories were symptoms of sources that genuinely contradicted the current
contract. They are now corrected in place:

- `cv_template.tex` summary was labelled "PROTECTED REGION 1 of 9" and its comment demanded
  a literal `{{JOB-TITLE}}` token; it is now "EDITABLE REGION 1 of 2" and the default text
  no longer carries the token. The Skills region was "THE ONLY EDITABLE REGION"; now
  "EDITABLE REGION 2 of 2".
- `skills_profile.md` sections 1 and 5 stated a skills-only scope; both now state the real
  scope. The ordering ambiguity note became a recorded resolution.
- The header claimed "No model ever reads this file", which was false: `assemble` passes
  both templates to every agent as source text. It now says the opposite and points at the
  real authority.

`source_issues` is therefore empty, and the three entries moved to `source_resolutions`,
which the prompts and transport instruction tell agents not to reopen. **A dry run now
reports "No validation findings" where it previously reported three permanent advisories.**

### Comment audit

- `cv_template.tex`: 132 -> 79 comment lines, 336 -> 282 total. Removed the duplicated
  header/CONTRACT blocks, seven repetitions of "FIXED HEADER -- do not edit", seven
  `PROTECTED REGION n of 9` markers and the dead bullet-ID lists (E1b, I1a, P1a...), which
  referenced the removed provenance file. Repaired two truncated ATS sentences. Kept every
  piece of real reasoning: itemsep=4pt, `\Needspace*`, no negative `\vspace`,
  `\resumeFlatItem`, literal UTF-8 accents.
- `cl_template.tex`: 47 -> 15 comment lines, 115 -> 78 total. The old block claimed
  "EDIT ZONES: only text between AI_EDIT_START and AI_EDIT_END may be changed", which was
  simply untrue: `render()` substitutes the nine tokens across the whole file and
  `boundaries()` is applied to the CV only. The 14 AI_EDIT markers were inert and
  misleading, so they were removed.
- Per-token guidance moved from a LaTeX comment into `editing_rules.cl_token_guidance`,
  which agents actually receive; `load_config` rejects drift from `cl_tokens`.
- Removing "Keep to one page" would have lost the page budget entirely, because agents
  never receive `pipeline.yaml`. `limits.cv_pages`/`limits.cl_pages` now mirror
  `document.page_limits`, and `load_config` fails if the two drift.
- Both templates now say plainly that comments are maintainer notes, never instructions.

### Verification

- Both templates compiled before and after with the same draft: **extracted PDF text
  identical, page counts identical (CV 2, CL 1), same single OVERFLOW_PROTECTED finding**.
  Every LaTeX line is byte-identical except the summary default text.
- Suite: **137 passed**, 2 skipped, 1 failed. The failure is environmental and unrelated:
  Windows Application Control now blocks lxml's `_elementpath` DLL, so `python-docx` cannot
  import. **DOCX job descriptions will fail to load on this machine until that policy is
  addressed**; PDF, TXT and MD inputs are unaffected.
- Eight new tests cover the cleanup: no legacy term survives in anything an agent reads,
  the sources no longer contradict the editable scope, every known issue is resolved rather
  than carried, the CL carries no inert markers, Office skills are approved and mutually
  exclusive, agents receive the page budget, and configuration drift is rejected.
- `docs/source_mapping.json` rehashed with today's authorized changes recorded per file.

## Follow-up — NOSI folded into the IAB role (2026-09-12)

User confirmed both the NOSI project and the IAB Working Student role have ended, and chose
to condense NOSI into a single IAB bullet rather than keep it as a standalone Projects entry.
These are protected template regions, so this was a manual master edit, not a pipeline one.

### cv_template.tex

- The three IAB bullets are past tense: Supported / Prepared, validated, and analysed /
  Produced.
- A fourth IAB bullet condenses NOSI and keeps the three numbers worth keeping: the
  19,900-record linked dataset, non-response bias at an 11.9% response rate, and the
  91.8% versus 85.0% employment finding, with the diagnostics presented to senior
  researchers. Dropped in the condensation: the "2x2" design label and the "incentive and
  reminder conditions" detail, which did not survive the one-line budget.
- The standalone NOSI Projects entry and its PROJECT_NOSI_BULLETS region were removed.
  Projects is now the Master's thesis alone, and eight AI_EDIT anchors remain rather than
  nine. The contract comment, the Projects order comment and the README region count all
  follow.

### Downstream

The tense change broke two evidence excerpts in `docs/general/generate.py`, which cited the
old present-tense IAB bullet; both were repointed. The general CV summary was also stale
(present tense for an ended role) and now carries the project-led summary the user selected,
with its evidence map rebuilt against the new bullets. Regenerated: still 2 pages and 1 page,
still exactly one expected finding (EVIDENCE_MISSING for the placeholder addressee).

The cover letter needed no change: it already described the IAB work in past tense.

### Verification

- Compiles to 2 pages with the same single OVERFLOW_PROTECTED advisory; no NOSI text remains
  in the rendered PDF; the IAB entry shows all four bullets and Projects shows the thesis.
- Suite: **138 passed**, 2 skipped, 0 failed. The lxml/Application Control block that failed
  the DOCX test on 2026-09-10 has cleared, so DOCX job descriptions load again.
- `docs/source_mapping.json` rehashed with the change recorded.

## Follow-up — CV trimmed to six anchors (2026-09-12)

User-directed removals, all manual edits to protected template regions.

- **Istanbul University** coursework bullet removed; header-only entry like Łódź.
- **Projects section removed entirely**, including the Master's thesis. The thesis title is
  still listed under Education; its detail now lives in the summary.
- **Ziraat Bank** retitled to "Intern --- Retail Banking" (em dash, matching the IAB entry)
  and given two further bullets.
- Anchors: nine at the start of the day, six now.

### Knock-on work

- `document_builder` hardcoded the expected CV section list, including "Projects". Left
  alone it would have fired SECTION_ORDER on every run. The list moved to
  `document.cv_sections`, and a new test asserts it matches the template headings.
- `test_user_confirmed_thesis_count_is_consistent` asserted the series count appears in the
  CV; that text lived in the removed thesis bullets. Rewritten: the cover letter is now the
  only template stating it, the CV must not, and the superseded 3,540 appears nowhere.
- The general-docs evidence map cited three thesis bullets. Two were repointed to the cover
  letter, which still carries the 27,000 series, the weekly-data span and the LSTM.
- **The 8.16% RMSE result is no longer stated in any supplied template.** It lived only in
  the removed thesis bullets, so the summary now carries it alone and nothing cross-checks
  it. Its evidence entry was dropped rather than faked.

### Verification

- Suite: **139 passed**, 2 skipped, 0 failed.
- CV compiles to 2 pages. **The 3.10pt overfull box is gone**: it sat in the Master's thesis
  heading, whose very long title caused it, so OVERFLOW_PROTECTED no longer fires at all.
  The general documents now report zero advisories.
- `docs/versions/yigit_coskun_cv_old_v1.tex` captures the start-of-day CV, with a README
  describing the convention and what changed since.

## Follow-up — the summary names the role again (2026-09-12)

User asked for the summary to close with a "Seeking <role>" sentence, with the role
substituted per posting. The old mechanism was a literal {{JOB-TITLE}} token inside the
summary, which the renderer and validator both reject; this is the same intent rebuilt on
the supported path, where the agent writes the role as plain text.

- `editing_rules.summary` now carries `role_target_required`, a `pattern` and the wording
  `guidance`. Configuration owns the rule, so it can be relaxed without a code change.
- `validate_draft` raises `SUMMARY_NO_ROLE_TARGET` (major) when the summary contains no
  seeking/looking-for/applying-for language. The pattern is a floor the validator can
  actually check; naming the advertised role itself stays the prompt's job, since the
  validator has no reliable way to confirm a title came from the posting.
- Agent A and B prompts and the transport instruction all reference the guidance.
- `tests/helpers.sample()` gained a closing sentence so the synthetic fixture satisfies the
  new floor; without it every mocked workflow run would have carried a spurious finding.
- The general CV summary was tightened by 15 characters to fit the closer while keeping the
  presenting-to-senior-researchers clause: 600 characters against the 650 limit. The closing
  sentence is deliberately uncited in the evidence map, for the same reason the placeholder
  addressee is: with no posting there is no vacancy to evidence it against.

Verification: 139 passed, 2 skipped. The rule fires on a summary without targeting language
and stays silent on one with it. General documents still 2 pages and 1 page, still exactly
one expected finding and zero advisories.

## Follow-up — master CV for PhD applications (2026-09-12)

User asked for a PhD-application CV built from everything established so far. Delivered as
`docs/phd/yigit_coskun_cv_phd.pdf` with `generate.py` and a README.

Standalone, not a pipeline document: no AI_EDIT anchors, never tailored automatically. The
generator lifts the preamble verbatim from `input/cv_template.tex`, so the two CVs stay
visually identical and a font or spacing change propagates on the next build. Only the body
differs.

### Academic restructuring

Much of what the industry CV shed on 2026-09-12 is exactly what an admissions committee
wants, so it was recovered from `docs/versions/yigit_coskun_cv_old_v1.tex`:

- Research Interests replaces the Summary; no objective statement, per academic convention.
- Research Projects restored with the thesis (all four bullets, including the 8.16% RMSE
  result) and NOSI as its own entry (all three bullets, including the 2x2 design).
- Seminar project and the Istanbul quantitative-training bullet restored.
- Work split into Research Experience (IAB) and Other Experience (Ziraat), with the
  Excel/branch-management bullet dropped as industry filler.
- Skills reduced to four research-oriented lines; the practice line was dropped.

### Two departures, both deliberate and documented

- **Stata is listed but is not approved inventory.** It is evidenced twice in the sources
  yet absent from `config/editing_rules.yaml`, so the pipeline can never list it. Flagged as
  worth adding for the industry CV as well.
- Method names such as "mixed-frequency modelling" are descriptive rather than
  inventory-controlled. Acceptable for a hand-maintained document; it would fail
  `validate_draft` if routed through the pipeline.

### Verification

Compiles to 2 pages, all eight sections present in the extracted text, and every expected
figure survives extraction (27,000 / 8.16 / 19,900 / 11.9 / 1,735 / Stata). One 3.10pt
overfull box at the thesis heading, the same one the industry CV reported before Projects
was removed. Nothing invented: the README lists the seven things a PhD application normally
wants that the sources do not supply, supervisor name and grades among them.

## Follow-up — Python packages in brackets; PhD CV trimmed (2026-09-12 to 2026-09-14)

- **PhD CV:** Certifications removed; Tools reduced to LaTeX, Git and CUDA (AWS, Docker,
  Power BI, Excel and AI/LLM tools dropped as unrelated to a PhD application); referee emails
  added. Dovern and Merkl come from the FAU staff directory; Kosyakova's IAB address came from
  search results because the IAB page does not expose it, and needs confirming. An earlier
  scripted edit had corrupted one `space` into a vertical-tab character, breaking the build;
  repaired.
- **Python packages print in brackets after Python**, e.g. `Python (pandas, NumPy, scikit-learn,
  TensorFlow/Keras, Matplotlib), R, SQL (PostgreSQL)`. `editing_rules.python_packages` owns the
  list and `load_config` rejects entries that are not approved Programming items. A single
  `template_renderer.skill_text` formatter is now used by the renderer, the validator's length
  limit and evidence fields, and the builder's extracted-text check. Changing only the renderer
  would have made the builder flag every CV as missing text. Agents still return plain items;
  the transport instruction tells them evidence claims quote the printed form.
- Rebuilt both CVs. Suite: 140 passed, 2 skipped.

## Follow-up — advanced Excel and Power BI (2026-09-14)

A review raised GAP-02: the vacancy asked for advanced Excel and Power BI, but the profile listed the
tools without a proficiency level. The user confirmed an advanced level in both. Recorded as a
proficiency note in `skills_profile.md` section 2 (citable evidence for the summary and cover letter)
and as the `EXCEL_POWER_BI_PROFICIENCY` source resolution so the reviewer does not reopen it. The
Skills line keeps the plain inventory names. Suite: 141 passed, 2 skipped.

## Follow-up — collisions replaced by automatic rerun IDs (2026-09-15)

A full batch reported 21 COLLISION and did nothing, because every posting already had an
output folder, including one left behind by the expired-OAuth failure on job 303. The skip
existed to protect earlier evidence, but it made rerunning impossible without deleting
folders by hand.

`unique_job_id` now walks to the next free ID (`job_x` -> `job_x_r2` -> `job_x_r3`), checking
both `output/temp` and `output/final` and the IDs already used in the current batch, with
case-insensitive matching and the 64-character ID limit respected. Batch and single-job runs
both use it, so the COLLISION status is gone from the code, the console and the exit-code
rules. The batch report records `rerun_of` when an ID was suffixed. Nothing is overwritten:
the guards in `execute` and `publish` that refuse to write over an existing final directory
are untouched.

Verified with a real dry run: job 303 wrote to `job_description_303_r2` while the original
folder stayed put. Suite: 141 passed, 2 skipped, plus the unrelated lxml/Application Control
DOCX failure, which has reappeared on this machine.

## Correction — a batch skips finished postings again (2026-09-16)

The 2026-09-15 change went too far. Removing the collision skip made a batch reprocess all 21
finished postings as `_r2`, when the intent was the opposite: run only what is new and stop
printing a COLLISION line per job.

`run_batch` now decides the queue before the loop. A posting whose ID already exists in
`output/temp` or `output/final` is marked `SKIPPED`, as is a second file in the same batch
that maps to the same ID. The console says `21 of 24 job descriptions already have output and
are skipped` followed by `Processing 3 new job description(s)`, and the closing table lists
only what ran plus a one-line skipped count. Skipped work is not a failure, so a batch with
nothing new exits 0.

Rerunning a finished posting is still possible and still non-destructive: name it with `-Job`
and `unique_job_id` gives it the next free ID. Verified with a dry run against the real job
folder, which skipped 21 and processed 304, 305 and 306. Suite: 143 passed, 2 skipped.

## Follow-up — no recipient address block; job 304 re-addressed (2026-09-16)

Job 304's posting came through Jobgether, a hiring intermediary rather than the employer, so
the letter should not name it. `{{COMPANY-NAME}}` is now "your company".

The recipient address block was removed from `cl_template.tex` at the user's request. Because
`{{COMPANY-ADDRESS}}` and `{{COMPANY-CITY}}` appeared nowhere else, `inspect_templates` would
have rejected the template with them still configured, so both tokens were retired from
`cl_tokens`, `optional_empty_tokens` (now empty) and `cl_token_guidance`. The renderer's
empty-address-row repair and `tests/test_address_rows.py` had nothing left to act on and were
removed with them. Agents now fill seven tokens instead of nine.

Job 304 was rebuilt twice without re-running any agent: the reviewed draft was re-rendered
through `render`, `validate_rendered` and the builder, so the protected template bytes were
verified exactly as in a normal run. `job_description_304_r3` is the current one;
`_r2` (an intermediate with "your organisation") and the original remain untouched. The
general cover letter was regenerated the same way. Suite: 142 passed, 2 skipped.
