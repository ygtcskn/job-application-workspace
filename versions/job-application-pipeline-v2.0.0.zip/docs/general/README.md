# General CV and cover letter

The untailored baseline pair: no employer, no advertised vacancy. Use them for a
speculative application, as an attachment when a posting asks for a CV before a role is
fixed, or as the reference point for what the pipeline starts from before it tailors
anything.

| File | What it is |
| --- | --- |
| `yigit_coskun_cv.pdf` | General CV, 2 pages |
| `yigit_coskun_cl.pdf` | General cover letter, 1 page |
| `cv.tex`, `cl.tex` | The exact LaTeX these PDFs were compiled from |
| `generate.py` | Regenerates all four files |

```bash
.\.venv\Scripts\python.exe docs\general\generate.py
```

## How they are built

Through the same code as a real run: `render()` for the byte-preserving substitution,
`validate_draft()` for the approved inventory, ordering rule and length limits,
`validate_rendered()` for the protected template bytes, and the same pdfLaTeX builder.
Nothing here is hand-edited LaTeX, so these documents cannot drift from the master
templates: change a template and the next regeneration follows it.

The content is drawn only from the existing CV, cover letter and skills profile. No claim
appears here that is not already evidenced in those sources.

## What "general" means for each field

The CV summary names no role and no employer. The Skills lines use the universal ordering
with the mandatory core first, then broadly relevant additions, so nothing is slanted
toward a particular posting.

The cover letter's fixed paragraphs are unchanged. Only the seven tokens differ from a
tailored letter, and they are filled with field-level rather than company-level wording:

- `{{JOB-TITLE}}` is **"Data Analysis"** — a field of work, not a job title. It appears in
  the heading and twice as "the Data Analysis role". This is the one place the letter has
  to name something, because the fixed sentences are built around it.
- `{{COMPANY-NAME}}` is **"your company"**, a placeholder addressee, appearing in two
  sentences. The recipient address block was removed from the template on 2026-09-16, so the
  letter opens with the sender block alone and there are no address tokens left to fill.

## Expected findings

Regeneration reports exactly two findings, both expected:

- `EVIDENCE_MISSING` for `cl_tokens.{{COMPANY-NAME}}` — **major, and correct**. A general
  letter names no employer, so the addressee is a placeholder rather than an applicant
  fact, and no source can honestly evidence it. Citing a source to silence this would be
  gaming the check. It disappears the moment a real posting supplies a company name.
- `OVERFLOW_PROTECTED` — advisory. The 3.10pt overfull box in the protected thesis heading,
  the same one every run reports; it is not fixable within the permitted edit scope.

No critical findings, and both documents compile to their page limits.

## Before sending

Replace "your organisation" with the employer and "Data Analysis" with the advertised role
if you send this by hand, or run the posting through the pipeline and let it tailor the
summary, the Skills selection and all nine tokens properly.
