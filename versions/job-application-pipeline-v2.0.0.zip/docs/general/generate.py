"""Build the general CV and cover letter in docs/general/.

These are the untailored baseline documents: no company, no advertised vacancy.
They are produced through the same renderer, validator and compiler the pipeline
uses, so the protected template bytes, the approved skills inventory, the ordering
rule and the length limits are all enforced exactly as they are for a real run.

    .\\.venv\\Scripts\\python.exe docs\\general\\generate.py
"""
from __future__ import annotations
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.document_builder import build
from src.findings import ordered
from src.input_loader import load_config, load_sources
from src.report import console_report
from src.schemas import CV, Draft, Evidence, SkillLine
from src.template_renderer import render, validate_rendered
from src.validator import validate_draft

OUTPUT = Path(__file__).resolve().parent
PUBLISHED = {'cv.tex': 'cv.tex', 'cv.pdf': 'yigit_coskun_cv.pdf',
             'cl.tex': 'cl.tex', 'cl.pdf': 'yigit_coskun_cl.pdf'}

SUMMARY = (
    "Recent Master's graduate in Economics whose work runs from data collection to "
    "evaluation. For my Master's thesis I combined 27,000 Google Trends series with "
    "financial indicators across 15 G20 economies and 20 years of weekly data, then built "
    "a mixed-frequency LSTM in TensorFlow/Keras that cut average forecast RMSE by 8.16% "
    "against a random walk. At the IAB I prepared linked survey and administrative data in "
    "Stata and R and measured non-response bias in a randomised field experiment, "
    "presenting the diagnostics to senior researchers. Seeking a Data Analysis role to "
    "apply and extend these skills."
)

SKILLS = {
    'Programming': ['Python', 'pandas', 'NumPy', 'scikit-learn', 'TensorFlow/Keras', 'R',
                    'SQL (PostgreSQL)', 'Matplotlib'],
    'Methods': ['machine learning (XGBoost, LightGBM)', 'deep learning (LSTM)',
                'data cleaning/wrangling', 'feature engineering', 'model evaluation/validation',
                'hypothesis testing', 'time-series analysis', 'forecasting/nowcasting',
                'data visualisation', 'exploratory data analysis (EDA)', 'statistics'],
    'Tools & Platforms': ['LaTeX', 'AI/LLM Tools (Codex, Claude Code)', 'Git', 'Power BI',
                          'Excel', 'AWS', 'Docker', 'CUDA'],
    'Skills': ['automation', 'reporting', 'stakeholder communication',
               'cross-functional collaboration', 'presenting findings'],
}

# No company and no advertised vacancy: the tokens name a field of work, not a job.
TOKENS = {
    '{{JOB-TITLE}}': 'Data Analysis',
    '{{COMPANY-NAME}}': 'your company',
    '{{SPECIFIC-TASK-OR-PROJECT}}': 'turning large, complex datasets into clear, decision-ready analysis',
    '{{RELEVANT-EXPERIENCE}}': 'linked survey and administrative datasets at the IAB and the forecasting models in my thesis',
    '{{RELATED-ACTIVITY}}': 'testing methods systematically against benchmarks and turning the results into clear tables and visualisations',
    '{{CONCRETE-CONTRIBUTION}}': 'preparing, validating and analysing data and presenting the findings clearly to specialist and non-specialist audiences',
    '{{COMPANY-DOMAIN}}': 'your field and the questions your teams work on',
}

# claim -> (source file, exact excerpt from that source)
EVIDENCE = [
    ('cv.summary', "Recent Master's graduate in Economics", 'cv_template.tex', "Recent Master's graduate in Economics"),
    # The Projects section was removed on 2026-09-12, so the thesis detail is now
    # evidenced from the cover letter rather than the CV.
    ('cv.summary', '27,000 Google Trends series', 'cl_template.tex', 'collection of 27,000 data series'),
    ('cv.summary', '20 years of weekly data', 'cl_template.tex', '20 years of weekly data'),
    ('cv.summary', 'mixed-frequency LSTM', 'cl_template.tex', 'mixed-frequency LSTM neural network'),
    # The 8.16% RMSE result is deliberately uncited: it lived only in the removed thesis
    # bullets, so no supplied template still states it. The claim stands on the applicant's
    # own record, not on a template excerpt. The closing "Seeking a Data Analysis role"
    # sentence is uncited for the same reason a placeholder addressee is: with no posting
    # there is no vacancy to evidence it against.
    ('cv.summary', 'prepared linked survey and administrative data in Stata and R', 'cv_template.tex', 'linked survey and administrative data in Stata and R'),
    ('cv.summary', 'measured non-response bias in a randomised field experiment', 'cv_template.tex', 'non-response bias'),
    ('cv.summary', 'presenting the diagnostics to senior researchers', 'cv_template.tex', 'presenting the diagnostics to senior researchers'),
    ('cv.skills.Programming', 'Python (pandas, NumPy, scikit-learn, TensorFlow/Keras, Matplotlib)', 'skills_profile.md', 'Python, pandas, NumPy, scikit-learn, TensorFlow/Keras'),
    ('cv.skills.Programming', 'R, SQL (PostgreSQL)', 'skills_profile.md', 'SQL (PostgreSQL)'),
    ('cv.skills.Methods', 'machine learning (XGBoost, LightGBM), deep learning (LSTM)', 'skills_profile.md', 'machine learning (XGBoost, LightGBM) and deep learning (LSTM)'),
    ('cv.skills.Methods', 'exploratory data analysis (EDA)', 'skills_profile.md', 'exploratory data analysis (EDA)'),
    ('cv.skills.Tools & Platforms', 'LaTeX, AI/LLM Tools (Codex, Claude Code), Git, Power BI', 'skills_profile.md', 'LaTeX, AI/LLM Tools (Codex, Claude Code), Git, and Power BI'),
    ('cv.skills.Tools & Platforms', 'Excel, AWS, Docker, CUDA', 'skills_profile.md', 'AWS; CUDA; Docker; Excel'),
    ('cv.skills.Skills', 'automation, reporting, stakeholder communication, cross-functional collaboration', 'skills_profile.md', 'automation, reporting, stakeholder communication, and cross-functional collaboration'),
    ('cv.skills.Skills', 'presenting findings', 'skills_profile.md', 'presenting findings'),
    ('cv.skills.Languages', 'Turkish (Native), English (Fluent), German (Intermediate)', 'skills_profile.md', 'Turkish (Native), English (Fluent), German (Intermediate)'),
    ('cl_tokens.{{JOB-TITLE}}', 'Data Analysis', 'cv_template.tex', 'Data Analysis'),
    # {{COMPANY-NAME}} is deliberately absent from this map. A general letter names no
    # employer, so the addressee is a placeholder rather than an applicant fact, and no
    # source can honestly evidence it. The resulting EVIDENCE_MISSING finding is expected
    # and disappears as soon as a real posting supplies the company name.
    ('cl_tokens.{{SPECIFIC-TASK-OR-PROJECT}}', 'large, complex datasets', 'cl_template.tex', 'large, messy datasets'),
    ('cl_tokens.{{RELEVANT-EXPERIENCE}}', 'linked survey and administrative datasets at the IAB', 'cl_template.tex', 'survey and administrative datasets in R and Stata'),
    ('cl_tokens.{{RELATED-ACTIVITY}}', 'clear tables and visualisations', 'cv_template.tex', 'tables and visualisations'),
    ('cl_tokens.{{CONCRETE-CONTRIBUTION}}', 'preparing, validating and analysing data', 'cv_template.tex', 'Prepared, validated, and analysed'),
    ('cl_tokens.{{COMPANY-DOMAIN}}', 'your field and the questions your teams work on', 'cl_template.tex', 'a deeper understanding of'),
]


def draft() -> Draft:
    skills = [SkillLine(label=label, items=list(items)) for label, items in SKILLS.items()]
    skills.append(SkillLine(label='Languages', items=['Turkish (Native), English (Fluent), German (Intermediate)']))
    evidence = [
        Evidence(claim_id=f'G{index}', field=field, claim=claim, claim_type='applicant_fact',
                 source=source, excerpt=excerpt, location='general baseline document')
        for index, (field, claim, source, excerpt) in enumerate(EVIDENCE, 1)
    ]
    return Draft(status='READY', cv=CV(summary=SUMMARY, skills=skills), cl_tokens=dict(TOKENS),
                 evidence=evidence, change_log=['Untailored baseline; no vacancy or employer named.'],
                 source_conflicts=[], qualification_gaps=[], feedback_resolutions=[], input_issues=[])


def main() -> int:
    config = load_config()
    sources = load_sources(config)
    originals = {name: sources.files[f'{name}_template.tex'].read_bytes() for name in ('cv', 'cl')}
    candidate = draft()

    findings = validate_draft(candidate, config['rules'], sources.texts)
    rendered = render(originals['cv'], originals['cl'], candidate, config['rules'])
    validate_rendered(originals, rendered, candidate, config['rules'])

    with tempfile.TemporaryDirectory(prefix='general-docs-') as work:
        report = build(rendered, candidate, Path(work) / 'build', {**config['document'], 'python_packages': config['rules'].get('python_packages', [])})
        findings += report['findings']
        OUTPUT.mkdir(parents=True, exist_ok=True)
        for name, published in PUBLISHED.items():
            shutil.copyfile(Path(work) / 'build' / name, OUTPUT / published)

    for name, document in report['documents'].items():
        print(f'{name}: {document["pages"]} page(s), {len(document["missing_text"])} missing text item(s)')
    console_report(ordered(findings), 'GENERAL DOCUMENTS', OUTPUT)
    return 1 if any(f.severity != 'advisory' for f in findings) else 0


if __name__ == '__main__':
    raise SystemExit(main())
