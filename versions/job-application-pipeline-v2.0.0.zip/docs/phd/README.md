# Master CV for PhD applications

`yigit_coskun_cv_phd.pdf` — 2 pages, academic ordering, research first.

```bash
.\.venv\Scripts\python.exe docs\phd\generate.py
```

This is a **standalone document, not a pipeline one**. It has no AI_EDIT anchors and is
never tailored automatically. `generate.py` takes the preamble straight from
`input/cv_template.tex`, so fonts, spacing and the ATS-safe `\resumeSubheading` macros stay
identical to the industry CV; only the body differs. Edit `generate.py`, not the `.tex`,
which is overwritten on every build.

Every fact comes from `input/cv_template.tex` or the pre-trim snapshot
`docs/versions/yigit_coskun_cv_old_v1.tex`. Nothing is invented.

## What differs from the industry CV

| | Industry CV | PhD CV |
| --- | --- | --- |
| Opening | Summary closing with "Seeking a … role" | **Research Interests** — five topic areas, no objective statement |
| Thesis | One line under Education | Full **Research Projects** entry with all four bullets, including the 8.16% RMSE result |
| NOSI | Condensed into one IAB bullet | Restored as its own research project with all three bullets, including the 2x2 design |
| Seminar project | Removed | Restored under Education |
| Istanbul University | Header only | Quantitative-training bullet restored |
| Work section | "Work Experience", both jobs | **Research Experience** — the IAB role only |
| Skills | Five fixed profile lines | Four research-oriented lines, Stata added, practice skills dropped |
| Ziraat Bank | Three bullets | Dropped entirely; a retail-banking internship adds nothing to a PhD application |
| Closing section | — | **References**, three named academics |

The reasoning throughout: an admissions committee reads for research capability and method,
so the experimental design, the benchmark comparison and the quantitative foundation matter
more than stakeholder communication or ATS keyword coverage.

## Two deliberate departures

**Stata is listed here but is not in the pipeline's approved inventory.** It is evidenced
twice — the IAB bullet and the cover letter both say the work was done "in Stata and R" —
but `config/editing_rules.yaml` has no Stata entry, so the pipeline can never list it. For
economics PhD applications Stata is expected, so it appears here. Worth adding to the
inventory for the industry CV too.

**Methods names here are descriptive, not inventory-controlled.** "Mixed-frequency
modelling" and "non-response and selection bias" describe work the CV evidences but are not
approved inventory strings. That is fine for a hand-maintained document; it would fail
`validate_draft` if it ever went through the pipeline.

## What is still missing

None of this exists in the supplied sources, so none of it was invented. A PhD application
usually wants:

- **Thesis supervisor's name.** The chair is named; the supervising academic is not.
- **Grades** — M.Sc. and B.A. results, or degree classification.
- **Conference presentations, seminars or posters**, including internal IAB talks.
- **Teaching or tutoring**, if any.
- **Scholarships, awards or funding.**
- **Working papers in progress**, if the thesis is heading toward one.

Grades in particular are usually expected. Add them to `generate.py` and rebuild.

## References

Three academics are named, with titles and affiliations verified against the institutions'
own pages on 2026-09-12:

| Referee | Role |
| --- | --- |
| Prof. Dr. Jonas Dovern | Chair of Statistics and Econometrics, FAU — the chair the thesis was written at |
| Prof. Dr. Yuliya Kosyakova | Head of the IAB research department "Migration and International Labour Studies", one of the two departments the CV names; Professor of Migration Research, University of Bamberg |
| Prof. Dr. Christian Merkl | Chair of Macroeconomics, FAU; Research Professor at the IAB |

**Contact details are deliberately withheld**, and the CV says "Contact details available on
request" instead. Two reasons: each referee should confirm the address they prefer, and a
referee must agree to be named before the CV is sent. Add the addresses in `generate.py`
once all three have confirmed, or leave the line as it stands — it is standard practice.

## Known layout note

One 3.10pt overfull box at the Master's thesis heading, caused by the very long thesis
title in a fixed-width heading slot. It is the same box the industry CV reported before the
Projects section was removed, and it is cosmetically invisible.
