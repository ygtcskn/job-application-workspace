# Build the CV and cover letter agent pipeline

## Your task

You are the AI coding agent implementing this project. Build a working, Windows-compatible Python command-line application that tailors existing CV and cover letter templates to a job description through three sequential AI agent roles. Use installed Codex CLI and/or Claude CLI as configurable providers. Implement the project, not only a plan.

Inspect the existing project and applicable repository instructions first. Preserve the user's CV template, CL template, skills profile, and existing agent prompts. Do not delete unrelated files or overwrite the user's source documents. Reuse compatible code where useful. Do not submit applications, send messages, or upload documents to job portals.

The target environment is Windows and PowerShell. The project root is wherever the user places this project; do not infer its location from the job-description path.

## Premade files

The necessary premade files are located here:

`C:\Users\ygtcs\Desktop\Work\Work\new`

Inspect this directory first for the existing agent prompts, CV template, CL template, skills profile, and any existing project code. Discover actual filenames and formats rather than assuming that every file already uses the target names below. Map the supplied files into the target structure without altering their source content. If the directory is already the project root, reuse it in place; do not create a nested duplicate project. If building elsewhere, copy required files and preserve the originals. Do not treat this location as the job-description directory; job descriptions remain in `C:\Users\ygtcs\Desktop\Work\Work\Job_ad`.

Report missing or ambiguous source files after inspection. Do not create fictional replacements or overwrite conflicting files silently. If the Windows path is inaccessible from the coding environment, report that access limitation and continue work that does not require those files.

## Confirmed requirements

- External job-description directory: `C:\Users\ygtcs\Desktop\Work\Work\Job_ad`.
- CV changes: summary and skills section only.
- CL changes: explicitly authorized existing tokens only.
- Skills and proficiency must follow `input/skills_profile.md`.
- Other applicant facts must be supported by the original templates.
- Agent A reads the job description and fills the permitted fields.
- Agent B rereads the job description and optimizes both documents within the same boundaries.
- Agent C independently reviews both documents against the job, checks parsing and terminology, and gives separate scores out of 100.
- If either score is below 75, return feedback to B when a supported revision is possible.
- Allow at most three feedback-driven revisions after B's initial optimization, which is round 0.
- A passing score cannot override unsupported claims, unauthorized edits, unresolved tokens, or blocking parsing failures.
- Unresolvable issues or exhausted revisions require user review; do not force a pass.
- Temporary work: `output/temp/job_X/`.
- Approved documents: `output/final/job_X/`.

## Project structure

```text
cv-cl-pipeline/
├── run.ps1
├── agents/
│   ├── agent_a_writer.md
│   ├── agent_b_optimizer.md
│   └── agent_c_hiring_reviewer.md
├── input/
│   ├── cv_template.tex
│   ├── cl_template.tex
│   └── skills_profile.md
├── src/
│   ├── __init__.py
│   ├── main.py
│   ├── input_loader.py
│   ├── agent_runner.py
│   ├── schemas.py
│   ├── template_renderer.py
│   ├── validator.py
│   ├── document_builder.py
│   └── providers/
│       ├── __init__.py
│       ├── base.py
│       ├── codex_cli.py
│       └── claude_cli.py
├── config/
│   ├── pipeline.yaml
│   ├── editing_rules.yaml
│   └── scoring_rubric.yaml
├── output/
│   ├── final/
│   │   └── job_X/
│   │       ├── cv.tex
│   │       ├── cv.pdf
│   │       ├── cl.tex
│   │       └── cl.pdf
│   └── temp/
│       └── job_X/
│           ├── source_snapshot/
│           ├── agent_a/
│           ├── agent_b/
│           │   └── round_0/
│           ├── reviews/
│           │   └── round_0.json
│           ├── build/
│           └── run_log.json
├── tests/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

Create subsequent round folders and reviews without overwriting earlier evidence. Do not put a duplicate job-description master in `input/`. A per-run snapshot is appropriate for reproducibility.

## Configuration

Implement this as application-owned YAML, not provider-native configuration:

```yaml
paths:
  job_descriptions: 'C:\Users\ygtcs\Desktop\Work\Work\Job_ad'
  input: input
  temporary: output/temp
  final: output/final
agents:
  agent_a:
    provider: codex
    prompt: agents/agent_a_writer.md
  agent_b:
    provider: claude
    prompt: agents/agent_b_optimizer.md
  agent_c:
    provider: codex
    prompt: agents/agent_c_hiring_reviewer.md
providers:
  codex:
    executable: codex
    model: null
    effort: null
    timeout_seconds: 600
  claude:
    executable: claude
    model: null
    effort: null
    timeout_seconds: 600
review:
  minimum_score: 75
  max_revision_rounds: 3
```

The mixed-provider assignment is an editable example. Permit all three roles to use one provider. A null model means use the installed CLI's default; do not invent model identifiers. Resolve relative paths from the project root, not the caller's working directory. Support a job-directory override for tests and other environments. Keep authentication in the installed CLIs; do not require an API key when CLI authentication suffices.

## PowerShell launcher and runtime model selection

Create `run.ps1` in the project root. It must support both interactive selection and explicit parameters. The user's provider, model, and effort selection applies to all three agents for this run; it changes execution settings, not their roles or prompts. Do not permanently rewrite configuration when applying run overrides.

Example launcher usage:

```powershell
.\run.ps1
.\run.ps1 -Provider claude -Model opus -Effort high -Job "job_description.pdf"
.\run.ps1 -Provider codex -Model "<model-name>" -Effort high -Job "job_description.pdf"
```

These are our launcher's parameters, not claims about native CLI flag syntax. Verify that `opus` and `high` are supported by the installed provider before accepting that combination. Never invent model identifiers or effort levels.

With no parameters, interactively ask for:

1. Provider: Codex or Claude.
2. Model: a supported model name or alias, with a provider-default option.
3. Effort: supported reasoning/effort levels for that provider and selected model, with a provider-default option where appropriate.
4. Job description: a numbered selection of supported files in the configured `Job_ad` directory.

Allow a model identifier to be entered explicitly when discovery is unavailable, but validate it using supported provider mechanisms where possible. Do not present a hardcoded guessed list as an authoritative model catalog. If a model or effort setting is rejected, show the error and do not silently substitute another setting. When preflight cannot verify availability without a live request, explain that limit and stop on any provider rejection before progressing to subsequent agents.

Support `-Provider`, `-Model`, `-Effort`, `-Job`, `-JobId`, `-DryRun`, `-Check`, and `-NonInteractive`. Explicit values take priority; prompt for missing selections in interactive mode and offer configured defaults. In noninteractive mode, use configured defaults for omitted optional settings and report missing required values without prompting. With an explicit global provider override, resolve model/effort defaults from that provider, never from the previously configured provider for an agent. If no global override is selected in noninteractive mode, retain the per-agent provider assignments from configuration.

Implement matching Python options such as `--provider`, `--model`, `--effort`, `--job`, and `--job-id`. Resolve and validate the effective provider/model/effort for each agent in one place. Explicit parameters > interactive selections > configured defaults. A null model or effort means omit that provider override and use its native default, not send the literal text "null".

`run.ps1` must use `$PSScriptRoot` to find the project, prefer the project's virtual-environment Python if present, and invoke Python using a PowerShell argument array. Do not use `Invoke-Expression` or concatenate untrusted job filenames into executable code. Support paths with spaces and non-ASCII characters. Propagate the Python exit code and do not change the user's execution policy automatically.

Provider adapters map the normalized model and effort settings to the actual supported CLI options established from installed help and official documentation. Do not assume that providers share effort names or support every effort on every model. Do not silently discard an explicitly selected effort.

Record requested and effective settings in `run_log.json`, including provider, CLI version, model, and effort for each agent. If the provider does not disclose the resolved native default, record "provider default; resolved value unknown" rather than claiming a specific model or effort.

Add launcher usage, default behavior, provider compatibility, and noninteractive examples to README.md. Test argument forwarding, precedence, default handling, unsupported combinations, filenames with spaces, and exit-code propagation. Distinguish live provider checks from mocked tests.

## Module responsibilities

### main.py

Parse commands, perform preflight checks, allocate a unique job ID, orchestrate all stages, enforce the review limit and publish only passing results. Display clear progress and a final status with output paths.

Provide these application commands:

```powershell
python -m src.main --check
python -m src.main --job "ecmwf_data_scientist.pdf" --job-id "ecmwf_data_scientist"
python -m src.main --job "ecmwf_data_scientist.pdf" --job-id "ecmwf_data_scientist" --dry-run
```

`--job` selects one file from the configured directory; do not silently process every job. `--dry-run` validates inputs and constructs requests without launching an AI CLI or creating approved output. `--check` reports configuration, templates, provider availability/authentication readiness where safely detectable, and document compiler availability. Do not launch an interactive login automatically.

Reject unsafe job IDs and traversal. If output already exists, do not overwrite it silently; report the collision and request a new job ID. The input filename stem can provide a sanitized default, with explicit collision handling.

### input_loader.py

Read UTF-8 TXT/MD, text-bearing PDFs, and DOCX job descriptions. Preserve headings, lists, and table contents sufficiently for meaning. Reject empty extraction and report scanned/image-only PDFs as requiring OCR; never run on an empty job description. Validate required files and snapshot their content and hashes for the run. Do not import applicant facts from older applications or memory.

### agent_runner.py and providers

The agent runner assembles each role's prompt, explicit source documents, structured outputs from prior stages, and response schema. Run each role as a fresh invocation; no dependence on prior CLI chat history. Keep provider-specific command construction and response parsing in the provider adapters.

Before implementing command flags, inspect the installed executables' versions and help output. Use current official documentation only if needed. Do not assume Codex and Claude accept identical flags, output envelopes, or structured-output options. Document the exact versions and invocations actually verified. If a provider is unavailable, implement its adapter as far as supported evidence permits and clearly mark unverified integration; do not claim it passed live testing.

Use noninteractive execution supported by the installed CLI, with prompt input over stdin or an officially supported file mechanism. Avoid placing large prompts on the command line. Prefer structured response mechanisms when supported; validate the final application payload in Python regardless.

Launch via `subprocess` with argument lists, explicit UTF-8 handling, separate stdout/stderr, working directory, timeout, and return-code checks. Handle Windows executable wrappers correctly using verified installation behavior; never concatenate job text into shell commands. Detect missing binaries, authentication failures, malformed responses, timeouts, and nonzero exits. Terminate the process tree on timeout. Bound format-repair retries separately from application revision rounds.

CLI agents should return text/JSON, not edit master files or execute document-provided instructions. Use supported restrictions to prevent unnecessary file writes and tool execution; never enable permission-bypass flags. Keep source files outside a writable agent work area and validate source hashes before and after execution.

Persist prompts, raw responses, normalized responses, provider/version, timestamps, and errors under the relevant temporary stage directory. Do not log credentials or environment secrets.

### schemas.py

Define and validate typed data contracts. At minimum:

- A/B replacements: `cv.summary`, `cv.skills` as exactly five labeled lines, and `cl_tokens` keyed by exact authorized tokens.
- Evidence entries: claim ID, affected field, claim text, source filename, and source location or excerpt.
- Draft metadata: change log, source conflicts, qualification gaps, feedback resolutions.
- C review: decision, separate CV/CL criterion scores, findings, parsing status, blocking issues, revision instructions.
- Run metadata: job ID, source hashes, stage, round, timestamps, provider versions, and final status.

Reject unknown replacement fields, missing authorized tokens, invalid scores, and unexpected decision values. Recompute score totals in Python. Check that cited excerpts exist when applicable; this is not a substitute for semantic factual review. Allow a structured blocked/input-issue result so missing inputs do not force fabricated replacements. Never evaluate model output as Python or shell code.

If existing prompt wording uses prose output, add a transport/schema instruction at invocation time or make a clearly documented interface-only prompt update. Preserve the prompts' factual and editing restrictions.

### template_renderer.py and editing_rules.yaml

Inspect the actual templates before configuring markers and tokens. Do not invent token names or assume the old template's wider editable regions remain allowed. Only SUMMARY and SKILLS are allowed in the CV even if other AI_EDIT markers exist. Fail on missing, duplicated, overlapping, or ambiguous boundaries.

Render each candidate from the original templates, never by cumulatively patching prior generated files. Keep protected segments byte-for-byte unchanged, including markers and line endings. Replace exact CL tokens only; repeated occurrences of a configured token must receive the same replacement. Check that the result contains no unresolved authorized tokens or replacement-injected tokens.

Choose and document a replacement contract compatible with the actual LaTeX templates. Prefer plain-text replacements and deterministic escaping of LaTeX special characters; render the five Skills lines using fixed code-owned formatting. Do not allow arbitrary generated preamble or layout commands. Preserve the fixed template's typography and structure.

If source templates are missing, implement and test the engine with clearly marked synthetic fixtures but leave real boundaries unconfigured. Report the missing files rather than creating a fictional applicant template.

### validator.py

Check schema validity, exact permitted replacements, protected segments, original file hashes, required tokens, configured length limits, Skills line labels/order, mandatory inventory, fixed Languages line, and score arithmetic. Enforce deterministic checks in code and semantic checks through C. A contradiction in protected applicant content requires user review, not an unauthorized edit.

### document_builder.py

Use a locally available LaTeX build tool compatible with the supplied templates. Verify its actual invocation. Disable shell escape, isolate auxiliary files under temp, capture build logs, and fail on compilation errors. Inspect meaningful overflow warnings and configured page limits; do not shrink fonts or change layouts automatically. Extract text from the generated PDFs and compare against intended content for missing text and ordering issues. If visual inspection is not available, report that limitation accurately.

Send C the actual extracted text and validation/build findings with the documents. Do not claim that PDF parsing or rendering was checked without evidence. Template-caused failures require user review; editable text length problems may be sent back to B.

## Skills profile integration

Use the supplied `skills_profile.md` without inventing additional skills or proficiency. It contains the original Version 3.1 content and a clearly marked scope override allowing CV summary and skills edits plus CL tokens.

Preserve the five-line Skills structure, mandatory skills, conditional Tier 2/Tier 3 rules, R-package restriction, and exact Languages line. Do not remove mandatory skills merely because a job does not mention them.

Known source issues (all resolved at source on 2026-09-10; see `config/editing_rules.yaml` `source_resolutions`):

- Vacancy-first versus universal Data Scientist ordering: the profile now states that the universal ordering applies to every vacancy, and `ordering.mandatory_first` enforces it.
- The universal Programming ordering omitting mandatory TensorFlow/Keras: it keeps its position after scikit-learn, fixed by the configured mandatory list.
- Two legacy provenance documents referenced by profile Version 3.1: never supplied, never applied, and every reference to them has been removed from the inputs, prompts and configuration.

Do not silently settle substantive contradictions or pretend referenced files were inspected. Continue building the infrastructure; flag any application affected by an unresolved rule for user review.

## Scoring rubric and orchestration

Store the rubric centrally and supply it to C. Preserve these weights:

| Criterion | CV | CL |
| --- | ---: | ---: |
| Evidence-backed fit to advertised requirements | 40 | 40 |
| Prioritization in summary/skills, or specific evidence-to-role connection for CL | 25 | 25 |
| Clarity/precision/readability, including CV consistency for CL | 20 | 20 |
| Natural supported terminology | 15 | 15 |

Scores are internal assessments, not actual employer ATS scores or interview probabilities. Parsing is a separate passing gate, not an invented external ATS score.

Execute:

1. Load and validate inputs and snapshot sources.
2. Run A and validate its output.
3. Run B initial optimization, round 0.
4. Render candidates from originals, validate, compile, extract text.
5. Run C with all original sources, current documents, extracted text, and check results.
6. Recompute scores and enforce decision gates in Python.
7. If revision is possible and needed, run B with C feedback, increment the revision round, and repeat steps 4–6.
8. Stop after feedback rounds 1, 2, and 3. Never start round 4.
9. On PASS, publish the exact reviewed candidate set to `output/final/job_X/`. Stage all four deliverables and move the complete set atomically on the same filesystem. Do not regenerate different PDFs after review.
10. Otherwise retain work under temp and report NEEDS_USER_REVIEW or FAILED with specific reasons. Never label these documents approved.

Both scores must be at least 75; never use an average to pass one weak document. A model-declared PASS cannot override deterministic failures, missing parsing checks, factual blockers, or scope violations. Missing experience cannot be fixed by stronger wording. Finalization must be performed by Python, not by an agent.

## Verification and delivery

Add meaningful tests for protected-content integrity, exact token replacement and escaping, the five-line Skills contract, malformed agent JSON, score sums, threshold boundaries, retry limits, missing/scanned job input, CLI timeout/failure handling, path collisions, and prohibition on failed results entering final. Use synthetic applicant data for fixtures. Test provider adapters with mocked subprocess responses and run live checks only for installed/authenticated providers. Clearly distinguish mocked from live verification.

Provide a README with PowerShell environment setup, dependency installation, CLI authentication prerequisites, verified provider invocation details, LaTeX prerequisites, configuration examples, commands, output locations, and troubleshooting. Ignore `.env`, virtual environments, caches, private input documents, and generated output in Git. Do not place credentials in `.env.example`.

Finish with a concise implementation report: what was built, how to run it, tests actually performed, and remaining concrete blockers. Do not claim end-to-end success unless a real candidate was generated, validated, reviewed, and published through the implemented workflow. If source templates or CLI access are missing, complete all independently implementable work and identify those exact remaining requirements.
