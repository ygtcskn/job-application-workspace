"""Validation reporting: a saved report plus colour-coded console output.

Crucial problems are printed in red so an unattended PowerShell run shows them
without opening the JSON, while the documents themselves are still produced.
"""
from __future__ import annotations
import os
import sys
from src.findings import ADVISORY, CRITICAL, CRUCIAL, MAJOR, at, counts, ordered, payload

RESET = "\033[0m"
STYLES = {CRITICAL: "\033[1;91m", MAJOR: "\033[91m", ADVISORY: "\033[93m"}
HEADINGS = {CRITICAL: "CRITICAL — publication withheld", MAJOR: "MAJOR — published, needs your attention", ADVISORY: "Advisory notes"}


def enable_ansi(stream=None) -> bool:
    """Turn on Windows virtual-terminal processing; stay plain when redirected.

    NO_COLOR disables colour anywhere; FORCE_COLOR keeps it through a pipe or a
    console whose mode cannot be queried.
    """
    stream = stream if stream is not None else sys.stdout
    if os.environ.get("NO_COLOR"):
        return False
    forced = bool(os.environ.get("FORCE_COLOR"))
    if not forced and not getattr(stream, "isatty", lambda: False)():
        return False
    if os.name != "nt":
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return forced
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004)) or forced
    except (OSError, AttributeError, ValueError):
        return forced


def paint(text: str, severity: str, colour: bool) -> str:
    return f"{STYLES[severity]}{text}{RESET}" if colour and severity in STYLES else text


def console_report(findings, status: str, destination, colour=None, stream=None) -> None:
    stream = stream if stream is not None else sys.stdout
    colour = enable_ansi(stream) if colour is None else colour
    findings = ordered(findings)
    tally = counts(findings)
    write = lambda line: print(line, file=stream, flush=True)
    write("")
    write(f"VALIDATION REPORT | {status} | {destination}")
    write(f"  critical {tally[CRITICAL]} | major {tally[MAJOR]} | advisory {tally[ADVISORY]}")
    crucial = at(findings, *CRUCIAL)
    if crucial:
        write(paint(f"CRUCIAL VALIDATION PROBLEMS ({len(crucial)}) — read before sending these documents", MAJOR, colour))
    for severity in (CRITICAL, MAJOR, ADVISORY):
        selected = at(findings, severity)
        if not selected:
            continue
        write(paint(f"  {HEADINGS[severity]} ({len(selected)})", severity, colour))
        for finding in selected:
            suffix = "" if finding.fixable else " [not fixable within the permitted edit scope]"
            write(paint(f"    - {finding.code} ({finding.origin}): {finding.message}{suffix}", severity, colour))
    if not findings:
        write("  No validation findings.")
    write("")


def markdown_report(findings, context: dict) -> str:
    findings = ordered(findings)
    tally = counts(findings)
    lines = [f"# Validation report — {context['job_id']}", "",
             f"- Status: **{context['status']}**",
             f"- Documents: {context['destination']}",
             f"- Scores: CV {context['scores'].get('cv', 'n/a')}/100, CL {context['scores'].get('cl', 'n/a')}/100 "
             f"(internal document-fit assessment, not an employer ATS score)",
             f"- Rounds used: {context['round']} of {context['max_rounds']}",
             f"- Findings: {tally[CRITICAL]} critical, {tally[MAJOR]} major, {tally[ADVISORY]} advisory", ""]
    for severity in (CRITICAL, MAJOR, ADVISORY):
        selected = at(findings, severity)
        if not selected:
            continue
        lines += [f"## {HEADINGS[severity]}", ""]
        lines += [f"- **{f.code}** ({f.origin}{'' if f.fixable else ', not fixable in scope'}): {f.message}" for f in selected]
        lines.append("")
    if not findings:
        lines += ["No validation findings were recorded.", ""]
    lines += ["## Interpretation", "",
              "Critical findings mean no trustworthy document could be produced and nothing was published.",
              "Major findings are published with the documents and need a human decision before sending.",
              "Advisory findings record source ambiguities, protected-template limits and informational notes.", ""]
    return "\n".join(lines)


def report_payload(findings, context: dict) -> dict:
    return {**context, "counts": counts(ordered(findings)), "findings": payload(findings)}
