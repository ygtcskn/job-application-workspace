"""Deterministic gates complement, but do not replace, semantic review.

Every gate returns a coded finding with a severity. Only critical findings can
withhold publication; the rest travel with the documents in a validation report.
"""
import re
from src.findings import ADVISORY, CRITICAL, CRUCIAL, MAJOR, at, make
from src.schemas import Draft, Review
from src.template_renderer import skill_text


def validate_draft(draft: Draft, rules: dict, texts: dict[str, str], overrides: dict | None = None) -> list:
    findings = []
    add = lambda code, severity, message, fixable=True: findings.append(make(code, severity, message, "validator", fixable, overrides))
    if draft.cv is None:
        add("NO_CANDIDATE", CRITICAL, "No candidate replacements: " + "; ".join(draft.input_issues + draft.source_conflicts), False)
        return findings
    if set(draft.cl_tokens) != set(rules["cl_tokens"]):
        add("CL_TOKEN_SET", CRITICAL, "Exact CL token mapping required")
    if len(draft.cv.summary) > rules["limits"]["summary_chars"]:
        add("SUMMARY_LENGTH", MAJOR, "CV summary exceeds length limit")
    summary_rule = rules.get("summary") or {}
    if summary_rule.get("role_target_required") and not re.search(summary_rule.get("pattern") or "", draft.cv.summary):
        add("SUMMARY_NO_ROLE_TARGET", MAJOR, "CV summary does not close by naming the role being sought")
    labels = [s.label for s in draft.cv.skills]
    if labels != rules["skills_labels"]:
        add("SKILLS_LABELS", MAJOR, "Skills must have the five exact labels in order")
    jd = "\n".join(v for k, v in texts.items() if k.startswith("job/"))
    ordered_labels = rules.get("ordering", {}).get("mandatory_first", [])
    packages = rules.get("python_packages", ())
    for line in draft.cv.skills:
        if len(skill_text(line.items, packages)) > rules["limits"]["skills_line_chars"]:
            add("SKILLS_LINE_LENGTH", MAJOR, f"{line.label}: length limit exceeded")
        if len(set(line.items)) != len(line.items):
            add("SKILLS_DUPLICATE", MAJOR, f"{line.label}: duplicate skills")
        if line.label == "Languages":
            if line.items != [rules["languages"]]:
                add("LANGUAGES_EXACT", MAJOR, "Languages must remain exact")
            continue
        required = rules["mandatory"].get(line.label, [])
        allowed = set(required) | set(rules["optional"].get(line.label, []))
        if not set(required) <= set(line.items):
            add("SKILLS_MANDATORY_MISSING", MAJOR, f"{line.label}: missing mandatory skills {sorted(set(required) - set(line.items))}")
        if not set(line.items) <= allowed:
            add("SKILLS_UNAPPROVED", MAJOR, f"{line.label}: unapproved inventory {sorted(set(line.items) - allowed)}")
        # Instruction precedence resolves the profile's ordering ambiguity: the universal
        # order leads each line, and the configured mandatory sequence fixes every position.
        if line.label in ordered_labels and set(required) <= set(line.items) and line.items[:len(required)] != required:
            add("SKILLS_ORDER", MAJOR, f"{line.label}: universal ordering requires {required} first, in that order")
        if "ggplot2" in line.items and not re.search(r"\bR\b", jd):
            add("R_PACKAGE_GATE", MAJOR, "R packages require an explicit R mention in the posting")
        # Overlapping entries such as Excel and Microsoft Office read as padding together.
        for group in rules.get("mutually_exclusive", []):
            listed = [item for item in group if item in line.items]
            if len(listed) > 1:
                add("SKILLS_REDUNDANT", MAJOR, f"{line.label}: list only one of {listed}")
    fields = {"cv.summary": draft.cv.summary}
    fields.update({f"cv.skills.{line.label}": skill_text(line.items, packages) for line in draft.cv.skills})
    fields.update({f"cl_tokens.{k}": v for k, v in draft.cl_tokens.items()})
    for field, value in fields.items():
        if any(ord(c) < 32 for c in value) or "{{" in value or "}}" in value:
            add("FIELD_INJECTION", CRITICAL, f"{field}: injected token/control character")
    for token, value in draft.cl_tokens.items():
        if not value.strip() and token not in rules["optional_empty_tokens"]:
            add("TOKEN_EMPTY", MAJOR, f"Empty required token {token}")
        if len(value) > rules["limits"]["cl_token_chars"]:
            add("TOKEN_LENGTH", MAJOR, f"{token}: length limit exceeded")
    target = rules.get("role_target", {})
    target_fields, target_pattern = target.get("allowed_fields", []), target.get("pattern", "")
    covered, ids = set(), set()
    for item in draft.evidence:
        if item.claim_id in ids:
            add("EVIDENCE_DUPLICATE_ID", ADVISORY, f"Duplicate evidence ID: {item.claim_id}")
        ids.add(item.claim_id)
        # Only original applicant sources or job facts, never prior drafts/config/prompts.
        allowed_source = item.source in {"cv_template.tex", "cl_template.tex", "skills_profile.md"} or item.source.startswith("job/")
        excerpt = ' '.join(item.excerpt.split())
        if not allowed_source or item.source not in texts or not excerpt or excerpt not in ' '.join(texts[item.source].split()):
            add("EVIDENCE_SOURCE", MAJOR, f"{item.claim_id}: source excerpt absent/unauthorized")
        if item.field not in fields or not item.claim or item.claim not in fields.get(item.field, ""):
            add("EVIDENCE_CLAIM", MAJOR, f"{item.claim_id}: claim not present in affected replacement field")
        if item.field.startswith("cv.") and item.source.startswith("job/"):
            # Naming the advertised role is targeting, not an applicant qualification.
            if item.claim_type != "role_target":
                add("EVIDENCE_VACANCY_FACT", MAJOR, f"{item.claim_id}: vacancy cannot establish applicant facts")
            elif item.field not in target_fields or not (target_pattern and re.search(target_pattern, item.claim)):
                add("EVIDENCE_ROLE_TARGET_SCOPE", MAJOR, f"{item.claim_id}: role_target evidence is only permitted as targeting language in {target_fields}")
        covered.add(item.field)
    for field, value in fields.items():
        if value and field not in covered:
            add("EVIDENCE_MISSING", MAJOR, f"Missing evidence for {field}")
    return findings


def source_findings(rules: dict, overrides: dict | None = None) -> list:
    """Supplied-source ambiguities declare their own severity in configuration."""
    result = []
    for issue in rules.get("source_issues", []):
        severity = issue.get("severity") or (CRITICAL if issue.get("blocking") else ADVISORY)
        detail = issue.get("resolution")
        message = issue["reason"] + (f" Resolution: {detail}" if detail else "")
        result.append(make(f"SOURCE_{issue['id']}", severity, message, "source", issue.get("fixable", False), overrides))
    return result


def draft_findings(draft: Draft, origin: str, overrides: dict | None = None) -> list:
    """Agent notes are evidence for the report, not automatic publication blockers."""
    blocked = draft.cv is None
    severity = CRITICAL if blocked else ADVISORY
    return ([make("AGENT_SOURCE_CONFLICT", severity, text, origin, not blocked, overrides) for text in draft.source_conflicts]
            + [make("AGENT_INPUT_ISSUE", severity, text, origin, not blocked, overrides) for text in draft.input_issues])


def review_findings(review: Review, overrides: dict | None = None) -> list:
    result = [make("REVIEW_BLOCKING_ISSUE", MAJOR, text, "agent_c", True, overrides) for text in review.blocking_issues]
    result += [make("REVIEW_FINDING", MAJOR if f.blocking else ADVISORY, f"{f.id} ({f.field}): {f.problem}", "agent_c", f.fixable, overrides) for f in review.findings]
    if review.decision == "NEEDS_USER_REVIEW":
        result.append(make("REVIEW_DECISION_USER_REVIEW", MAJOR, "Reviewer asked for user review of this candidate", "agent_c", False, overrides))
    if review.parsing_status != "Verified" or not review.parsing_evidence.strip():
        result.append(make("PARSING_NOT_VERIFIED", MAJOR, f"ATS parsing status: {review.parsing_status}", "agent_c", True, overrides))
    return result


def score_findings(totals: dict, threshold: int, overrides: dict | None = None) -> list:
    """A published document that missed the bar says so in its own report."""
    return [make("SCORE_BELOW_THRESHOLD", MAJOR, f"{name}: {total}/100 is below the {threshold}-point threshold", "review", True, overrides)
            for name, total in totals.items() if total < threshold]


def decision(review: Review, rubric: dict, findings: list, round_number: int, max_rounds: int, threshold: int = 75, publish_policy: str = "always") -> tuple[str, dict]:
    """PASS, PUBLISH, REVISE or NEEDS_USER_REVIEW; only critical findings withhold documents."""
    totals = review.totals(rubric)
    critical, crucial = at(findings, CRITICAL), at(findings, *CRUCIAL)
    scores_ok = all(n >= threshold for n in totals.values())
    if scores_ok and not crucial and review.decision == "PASS":
        return "PASS", totals
    unresolved = not scores_ok or any(f.fixable for f in crucial)
    if round_number < max_rounds and review.revision_instructions and unresolved:
        return "REVISE", totals
    if critical or publish_policy != "always":
        return "NEEDS_USER_REVIEW", totals
    return "PUBLISH", totals
