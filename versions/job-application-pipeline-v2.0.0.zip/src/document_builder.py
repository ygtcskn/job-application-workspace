"""Compile reviewed candidates locally; never edit template layout."""
import os
import re
import shutil
import unicodedata
from pathlib import Path
from time import perf_counter
import pymupdf as fitz
from src.findings import ADVISORY, CRITICAL, MAJOR, make
from src.input_loader import write_json
from src.process import run_process, ProcessFailure
from src.progress import Activity, emit, duration
from src.template_renderer import boundaries, skill_text

OVERFULL = re.compile(r"Overfull \\[hv]box \(([\d.]+)pt too[^)]*\)([^\n]*)")
AT_LINES = re.compile(r"at lines? (\d+)(?:--(\d+))?")


def find_compiler(config: dict) -> str:
    executable = config["executable"]
    found = shutil.which(executable)
    if found:
        return found
    if Path(executable).is_file():
        return str(Path(executable).resolve())
    if executable == "pdflatex":
        local = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/MiKTeX/miktex/bin/x64/pdflatex.exe"
        if local.is_file():
            return str(local)
    raise ValueError(f"LaTeX compiler unavailable: {executable}")


def norm(text: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", text)).replace("’", "'").replace("–", "-").replace("−", "-")


def contains_replacement(expected: str, extracted: str) -> bool:
    """Accept discretionary word breaks without ignoring ordinary hyphens."""
    if norm(expected) in norm(extracted):
        return True
    marker = "\ue000"
    # Mark only hyphens between letters across a physical line break. A real
    # compound hyphen at that position may also be retained by the comparison.
    marked = re.sub(r"(?<=[^\W\d_])[-\u00ad][ \t]*\r?\n[ \t]*(?=[^\W\d_])",
                    marker, unicodedata.normalize("NFKC", extracted))
    pattern = (marker + "?").join(
        f"[-{marker}]" if char == "-" else re.escape(char)
        for char in norm(expected)
    )
    return re.search(pattern, norm(marked)) is not None


def editable_lines(data: bytes) -> set[int]:
    """1-based source lines inside SUMMARY/SKILLS, so overflow can be attributed."""
    try:
        regions = boundaries(data)
    except ValueError:
        return set()
    lines = set()
    newline = b"\n"
    for name, (start, end) in regions.items():
        if name in {"SUMMARY", "SKILLS"}:
            lines.update(range(data.count(newline, 0, start) + 1, data.count(newline, 0, end) + 1))
    return lines


def overflow_findings(name: str, texlog: str, editable: set[int], tolerance: float, overrides) -> tuple[list, list[float]]:
    """Split overflow by origin: agent-editable text is fixable, template layout is not."""
    result, sizes = [], []
    for size, tail in OVERFULL.findall(texlog):
        size = float(size)
        sizes.append(size)
        if size <= tolerance:
            continue
        span = AT_LINES.search(tail)
        first = int(span[1]) if span else None
        last = int(span[2] or span[1]) if span else None
        where = f" at lines {first}--{last}" if first else ""
        if first is not None and editable and any(line in editable for line in range(first, last + 1)):
            result.append(make("OVERFLOW_EDITABLE", MAJOR,
                               f"{name}: overfull box {size:.2f}pt in editable text{where}; shorten the replacement",
                               "builder", True, overrides))
        else:
            result.append(make("OVERFLOW_PROTECTED", ADVISORY,
                               f"{name}: overfull box {size:.2f}pt in protected template layout{where}",
                               "builder", False, overrides))
    return result, sizes


def build(candidate: dict[str, bytes], draft, directory: Path, config: dict, overrides: dict | None = None) -> dict:
    directory.mkdir(parents=True, exist_ok=False)
    executable = find_compiler(config)
    version, _ = run_process([executable, "--version"], directory, 15)
    build_started = perf_counter()
    results = {"compiler": version.splitlines()[0], "documents": {}, "findings": [], "timings": {}}
    add = lambda code, severity, message, fixable=True: results["findings"].append(make(code, severity, message, "builder", fixable, overrides))
    for name, data in candidate.items():
        source = directory / f"{name}.tex"
        source.write_bytes(data)
        args = [executable, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error", f"-output-directory={directory}", str(source)]
        # MiKTeX's package installer must not prompt or silently download during a run.
        if "MiKTeX" in version:
            args.insert(1, "--disable-installer")
        try:
            with Activity(f'{name.upper()} PDF compilation | {directory.name}', timeout=config['timeout_seconds']) as compile_timing:
                stdout, stderr = run_process(args, directory, config["timeout_seconds"])
        except ProcessFailure as exc:
            stdout, stderr = exc.stdout, exc.stderr
            add("COMPILE_FAILED", CRITICAL, f"{name}: compilation failed; see compiler logs", False)
        results['timings'][name] = {'compile': compile_timing}
        (directory / f"{name}.stdout.txt").write_text(stdout, encoding="utf-8")
        (directory / f"{name}.stderr.txt").write_text(stderr, encoding="utf-8")
        pdfpath = directory / f"{name}.pdf"
        if not pdfpath.is_file():
            add("PDF_MISSING", CRITICAL, f"{name}: no PDF was produced", False)
            continue
        extraction_started = perf_counter()
        emit(f'START {name.upper()} PDF text/layout checks and page previews')
        texlog = (directory / f"{name}.log").read_text(encoding="utf-8", errors="replace")
        found, overflows = overflow_findings(name, texlog, editable_lines(data), config["overflow_tolerance_pt"], overrides)
        results["findings"] += found
        warnings = [line for line in texlog.splitlines() if "Warning" in line or "Overfull" in line or "Underfull" in line]
        with fitz.open(pdfpath) as pdf:
            text = "\n\n".join(p.get_text(sort=True) for p in pdf)
            pages = len(pdf)
            for i, page in enumerate(pdf):
                page.get_pixmap(matrix=fitz.Matrix(1.25, 1.25)).save(directory / f"{name}-page-{i+1}.png")
            outside = [i + 1 for i, page in enumerate(pdf) if any(not page.rect.contains(fitz.Rect(b[:4])) for b in page.get_text("blocks") if b[4].strip())]
        if pages > config["page_limits"][name]:
            add("PAGE_LIMIT", MAJOR, f"{name}: {pages} pages exceeds {config['page_limits'][name]}")
        if outside:
            add("TEXT_OUTSIDE_PAGE", MAJOR, f"{name}: text outside page bounds {outside}")
        expected = ([draft.cv.summary] + [s.label + ": " + skill_text(s.items, config.get("python_packages", ())) for s in draft.cv.skills]) if name == "cv" else list(draft.cl_tokens.values())
        missing = [value for value in expected if value and not contains_replacement(value, text)]
        if missing or not text.strip() or "�" in text:
            add("TEXT_EXTRACTION", CRITICAL, f"{name}: missing/corrupt extracted replacement text")
        if name == "cv":
            positions = [text.find(s) for s in config["cv_sections"]]
            if any(p < 0 for p in positions) or positions != sorted(positions):
                add("SECTION_ORDER", MAJOR, "cv: section reading order not verified")
        (directory / f"{name}.extracted.txt").write_text(text, encoding="utf-8")
        results["documents"][name] = {"pages": pages, "text": text, "missing_text": missing, "warnings": warnings, "overflow_pt": overflows, "page_images": [f"{name}-page-{i+1}.png" for i in range(pages)]}
        extraction_elapsed = perf_counter() - extraction_started
        results['timings'][name]['extraction_and_checks_seconds'] = round(extraction_elapsed, 3)
        emit(f'DONE {name.upper()} PDF checks | {pages} page(s) | {len(missing)} missing text item(s) | '
             f'{len(warnings)} compiler warning(s) | {duration(extraction_elapsed)}')
    if set(results["documents"]) != {"cv", "cl"}:
        add("DOCUMENT_SET_INCOMPLETE", CRITICAL, "Both PDFs must compile and be extracted", False)
    results["visual_inspection"] = "Page images generated; no automated claim of visual review"
    results['elapsed_seconds'] = round(perf_counter() - build_started, 3)
    write_json(directory / "build_report.json", {**results, "findings": [f.as_dict() for f in results["findings"]]})
    return results
