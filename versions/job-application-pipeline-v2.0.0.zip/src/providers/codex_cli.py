"""Codex exec adapter, verified against installed 0.149.0 help."""
import json
from pathlib import Path
from src.process import run_process
from src.providers.base import ProviderFailure


def command(settings, schema_path: Path, output_path: Path, cwd: Path):
    args = [settings.executable, "exec", "--ignore-user-config", "--ephemeral", "--skip-git-repo-check", "--sandbox", "read-only", "--color", "never", "--json", "--output-schema", str(schema_path), "--output-last-message", str(output_path), "-C", str(cwd)]
    for value in ("approval_policy=\"never\"", "features.shell_tool=false", "features.unified_exec=false", "features.multi_agent=false", "features.apps=false", "features.memories=false", "web_search=\"disabled\""):
        args += ["-c", value]
    if settings.model:
        args += ["--model", settings.model]
    if settings.effort:
        args += ["-c", "model_reasoning_effort=" + json.dumps(settings.effort)]
    return args + ["-"]


def invoke(settings, prompt, schema_path, stage_dir, cwd):
    output = stage_dir / "last_message.json"
    args = command(settings, schema_path, output, cwd)
    stdout, stderr = run_process(args, cwd, settings.timeout_seconds, prompt)
    (stage_dir / "stdout.txt").write_text(stdout, encoding="utf-8")
    (stage_dir / "stderr.txt").write_text(stderr, encoding="utf-8")
    if not output.is_file():
        raise ProviderFailure("Codex returned no final message; see provider logs")
    # Fail if an unexpected tool was used despite the restricted invocation.
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if event.get('type') in {'error','turn.failed'}:
            raise ProviderFailure(f'Codex request failed: {event.get("error") or event.get("message") or event}')
        item_type = event.get("item", {}).get("type", "")
        if item_type in {"command_execution", "file_change", "mcp_tool_call", "web_search"}:
            raise ValueError(f"Unexpected Codex tool use: {item_type}")
    return output.read_text(encoding="utf-8")
