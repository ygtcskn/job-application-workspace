"""Byte-preserving rendering from masters, with code-owned LaTeX only."""
import re
from src.schemas import Draft

ESCAPES = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}


def escape(text: str) -> str:
    if any(ord(c) < 32 for c in text) or "{{" in text or "}}" in text:
        raise ValueError("Replacement must be one plain-text line without tokens or controls")
    return "".join(ESCAPES.get(c, c) for c in text)


def skill_text(items: list[str], packages=()) -> str:
    """A Skills line as printed: Python packages sit in brackets after Python."""
    grouped = [item for item in items if item in packages]
    if not grouped or "Python" not in items:
        return ", ".join(items)
    rest = [item for item in items if item not in packages]
    return ", ".join(f"Python ({', '.join(grouped)})" if item == "Python" else item for item in rest)


def boundaries(template: bytes) -> dict[str, tuple[int, int]]:
    anchors = list(re.finditer(rb"(?m)^[ \t]*% AI_EDIT_(START|END): ([A-Z0-9_]+)[ \t]*\r?\n", template))
    regions, active = {}, None
    for match in anchors:
        kind, name = match[1].decode(), match[2].decode()
        if kind == "START":
            if active or name in regions:
                raise ValueError(f"Duplicated or overlapping boundary: {name}")
            active = (name, match.end())
        else:
            if not active or active[0] != name:
                raise ValueError(f"Unmatched boundary: {name}")
            regions[name] = (active[1], match.start())
            active = None
    if active:
        raise ValueError("Unclosed boundary")
    if not {"SUMMARY", "SKILLS"} <= regions.keys():
        raise ValueError("Missing SUMMARY/SKILLS boundaries")
    return regions


def inspect_templates(cv: bytes, cl: bytes, rules: dict):
    boundaries(cv)
    if rules["cv_regions"] != ["SUMMARY", "SKILLS"]:
        raise ValueError("Only SUMMARY and SKILLS may be configured")
    found = set(re.findall(rb"\{\{[^{}\r\n]+\}\}", cl))
    expected = {t.encode() for t in rules["cl_tokens"]}
    if len(expected) != len(rules["cl_tokens"]) or found != expected:
        raise ValueError("CL token inventory differs from exact configured tokens")
    body = cl.split(b"\\begin{document}", 1)[-1]
    if any(t not in body for t in expected):
        raise ValueError("Configured token appears only in comments")


def render(cv: bytes, cl: bytes, draft: Draft, rules: dict) -> dict[str, bytes]:
    inspect_templates(cv, cl, rules)
    if draft.cv is None or set(draft.cl_tokens) != set(rules["cl_tokens"]):
        raise ValueError("Incomplete replacement set")
    newline = "\r\n" if b"\r\n" in cv else "\n"
    summary = "{\\small " + escape(draft.cv.summary) + "}" + newline + newline
    lines = [r"\resumeSubHeadingListStart"]
    for line in draft.cv.skills:
        lines.append(r"  \item\small{\textbf{" + escape(line.label) + ":} " + escape(skill_text(line.items, rules.get("python_packages", ()))) + "}")
    lines += [r"\resumeSubHeadingListEnd", ""]
    updates = {"SUMMARY": summary.encode(), "SKILLS": newline.join(lines).encode()}
    output = cv
    for name, (start, end) in sorted(boundaries(cv).items(), key=lambda x: x[1][0], reverse=True):
        if name in updates:
            output = output[:start] + updates[name] + output[end:]
    # One regex pass ensures replacements cannot become new replacement targets.
    # An empty LaTeX line followed by the protected \\ causes a compile error.
    # A code-owned empty box has no visible content and leaves that \\ untouched.
    values = {k.encode(): (escape(v).encode() if v else rb"\mbox{}") for k, v in draft.cl_tokens.items()}
    cl_out = re.sub(rb"\{\{[^{}\r\n]+\}\}", lambda m: values[m[0]], cl)
    for name, data in (("cv", output), ("cl", cl_out)):
        # Comments are stripped first: a token named in a maintainer note is documentation,
        # never PDF content, so it must not be mistaken for an unresolved substitution.
        active = re.sub(rb"(?m)^[ \t]*%.*$", b"", data)
        if re.search(rb"\{\{[A-Z][A-Z0-9_-]*\}\}", active):
            raise ValueError(f"Unresolved token in {name}")
    return {"cv": output, "cl": cl_out}


def protected_segments(template: bytes):
    cursor, parts = 0, []
    for name, (start, end) in sorted(boundaries(template).items(), key=lambda x: x[1][0]):
        if name in {"SUMMARY", "SKILLS"}:
            parts.append(template[cursor:start])
            cursor = end
    parts.append(template[cursor:])
    return parts


def validate_rendered(originals: dict[str, bytes], candidate: dict[str, bytes], draft: Draft, rules: dict):
    if protected_segments(originals["cv"]) != protected_segments(candidate["cv"]):
        raise ValueError("Protected CV bytes changed")
    expected = render(originals["cv"], originals["cl"], draft, rules)
    if candidate != expected:
        raise ValueError("Unauthorized edits or replacement mismatch")
