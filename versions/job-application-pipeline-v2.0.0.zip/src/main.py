"""Windows-friendly entry point; all paths are relative to this project."""
from __future__ import annotations
import argparse
import json
import sys
from src.input_loader import ROOT, available_jobs, job_id, load_config, load_sources, select_job, unique_job_id
from src.providers.base import SUPPORTED_PROVIDERS, resolve_settings, probe
from src.template_renderer import inspect_templates
from src.document_builder import find_compiler
from src.findings import CRITICAL, CRUCIAL, at, payload
from src.report import console_report
from src.validator import source_findings
from src.process import run_process


def parser():
    p = argparse.ArgumentParser(description="Tailor and review CV/CL through installed CLI providers")
    p.add_argument('--provider', choices=list(SUPPORTED_PROVIDERS), help='One provider for every agent in this run')
    p.add_argument('--model', help="Explicit identifier or 'default' for native default")
    p.add_argument('--effort', help="Explicit supported effort or 'default'")
    p.add_argument('--job', help='Process only this relative file; omit to process every available job')
    p.add_argument('--job-id', help='Custom output ID for a single --job only')
    p.add_argument('--job-directory', help='Override external job directory')
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--check', action='store_true')
    p.add_argument('--non-interactive', action='store_true')
    return p


def interactive(args, config):
    if args.provider is None:
        default_provider = config['execution']['provider']
        value = input(f"Provider for all agents: {' / '.join(SUPPORTED_PROVIDERS)} [{default_provider}]: ").strip().lower()
        if value and value not in SUPPORTED_PROVIDERS:
            raise ValueError(f"Select {', '.join(SUPPORTED_PROVIDERS)}, or leave blank")
        args.provider = value or default_provider
    probes = {}
    for settings in resolve_settings(config, args.provider).values():
        if settings.provider not in probes:
            try:
                probes[settings.provider] = probe(settings, ROOT)
            except (ValueError, RuntimeError) as exc:
                print(f'{settings.provider}: {exc}')
    for provider, info in probes.items():
        print(f"{provider}: model hints from installed CLI/cache: {', '.join(info['models']) or 'discovery unavailable'}")
        print(f"{provider}: response schema {info['schema_enforcement']}")
        print(info['availability'])
    if args.model is None:
        args.model = input('Model identifier [configured default], or default for native default: ').strip() or None
    if args.effort is None:
        for provider, info in probes.items():
            levels=info['efforts']
            if provider=='codex':
                from src.providers.base import model_catalog
                effective=next(s for s in resolve_settings(config,args.provider,args.model).values() if s.provider==provider)
                levels=model_catalog().get(effective.model,levels)
            if provider=='gemini':
                print('gemini: no reasoning-effort control; leave effort blank or enter default')
                continue
            print(f"{provider}: effort hints for the selection: {', '.join(levels) or 'discovery unavailable; live validation required'}")
        args.effort = input('Effort [configured default], or default for native default: ').strip() or None


def check(config, settings):
    sources = load_sources(config)
    inspect_templates(sources.files['cv_template.tex'].read_bytes(), sources.files['cl_template.tex'].read_bytes(), config['rules'])
    issues = source_findings(config['rules'], config['validation']['severity_overrides'])
    report = {'configuration': 'valid', 'templates': 'valid boundaries; source hashes checked', 'source_issues': payload(issues), 'publish_policy': config['review']['publish_policy'], 'job_directory': str(config['paths']['job_descriptions']), 'job_count': len(available_jobs(config['paths']['job_descriptions'])), 'providers': {}}
    ready = True
    for role, selected in settings.items():
        try:
            info = probe(selected, ROOT)
            report['providers'][role] = {**selected.metadata(), **{k:v for k,v in info.items() if k != 'help'}}
            if info['auth'] != 'signed in':
                ready = False
        except (ValueError, RuntimeError) as exc:
            ready = False
            report['providers'][role] = {'error': str(exc)}
    try:
        compiler = find_compiler(config['document'])
        version,_=run_process([compiler,'--version'],ROOT,20)
        report['compiler'] = {'path':compiler, 'version':version.splitlines()[0]}
    except (ValueError, RuntimeError) as exc:
        ready = False
        report['compiler'] = {'error':str(exc)}
    report['runtime_ready'] = ready
    report['approval_ready'] = ready and not at(issues, CRITICAL)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if at(issues, *CRUCIAL):
        console_report(issues, 'CHECK', config['paths']['input'])
    return 0 if ready else 1


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        config = load_config(ROOT, args.job_directory)
        if args.check:
            return check(config, resolve_settings(config,args.provider,args.model,args.effort))
        if args.job_id and not args.job:
            raise ValueError('--job-id requires --job; batch runs use each filename as its output ID')
        needs_selection = any(value is None for value in (args.provider,args.model,args.effort))
        if not args.non_interactive and not args.dry_run and needs_selection:
            if not sys.stdin.isatty():
                raise ValueError('Interactive input unavailable; use --non-interactive')
            interactive(args,config)
        settings = resolve_settings(config,args.provider,args.model,args.effort)
        if not args.job:
            from src.batch import run_batch
            return run_batch(config,settings,vars(args))
        job = select_job(config['paths']['job_descriptions'],args.job)
        identifier = unique_job_id(config['paths'], job_id(args.job_id,job.stem))
        from src.workflow import execute
        return execute(config,job,identifier,settings,vars(args))
    except (ValueError, RuntimeError, OSError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
