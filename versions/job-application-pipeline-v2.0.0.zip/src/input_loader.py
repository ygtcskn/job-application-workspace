"""Load only explicitly supplied sources, preserving originals and evidence."""
from __future__ import annotations
import hashlib
import json
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
import yaml
from src.providers.base import SUPPORTED_PROVIDERS

ROOT = Path(__file__).resolve().parents[1]
SUPPORTED = {".txt", ".md", ".pdf", ".docx"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def root_path(root: Path, value: str) -> Path:
    p = Path(value).expanduser()
    return (p if p.is_absolute() else root / p).resolve()


def load_config(root: Path = ROOT, job_dir: str | None = None) -> dict:
    config = yaml.safe_load((root / "config/pipeline.yaml").read_text(encoding="utf-8"))
    config["root"] = root.resolve()
    config["paths"] = {k: root_path(root, v) for k, v in config["paths"].items()}
    if job_dir:
        config["paths"]["job_descriptions"] = root_path(root, job_dir)
    if not 0 <= config["review"]["max_revision_rounds"] <= 3:
        raise ValueError("max_revision_rounds must be between 0 and 3")
    if not 75 <= config["review"]["minimum_score"] <= 100:
        raise ValueError("minimum_score must be 75..100")
    if not 0 <= config["review"]["format_retries"] <= 2:
        raise ValueError("format_retries must be 0..2")
    config["review"].setdefault("publish_policy", "always")
    if config["review"]["publish_policy"] not in ("always", "pass_only"):
        raise ValueError("review.publish_policy must be always or pass_only")
    validation = config.get("validation") or {}
    overrides = validation.get("severity_overrides") or {}
    if not isinstance(overrides, dict) or any(v not in ("critical", "major", "advisory") for v in overrides.values()):
        raise ValueError("validation.severity_overrides must map finding codes to critical/major/advisory")
    config["validation"] = {**validation, "severity_overrides": overrides}
    if set(config["agents"]) != {"agent_a", "agent_b", "agent_c"}:
        raise ValueError("Exactly roles A, B, C are required")
    if config.get('execution', {}).get('provider') not in SUPPORTED_PROVIDERS:
        raise ValueError(f"execution.provider must select one of {', '.join(SUPPORTED_PROVIDERS)} for all agents")
    missing = [p for p in SUPPORTED_PROVIDERS if p not in config.get('providers', {})]
    if missing:
        raise ValueError(f"providers configuration is missing {', '.join(missing)}")
    for role in config["agents"].values():
        if 'provider' in role:
            raise ValueError('Per-agent provider settings are not supported; use execution.provider or --provider')
    temp, final = config["paths"]["temporary"], config["paths"]["final"]
    for p in (temp, final):
        if not p.is_relative_to(root.resolve()) or p == root.resolve():
            raise ValueError("Output directories must be inside project root")
    if temp == final or temp.is_relative_to(final) or final.is_relative_to(temp):
        raise ValueError("Temporary and final directories must be separate")
    config["rules"] = yaml.safe_load((root / "config/editing_rules.yaml").read_text(encoding="utf-8"))
    rules = config["rules"]
    guidance = rules.get("cl_token_guidance") or {}
    if guidance and set(guidance) != set(rules["cl_tokens"]):
        raise ValueError("cl_token_guidance must describe exactly the configured cl_tokens")
    pages = config["document"]["page_limits"]
    if (rules["limits"].get("cv_pages"), rules["limits"].get("cl_pages")) != (pages["cv"], pages["cl"]):
        raise ValueError("editing_rules.limits cv_pages/cl_pages must match document.page_limits")
    inventory = {item for line in rules["mandatory"].values() for item in line}
    inventory |= {item for line in rules["optional"].values() for item in line}
    for group in rules.get("mutually_exclusive", []):
        unknown = sorted(set(group) - inventory)
        if len(group) < 2 or unknown:
            raise ValueError(f"mutually_exclusive groups need two or more approved skills; unknown: {unknown}")
    programming = set(rules["mandatory"].get("Programming", [])) | set(rules["optional"].get("Programming", []))
    stray = sorted(set(rules.get("python_packages", [])) - programming)
    if stray:
        raise ValueError(f"python_packages must be approved Programming items; unknown: {stray}")
    config["rubric"] = yaml.safe_load((root / "config/scoring_rubric.yaml").read_text(encoding="utf-8"))
    if list(config["rubric"]["criteria"].values()) != [40, 25, 20, 15]:
        raise ValueError("Rubric must retain 40/25/20/15 weights")
    return config


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md", ".tex"}:
        text = path.read_bytes().decode("utf-8-sig")
    elif suffix == ".pdf":
        import pymupdf as fitz
        with fitz.open(path) as pdf:
            text = "\n\n".join(page.get_text(sort=True) for page in pdf)
        if not text.strip():
            raise ValueError(f"{path.name}: no PDF text; scanned/image-only PDF requires OCR")
    elif suffix == ".docx":
        from docx import Document
        from docx.table import Table
        from docx.text.paragraph import Paragraph
        doc = Document(path)
        parts = []
        for element in doc.element.body:
            if element.tag.endswith("}p"):
                parts.append(Paragraph(element, doc).text)
            elif element.tag.endswith("}tbl"):
                parts.extend(" | ".join(c.text for c in row.cells) for row in Table(element, doc).rows)
        text = "\n".join(parts)
    else:
        raise ValueError(f"Unsupported input format: {suffix}")
    if not text.strip():
        raise ValueError(f"{path.name}: empty extracted input")
    return text


def available_jobs(directory: Path) -> list[Path]:
    if not directory.is_dir():
        raise ValueError(f"Job directory missing: {directory}")
    return sorted((p for p in directory.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED), key=lambda p: str(p).casefold())


def select_job(directory: Path, name: str) -> Path:
    candidate = Path(name)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError("--job must be a relative file inside the configured job directory")
    p = (directory / candidate).resolve()
    if not p.is_relative_to(directory.resolve()) or not p.is_file() or p.suffix.lower() not in SUPPORTED:
        raise ValueError(f"Unsupported or missing job file: {name}")
    return p


def job_id(value: str | None, stem: str) -> str:
    value = value if value is not None else re.sub(r"[^A-Za-z0-9_-]+", "_", stem).strip("_")[:64]
    if not value or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", value) or value.upper() in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(10)), *(f"LPT{i}" for i in range(10))}:
        raise ValueError("Unsafe job ID; use 1–64 ASCII letters, digits, underscore or hyphen")
    return value if value.startswith("job_") else f"job_{value}"


def unique_job_id(paths: dict, identifier: str, taken=()) -> str:
    """The next free output id. Reruns never overwrite earlier evidence, and never
    stop the batch either: job_x becomes job_x_r2, then job_x_r3, and so on."""
    taken = {value.casefold() for value in taken}
    candidate, index = identifier, 1
    while candidate.casefold() in taken or any((paths[kind] / candidate).exists() for kind in ("temporary", "final")):
        index += 1
        suffix = f"_r{index}"
        candidate = identifier[:64 - len(suffix)] + suffix
    return candidate


@dataclass
class Sources:
    files: dict[str, Path]
    hashes: dict[str, str]
    texts: dict[str, str]

    def verify(self):
        for name, path in self.files.items():
            if not path.is_file() or sha256(path) != self.hashes[name]:
                raise ValueError(f"Source changed during run: {name}")

    def snapshot(self, directory: Path):
        self.verify()
        directory.mkdir(parents=True, exist_ok=False)
        for name, path in self.files.items():
            dest = directory / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)
            if sha256(dest) != self.hashes[name]:
                raise ValueError(f"Snapshot changed: {name}")
        write_json(directory / "hashes.json", self.hashes)
        write_json(directory / "extracted_sources.json", self.texts)
        self.verify()


def load_sources(config: dict, job: Path | None = None) -> Sources:
    root, inp = config["root"], config["paths"]["input"]
    files = {n: inp / n for n in ("cv_template.tex", "cl_template.tex", "skills_profile.md")}
    files.update({f"agents/{role}.md": root_path(root, spec["prompt"]) for role, spec in config["agents"].items()})
    files.update({f"config/{n}.yaml": root / f"config/{n}.yaml" for n in ("pipeline", "editing_rules", "scoring_rubric")})
    if job:
        files[f"job/{job.name}"] = job
    for name, path in files.items():
        if not path.is_file():
            raise ValueError(f"Missing source {name}: {path}")
    hashes = {n: sha256(p) for n, p in files.items()}
    texts = {n: extract_text(p) if p.suffix != ".yaml" else p.read_text(encoding="utf-8") for n, p in files.items()}
    sources = Sources(files, hashes, texts)
    sources.verify()
    return sources
