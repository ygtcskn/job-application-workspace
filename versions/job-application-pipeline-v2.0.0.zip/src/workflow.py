"""Bounded sequential orchestration and application-owned final publication.

The pipeline always finishes the documents it can build. Remaining problems are
recorded in a validation report and printed in red, instead of withholding PDFs.
"""
from __future__ import annotations
import json
import shutil
import tempfile
from pathlib import Path
from src.agent_runner import assemble, invoke_role, now
from src.findings import ADVISORY, CRITICAL, MAJOR, counts, make, messages, ordered
from src.input_loader import load_sources, sha256, write_json
from src.report import console_report, markdown_report, report_payload
from src.schemas import Draft, Review, RunMetadata
from src.providers.base import probe, schema_for, ProviderFailure
from src.template_renderer import render, inspect_templates, validate_rendered
from src.document_builder import build
from src.validator import validate_draft, decision, draft_findings, review_findings, score_findings, source_findings
from src.progress import JobProgress, emit

DOCUMENTS = ('cv.tex', 'cv.pdf', 'cl.tex', 'cl.pdf')
OUTPUT_NAMES = {'cv.pdf': 'yigit_coskun_cv.pdf', 'cl.pdf': 'yigit_coskun_cl.pdf'}
# Documents published; the report travels with them. Distinct from PASS so a batch
# can still tell a clean run from one that needs a human read.
PUBLISHED_WITH_FINDINGS = 3


def publish(build_dir: Path, final_dir: Path, expected_hashes: dict[str, str], extras: dict[str, str] | None = None):
    if set(expected_hashes) != set(DOCUMENTS):
        raise ValueError('Cannot publish incomplete candidate set')
    if final_dir.exists():
        raise ValueError('Final output collision')
    final_dir.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix='.publishing-',dir=final_dir.parent))
    try:
        for name in DOCUMENTS:
            source=build_dir/name
            if not source.is_file() or sha256(source)!=expected_hashes[name]:
                raise ValueError(f'Reviewed candidate changed: {name}')
            destination = staging / OUTPUT_NAMES.get(name, name)
            shutil.copyfile(source,destination)
            if sha256(destination)!=expected_hashes[name]:
                raise ValueError(f'Publication hash mismatch: {name}')
        for name, text in (extras or {}).items():
            (staging/name).write_text(text,encoding='utf-8')
        # Directory rename on the same filesystem makes all files appear together.
        staging.rename(final_dir)
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def execute(config, job, identifier, settings, requested, runner=invoke_role, builder=build):
    if set(settings) != {'agent_a', 'agent_b', 'agent_c'} or len({s.provider for s in settings.values()}) != 1:
        raise ValueError('All three agents must use the same provider for this run')
    overrides=config.get('validation',{}).get('severity_overrides',{})
    policy=config['review'].get('publish_policy','always')
    progress=JobProgress(identifier)
    findings=[]
    published=None
    progress.start('load and validate inputs')
    try:
        sources=load_sources(config,job)
        originals={name:sources.files[f'{name}_template.tex'].read_bytes() for name in ('cv','cl')}
        inspect_templates(originals['cv'],originals['cl'],config['rules'])
        temp=config['paths']['temporary']/identifier
        final=config['paths']['final']/identifier
        if final.exists():
            raise ValueError(f'Final output collision: {identifier}')
        temp.mkdir(parents=True,exist_ok=False)
    except BaseException:
        progress.finish('FAILED')
        raise
    log=RunMetadata(job_id=identifier,source_hashes=sources.hashes,stage='snapshot',round=0,started_at=now(),updated_at=now(),settings={'requested':requested,'agents':{k:s.metadata() for k,s in settings.items()}},final_status='RUNNING',reasons=[])
    def save(stage=None):
        if stage:
            log.stage=stage
            progress.start(stage)
        log.updated_at=now()
        log.elapsed_seconds=progress.elapsed_seconds
        log.stage_timings=progress.records
        log.settings['agents']={k:s.metadata() for k,s in settings.items()}
        write_json(temp/'run_log.json',log.model_dump())
    def report(status, totals, round_number):
        """One report per run, refreshed each round and copied beside published documents."""
        context={'job_id':identifier,'status':status,'scores':totals,'round':round_number,
                 'max_rounds':config['review']['max_revision_rounds'],'publish_policy':policy,
                 'destination':str(final if status in ('PASS','PUBLISHED_WITH_FINDINGS') else temp),
                 'generated_at':now()}
        text=markdown_report(findings,context)
        payload=report_payload(findings,context)
        (temp/'validation_report.md').write_text(text,encoding='utf-8')
        write_json(temp/'validation_report.json',payload)
        log.reasons=messages(findings) or ['No validation findings']
        return {'validation_report.md':text,'validation_report.json':json.dumps(payload,ensure_ascii=False,indent=2)}
    try:
        save('snapshot')
        sources.snapshot(temp/'source_snapshot')
        findings+=source_findings(config['rules'],overrides)
        if requested.get('dry_run'):
            save('construct dry-run requests')
            for role in settings:
                contract=Review if role=='agent_c' else Draft
                schema=schema_for(contract,config['rules'],config['rubric']['criteria'])
                context={'dry_run':True,'dependent_inputs':'Will be supplied from the preceding live stage; this request is a preview only.'}
                prompt=assemble(role,sources,config['rules'],config['rubric'],context,schema)
                (temp/f'{role}.request.txt').write_text(prompt,encoding='utf-8')
            log.final_status='DRY_RUN'
            log.reasons=messages(findings) or ['No validation findings']
            emit('Dry run complete — no AI CLI invoked')
            return 0
        save('provider preflight')
        for role, selected in settings.items():
            try:
                info=probe(selected,config['root'])
            except (ValueError,RuntimeError,OSError) as exc:
                raise ProviderFailure(f'{selected.provider} preflight failed: {exc}') from exc
            write_json(temp/f'{role}.provider.json',{k:v for k,v in info.items() if k!='help'})
            (temp/f'{role}.help.txt').write_text(info['help'],encoding='utf-8')
            if info['auth']=='not signed in':
                raise ProviderFailure(f'{selected.provider}: sign in manually before running')
            emit(f"{role}: {selected.provider} | {info['version'] if 'version' in info else selected.version} | "
                 f"model={selected.model or 'provider default'} | effort={selected.effort or 'provider default'} | auth={info['auth']}")
        log.settings['agents']={k:s.metadata() for k,s in settings.items()}
        retries=config['review']['format_retries']
        def call(role, context, path):
            sources.verify()
            result=runner(role,settings[role],sources,config['rules'],config['rubric'],context,path,retries)
            sources.verify()
            return result
        save('Agent A — writer')
        draft=call('agent_a',{'round':0},temp/'agent_a')
        if draft.cv is None:
            findings+=draft_findings(draft,'agent_a',overrides)
            log.final_status='NEEDS_USER_REVIEW'
            report(log.final_status,{},0)
            return 2
        source_notes=source_findings(config['rules'],overrides)+draft_findings(draft,'agent_a',overrides)
        errors=validate_draft(draft,config['rules'],sources.texts,overrides)
        feedback=None
        max_rounds=config['review']['max_revision_rounds']
        for round_number in range(max_rounds+1):
            log.round=round_number
            # B receives the full assembled current documents when structurally safe.
            try:
                previous=render(originals['cv'],originals['cl'],draft,config['rules'])
                previous={k:v.decode('utf-8') for k,v in previous.items()}
            except ValueError:
                previous={'assembly_error':'Previous replacements could not be safely rendered; correct validation findings.'}
            save(f'Agent B — optimization round {round_number}')
            context={'round':round_number,'current_replacements':draft.model_dump(),'assembled_documents':previous,
                     'validation_findings':[f.as_dict() for f in ordered(errors+source_notes)],'review':feedback}
            draft=call('agent_b',context,temp/'agent_b'/f'round_{round_number}')
            if draft.cv is None:
                findings=source_findings(config['rules'],overrides)+draft_findings(draft,'agent_b',overrides)
                log.final_status='NEEDS_USER_REVIEW'
                report(log.final_status,{},round_number)
                return 2
            # Each round is judged on its own candidate; stale notes never accumulate.
            source_notes=source_findings(config['rules'],overrides)+draft_findings(draft,'agent_b',overrides)
            errors=validate_draft(draft,config['rules'],sources.texts,overrides)
            emit(f'Round {round_number}: {len(errors)} replacement validation issue(s)')
            build_dir=temp/'build'/f'round_{round_number}'
            save(f'render and compile round {round_number}')
            try:
                candidate=render(originals['cv'],originals['cl'],draft,config['rules'])
                validate_rendered(originals,candidate,draft,config['rules'])
                results=builder(candidate,draft,build_dir,{**config['document'],'python_packages':config['rules'].get('python_packages',[])},overrides)
                errors+=results['findings']
            except ValueError as exc:
                candidate={}
                results={'documents':{},'findings':[]}
                errors.append(make('RENDER_FAILED',CRITICAL,str(exc),'render',True,overrides))
            sources.verify()
            hashes={name:sha256(build_dir/name) for name in DOCUMENTS if (build_dir/name).is_file()}
            write_json(temp/'reviews'/f'round_{round_number}.checks.json',
                       {'findings':[f.as_dict() for f in ordered(errors+source_notes)],'reviewed_hashes':hashes})
            save(f'Agent C — review round {round_number}')
            context={'round':round_number,'replacements':draft.model_dump(),
                     'documents':{k:v.decode('utf-8') for k,v in candidate.items()},
                     'pdf_checks':{k:v for k,v in results.items() if k!='findings'},
                     'validation_findings':[f.as_dict() for f in ordered(errors)],
                     'source_findings':[f.as_dict() for f in ordered(source_notes)],'previous_review':feedback}
            review=call('agent_c',context,temp/'reviews'/f'round_{round_number}')
            save(f'score and decision checks round {round_number}')
            threshold=config['review']['minimum_score']
            findings=ordered(errors+source_notes+review_findings(review,overrides)
                             +score_findings(review.totals(config['rubric']['criteria']),threshold,overrides))
            status,totals=decision(review,config['rubric']['criteria'],findings,round_number,max_rounds,threshold,policy)
            feedback={**review.model_dump(),'computed_scores':totals,'enforced_decision':status}
            write_json(temp/'reviews'/f'round_{round_number}.json',feedback)
            tally=counts(findings)
            emit(f"CV {totals['cv']}/100; CL {totals['cl']}/100 — {status} | round {round_number}/{max_rounds} | "
                 f"{tally[CRITICAL]} critical, {tally[MAJOR]} major, {tally[ADVISORY]} advisory finding(s)")
            if status in ('PASS','PUBLISH'):
                save('publish reviewed documents')
                sources.verify()
                # Re-check exact reviewed TEX bytes and all four file hashes, no rebuild.
                try:
                    if set(hashes)!=set(DOCUMENTS):
                        raise ValueError(f'Incomplete candidate set: {sorted(set(DOCUMENTS)-set(hashes))}')
                    actual={n:(build_dir/f'{n}.tex').read_bytes() for n in ('cv','cl')}
                    validate_rendered(originals,actual,draft,config['rules'])
                except (OSError,ValueError) as exc:
                    findings.append(make('PUBLICATION_INTEGRITY',CRITICAL,f'Reviewed bytes failed the final check: {exc}','publish',False,overrides))
                    log.final_status='NEEDS_USER_REVIEW'
                    report(log.final_status,totals,round_number)
                    return 2
                log.final_status='PASS' if status=='PASS' else 'PUBLISHED_WITH_FINDINGS'
                publish(build_dir,final,hashes,report(log.final_status,totals,round_number))
                published=final
                return 0 if status=='PASS' else PUBLISHED_WITH_FINDINGS
            if status=='NEEDS_USER_REVIEW':
                log.final_status=status
                report(log.final_status,totals,round_number)
                return 2
        raise RuntimeError('Invalid workflow fallthrough')
    except KeyboardInterrupt:
        log.final_status='INTERRUPTED'
        log.reasons=['Interrupted by user']
        raise
    except Exception as exc:
        log.final_status='FAILED'
        log.reasons=[str(exc)]
        raise
    finally:
        progress.finish(log.final_status)
        log.stage='complete'
        save()
        destination=published or temp
        print(f'{log.final_status}: {destination}',flush=True)
        if findings:
            console_report(findings,log.final_status,destination)
        else:
            for reason in log.reasons:
                print(f'- {reason}',flush=True)
