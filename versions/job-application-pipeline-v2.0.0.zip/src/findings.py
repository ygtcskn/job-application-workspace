"""Severity-classified findings.

Publication is withheld only for defects that leave no trustworthy artefact.
Everything else is published together with a validation report, so a run always
finishes its PDFs instead of stopping on an advisory note.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass

CRITICAL, MAJOR, ADVISORY = "critical", "major", "advisory"
# Ranking drives report ordering and the red/yellow console split.
RANK = {CRITICAL: 0, MAJOR: 1, ADVISORY: 2}
CRUCIAL = (CRITICAL, MAJOR)


@dataclass(frozen=True)
class Finding:
    code: str
    severity: str
    message: str
    origin: str
    fixable: bool = True

    def __post_init__(self):
        if self.severity not in RANK:
            raise ValueError(f"Unknown severity {self.severity!r} for {self.code}")

    @property
    def label(self) -> str:
        return f"[{self.severity.upper()}] {self.code}: {self.message}"

    def as_dict(self) -> dict:
        return asdict(self)


def make(code: str, severity: str, message: str, origin: str, fixable: bool = True, overrides: dict | None = None) -> Finding:
    """Configuration may promote or demote any code; the policy stays application-owned."""
    return Finding(code, (overrides or {}).get(code, severity), message, origin, fixable)


def dedupe(findings) -> list[Finding]:
    seen, result = set(), []
    for finding in findings:
        key = (finding.code, finding.message)
        if key not in seen:
            seen.add(key)
            result.append(finding)
    return result


def ordered(findings) -> list[Finding]:
    return sorted(dedupe(findings), key=lambda f: (RANK[f.severity], f.origin, f.code, f.message))


def at(findings, *severities) -> list[Finding]:
    return [f for f in findings if f.severity in severities]


def counts(findings) -> dict[str, int]:
    return {severity: len(at(findings, severity)) for severity in RANK}


def payload(findings) -> list[dict]:
    return [f.as_dict() for f in ordered(findings)]


def messages(findings) -> list[str]:
    """Plain lines for prompts, run logs and legacy string consumers."""
    return [f.label for f in ordered(findings)]
