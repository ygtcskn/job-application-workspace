"""Strict transport contracts. Model totals are never trusted."""
from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class SkillLine(Strict):
    label: str
    items: list[str] = Field(min_length=1)


class CV(Strict):
    summary: str = Field(min_length=1)
    skills: list[SkillLine] = Field(min_length=5, max_length=5)


class Evidence(Strict):
    claim_id: str
    field: str
    claim: str
    # Vacancy text can name the advertised role without establishing applicant facts.
    claim_type: Literal["applicant_fact", "role_target"]
    source: str
    excerpt: str = Field(min_length=1)
    location: str


class Resolution(Strict):
    finding_id: str
    status: Literal["Resolved", "Partially resolved", "Cannot resolve"]
    explanation: str


class Draft(Strict):
    status: Literal["READY", "BLOCKED"]
    cv: CV | None
    cl_tokens: dict[str, str]
    evidence: list[Evidence]
    change_log: list[str]
    source_conflicts: list[str]
    qualification_gaps: list[str]
    feedback_resolutions: list[Resolution]
    input_issues: list[str]

    @model_validator(mode="after")
    def usable(self):
        if self.status == "READY" and self.cv is None:
            raise ValueError("READY requires cv")
        if self.status == "BLOCKED" and not (self.input_issues or self.source_conflicts):
            raise ValueError("BLOCKED requires specific issues")
        return self


class Criterion(Strict):
    points: int = Field(ge=0)
    maximum: int = Field(ge=1)
    reason: str = Field(min_length=1)


class Finding(Strict):
    id: str
    field: str
    problem: str
    evidence: str
    correction: str
    fixable: bool
    blocking: bool


class Review(Strict):
    decision: Literal["PASS", "REVISE", "NEEDS_USER_REVIEW"]
    cv_scores: dict[str, Criterion]
    cl_scores: dict[str, Criterion]
    findings: list[Finding]
    parsing_status: Literal["Verified", "Issues found", "Not verified"]
    parsing_evidence: str
    blocking_issues: list[str]
    revision_instructions: list[str]
    qualification_gaps: list[str]

    def totals(self, rubric: dict[str, int]) -> dict[str, int]:
        totals = {}
        for name, scores in (("cv", self.cv_scores), ("cl", self.cl_scores)):
            if set(scores) != set(rubric):
                raise ValueError(f"{name}: criterion names differ from rubric")
            for key, score in scores.items():
                if score.maximum != rubric[key] or score.points > score.maximum:
                    raise ValueError(f"{name}.{key}: invalid score or maximum")
            totals[name] = sum(score.points for score in scores.values())
        return totals


class RunMetadata(Strict):
    job_id: str
    source_hashes: dict[str, str]
    stage: str
    round: int
    started_at: str
    updated_at: str
    settings: dict
    final_status: str
    reasons: list[str]
    elapsed_seconds: float = 0.0
    stage_timings: list[dict] = Field(default_factory=list)
