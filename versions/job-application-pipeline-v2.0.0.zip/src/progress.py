"""Timestamped console progress and monotonic elapsed times, without model text."""
from __future__ import annotations
from datetime import datetime, timezone
from threading import Event, Thread
from time import perf_counter


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def duration(seconds):
    seconds = max(0.0, seconds)
    if seconds < 60:
        return f'{seconds:.1f}s'
    minutes, remainder = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    return f'{hours}h {minutes:02d}m {remainder:02d}s' if hours else f'{minutes}m {remainder:02d}s'


def emit(message):
    print(f'[{datetime.now().astimezone():%H:%M:%S}] {message}', flush=True)


class Activity:
    """Live elapsed updates while a blocking provider or compiler call runs."""
    def __init__(self, label, timeout=None, heartbeat_seconds=15):
        self.label, self.timeout, self.heartbeat_seconds = label, timeout, heartbeat_seconds
        self.record = {}
        self.stop = Event()

    def __enter__(self):
        self.started = perf_counter()
        self.record.update(started_at=timestamp(), status='RUNNING')
        limit = f' | timeout {duration(self.timeout)}' if self.timeout else ''
        emit(f'START {self.label}{limit}')
        self.thread = Thread(target=self._heartbeat, daemon=True)
        self.thread.start()
        return self.record

    def _heartbeat(self):
        while not self.stop.wait(self.heartbeat_seconds):
            elapsed = perf_counter() - self.started
            limit = f' / timeout {duration(self.timeout)}' if self.timeout else ''
            emit(f'WAIT  {self.label} | elapsed {duration(elapsed)}{limit} | process still running')

    def __exit__(self, exc_type, exc, traceback):
        self.stop.set()
        self.thread.join()
        elapsed = perf_counter() - self.started
        status = 'DONE' if exc_type is None else ('INTERRUPTED' if issubclass(exc_type, KeyboardInterrupt) else 'FAILED')
        self.record.update(finished_at=timestamp(), elapsed_seconds=round(elapsed, 3), status=status)
        emit(f'{status} {self.label} | elapsed {duration(elapsed)}')
        return False


class JobProgress:
    def __init__(self, identifier):
        self.identifier = identifier
        self.started = perf_counter()
        self.records = []
        self.active = None

    @property
    def elapsed_seconds(self):
        return round(perf_counter() - self.started, 3)

    def start(self, stage):
        self._close('DONE')
        self.stage_started = perf_counter()
        self.active = {'stage': stage, 'started_at': timestamp(), 'status': 'RUNNING'}
        self.records.append(self.active)
        emit(f'{self.identifier} | +{duration(self.elapsed_seconds)} | START {stage}')

    def _close(self, status):
        if self.active is not None:
            elapsed = perf_counter() - self.stage_started
            self.active.update(finished_at=timestamp(), elapsed_seconds=round(elapsed, 3), status=status)
            emit(f"{self.identifier} | {status} {self.active['stage']} | {duration(elapsed)}")
            self.active = None

    def finish(self, status):
        self._close(status)
        emit(f'{self.identifier} | {status} | TOTAL {duration(self.elapsed_seconds)}')
        for record in self.records:
            emit(f"  {record['stage']}: {duration(record['elapsed_seconds'])}")
