"""Sequential all-job execution with per-job results and a durable batch report."""
from __future__ import annotations
import pathlib
from collections import Counter
from copy import deepcopy
from uuid import uuid4
from time import perf_counter
from src.agent_runner import now
from src.input_loader import available_jobs, job_id, select_job, unique_job_id, write_json
from src.providers.base import ProviderFailure
from src.process import ProcessFailure
from src.progress import emit, duration

# Exit codes shared with src.main: 0 clean, 2 review required, 3 published with findings.
STATUS_BY_CODE = {0: 'PASS', 2: 'NEEDS_USER_REVIEW', 3: 'PUBLISHED_WITH_FINDINGS'}
PUBLISHED = {'PASS', 'PUBLISHED_WITH_FINDINGS'}


def run_batch(config, settings, requested, executor=None):
    batch_started=perf_counter()
    if executor is None:
        from src.workflow import execute
        executor = execute
    directory = config['paths']['job_descriptions']
    jobs = available_jobs(directory)
    if not jobs:
        raise ValueError(f'No supported job descriptions in {directory}')
    batch_id = 'batch_' + now().replace(':','').replace('-','').replace('+','_') + '_' + uuid4().hex[:8]
    report_path = config['paths']['temporary'] / 'batches' / f'{batch_id}.json'
    report = {'batch_id':batch_id, 'started_at':now(), 'updated_at':now(), 'status':'RUNNING',
              'requested':requested, 'settings':{r:s.metadata() for r,s in settings.items()},
              'jobs':[{'job':str(p.relative_to(directory)), 'status':'PENDING'} for p in jobs]}
    def save():
        report['updated_at']=now()
        report['elapsed_seconds']=round(perf_counter()-batch_started,3)
        report['counts']=dict(Counter(row['status'] for row in report['jobs']))
        write_json(report_path,report)
    # A posting that already has output is done; a batch only picks up new ones.
    done, claimed = 0, set()
    for row in report['jobs']:
        identifier = job_id(None, pathlib.Path(row['job']).stem)
        existing = any((config['paths'][kind] / identifier).exists() for kind in ('temporary', 'final'))
        if existing or identifier.casefold() in claimed:
            reason = ('Output already exists' if existing else
                      f'Another file in this batch already uses the ID {identifier}')
            row.update(status='SKIPPED', job_id=identifier,
                       reason=f'{reason}; rerun with -Job and -JobId to redo it')
            done += 1
        claimed.add(identifier.casefold())
    pending = [row for row in report['jobs'] if row['status'] == 'PENDING']
    save()
    if done:
        emit(f'{done} of {len(jobs)} job descriptions already have output and are skipped.')
    emit(f'Processing {len(pending)} new job description(s) sequentially.')
    selected=next(iter(settings.values()))
    emit(f'Provider: {selected.provider} | Model: {selected.model or "provider default"} | Effort: {selected.effort or "provider default"}')
    emit(f'Batch report: {report_path}')
    used_ids=set()
    provider_error=False
    try:
        for index,row in enumerate(pending,1):
            emit(f"JOB {index}/{len(pending)} | {row['job']} | batch elapsed {duration(perf_counter()-batch_started)}")
            job_started=perf_counter()
            row['started_at']=now()
            try:
                job=select_job(directory,row['job'])
                preferred=job_id(None,job.stem)
                identifier=unique_job_id(config['paths'],preferred,used_ids)
                row['job_id']=identifier
                if identifier!=preferred:
                    # Earlier output for this posting is kept; this run gets its own folder.
                    row['rerun_of']=preferred
                    emit(f'{preferred} already has output; this run writes to {identifier}')
                used_ids.add(identifier.casefold())
                row['status']='RUNNING'
                save()
                job_request={**requested,'job':row['job'],'job_id':identifier,'batch_id':batch_id}
                # Keep the selected settings, without leaking resolved metadata between jobs.
                code=executor(config,job,identifier,deepcopy(settings),job_request)
                row['exit_code']=code
                row['status']=STATUS_BY_CODE.get(code,'FAILED')
                if code==0 and requested.get('dry_run'):
                    row['status']='DRY_RUN'
                row['output']=str(config['paths']['final' if row['status'] in PUBLISHED else 'temporary']/identifier)
            except (ProviderFailure,ProcessFailure) as exc:
                row['status']='FAILED'
                row['reason']=str(exc)
                provider_error=True
                print(f'Provider failed; stopping batch: {exc}',flush=True)
                break
            except (ValueError,RuntimeError,OSError) as exc:
                row['status']='FAILED'
                row['reason']=str(exc)
                print(f"Job failed; continuing: {exc}",flush=True)
            finally:
                row['finished_at']=now()
                row['elapsed_seconds']=round(perf_counter()-job_started,3)
                if row['status']=='RUNNING':
                    row['status']='INTERRUPTED'
                save()
                emit(f"JOB {index}/{len(pending)} | {row['status']} | took {duration(row['elapsed_seconds'])} | "
                     f"batch elapsed {duration(report['elapsed_seconds'])}")
    finally:
        for row in report['jobs']:
            if row['status']=='PENDING':
                row['status']='NOT_RUN'
                row['reason']='Provider failure stopped the batch' if provider_error else 'Batch interrupted'
            elif row['status']=='RUNNING':
                row['status']='INTERRUPTED'
        statuses={row['status'] for row in report['jobs']}
        if statuses & {'FAILED','NOT_RUN','INTERRUPTED'}:
            exit_code, report['status'] = 1, 'INCOMPLETE'
        elif 'NEEDS_USER_REVIEW' in statuses:
            exit_code, report['status'] = 2, 'NEEDS_USER_REVIEW'
        elif 'PUBLISHED_WITH_FINDINGS' in statuses:
            exit_code, report['status'] = 3, 'PUBLISHED_WITH_FINDINGS'
        else:
            exit_code, report['status'] = 0, 'COMPLETED'
        report['exit_code']=exit_code
        report['finished_at']=now()
        save()
        emit('Batch summary: '+', '.join(f'{n} {status}' for status,n in report['counts'].items()))
        emit(f"Total batch time: {duration(report['elapsed_seconds'])}")
        for index,row in enumerate([r for r in report['jobs'] if r['status']!='SKIPPED'],1):
            elapsed=duration(row['elapsed_seconds']) if 'elapsed_seconds' in row else 'not started'
            emit(f"  {index:>3}. {elapsed:>12} | {row['status']:<18} | {row['job']}")
        if done:
            emit(f'  {done} already-processed job description(s) skipped.')
        emit(f'Results: {report_path}')
    return exit_code
