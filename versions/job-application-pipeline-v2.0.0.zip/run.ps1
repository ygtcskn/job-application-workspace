[CmdletBinding()]
# Omitting -Job processes every available job description sequentially.
param(
    [ValidateSet('codex', 'claude', 'gemini')][string] $Provider,
    [string] $Model,
    [string] $Effort,
    [string] $Job,
    [string] $JobId,
    [string] $JobDirectory,
    [switch] $DryRun,
    [switch] $Check,
    [switch] $NonInteractive
)
$ErrorActionPreference = 'Stop'
$PythonExe = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $PythonExe)) {
    if ($env:CV_PIPELINE_PYTHON) { $PythonExe = $env:CV_PIPELINE_PYTHON }
    else { $PythonExe = (Get-Command python -ErrorAction Stop).Source }
}
$PythonArgs = @('-u', '-m', 'src.main')
$OptionMap = @{Provider='--provider'; Model='--model'; Effort='--effort'; Job='--job'; JobId='--job-id'; JobDirectory='--job-directory'}
foreach ($Key in $OptionMap.Keys) {
    if ($PSBoundParameters.ContainsKey($Key)) { $PythonArgs += @($OptionMap[$Key], [string]$PSBoundParameters[$Key]) }
}
if ($DryRun) { $PythonArgs += '--dry-run' }
if ($Check) { $PythonArgs += '--check' }
if ($NonInteractive) { $PythonArgs += '--non-interactive' }
$PreviousUtf8 = $env:PYTHONUTF8
$ExitCode = 1
Push-Location $PSScriptRoot
try {
    $env:PYTHONUTF8 = '1'
    & $PythonExe @PythonArgs
    $ExitCode = $LASTEXITCODE
}
finally {
    $env:PYTHONUTF8 = $PreviousUtf8
    Pop-Location
}
exit $ExitCode
