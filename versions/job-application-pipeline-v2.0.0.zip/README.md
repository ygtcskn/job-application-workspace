```powershell
.\run.ps1 -Provider claude -Model opus -Effort medium
```
```powershell
.\run.ps1 -Provider gemini -Model gemini-3.1-pro -Effort default
```
```powershell
.\run.ps1 -Provider codex -Model gpt-5.6-sol -Effort medium
```
# CV and cover letter pipeline

A Windows/Python application that uses installed Codex CLI, Claude Code and Gemini CLI to write, optimize, and independently review CVs and cover letters for **all available job descriptions, sequentially**. Use `-Job` to limit a run to one file. CV edits are limited to SUMMARY and SKILLS. Cover-letter edits are limited to the nine existing tokens. Agents return structured replacements; Python owns rendering, validation, compilation, scoring gates, and publication.

Current build: **2.0.0**. The previous project's preserved ZIPs remain under `versions/`. The master build specification is `docs/BUILD_PROJECT.md`. Implementation and verification history is in `PROGRESS.md`.

## Quick start on this machine

```powershell
Set-Location 'C:\Users\ygtcs\Desktop\Work\Work\job_py'
.\run.ps1 -Check -NonInteractive
.\run.ps1
```

The project virtual environment is installed. With no launcher parameters, select **one provider for all three agents**, model, and effort; the pipeline then processes every supported job file automatically. There is no job-number prompt. Press Enter at the provider prompt to use the configured default (Codex). You can choose Codex, Claude or Gemini anew on every run. Model and effort hints come from installed help or Codex's local model cache; they are not an authoritative account-access catalog. Gemini CLI advertises no reasoning-effort control, so leave effort blank or enter `default` for it. It also discloses no model default in help, so its model list shows as unavailable; omitting `-Model` lets the CLI route models itself, and the run log records whichever model served the `main` role. Not every published Gemini model name is enabled on every account: on this machine `gemini-3.5-flash` works while `gemini-3.1-pro` and `gemini-3.5-pro` return `not found for API version v1beta`. You can enter an explicit model identifier. A provider rejection stops the batch; no model or effort is silently substituted.

Process every job with the selected settings:

```powershell
.\run.ps1 -Provider claude -Model opus -Effort medium
```

When all three settings are explicit, execution starts without interactive questions. An all-job example using Codex's native defaults:

```powershell
.\run.ps1 -Provider codex -NonInteractive
```

**Every runnable candidate is finished and published.** A run compiles both PDFs, uses its full revision budget, and publishes the reviewed set together with a validation report. Remaining problems are recorded there and printed in red in PowerShell instead of withholding the documents. Publication is withheld only for a **critical** finding, meaning no trustworthy artefact exists: a compilation failure, a missing PDF, missing or corrupt extracted replacement text, or an integrity violation. Reusing an existing job ID fails rather than overwriting prior evidence.

## Environment setup on another Windows installation

Use Python 3.11 or newer (verified here with Python 3.12):

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Install and sign in to Codex CLI, Claude Code and/or Gemini CLI through their own supported login flows. CLI authentication suffices; this application does not require an API key, read credential files, initiate login, or load `.env`. `.env.example` contains no credentials. `-Check` reads safe authentication status only, omitting account identifiers from saved reports. For Gemini the check is presence-only: a set `GEMINI_API_KEY`, `GOOGLE_GENAI_USE_VERTEXAI` or `GOOGLE_GENAI_USE_GCA` variable, an existing `~/.gemini/oauth_creds.json`, or a declared auth type in `~/.gemini/settings.json`. Credential files are never opened and no key value is read or recorded. Installing the CLI is not the same as authenticating it: with none of those present, `--check` reports `auth: not signed in` and a run stops at preflight with `gemini: sign in manually before running`. Sign in by launching `gemini` once interactively and choosing an auth method, or by setting one of those variables yourself.

Gemini CLI is distributed as a Node package (`npm install -g @google/gemini-cli`) with no native executable, so Node.js must be on PATH. The adapter resolves the package's own `bin` script from its `package.json` and launches it as `node <script>`, never through the `gemini.cmd` shim.

Install a compatible pdfLaTeX distribution. The supplied CV explicitly uses the pdfTeX hyperref driver, so this build uses **pdfLaTeX**, not XeLaTeX. MiKTeX-pdfTeX 4.27 (MiKTeX 26.5) was verified here. Required template packages, including newtxtext/newtxmath, must already be installed. Compilation disables shell escape and MiKTeX automatic package installation. Missing packages are actionable compiler failures, not prompts that hang an unattended run.

The launcher uses `$PSScriptRoot`, prefers `.venv\Scripts\python.exe`, and otherwise uses `$env:CV_PIPELINE_PYTHON` or `python` from PATH. It forwards an argument array, supports spaces and Unicode paths, preserves the caller's location, and propagates Python's exit code. It never changes PowerShell execution policy. If local policy prevents running `.ps1`, use the equivalent Python command below or your organization's approved policy process.

## Commands and settings

```powershell
# Interactive selection
.\run.ps1

# All jobs with one provider/model/effort for the entire batch
.\run.ps1 -Provider claude -Model opus -Effort medium

# Use the configured default provider for A, B and C (currently Codex)
.\run.ps1 -Job 'old\job_description_275.pdf' -JobId 'deeprec_default_01' -NonInteractive

# Choose the provider at launch; remaining selections stay interactive
.\run.ps1 -Provider codex
.\run.ps1 -Provider claude
.\run.ps1 -Provider gemini

# Gemini takes a model but no effort
.\run.ps1 -Provider gemini -Model gemini-2.5-pro -Effort default -NonInteractive

# Apply a provider and explicit settings to all three roles
.\run.ps1 -Provider claude -Model opus -Effort high -Job 'old\job_description_275.pdf' -JobId 'deeprec_claude_01' -NonInteractive

# Construct requests and snapshots without invoking an AI CLI
.\run.ps1 -Provider codex -Job 'old\job_description_275.pdf' -JobId 'deeprec_preview_01' -DryRun -NonInteractive

# Override the external job directory
.\run.ps1 -JobDirectory 'D:\Jobs with spaces' -Job 'Analyst München.pdf' -NonInteractive

# Direct Python equivalents, from this project root
.\.venv\Scripts\python.exe -m src.main --check
.\.venv\Scripts\python.exe -m src.main --job 'old\job_description_275.pdf' --job-id deeprec_python_01 --provider codex --non-interactive
```

`-Provider`, `-Model`, `-Effort`, `-Job`, `-JobId`, `-JobDirectory`, `-DryRun`, `-Check`, and `-NonInteractive` map to matching hyphenated Python options. Explicit values take precedence over interactive selections and application configuration. Missing optional noninteractive selections retain configured defaults. Omitting `-Job` processes all supported files; `-JobId` is only valid with an explicit `-Job`. `-Model default` or `-Effort default` explicitly chooses the native default even when a configured override exists. YAML `null` omits a native flag; the literal text `null` is never sent for it.

The selected provider and model/effort settings apply to **every role**. Without `-Provider`, noninteractive runs use `execution.provider` in `config/pipeline.yaml` (currently `codex`); `codex`, `claude` and `gemini` are accepted. The `agents` configuration maps roles to prompts only; per-agent provider entries are rejected. Changing provider at launch never rewrites YAML. Model/effort defaults come from the selected provider, and native defaults are recorded as `provider default; resolved value unknown` unless the CLI discloses the actual value; explicit selections and any disclosed resolved model are recorded separately.

Exit codes: **0** = PASS with no findings, successful dry run, or runtime-ready check; **3** = PUBLISHED_WITH_FINDINGS, documents published with a validation report that needs reading; **2** = NEEDS_USER_REVIEW, nothing published because a critical finding remains; **1** = input/provider/build/runtime failure. A batch reports the most serious outcome across its jobs, in that order. `-Check` reports `runtime_ready` separately from `approval_ready`; only a source issue configured as `severity: critical` can clear the runtime but block approval.

## Configuration and input files

`config/pipeline.yaml` is application-owned YAML. Relative paths resolve from `job_py`, never from the external job path or caller's working directory. The configured job directory is `C:\Users\ygtcs\Desktop\Work\Work\Job_ad`. Batch mode enumerates supported files, including subfolders, once at the start and announces the count. Explicit `-Job` accepts a relative subfolder path but rejects absolute paths, traversal, unsupported formats, and links outside the configured job directory. The user's all-job instruction supersedes the master specification's original one-job default.

Job inputs support UTF-8 TXT/MD, text-bearing PDF, and DOCX. DOCX paragraphs and table cells are extracted in document order. Empty extraction fails; image-only PDFs require OCR outside the pipeline. PDF extraction can contain damaged source glyphs; agents receive the extracted text and must flag ambiguity. No master job description is copied into `input/`; each run has its own reproducibility snapshot.

The following files were initially copied byte-for-byte from `..\new`:

| Supplied filename | Project copy |
| --- | --- |
| `yigit_coskun_cv.tex` | `input/cv_template.tex` |
| `yigit_coskun_cover_letter.tex` | `input/cl_template.tex` |
| `skills_profile.md` | `input/skills_profile.md` |
| `agent_a_writer.md` | `agents/agent_a_writer.md` |
| `agent_b_optimizer.md` | `agents/agent_b_optimizer.md` |
| `agent_c_hiring_reviewer.md` | `agents/agent_c_hiring_reviewer.md` |

On 2026-09-09, the user confirmed **27,000** Google Trends series. The active CV count was updated from 3,540 to 27,000 and the active CL now says 27,000 without the former “more than” qualifier. All other template bytes, the supplied originals in `..\new`, the skills profile and the original prompts remain unchanged. Original and current hashes plus the authorized correction are recorded in `docs/source_mapping.json`; the thesis-count blocker is resolved.

An invocation-time transport instruction adds the response schema and reiterates factual/editing restrictions. The older ZIPs, unrelated projects, older applications, and personal memory are not applicant evidence. Two legacy provenance documents named by profile Version 3.1 were never supplied and never governed this pipeline; every reference to them was removed on 2026-09-10. The current single-provider requirement supersedes the master specification's earlier mixed-provider example.

`config/editing_rules.yaml` maps inspected boundaries/tokens and records length limits, exact five Skills labels, inventory, fixed Languages line, and unresolved source issues. `config/scoring_rubric.yaml` owns the 40/25/20/15 criterion weights. Semantic evidence, relevance, proficiency, Tier 2/Tier 3 conditions and the dual job-title/job-description match are checked by C; exact inventory, mandatory inclusions, R-package trigger, labels, token keys, excerpts, lengths and protected bytes are checked in Python. Excerpt membership is not a semantic proof that a claim is supported.

## Rendering and review gates

Every candidate starts from original bytes. Only the SUMMARY and SKILLS bodies may change, despite four other CV AI_EDIT regions. Marker lines, all protected text, preambles and line endings remain intact. CL edits replace exact configured tokens consistently, including repeated occurrences. Empty optional address tokens render as an invisible `\mbox{}` to preserve the fixed following line break without a LaTeX error. The engine escapes plain text; it does not accept generated layout/preamble commands. Legacy token mentions in immutable CV comments are not treated as visible unresolved tokens.

The builder runs pdfLaTeX with `-no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=...`; on MiKTeX it also uses `--disable-installer`. Each round has isolated auxiliary files and logs. Current limits are three CV pages, one CL page, and a 2pt overfull-box tolerance. Nothing automatically shrinks fonts or changes layout. Actual PDF text is extracted and checked for replacement text, CV section order, empty/corrupt text and out-of-page blocks. Every page is also rendered to PNG for human visual review. Text checks are compatibility proxies, not a universal ATS guarantee, and PNG creation alone does not imply visual approval.

A writes, B optimizes at round 0, then C independently reviews originals, candidate LaTeX, replacement evidence, actual PDF-extracted text and build findings. C cannot modify or publish files. Format repair is at most one additional invocation by default, separate from feedback rounds 1, 2 and 3. Provider errors are not treated as formatting retries. A structured input block can stop the pipeline before document generation.

Python recalculates separate CV and CL totals. Both must be at least 75, and every factual, source, editing, token and parsing gate must pass, for the clean **PASS** outcome. An average cannot mask a weak document, and a model-declared PASS cannot override failures.

Each gate produces a coded finding with a severity, and the severity, not the mere existence of a note, decides routing:

| Severity | Meaning | Effect |
| --- | --- | --- |
| `critical` | No trustworthy document exists | Publication withheld; exit 2 |
| `major` | Published, but a human must read it before sending | Drives a revision round while one is available and the finding is fixable; otherwise published with the report; exit 3 |
| `advisory` | Source ambiguity, protected-template limit or informational note | Recorded only; never blocks |

Findings are deduplicated by code and message, so a repeated warning is reported once. Agent-reported source conflicts and input notes are advisory while a candidate exists, and a reviewer's own `NEEDS_USER_REVIEW` decision becomes a major finding rather than an automatic stop. Overfull boxes are attributed by source line: inside SUMMARY/SKILLS they are `major` and fixable, and inside protected template layout they are `advisory` and explicitly not fixable within the permitted edit scope. `review.publish_policy: pass_only` restores the earlier withhold-on-any-gate behaviour, and `validation.severity_overrides` promotes or demotes any finding code without code changes. Scores are internal fit assessments, not employer ATS scores or interview probabilities.

### Supplied sources and instruction precedence

The supplied sources no longer contradict each other. On 2026-09-10 the legacy wording was corrected in place rather than carried as permanent advisory noise: `cv_template.tex` and `skills_profile.md` sections 1 and 5 now state the real editable scope, the summary comment no longer demands a literal `{{JOB-TITLE}}` token, the profile records the settled Skills ordering, and the two legacy provenance references are gone. `source_issues` is consequently empty and a clean run reports **no validation findings**; the history moved to `source_resolutions`, which agents are told not to reopen.

Both templates were also comment-audited: the CV dropped from 132 to 79 comment lines and the cover letter from 47 to 15, with every LaTeX line preserved and the compiled PDF text and page count verified unchanged. Per-token cover-letter guidance moved out of a `.tex` comment into `cl_token_guidance`, and `limits.cv_pages`/`limits.cl_pages` mirror `document.page_limits` so the agents, which never receive `pipeline.yaml`, still know the page budget; `load_config` fails if the two drift. Template comments are now explicitly maintainer notes, never instructions.

### Instruction precedence

`config/editing_rules.yaml` carries an explicit `instruction_precedence` list, supplied to all three agents and repeated in the transport instruction, so recurring source contradictions are settled once instead of being re-raised every run. It records that the current pipeline scope permits summary, skills and authorized CL-token edits; that the profile's section 4 universal ordering governs within-line Skills order for every vacancy, with the configured mandatory sequence fixing the TensorFlow/Keras position; and that the legacy skills-only scope and the protected comment demanding a literal `{{JOB-TITLE}}` token in the summary are superseded. The superseded wording stays in the sources for provenance and is reported as an advisory note. `ordering.mandatory_first` is enforced deterministically for Programming, Methods and Tools & Platforms; the Skills line is exempt because section 4 puts posting-named practices first there.

Skills inventory additions are configuration, not code: `optional` lists what may be selected, and `mutually_exclusive` groups block overlapping entries appearing together, so a line cannot read "Excel, Microsoft Office (Word, Excel, PowerPoint)". Excel and Microsoft Office are Tier 2 in the profile, stated confidently when the posting makes them relevant.

Evidence entries declare a `claim_type`. `applicant_fact` may never cite the vacancy. `role_target` may, but only for naming the advertised role in the fields listed under `role_target.allowed_fields`, and only when the claim matches `role_target.pattern`. So "Seeking a Quality Data Analyst position" is accepted as targeting, while a qualification claim sourced from the posting is still rejected.

## Provider compatibility actually checked

| Provider | Local evidence | Integration result |
| --- | --- | --- |
| Codex | Desktop executable 0.149.0 help inspected; launcher's PATH selected native 0.143.0 and rechecked its required flags | Live A invocation returned schema-valid BLOCKED; model/effort left at native defaults |
| Claude Code | Native 2.1.238 help and signed-in status inspected; npm wrapper verified | Live `opus`/`high` request reached service but returned HTTP 429 session limit before inference; that model/effort combination is not claimed inference-verified |
| Gemini CLI | `@google/gemini-cli` 0.59.0 installed and signed in; `--version` and full `--help` inspected; `bundle/gemini.js` resolved behind the `gemini.ps1` shim; success and error envelopes captured from real headless calls | Preflight and headless invocation verified. `gemini-3.5-flash` accepted; `gemini-3.1-pro` and `gemini-3.5-pro` rejected by the API on this account as `not found for API version v1beta` |
| MiKTeX | pdfTeX 4.27 / MiKTeX 26.5 version/help and actual invocations | Both original templates compiled with test replacements; 2-page CV and 1-page CL extracted and visually inspected |

Codex invocation: `codex exec --ignore-user-config --ephemeral --skip-git-repo-check --sandbox read-only --json --output-schema <file> --output-last-message <file> -C <isolated-dir> -`, with shell/unified-exec/multi-agent/apps/memory disabled, approvals set to never and web search disabled. Explicit model uses `--model`; effort uses the documented `-c model_reasoning_effort="..."` setting. Prompts enter through stdin. Required flags are rechecked against installed help before every live run. The local cache's model/effort hints can be stale or absent; server rejection remains authoritative. Configuration reference: [official Codex documentation](https://learn.chatgpt.com/docs/config-file/config-reference).

Claude invocation: native executable with `--print --safe-mode --tools "" --permission-mode dontAsk --no-session-persistence --output-format json --json-schema <schema> --system-prompt <transport-policy>`. Prompt content enters through stdin. Explicit model and effort use its verified `--model` and `--effort` flags. Safe mode keeps authentication but disables customizations; no permission-bypass flags are used. The adapter reads `structured_output` from the CLI envelope and rejects errors. Help lists effort values low/medium/high/xhigh/max, but support still depends on model/account. `--bare` is deliberately not used because installed help states it excludes normal OAuth authentication.

Gemini invocation: `node <gemini-cli bin> --output-format json --approval-mode default --skip-trust --prompt <closing instruction>`, with `--model` added only when explicitly selected. Installed help states that the CLI "Defaults to interactive mode. Use -p/--prompt for non-interactive (headless) mode", and that `-p` is "Appended to input on stdin (if any)"; the assembled prompt therefore travels on stdin and `-p` carries only a short closing instruction, so no personal content reaches argv. `--yolo`, `--sandbox` and `--raw-output` are deliberately absent, and `default` approval never auto-runs a tool. `--skip-trust` is required because 0.59.0 refuses to run headless in an untrusted folder; it applies only to the empty per-invocation temporary directory each agent runs in, which contains no project configuration, no extensions, no context files and none of the applicant's sources, so it trusts nothing that could carry instructions. Required flags `--output-format`, `--approval-mode`, `--model`, `--prompt` and `--skip-trust` are rechecked against installed help before every live run; a missing flag stops the run with `installed CLI lacks required safe/structured flags` rather than falling back to a looser invocation. Version 0.59.0 has no telemetry flag, so telemetry follows the user's own `~/.gemini/settings.json`.

Two Gemini differences are recorded rather than papered over. It exposes **no per-request response-schema flag**, so the schema reaches the model inside the assembled prompt and the reply is validated locally against the same Pydantic contract; a malformed reply becomes an ordinary format-repair attempt. Each probe records this as `schema_enforcement`, which is `prompt only; validated locally with format repair` for Gemini and `provider enforced` for the other two. It also exposes **no reasoning-effort control**, so an explicit `-Effort` other than `default` is rejected at preflight rather than ignored. The adapter strips code fences and surrounding prose from the reply and rejects any response whose `stats.tools.totalCalls` is non-zero. A rejected request exits non-zero and prints its JSON error envelope to **stderr** after a stack trace, so the adapter recovers the envelope from either stream and reports, for example, `Gemini rejected request: models/gemini-3.1-pro is not found for API version v1beta`; without a recognisable envelope the original process failure is re-raised unchanged rather than given an invented explanation. 0.59.0 routes roles to different models, so the run log records the model that served the `main` role as the resolved model. Gemini CLI has no `--ignore-user-config` equivalent, so settings in the user's own `~/.gemini/settings.json` still apply.

All three adapters use argument lists, UTF-8 stdin/stdout/stderr, explicit working directories and bounded timeouts. Windows `.cmd`/Unix npm shims are resolved to verified native executables rather than interpolated into shell commands. Configure an absolute native executable path if discovery cannot identify your installation. Timeouts terminate the process tree. Agents run in fresh OS-temporary directories outside source files; source hashes are checked before/after each invocation and before publication. Unexpected Codex tool execution events and Gemini tool-call counts are rejected. Local administrative policy and CLI internals remain outside this application's control.

## Outputs and audit trail

### Detailed PowerShell progress and timings

Timing output is enabled by default; your command stays the same:

```powershell
.\run.ps1 -Provider claude -Model opus -Effort medium
```

The console prints local timestamps, selected provider/model/effort, job number/count, stage starts and finishes, model attempt and feedback-round numbers, validation findings, CV/CL scores, PDF page/check results, and final status. Long provider and compiler calls print an elapsed-time heartbeat every 15 seconds until they return or fail; this means the process is still running, not that model progress can be measured. Each job ends with a stage-duration breakdown. The batch ends with total elapsed time and a per-job duration/status table. Python output is unbuffered for immediate display in PowerShell. Durations use a monotonic clock; saved timestamps use UTC.

Illustrative console output (not measured performance):

```text
[14:20:00] JOB 1/16 | job_description_276.pdf | batch elapsed 0.0s
[14:20:02] START AGENT A | round 0 | attempt 1/2 | claude | model=opus | effort=medium | timeout 10m 00s
[14:20:17] WAIT  AGENT A | ... | elapsed 15.0s / timeout 10m 00s | process still running
[14:20:30] DONE AGENT A | ... | elapsed 28.0s
[14:21:02] DONE CV PDF compilation | round_0 | elapsed 1.8s
[14:21:35] CV 81/100; CL 79/100 — PASS | round 0/3 | 0 validation issue(s), 0 source/build blocker(s)
[14:21:36] JOB 1/16 | PASS | took 1m 36s | batch elapsed 1m 36s
```

Durations are also saved: `run_log.json` has `elapsed_seconds` and `stage_timings`; every agent attempt has total/provider elapsed seconds in `metadata.json`; `build_report.json` has compilation and extraction/check timings; each batch report records overall and per-job elapsed seconds. Failed attempts are timed as well. No raw model reasoning or credentials are printed.

`output/temp/job_<id>/` contains snapshots/hashes, role prompts, transport schemas, raw and normalized responses, CLI versions/settings/timestamps/errors, B round folders, C review JSON, compiler logs, PDF-extracted text, rendered page images, and `run_log.json`. Dry runs create request previews here with explicit dependent-input placeholders; they do not invent B/C results.

Batch runs also write `output/temp/batches/batch_<timestamp>_<id>.json`, updated after every job, with the queue, selected settings, statuses, output paths and errors. Each job completes A → B → C and any allowed feedback rounds before the next starts. Review-required results and input-specific failures are recorded and processing continues. Provider/authentication/model/quota/process failures stop the batch and mark the remaining jobs `NOT_RUN`. A batch picks up only postings that have no output yet. Anything already processed is marked `SKIPPED` in the report and summarised in one console line rather than a line per job, and duplicate filename stems inside one batch are skipped the same way; skipped work does not affect the exit code. To redo a finished posting, name it with `-Job`, which takes the next free ID (`job_x` becomes `job_x_r2`, then `job_x_r3`) so earlier evidence and published documents are never overwritten. Batch exit code is 1 for failures/unrun jobs, 2 when completed jobs only need user review, 3 when documents published with findings, otherwise 0. `-DryRun` also works for the full batch without any AI invocation; its snapshots reserve output IDs just like single-job dry runs.

PASS and PUBLISHED_WITH_FINDINGS both create `output/final/job_<id>/{cv.tex,yigit_coskun_cv.pdf,cl.tex,yigit_coskun_cl.pdf,validation_report.md,validation_report.json}`. Python verifies reviewed hashes, stages every file beside the final destination, then renames the complete directory on the same filesystem. It never regenerates PDFs after review. The same report is always written to `output/temp/job_<id>/`, refreshed each round, so a withheld run still leaves a full account. Only critical findings keep documents in temp. Private input files, `.env`, virtual environments, caches and generated output are Git-ignored. Prompts and generated logs contain personal source content; keep the local output directory private.

## Verification and current limitations

Run tests with:

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
```

The current suite passed **137 tests**, with the two real-PowerShell launcher tests skipped when local execution policy forbids running `.ps1` and the DOCX test failing because Windows Application Control blocks lxml on this machine, including monotonic stage durations, heartbeat output/cleanup, failure timings, automatic batches, shared settings, continuation after job-specific failures, provider-failure stopping, collision protection and real PowerShell batch dry runs. It also covers shared-provider defaults, interactive switching, mixed-provider rejection, the authorized thesis-count correction, mocked provider envelopes/workflows/compiler outputs, exact boundaries/escaping/tokens/inventory/evidence checks, malformed response repair bounds, individual score thresholds, max feedback rounds, failed-result publication prohibition, mutation detection, scanned PDF rejection, DOCX tables, and local process tests. It also covers severity classification and routing, publication with findings, critical withholding, overflow attribution to editable versus protected lines, role-target evidence acceptance and its limits, universal Skills ordering, finding deduplication and ranking, the red and yellow console report with its `NO_COLOR`/`FORCE_COLOR` overrides, the `PUBLISHED_WITH_FINDINGS` batch outcome, and the Gemini adapter: restricted argument list checked against a verbatim copy of the installed 0.59.0 `--help` so no flag can be invented, Node-script resolution instead of the `.ps1` shim, prompt-by-stdin, fenced/prose JSON extraction, error and tool-use rejection, preflight flag and effort refusal, model-hint parsing, presence-only authentication detection including the unauthenticated case, headless workspace trust, resolution of the model that served the `main` role, and recovery of a JSON error envelope from a non-zero exit. Mock PDFs in publication tests are explicitly synthetic bytes, not evidence of successful LaTeX generation. Actual template compilation and the live provider calls are separate checks recorded in `PROGRESS.md`.

Outstanding notes for a real application:

1. The Skills ordering ambiguity is resolved by documented precedence rather than a blocking gate: section 4's universal ordering wins for every vacancy, and TensorFlow/Keras keeps its position after scikit-learn from the configured mandatory sequence. Section 4 states that it applies to all vacancies and section 5 re-checks it, so this reads the profile rather than overriding it. The originals are unchanged; change the `ordering` block if the opposite reading is wanted.
2. The protected CV thesis heading's 3.09859pt overfull box is reported as an advisory protected-template defect at `cv.tex` line 262, because it lies outside the editable regions and no permitted edit can fix it. The 2pt tolerance is unchanged for overflow inside SUMMARY/SKILLS, which is still reported as major. The one-page CL preview is close to the bottom edge even with short test replacements, so real text may require permitted shortening or a separately authorized template change.
3. Claude's earlier live check returned a session-limit error with a reset reported as 14:30 Europe/Berlin on 2026-09-09. That result is historical, not a fresh availability check. Select either provider at launch.

The real DeepRec.ai run (`job_verification_live`) stopped at A. B/C live document review and real approved publication have **not** been verified. No application was submitted, no job portal was used, and no final document set was published.

On Windows, the default Codex adapter prefers the npm installation over the desktop app's bundled CLI, so npm upgrades apply to pipeline runs. An explicit executable path in config/pipeline.yaml overrides automatic discovery.


Empty optional recipient street-address/city rows are omitted automatically, without reserving a blank line.

