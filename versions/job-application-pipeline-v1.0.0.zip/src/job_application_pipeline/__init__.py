"""Tailored CV and cover-letter generation."""

from .paths import Paths, PipelinePaths
from .pipeline import (
    EFFORT_LEVELS,
    ApplicationPipeline,
    JobResult,
    PipelineError,
    RunSummary,
    run,
    validate_effort,
    validate_model,
)

__all__ = [
    "EFFORT_LEVELS",
    "ApplicationPipeline",
    "JobResult",
    "Paths",
    "PipelineError",
    "PipelinePaths",
    "RunSummary",
    "run",
    "validate_effort",
    "validate_model",
]
