"""Command-line entry point for provider, model, and effort selection."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence

from .pipeline import EFFORT_LEVELS, PipelineError, run


def emit(message: str) -> None:
    """Print one progress line immediately.

    Output is flushed so the console reflects a run in real time, and a console
    that cannot represent a character (a cp1252 terminal and a job ad naming a
    company such as "Eruygur Akademi ve Danismanlik") must not end the run.
    """

    stream = sys.stdout
    try:
        stream.write(message + "\n")
    except UnicodeEncodeError:
        encoding = stream.encoding or "ascii"
        stream.write(message.encode(encoding, "replace").decode(encoding) + "\n")
    stream.flush()


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="job-application-pipeline",
        description="Generate English CV and cover-letter PDFs for every new job ad.",
    )
    parser.add_argument("provider", choices=("claude", "codex"))
    parser.add_argument("--model")
    parser.add_argument(
        "--effort",
        help=(
            "Reasoning-effort level for the selected provider. "
            + "; ".join(
                f"{provider}: {', '.join(levels)}"
                for provider, levels in EFFORT_LEVELS.items()
            )
            + ". Omit to use the CLI default."
        ),
    )
    parser.add_argument(
        "--fresh",
        action="store_true",
        help=(
            "Always call the provider, even when .artifacts already holds "
            "output built from an identical request."
        ),
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-step progress and print only the closing summary.",
    )
    args = parser.parse_args(argv)

    try:
        summary = run(
            args.provider,
            args.model,
            args.effort,
            fresh=args.fresh,
            progress=None if args.quiet else emit,
        )
    except (OSError, ValueError, PipelineError) as error:
        print(f"Pipeline failed: {error}", file=sys.stderr)
        return 1

    emit("")
    for result in summary.processed:
        emit(
            f"Created job_{result.document_number} for {result.job_ad.name}: "
            f"{result.archive_dir}"
        )
    if summary.skipped:
        emit(f"Skipped {len(summary.skipped)} already-complete job ad(s).")
    emit(
        f"Finished: {len(summary.processed)} created, "
        f"{len(summary.skipped)} skipped."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
