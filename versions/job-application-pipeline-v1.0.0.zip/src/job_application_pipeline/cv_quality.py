"""Deterministic CV quality checks and canonical validation reports.

The validator deliberately separates deterministic blockers from heuristic
review signals.  Every check is represented as a structured finding and the
JSON and XLSX reports are projections of the same immutable ``QualityReport``.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import tempfile
import unicodedata
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from .validation import CV_EDIT_REGIONS, parse_cv_regions


SCHEMA_VERSION = "1.1"
VALIDATOR_VERSION = "1.3.0"

_BULLET_REGIONS = CV_EDIT_REGIONS[1:-1]
_CURRENT_ROLE_REGIONS = ("EXPERIENCE_IAB_BULLETS", "PROJECT_NOSI_BULLETS")
_US_SPELLINGS = (
    "visualization",
    "visualizations",
    "analyze",
    "analyzed",
    "analyzes",
    "labor market",
    "randomized",
    "modeling",
    "behavior",
    "organization",
)
_EXPECTED_UNICODE_TOKENS = ("Universität", "Nürnberg", "Łódź", "für", "Arbeitskräfte")
_SECTION_HEADINGS = (
    "Summary",
    "Education",
    "Work Experience",
    "Projects",
    "Publications",
    "Certifications",
    "Skills",
)
_BULLET_SOURCE_RE = re.compile(
    r"^([A-Z]{1,3}[0-9]{0,2}[a-z]?(?:-[A-Z]{2,4})?)\s+\[([^\]]+)\]\s*(.+)$"
)
_FINANCE_RE = re.compile(
    r"(?<!\w)(?:bank(?:ing)?|finance|financial|insurance|credit|risk|trading|investment)(?!\w)",
    flags=re.IGNORECASE,
)
_PAST_TENSE_RE = re.compile(
    r"^(?:Supported|Prepared|Created|Cleaned|Produced|Identified|Worked|Analysed|"
    r"Analyzed|Built|Developed|Conducted|Implemented|Collected|Evaluated|Designed|"
    r"Managed|Performed|Used)\b"
)
_OVERFULL_RE = re.compile(
    r"Overfull\s+\\hbox\s+\(([-+]?\d+(?:\.\d+)?)pt\s+too wide\)",
    flags=re.IGNORECASE,
)


class Severity(str, Enum):
    """Severity of a deterministic check result."""

    PASS = "PASS"
    WARN = "WARN"
    ERROR = "ERROR"


@dataclass(frozen=True, slots=True)
class QualityFinding:
    """One validation outcome, including its governing CV rule(s)."""

    check_id: str
    rule_ids: tuple[str, ...]
    category: str
    severity: Severity
    message: str
    evidence: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.check_id,
            "rules": list(self.rule_ids),
            "category": self.category,
            "status": self.severity.value,
            "message": self.message,
            "evidence": _json_value(self.evidence),
        }


@dataclass(frozen=True, slots=True)
class BulletProvenance:
    """Best deterministic source-library match for one generated bullet."""

    region: str
    bullet_index: int
    text: str
    source_id: str | None
    source_text: str | None
    similarity: float
    match: str
    tier: str = ""
    profiles: str = ""
    priority: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "region": self.region,
            "bullet_index": self.bullet_index,
            "text": self.text,
            "source_id": self.source_id,
            "source_text": self.source_text,
            "similarity": self.similarity,
            "match": self.match,
            "tier": self.tier,
            "profiles": self.profiles,
            "priority": self.priority,
        }


@dataclass(frozen=True, slots=True)
class JDMatch:
    """One job-description term and whether it is evidenced/on the CV."""

    term: str
    in_inventory: bool
    on_cv: bool
    tier: int | None
    action: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": self.term,
            "in_inventory": self.in_inventory,
            "on_cv": self.on_cv,
            "tier": self.tier,
            "action": self.action,
        }


@dataclass(frozen=True, slots=True)
class QualityReport:
    """Immutable result used as the sole source for both report formats."""

    schema_version: str
    validator_version: str
    generated_at_utc: str
    provider: str
    model: str
    effort: str
    hashes: Mapping[str, str]
    findings: tuple[QualityFinding, ...]
    provenance: tuple[BulletProvenance, ...]
    jd_metrics: Mapping[str, int | float | None]
    jd_matches: tuple[JDMatch, ...]

    @property
    def checks(self) -> tuple[QualityFinding, ...]:
        """Alias matching the canonical JSON key."""

        return self.findings

    @property
    def counts(self) -> dict[str, int]:
        counts = Counter(finding.severity.value for finding in self.findings)
        return {
            "PASS": counts[Severity.PASS.value],
            "WARN": counts[Severity.WARN.value],
            "ERROR": counts[Severity.ERROR.value],
            "TOTAL": len(self.findings),
        }

    @property
    def verdict(self) -> str:
        if self.counts["ERROR"]:
            return "NOT_READY"
        if self.counts["WARN"]:
            return "READY_WITH_WARNINGS"
        return "READY"

    @property
    def has_errors(self) -> bool:
        return self.counts["ERROR"] > 0

    def with_findings(self, *findings: QualityFinding) -> "QualityReport":
        """Return a copy with externally produced deterministic findings added."""

        if any(not isinstance(finding, QualityFinding) for finding in findings):
            raise TypeError("with_findings accepts only QualityFinding values.")
        return replace(self, findings=(*self.findings, *findings))

    def to_dict(self) -> dict[str, Any]:
        return {
            "metadata": {
                "schema_version": self.schema_version,
                "validator_version": self.validator_version,
                "generated_at_utc": self.generated_at_utc,
                "provider": self.provider,
                "model": self.model,
                "effort": self.effort,
                "hashes": dict(sorted(self.hashes.items())),
            },
            "counts": self.counts,
            "verdict": self.verdict,
            "checks": [finding.to_dict() for finding in self.findings],
            "provenance": [entry.to_dict() for entry in self.provenance],
            "jd_metrics": _json_value(self.jd_metrics),
            "jd_matches": [match.to_dict() for match in self.jd_matches],
        }


@dataclass(frozen=True, slots=True)
class _SourceBullet:
    source_id: str
    text: str
    tier: str
    profiles: str
    priority: str


def _json_value(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_value(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _sha256_text(content: str) -> str:
    return _sha256_bytes(content.encode("utf-8"))


def _utc_timestamp(value: datetime | None) -> str:
    if value is None:
        value = datetime.now(timezone.utc)
    elif value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _is_escaped(text: str, index: int) -> bool:
    backslashes = 0
    index -= 1
    while index >= 0 and text[index] == "\\":
        backslashes += 1
        index -= 1
    return backslashes % 2 == 1


def _extract_braced_group(text: str, opening_brace: int) -> tuple[str, int]:
    if opening_brace >= len(text) or text[opening_brace] != "{":
        raise ValueError("Expected an opening LaTeX brace.")
    depth = 1
    cursor = opening_brace + 1
    while cursor < len(text) and depth:
        character = text[cursor]
        if not _is_escaped(text, cursor):
            if character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
        cursor += 1
    if depth:
        raise ValueError("LaTeX content contains unbalanced braces.")
    return text[opening_brace + 1 : cursor - 1], cursor


def _extract_calls(text: str, command: str) -> list[str]:
    arguments: list[str] = []
    cursor = 0
    while cursor < len(text):
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        if cursor >= len(text):
            break
        match = re.match(re.escape(command) + r"\s*\{", text[cursor:])
        if match is None:
            raise ValueError(f"Content appears outside a {command} argument.")
        argument, cursor = _extract_braced_group(text, cursor + match.end() - 1)
        arguments.append(argument)
    return arguments


def _extract_bullets(region: str) -> list[str]:
    value = region.strip()
    if not value:
        return []
    start = r"\resumeItemListStart"
    end = r"\resumeItemListEnd"
    if not value.startswith(start) or not value.endswith(end):
        raise ValueError("Bullet region is missing its list wrapper.")
    return _extract_calls(value[len(start) : -len(end)], r"\resumeItemPlain")


def _latex_to_plain(value: str) -> str:
    text = value.replace("---", "—").replace("--", "–")
    replacements = {
        r"\%": "%",
        r"\&": "&",
        r"\_": "_",
        r"\#": "#",
        r"\textbar{}": "|",
        "``": '"',
        "''": '"',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    # Repeatedly unwrap commands with simple braced bodies.  This is a
    # comparison normaliser, not a general LaTeX parser.
    previous = None
    while previous != text:
        previous = text
        text = re.sub(r"\\[A-Za-z@]+\*?\s*\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\[A-Za-z@]+\*?", " ", text)
    text = re.sub(r"[$~{}]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _normalise_exact(value: str) -> str:
    text = unicodedata.normalize("NFKC", _latex_to_plain(value))
    text = text.replace("’", "'").replace("‘", "'")
    text = text.replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", text).strip().casefold()


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9+#]+", " ", _normalise_exact(value)).strip()


def _term_pattern(term: str) -> re.Pattern[str]:
    words = [re.escape(word) for word in term.split()]
    return re.compile(r"(?<!\w)" + r"\s+".join(words) + r"(?!\w)", re.IGNORECASE)


def _parse_source_bullets(source: str) -> tuple[_SourceBullet, ...]:
    bullets: list[_SourceBullet] = []
    for raw_line in source.splitlines():
        match = _BULLET_SOURCE_RE.match(raw_line.strip())
        if match is None:
            continue
        source_id, tag_blob, text = match.groups()
        tags = [part.strip() for part in re.split(r"[·|]", tag_blob)]
        tier = next((tag for tag in tags if re.fullmatch(r"T[123]", tag)), "")
        priority = next((tag for tag in tags if tag in {"CORE", "OPT"}), "")
        profiles = "/".join(
            profile.strip()
            for tag in tags
            if tag not in {tier, priority}
            for profile in tag.split("/")
            if profile.strip()
        )
        bullets.append(
            _SourceBullet(
                source_id=source_id,
                text=_latex_to_plain(text),
                tier=tier,
                profiles=profiles,
                priority=priority,
            )
        )
    return tuple(bullets)


def _similarity(left: str, right: str) -> float:
    left_tokens = set(_slug(left).split())
    right_tokens = set(_slug(right).split())
    if not left_tokens or not right_tokens:
        return 0.0
    return 2.0 * len(left_tokens & right_tokens) / (
        len(left_tokens) + len(right_tokens)
    )


def _split_skill_terms(value: str) -> list[str]:
    """Split source skill lists, preserving the single term ``A/B``."""

    protected = re.sub(r"(?i)(?<!\w)A\s*/\s*B(?!\w)", "A⁄B", value)
    return [
        chunk.replace("A⁄B", "A/B").strip()
        for chunk in re.split(r"[,;/]", protected)
        if chunk.replace("A⁄B", "A/B").strip()
    ]


def _parse_inventory(
    skills_profiles: str,
) -> tuple[set[str], dict[str, int], tuple[str, ...]]:
    """Extract a conservative skill inventory and its explicitly stated tiers."""

    start = skills_profiles.find("1. Master Skills Inventory")
    end = skills_profiles.find("2. Profile:")
    inventory_text = (
        skills_profiles[start:end]
        if start >= 0 and end > start
        else skills_profiles
    )
    section_six = skills_profiles.find("6. CV Skills Section Format")
    section_seven = skills_profiles.find("7. Quick Adaptation")
    if section_six >= 0:
        inventory_text += "\n" + skills_profiles[
            section_six : section_seven if section_seven > section_six else None
        ]

    terms: set[str] = set()
    for raw_line in inventory_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(("1. Master", "6. CV Skills")):
            continue
        if ":" in line:
            label, remainder = line.split(":", 1)
            label = re.sub(r"^Line \d+\s*[\u2014-]*\s*", "", label).strip()
            for part in _split_skill_terms(label):
                candidate = part.strip()
                if 1 < len(candidate) <= 45:
                    terms.add(candidate)
            line = remainder
        # Parentheses in the master inventory generally contain useful
        # sub-skills, so turn their delimiters into separators.
        split_line = line.replace("(", ",").replace(")", ",")
        for chunk in _split_skill_terms(split_line):
            candidate = chunk.strip(" .\u2014-")
            if not 1 < len(candidate) <= 45 or len(candidate.split()) > 6:
                continue
            if candidate.casefold().startswith(
                ("master", "student assistant", "internship", "line ")
            ):
                continue
            if len(_slug(candidate)) > 1:
                terms.add(candidate)

    tiers: dict[str, int] = {}
    current_tier: int | None = None
    saw_tier_three = False
    tier_three_terms: dict[str, str] = {}
    for raw_line in skills_profiles.splitlines():
        line = raw_line.strip()
        tier_match = re.match(r"^Tier ([123])\b", line)
        if tier_match:
            current_tier = int(tier_match.group(1))
            saw_tier_three = saw_tier_three or current_tier == 3
            continue
        if re.match(r"^[567]\.\s", line):
            current_tier = None
        if current_tier is None or not line:
            continue
        head = re.split(r"\u2014|--", line, maxsplit=1)[0]
        for chunk in _split_skill_terms(head):
            candidate = re.sub(r"\([^)]*\)", "", chunk).strip(" .()")
            if 1 < len(candidate) <= 45:
                normalised = _normalise_exact(candidate)
                tiers[normalised] = current_tier
                terms.add(candidate)
                if current_tier == 3:
                    tier_three_terms.setdefault(normalised, candidate)

    if not saw_tier_three:
        raise ValueError("skills_profiles does not contain a Tier 3 section")
    if not tier_three_terms:
        raise ValueError("skills_profiles Tier 3 section contains no parseable terms")
    return (
        terms,
        tiers,
        tuple(
            tier_three_terms[key]
            for key in sorted(tier_three_terms, key=lambda value: (value, tier_three_terms[value]))
        ),
    )


def _technical_jd_candidates(job_description: str) -> set[str]:
    candidates = set(
        re.findall(
            r"\b[A-Z][A-Za-z+#.]{2,}(?:\s+[A-Z][A-Za-z+#.]{2,})?\b",
            job_description,
        )
    )
    stop = {
        "About",
        "And",
        "Application",
        "Apply",
        "Bachelor",
        "Benefits",
        "Company",
        "Contact",
        "Degree",
        "Desirable",
        "Excellent",
        "Experience",
        "Familiarity",
        "Fluent",
        "For",
        "Full",
        "Good",
        "Ideally",
        "Join",
        "Knowledge",
        "Location",
        "Looking",
        "Master",
        "Must",
        "Native",
        "Nice",
        "Offer",
        "Our",
        "Page",
        "Part",
        "PhD",
        "Please",
        "Position",
        "Preferred",
        "Profile",
        "Qualifications",
        "Required",
        "Requirements",
        "Responsibilities",
        "Role",
        "Send",
        "Skills",
        "Strong",
        "Tasks",
        "Team",
        "The",
        "This",
        "Time",
        "University",
        "We",
        "With",
        "Work",
        "Working",
        "Years",
        "You",
        "Your",
    }
    return {candidate for candidate in candidates if candidate not in stop}


def _match_job_description(
    *,
    job_description: str,
    cv_text: str,
    inventory: set[str],
    tiers: Mapping[str, int],
) -> tuple[tuple[JDMatch, ...], dict[str, int | float | None]]:
    inventory_by_slug: dict[str, str] = {}
    for term in sorted(inventory, key=lambda value: (_slug(value), value)):
        slug = _slug(term)
        if slug:
            inventory_by_slug.setdefault(slug, term)

    generic = {
        "analysis",
        "cloud",
        "communication",
        "data",
        "engineering",
        "languages",
        "mathematics",
        "methods",
        "modeling",
        "modelling",
        "programming",
        "publications",
        "software",
        "statistics",
        "tools",
    }
    jd_slug = f" {_slug(job_description)} "
    cv_slug = f" {_slug(cv_text)} "
    rows: list[JDMatch] = []

    for slug, display in sorted(inventory_by_slug.items()):
        if len(slug) < 3 or slug in generic or f" {slug} " not in jd_slug:
            continue
        on_cv = f" {slug} " in cv_slug
        rows.append(
            JDMatch(
                term=display,
                in_inventory=True,
                on_cv=on_cv,
                tier=tiers.get(_normalise_exact(display)),
                action="" if on_cv else "add to CV if relevant; this is in the inventory",
            )
        )

    inventory_slugs = set(inventory_by_slug)
    existing_row_slugs = {_slug(row.term) for row in rows}
    for candidate in sorted(_technical_jd_candidates(job_description)):
        slug = _slug(candidate)
        if not slug or slug in inventory_slugs or slug in existing_row_slugs:
            continue
        if any(slug in known or known in slug for known in inventory_slugs):
            continue
        rows.append(
            JDMatch(
                term=candidate,
                in_inventory=False,
                on_cv=f" {slug} " in cv_slug,
                tier=None,
                action="not in the profile; do not invent" if f" {slug} " not in cv_slug else "",
            )
        )

    rows.sort(key=lambda row: (not row.in_inventory, row.term.casefold(), row.term))
    evidenced = [row for row in rows if row.in_inventory]
    tailoring = (
        round(100.0 * sum(row.on_cv for row in evidenced) / len(evidenced), 2)
        if evidenced
        else None
    )
    coverage = (
        round(100.0 * sum(row.on_cv for row in rows) / len(rows), 2)
        if rows
        else None
    )
    metrics: dict[str, int | float | None] = {
        "inventory_terms_requested": len(evidenced),
        "inventory_terms_on_cv": sum(row.on_cv for row in evidenced),
        "all_terms_requested": len(rows),
        "all_terms_on_cv": sum(row.on_cv for row in rows),
        "tailoring_percent": tailoring,
        "coverage_percent": coverage,
    }
    return tuple(rows), metrics


def _source_findings(
    *,
    regions: Mapping[str, str],
    bullets: Mapping[str, Sequence[str]],
    job_description: str,
    bullet_library: str,
    skills_profiles: str,
    expected_job_title: str = "",
) -> tuple[
    list[QualityFinding],
    tuple[BulletProvenance, ...],
    tuple[JDMatch, ...],
    dict[str, int | float | None],
]:
    inventory, tiers, tier_three_terms = _parse_inventory(skills_profiles)
    findings: list[QualityFinding] = []
    plain_bullets = {
        region: [_latex_to_plain(bullet) for bullet in region_bullets]
        for region, region_bullets in bullets.items()
    }

    education_text = " ".join(plain_bullets["EDUCATION_FAU_BULLETS"])
    education_has_grade = re.search(r"(?<!\w)grade(?!\w)", education_text, re.I) is not None
    findings.append(
        QualityFinding(
            check_id="EDUCATION_GRADE",
            rule_ids=("R-05",),
            category="structure",
            severity=Severity.PASS if education_has_grade else Severity.ERROR,
            message=(
                "FAU education bullets include the thesis grade"
                if education_has_grade
                else "FAU education bullets must include the thesis grade"
            ),
            evidence={"region": "EDUCATION_FAU_BULLETS"},
        )
    )

    thesis_text = " ".join(plain_bullets["PROJECT_THESIS_BULLETS"])
    thesis_has_grade = (
        re.search(r"(?<!\w)grade(?!\w)", thesis_text, re.I) is not None
        or re.search(r"(?<![\d.,])1[.,]3(?![\d.,])", thesis_text) is not None
    )
    findings.append(
        QualityFinding(
            check_id="THESIS_PROJECT_GRADE",
            rule_ids=("R-05",),
            category="structure",
            severity=Severity.ERROR if thesis_has_grade else Severity.PASS,
            message=(
                "Projects thesis bullets repeat a grade"
                if thesis_has_grade
                else "Projects thesis bullets contain no grade"
            ),
            evidence={"region": "PROJECT_THESIS_BULLETS"},
        )
    )

    terminal_periods = [
        {"region": region, "bullet_index": index, "text": text}
        for region, region_bullets in plain_bullets.items()
        for index, text in enumerate(region_bullets, start=1)
        if text.rstrip().endswith(".")
    ]
    findings.append(
        QualityFinding(
            check_id="BULLET_TERMINAL_PERIOD",
            rule_ids=("R-26",),
            category="house_style",
            severity=Severity.ERROR if terminal_periods else Severity.PASS,
            message=(
                f"{len(terminal_periods)} bullet(s) end with a full stop"
                if terminal_periods
                else "No bullet ends with a full stop"
            ),
            evidence={"bullets": terminal_periods},
        )
    )

    prose = " ".join(
        [
            _latex_to_plain(regions["SUMMARY"]),
            *(text for values in plain_bullets.values() for text in values),
        ]
    )
    # A job title is a posting proper noun, not generated prose. Preserve its
    # spelling exactly for ATS matching (for example, "Data Visualization
    # Analyst") while continuing to reject US spellings everywhere else.
    if expected_job_title:
        prose = re.sub(
            re.escape(expected_job_title),
            " ",
            prose,
            flags=re.IGNORECASE,
        )
    us_spellings = sorted(
        {term for term in _US_SPELLINGS if _term_pattern(term).search(prose)},
        key=str.casefold,
    )
    findings.append(
        QualityFinding(
            check_id="US_SPELLING",
            rule_ids=("R-25",),
            category="house_style",
            severity=Severity.ERROR if us_spellings else Severity.PASS,
            message=(
                "US spellings found: " + ", ".join(us_spellings)
                if us_spellings
                else "No listed US spellings were found"
            ),
            evidence={"terms": us_spellings},
        )
    )

    skills_text = _latex_to_plain(regions["SKILLS"])
    present_tier_three = [
        skill
        for skill in tier_three_terms
        if _term_pattern(skill).search(skills_text)
    ]
    unasked_tier_three = [
        skill
        for skill in present_tier_three
        if _term_pattern(skill).search(job_description) is None
    ]
    findings.append(
        QualityFinding(
            check_id="TIER3_SKILLS",
            rule_ids=("R-10", "R-23"),
            category="factual",
            severity=Severity.ERROR if unasked_tier_three else Severity.PASS,
            message=(
                "Tier-3 skills not explicitly named by the job description: "
                + ", ".join(unasked_tier_three)
                if unasked_tier_three
                else "Every listed Tier-3 skill is explicitly named by the job description"
            ),
            evidence={
                "listed": present_tier_three,
                "not_explicitly_requested": unasked_tier_three,
            },
        )
    )

    exact_locations: dict[str, list[dict[str, Any]]] = {}
    for region, region_bullets in plain_bullets.items():
        for index, text in enumerate(region_bullets, start=1):
            exact_locations.setdefault(_normalise_exact(text), []).append(
                {"region": region, "bullet_index": index, "text": text}
            )
    exact_duplicates = [
        locations
        for normalised, locations in exact_locations.items()
        if normalised and len(locations) > 1
    ]
    findings.append(
        QualityFinding(
            check_id="BULLET_EXACT_DUPLICATES",
            rule_ids=("R-12",),
            category="factual",
            severity=Severity.ERROR if exact_duplicates else Severity.PASS,
            message=(
                f"{len(exact_duplicates)} exact normalised bullet duplicate group(s) found"
                if exact_duplicates
                else "No exact normalised bullet text is duplicated"
            ),
            evidence={"duplicate_groups": exact_duplicates},
        )
    )

    finance_posting = _FINANCE_RE.search(job_description) is not None
    ziraat_count = len(plain_bullets["EXPERIENCE_ZIRAAT_BULLETS"])
    ziraat_expected = finance_posting
    ziraat_ok = (ziraat_count > 0) if ziraat_expected else ziraat_count == 0
    findings.append(
        QualityFinding(
            check_id="ZIRAAT_RELEVANCE",
            rule_ids=("R-04",),
            category="heuristic",
            severity=Severity.PASS if ziraat_ok else Severity.WARN,
            message=(
                f"Ziraat bullet count ({ziraat_count}) is consistent with the inferred job domain"
                if ziraat_ok
                else f"Review Ziraat bullet count ({ziraat_count}); finance-related posting inferred: {finance_posting}"
            ),
            evidence={
                "finance_posting_inferred": finance_posting,
                "ziraat_bullet_count": ziraat_count,
            },
        )
    )

    tense_flags = [
        {"region": region, "bullet_index": index, "text": text}
        for region in _CURRENT_ROLE_REGIONS
        for index, text in enumerate(plain_bullets[region], start=1)
        if _PAST_TENSE_RE.match(text)
    ]
    findings.append(
        QualityFinding(
            check_id="CURRENT_ROLE_TENSE",
            rule_ids=("R-27",),
            category="heuristic",
            severity=Severity.WARN if tense_flags else Severity.PASS,
            message=(
                f"{len(tense_flags)} current-role bullet(s) begin with a likely past-tense verb"
                if tense_flags
                else "No likely past-tense opening was found in current-role bullets"
            ),
            evidence={"bullets": tense_flags},
        )
    )

    source_bullets = _parse_source_bullets(bullet_library)
    provenance: list[BulletProvenance] = []
    inferred_ids: list[str] = []
    unmatched_count = 0
    for region, region_bullets in plain_bullets.items():
        for index, text in enumerate(region_bullets, start=1):
            if source_bullets:
                best = max(source_bullets, key=lambda source: _similarity(text, source.text))
                score = _similarity(text, best.text)
                source_id: str | None = best.source_id if score >= 0.55 else None
                source_text: str | None = best.text if score >= 0.55 else None
                if source_id is not None:
                    inferred_ids.append(source_id)
                else:
                    unmatched_count += 1
                match = "exact" if score >= 0.97 else "fuzzy" if score >= 0.55 else "unmatched"
                provenance.append(
                    BulletProvenance(
                        region=region,
                        bullet_index=index,
                        text=text,
                        source_id=source_id,
                        source_text=source_text,
                        similarity=round(score, 4),
                        match=match,
                        tier=best.tier if source_id else "",
                        profiles=best.profiles if source_id else "",
                        priority=best.priority if source_id else "",
                    )
                )
            else:
                unmatched_count += 1
                provenance.append(
                    BulletProvenance(
                        region=region,
                        bullet_index=index,
                        text=text,
                        source_id=None,
                        source_text=None,
                        similarity=0.0,
                        match="unmatched",
                    )
                )

    provenance_warning = not source_bullets or unmatched_count > 0
    findings.append(
        QualityFinding(
            check_id="BULLET_PROVENANCE",
            rule_ids=("R-07",),
            category="heuristic",
            severity=Severity.WARN if provenance_warning else Severity.PASS,
            message=(
                "Bullet library has no parseable source IDs"
                if not source_bullets
                else f"{unmatched_count} bullet(s) have no sufficiently similar source match"
                if unmatched_count
                else "Every bullet has a sufficiently similar source-library match"
            ),
            evidence={
                "parseable_source_ids": len(source_bullets),
                "unmatched_bullets": unmatched_count,
                "threshold": 0.55,
            },
        )
    )

    inferred_duplicates = sorted(
        source_id for source_id, count in Counter(inferred_ids).items() if count > 1
    )
    findings.append(
        QualityFinding(
            check_id="BULLET_INFERRED_ID_DUPLICATES",
            rule_ids=("R-12",),
            category="heuristic",
            severity=Severity.WARN if inferred_duplicates else Severity.PASS,
            message=(
                "Multiple bullets infer the same source ID: " + ", ".join(inferred_duplicates)
                if inferred_duplicates
                else "No duplicate source IDs were inferred"
            ),
            evidence={"source_ids": inferred_duplicates},
        )
    )

    cv_matching_text = " ".join(
        (
            _latex_to_plain(regions["SUMMARY"]),
            *(text for values in plain_bullets.values() for text in values),
            skills_text,
        )
    )
    jd_matches, jd_metrics = _match_job_description(
        job_description=job_description,
        cv_text=cv_matching_text,
        inventory=inventory,
        tiers=tiers,
    )
    coverage = jd_metrics["coverage_percent"]
    missing_matches = [match.term for match in jd_matches if not match.on_cv]
    findings.append(
        QualityFinding(
            check_id="JD_COVERAGE",
            rule_ids=("R-13",),
            category="heuristic",
            severity=Severity.WARN if missing_matches else Severity.PASS,
            message=(
                f"Review {len(missing_matches)} uncovered JD term(s); coverage {coverage}%"
                if missing_matches
                else "All deterministically detected JD terms appear on the CV"
                if jd_matches
                else "No deterministic JD terms were available for coverage scoring"
            ),
            evidence={"missing_terms": missing_matches},
        )
    )
    return findings, tuple(provenance), jd_matches, jd_metrics


def _pdf_text_findings(page_texts: Sequence[str], tex: str) -> list[QualityFinding]:
    findings: list[QualityFinding] = []
    all_text = "\n\f\n".join(page_texts)
    nonempty_lines = [line.strip() for line in all_text.splitlines() if line.strip()]
    first_line = nonempty_lines[0] if nonempty_lines else ""
    findings.append(
        QualityFinding(
            check_id="PDF_NAME_FIRST_LINE",
            rule_ids=("R-18",),
            category="ats",
            severity=Severity.PASS if first_line == "Yigit Coskun" else Severity.ERROR,
            message=(
                "First nonempty extracted line is exactly 'Yigit Coskun'"
                if first_line == "Yigit Coskun"
                else f"First nonempty extracted line must be 'Yigit Coskun'; got {first_line!r}"
            ),
            evidence={"first_nonempty_line": first_line},
        )
    )

    normalised_tex = unicodedata.normalize("NFKC", tex)
    compact_text = re.sub(
        r"\s+", " ", unicodedata.normalize("NFKC", all_text)
    )
    expected_tokens = [
        token
        for token in _EXPECTED_UNICODE_TOKENS
        if unicodedata.normalize("NFKC", token) in normalised_tex
    ]
    missing_tokens = [
        token
        for token in expected_tokens
        if unicodedata.normalize("NFKC", token) not in compact_text
    ]
    findings.append(
        QualityFinding(
            check_id="PDF_UNICODE_TOKENS",
            rule_ids=("R-19", "R-24"),
            category="ats",
            severity=Severity.ERROR if missing_tokens else Severity.PASS,
            message=(
                "Expected UTF-8 tokens missing from extracted PDF text: "
                + ", ".join(missing_tokens)
                if missing_tokens
                else f"All {len(expected_tokens)} expected UTF-8 token(s) survived extraction"
            ),
            evidence={"expected": expected_tokens, "missing": missing_tokens},
        )
    )

    glued = [
        {"page": page_number, "line": line.strip()}
        for page_number, page_text in enumerate(page_texts, start=1)
        for line in page_text.splitlines()
        if line.count("◦") > 1
    ]
    findings.append(
        QualityFinding(
            check_id="PDF_GLUED_BULLETS",
            rule_ids=("R-20", "R-24"),
            category="ats",
            severity=Severity.ERROR if glued else Severity.PASS,
            message=(
                f"{len(glued)} extracted line(s) contain glued nested bullets"
                if glued
                else "No glued nested bullets were found"
            ),
            evidence={"lines": glued},
        )
    )

    stranded: list[dict[str, Any]] = []
    for page_number, page_text in enumerate(page_texts[:-1], start=1):
        lines = [
            line.strip().lstrip("\ufeff\x0c")
            for line in page_text.splitlines()
            if line.strip().lstrip("\ufeff\x0c")
        ]
        if lines and lines[-1] in _SECTION_HEADINGS:
            stranded.append({"page": page_number, "heading": lines[-1]})
    findings.append(
        QualityFinding(
            check_id="PDF_STRANDED_HEADING",
            rule_ids=("R-22",),
            category="ats",
            severity=Severity.ERROR if stranded else Severity.PASS,
            message=(
                f"{len(stranded)} section heading(s) are stranded at a page foot"
                if stranded
                else "No section heading is stranded at a page foot"
            ),
            evidence={"headings": stranded},
        )
    )
    return findings


def _font_name_key(value: Any) -> str:
    name = unicodedata.normalize("NFKC", str(value)).strip().lstrip("/")
    name = re.sub(r"^[A-Za-z]{6}\+", "", name)
    return re.sub(r"\s+", "", name).casefold()


def _used_text_fonts(page: Any) -> dict[str, str]:
    text_dictionary = page.get_text("dict", sort=True)
    if not isinstance(text_dictionary, Mapping):
        raise ValueError("PyMuPDF text dictionary is not a mapping")
    used: dict[str, str] = {}
    for block in text_dictionary.get("blocks", ()):  # type: ignore[union-attr]
        if not isinstance(block, Mapping):
            continue
        for line in block.get("lines", ()):
            if not isinstance(line, Mapping):
                continue
            for span in line.get("spans", ()):
                if not isinstance(span, Mapping) or not str(span.get("text", "")).strip():
                    continue
                display = str(span.get("font", "")).strip()
                key = _font_name_key(display)
                if key:
                    used.setdefault(key, display)
    return used


def _font_findings(document: Any) -> list[QualityFinding]:
    try:
        font_rows: dict[int, tuple[Any, ...]] = {}
        used_fonts: dict[str, str] = {}
        matched_used_fonts: set[str] = set()
        for page_number in range(document.page_count):
            page = document.load_page(page_number)
            page_used_fonts = _used_text_fonts(page)
            used_fonts.update(page_used_fonts)
            if hasattr(page, "get_fonts"):
                rows = page.get_fonts(full=True)
            elif hasattr(document, "get_page_fonts"):
                rows = document.get_page_fonts(page_number, full=True)
            else:
                raise RuntimeError("PyMuPDF does not expose page font metadata")
            for row in rows:
                if not row or len(row) < 4:
                    continue
                xref = int(row[0])
                font_key = _font_name_key(row[3])
                if xref > 0 and font_key in page_used_fonts:
                    font_rows.setdefault(xref, tuple(row))
                    matched_used_fonts.add(font_key)

        unmatched_used_fonts = sorted(
            used_fonts[key]
            for key in used_fonts.keys() - matched_used_fonts
        )
        if not used_fonts:
            return [
                QualityFinding(
                    check_id="PDF_FONT_TOUNICODE",
                    rule_ids=("R-19", "R-24"),
                    category="ats",
                    severity=Severity.ERROR,
                    message="No used text-span fonts were available for ToUnicode inspection",
                    evidence={
                        "fonts_inspected": 0,
                        "used_span_fonts": [],
                        "unmatched_used_fonts": [],
                        "missing": [],
                    },
                )
            ]

        missing: list[dict[str, Any]] = []
        inspected: list[dict[str, Any]] = []
        for xref, row in sorted(font_rows.items()):
            extension = str(row[1]) if len(row) > 1 else ""
            font_type = str(row[2]) if len(row) > 2 else ""
            base_font = str(row[3]) if len(row) > 3 else ""
            key_type, key_value = document.xref_get_key(xref, "ToUnicode")
            item = {
                "xref": xref,
                "font": base_font,
                "type": font_type,
                "extension": extension,
                "to_unicode_type": key_type,
                "to_unicode_value": key_value,
            }
            inspected.append(item)
            if (
                extension.casefold() in {"", "n/a"}
                or key_type != "xref"
                or not re.fullmatch(r"\d+\s+0\s+R", str(key_value))
            ):
                missing.append(item)

        if not inspected:
            return [
                QualityFinding(
                    check_id="PDF_FONT_TOUNICODE",
                    rule_ids=("R-19", "R-24"),
                    category="ats",
                    severity=Severity.ERROR,
                    message="No used PDF font resource matched the extracted text spans",
                    evidence={
                        "fonts_inspected": 0,
                        "used_span_fonts": sorted(used_fonts.values()),
                        "unmatched_used_fonts": unmatched_used_fonts,
                        "missing": [],
                    },
                )
            ]
        has_errors = bool(missing or unmatched_used_fonts)
        return [
            QualityFinding(
                check_id="PDF_FONT_TOUNICODE",
                rule_ids=("R-19", "R-24"),
                category="ats",
                severity=Severity.ERROR if has_errors else Severity.PASS,
                message=(
                    f"{len(missing)} of {len(inspected)} used fonts lack a ToUnicode map; "
                    f"{len(unmatched_used_fonts)} used font name(s) were unmatched"
                    if has_errors
                    else f"All {len(inspected)} used text fonts have ToUnicode maps"
                ),
                evidence={
                    "fonts_inspected": len(inspected),
                    "used_span_fonts": sorted(used_fonts.values()),
                    "unmatched_used_fonts": unmatched_used_fonts,
                    "missing": missing,
                },
            )
        ]
    except Exception as error:
        # Font inspection is an ATS blocker; never turn an inspection failure
        # into a silent pass.
        return [
            QualityFinding(
                check_id="PDF_FONT_TOUNICODE",
                rule_ids=("R-19", "R-24"),
                category="ats",
                severity=Severity.ERROR,
                message=f"Could not inspect embedded-font ToUnicode maps: {error}",
                evidence={"error_type": type(error).__name__},
            )
        ]


def _postcompile_findings(
    *, tex: str, pdf_path: Path, log_path: Path
) -> list[QualityFinding]:
    findings: list[QualityFinding] = []
    document: Any | None = None
    try:
        import fitz

        document = fitz.open(pdf_path)
        page_texts = [
            document.load_page(page_number).get_text("text", sort=True)
            for page_number in range(document.page_count)
        ]
        if not any(text.strip() for text in page_texts):
            findings.append(
                QualityFinding(
                    check_id="PDF_TEXT_EXTRACTION",
                    rule_ids=("R-18", "R-19", "R-24"),
                    category="ats",
                    severity=Severity.ERROR,
                    message="PyMuPDF extracted no text from the compiled CV",
                    evidence={"page_count": document.page_count},
                )
            )
        else:
            findings.append(
                QualityFinding(
                    check_id="PDF_TEXT_EXTRACTION",
                    rule_ids=("R-18", "R-19", "R-24"),
                    category="ats",
                    severity=Severity.PASS,
                    message=f"PyMuPDF extracted text from {document.page_count} page(s)",
                    evidence={"page_count": document.page_count},
                )
            )
            findings.extend(_pdf_text_findings(page_texts, tex))
        findings.extend(_font_findings(document))
    except Exception as error:
        findings.append(
            QualityFinding(
                check_id="PDF_TEXT_EXTRACTION",
                rule_ids=("R-18", "R-19", "R-24"),
                category="ats",
                severity=Severity.ERROR,
                message=f"Could not inspect compiled CV PDF: {error}",
                evidence={"path": str(pdf_path), "error_type": type(error).__name__},
            )
        )
    finally:
        if document is not None:
            try:
                document.close()
            except Exception:
                # A close failure does not invalidate already extracted data;
                # unlike inspection failures it cannot affect check accuracy.
                pass

    try:
        log_text = log_path.read_text(encoding="utf-8", errors="replace")
    except Exception as error:
        findings.append(
            QualityFinding(
                check_id="LATEX_OVERFULL",
                rule_ids=("R-24",),
                category="layout",
                severity=Severity.ERROR,
                message=f"Could not read the explicit LaTeX log: {error}",
                evidence={"path": str(log_path), "error_type": type(error).__name__},
            )
        )
        return findings

    all_overfull = len(re.findall(r"Overfull\s+\\hbox", log_text, flags=re.IGNORECASE))
    widths = [float(value) for value in _OVERFULL_RE.findall(log_text)]
    accepted_baseline = (
        all_overfull == 1
        and len(widths) == 1
        and 3.0 <= widths[0] <= 3.2
    )
    acceptable = all_overfull == 0 or accepted_baseline
    findings.append(
        QualityFinding(
            check_id="LATEX_OVERFULL",
            rule_ids=("R-24",),
            category="layout",
            severity=Severity.PASS if acceptable else Severity.ERROR,
            message=(
                "No overfull hbox warnings were found"
                if all_overfull == 0
                else f"Accepted one known baseline overfull hbox ({widths[0]:.3g}pt)"
                if accepted_baseline
                else f"Review {all_overfull} overfull hbox warning(s); parsed widths: {widths}"
            ),
            evidence={
                "count": all_overfull,
                "widths_pt": widths,
                "accepted_baseline": accepted_baseline,
                "baseline_range_pt": [3.0, 3.2],
            },
        )
    )
    return findings


def validate_cv_quality(
    *,
    tex_path: Path,
    job_description: str,
    cv_rules: str,
    bullet_library: str,
    skills_profiles: str,
    expected_job_title: str = "",
    pdf_path: Path | None = None,
    log_path: Path | None = None,
    provider: str = "",
    model: str | None = None,
    effort: str | None = None,
    hashes: Mapping[str, str] | None = None,
    generated_at: datetime | None = None,
) -> QualityReport:
    """Validate one generated CV and return a structured cumulative report.

    ``pdf_path`` and ``log_path`` are a pair: omit both for precompile checks,
    or supply both for precompile plus postcompile checks.  The three source
    strings must be freshly extracted from the authoritative CV documents.
    """

    if (pdf_path is None) != (log_path is None):
        raise ValueError("pdf_path and log_path must be supplied together.")
    for label, value in (
        ("job_description", job_description),
        ("cv_rules", cv_rules),
        ("bullet_library", bullet_library),
        ("skills_profiles", skills_profiles),
        ("expected_job_title", expected_job_title),
    ):
        if not isinstance(value, str):
            raise TypeError(f"{label} must be a string.")
        if label not in {"job_description", "expected_job_title"} and not value.strip():
            raise ValueError(f"{label} cannot be empty.")

    tex_path = Path(tex_path)
    tex_bytes = tex_path.read_bytes()
    try:
        tex = tex_bytes.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(f"Generated CV is not valid UTF-8: {tex_path}") from error

    computed_hashes: dict[str, str] = {
        "tex": _sha256_bytes(tex_bytes),
        "job_description": _sha256_text(job_description),
        "cv_rules": _sha256_text(cv_rules),
        "bullet_library": _sha256_text(bullet_library),
        "skills_profiles": _sha256_text(skills_profiles),
    }
    if pdf_path is not None:
        pdf_path = Path(pdf_path)
        if pdf_path.is_file():
            computed_hashes["pdf"] = _sha256_bytes(pdf_path.read_bytes())
    if log_path is not None:
        log_path = Path(log_path)
        if log_path.is_file():
            computed_hashes["log"] = _sha256_bytes(log_path.read_bytes())
    if hashes is not None:
        for key, value in hashes.items():
            computed_hashes[str(key)] = str(value)

    findings: list[QualityFinding] = []
    provenance: tuple[BulletProvenance, ...] = ()
    jd_matches: tuple[JDMatch, ...] = ()
    jd_metrics: dict[str, int | float | None] = {
        "inventory_terms_requested": 0,
        "inventory_terms_on_cv": 0,
        "all_terms_requested": 0,
        "all_terms_on_cv": 0,
        "tailoring_percent": None,
        "coverage_percent": None,
    }
    try:
        _, regions = parse_cv_regions(tex)
        bullets = {
            region: _extract_bullets(regions[region]) for region in _BULLET_REGIONS
        }
    except Exception as error:
        findings.append(
            QualityFinding(
                check_id="LATEX_STRUCTURE",
                rule_ids=("R-01",),
                category="structure",
                severity=Severity.ERROR,
                message=f"Could not parse generated CV edit regions: {error}",
                evidence={"error_type": type(error).__name__},
            )
        )
    else:
        findings.append(
            QualityFinding(
                check_id="LATEX_STRUCTURE",
                rule_ids=("R-01",),
                category="structure",
                severity=Severity.PASS,
                message="All nine CV edit regions were parsed",
                evidence={"region_count": len(regions)},
            )
        )
        try:
            source_findings, provenance, jd_matches, jd_metrics = _source_findings(
                regions=regions,
                bullets=bullets,
                job_description=job_description,
                bullet_library=bullet_library,
                skills_profiles=skills_profiles,
                expected_job_title=expected_job_title,
            )
        except Exception as error:
            findings.append(
                QualityFinding(
                    check_id="SOURCE_VALIDATION_RUNTIME",
                    rule_ids=("R-07", "R-10", "R-12"),
                    category="configuration",
                    severity=Severity.ERROR,
                    message=f"Could not run authoritative source checks: {error}",
                    evidence={"error_type": type(error).__name__},
                )
            )
        else:
            findings.extend(source_findings)

    if pdf_path is not None and log_path is not None:
        findings.extend(
            _postcompile_findings(tex=tex, pdf_path=pdf_path, log_path=log_path)
        )

    return QualityReport(
        schema_version=SCHEMA_VERSION,
        validator_version=VALIDATOR_VERSION,
        generated_at_utc=_utc_timestamp(generated_at),
        provider=str(provider),
        model="" if model is None else str(model),
        effort="" if effort is None else str(effort),
        hashes=computed_hashes,
        findings=tuple(findings),
        provenance=provenance,
        jd_metrics=jd_metrics,
        jd_matches=jd_matches,
    )


def _xlsx_safe(value: Any) -> Any:
    """Prevent spreadsheet formula execution without changing canonical JSON."""

    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _write_row(sheet: Any, row: Sequence[Any]) -> None:
    sheet.append([_xlsx_safe(value) for value in row])


def _build_xlsx(report: QualityReport) -> bytes:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError as error:  # pragma: no cover - installation issue
        raise RuntimeError(
            "openpyxl is required to write validation.xlsx; install project dependencies."
        ) from error

    workbook = Workbook()
    workbook.properties.creator = "job-application-pipeline"
    workbook.properties.title = "CV and cover-letter validation"
    summary = workbook.active
    summary.title = "Summary"

    summary_rows: list[tuple[Any, Any]] = [
        ("Schema version", report.schema_version),
        ("Validator version", report.validator_version),
        ("Generated at (UTC)", report.generated_at_utc),
        ("Provider", report.provider),
        ("Model", report.model),
        ("Effort", report.effort),
        ("Verdict", report.verdict),
        ("PASS", report.counts["PASS"]),
        ("WARN", report.counts["WARN"]),
        ("ERROR", report.counts["ERROR"]),
        ("TOTAL", report.counts["TOTAL"]),
    ]
    summary_rows.extend(
        (f"Hash: {key}", value) for key, value in sorted(report.hashes.items())
    )
    summary_rows.extend(
        (f"JD: {key}", value if value is not None else "n/a")
        for key, value in report.jd_metrics.items()
    )
    _write_row(summary, ("Metric", "Value"))
    for row in summary_rows:
        _write_row(summary, row)

    checks = workbook.create_sheet("Checks")
    _write_row(
        checks,
        ("ID", "Rules", "Category", "Status", "Message", "Evidence (JSON)"),
    )
    for finding in report.findings:
        _write_row(
            checks,
            (
                finding.check_id,
                ", ".join(finding.rule_ids),
                finding.category,
                finding.severity.value,
                finding.message,
                json.dumps(
                    _json_value(finding.evidence),
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ),
            ),
        )

    repairs = workbook.create_sheet("Repairs")
    _write_row(
        repairs,
        (
            "Attempt",
            "Status",
            "Trigger checks",
            "Changed files",
            "Summary",
            "Change-log notes",
            "Provider log",
        ),
    )
    for finding in report.findings:
        if finding.category != "ai-repair":
            continue
        evidence = finding.evidence
        trigger_checks = evidence.get("trigger_checks", ())
        changed_files = evidence.get("changed_files", ())
        _write_row(
            repairs,
            (
                evidence.get("attempt", ""),
                finding.severity.value,
                ", ".join(str(item) for item in trigger_checks),
                ", ".join(str(item) for item in changed_files),
                finding.message,
                evidence.get("change_log_notes", ""),
                evidence.get("provider_log", ""),
            ),
        )

    bullets = workbook.create_sheet("Bullets")
    _write_row(
        bullets,
        (
            "Region",
            "Bullet #",
            "Text",
            "Source ID",
            "Source text",
            "Similarity",
            "Match",
            "Tier",
            "Profiles",
            "Priority",
        ),
    )
    for entry in report.provenance:
        _write_row(
            bullets,
            (
                entry.region,
                entry.bullet_index,
                entry.text,
                entry.source_id or "",
                entry.source_text or "",
                entry.similarity,
                entry.match,
                entry.tier,
                entry.profiles,
                entry.priority,
            ),
        )

    jd_match = workbook.create_sheet("JDMatch")
    _write_row(jd_match, ("Term", "In inventory", "On CV", "Tier", "Action"))
    for match in report.jd_matches:
        _write_row(
            jd_match,
            (
                match.term,
                "yes" if match.in_inventory else "no",
                "yes" if match.on_cv else "no",
                match.tier if match.tier is not None else "",
                match.action,
            ),
        )

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    status_fills = {
        Severity.PASS.value: PatternFill("solid", fgColor="E2F0D9"),
        Severity.WARN.value: PatternFill("solid", fgColor="FFF2CC"),
        Severity.ERROR.value: PatternFill("solid", fgColor="F4CCCC"),
    }
    widths = {
        "Summary": (28, 72),
        "Checks": (28, 18, 18, 12, 72, 72),
        "Repairs": (12, 12, 38, 42, 72, 72, 64),
        "Bullets": (38, 10, 72, 16, 72, 12, 14, 10, 18, 12),
        "JDMatch": (38, 14, 12, 10, 60),
    }
    for sheet in workbook.worksheets:
        sheet.freeze_panes = "A2"
        if sheet.max_row >= 1:
            sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        for column_index, width in enumerate(widths[sheet.title], start=1):
            sheet.column_dimensions[get_column_letter(column_index)].width = width

    for row in checks.iter_rows(min_row=2):
        status_cell = row[3]
        fill = status_fills.get(str(status_cell.value))
        if fill is not None:
            status_cell.fill = fill
            status_cell.font = Font(bold=True)
    for row in repairs.iter_rows(min_row=2):
        status_cell = row[1]
        fill = status_fills.get(str(status_cell.value))
        if fill is not None:
            status_cell.fill = fill
            status_cell.font = Font(bold=True)
    for row in summary.iter_rows(min_row=2, max_col=1):
        row[0].font = Font(bold=True)

    output = io.BytesIO()
    workbook.save(output)
    return output.getvalue()


def _atomic_write(path: Path, content: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        ) as stream:
            temporary = Path(stream.name)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def _snapshot_report_file(path: Path) -> tuple[bool, bytes]:
    try:
        return True, path.read_bytes()
    except FileNotFoundError:
        return False, b""


def _restore_report_file(path: Path, existed: bool, content: bytes) -> None:
    if existed:
        try:
            unchanged = path.is_file() and path.read_bytes() == content
        except OSError:
            unchanged = False
        if not unchanged:
            _atomic_write(path, content)
        return
    if path.is_symlink() or path.exists():
        path.unlink()


def write_quality_reports(
    report: QualityReport, *, json_path: Path, xlsx_path: Path
) -> None:
    """Atomically write canonical JSON and human XLSX from one report value."""

    if not isinstance(report, QualityReport):
        raise TypeError("report must be a QualityReport.")
    json_path = Path(json_path)
    xlsx_path = Path(xlsx_path)
    if json_path.resolve() == xlsx_path.resolve():
        raise ValueError("json_path and xlsx_path must be different files.")

    canonical_json = (
        json.dumps(
            report.to_dict(),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")
    # Render both before replacing either destination.  A serialization error
    # therefore leaves any existing report pair untouched.
    xlsx_bytes = _build_xlsx(report)
    previous_json = _snapshot_report_file(json_path)
    previous_xlsx = _snapshot_report_file(xlsx_path)
    try:
        _atomic_write(json_path, canonical_json)
        _atomic_write(xlsx_path, xlsx_bytes)
    except Exception as error:
        rollback_errors: list[str] = []
        for path, (existed, content) in (
            (json_path, previous_json),
            (xlsx_path, previous_xlsx),
        ):
            try:
                _restore_report_file(path, existed, content)
            except Exception as rollback_error:
                rollback_errors.append(f"{path}: {rollback_error}")
        if rollback_errors:
            raise RuntimeError(
                "Quality-report pair commit failed and rollback was incomplete: "
                + "; ".join(rollback_errors)
            ) from error
        raise


__all__ = [
    "BulletProvenance",
    "JDMatch",
    "QualityFinding",
    "QualityReport",
    "SCHEMA_VERSION",
    "Severity",
    "VALIDATOR_VERSION",
    "validate_cv_quality",
    "write_quality_reports",
]
