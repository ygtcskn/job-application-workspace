"""Build one self-contained provider request for a job advertisement."""

from __future__ import annotations

import re
from pathlib import Path

from .documents import extract_docx_text, extract_pdf_text, read_text
from .paths import PipelinePaths
from .validation import validate_cover_template, validate_cv_template


PROMPT_PLACEHOLDERS = (
    "OUTPUT_DIR",
    "CLEAN_JOB_TITLE",
    "CV_RULES",
    "BULLET_LIBRARY",
    "SKILLS_PROFILES",
    "CV_TEMPLATE",
    "COVER_RULES",
    "COVER_TEMPLATE",
    "JOB_DESCRIPTION",
)
_PLACEHOLDER_RE = re.compile(r"\{\{([A-Z0-9_]+)\}\}")

_GENDER_MARKER_RE = re.compile(
    r"^[mfwxd](?:(?:\s*[/|]\s*|\s+)[mfwxd]){1,4}$",
    flags=re.IGNORECASE,
)
_LOGISTICS_RE = re.compile(
    r"^(?:remote|hybrid|on[ -]?site|full[ -]?time|part[ -]?time|contract|"
    r"vollzeit|teilzeit|befristet)(?:\s+(?:role|position|work))?$",
    flags=re.IGNORECASE,
)
# A trailing engagement type is metadata about the contract, not part of the
# role noun phrase: "Data Analyst Internship" and "Data Analyst (Intern)" are
# both applications for "Data Analyst".
_ENGAGEMENT_WORDS = (
    r"intern(?:ship)?s?|praktikum|praktikant(?:in)?|working\s+student|"
    r"werkstudent(?:in)?|trainee(?:\s+programme?)?|graduate\s+(?:programme?|scheme)|"
    r"apprentice(?:ship)?|volontariat|thesis|abschlussarbeit"
)
_ENGAGEMENT_RE = re.compile(rf"^(?:{_ENGAGEMENT_WORDS})$", flags=re.IGNORECASE)
_LEADING_ENGAGEMENT_RE = re.compile(
    rf"^(?:{_ENGAGEMENT_WORDS})[\s,:–—-]+(?=\S)", flags=re.IGNORECASE
)
_TRAILING_ENGAGEMENT_RE = re.compile(
    rf"[\s,\u2013\u2014-]+(?:{_ENGAGEMENT_WORDS})\s*$", flags=re.IGNORECASE
)


def clean_job_title(value: str) -> str:
    """Return the role noun phrase without work-mode or gender metadata."""

    original = re.sub(r"\s+", " ", value).strip()
    cleaned = re.sub(r"^job\s*title\s*:\s*", "", original, flags=re.IGNORECASE)

    def strip_parenthetical(match: re.Match[str]) -> str:
        content = re.sub(r"\s+", " ", match.group(1)).strip()
        if (
            _GENDER_MARKER_RE.fullmatch(content)
            or _LOGISTICS_RE.fullmatch(content)
            or _ENGAGEMENT_RE.fullmatch(content)
        ):
            return ""
        return match.group(0)

    cleaned = re.sub(r"\(([^()]*)\)", strip_parenthetical, cleaned)
    # A dash/pipe suffix is metadata under the approved cover-letter rules.
    cleaned = re.split(r"\s+(?:[|\u2013\u2014]|-)\s+", cleaned, maxsplit=1)[0]
    cleaned = re.sub(
        r"\s+(?:remote|hybrid|on[ -]?site|full[ -]?time|part[ -]?time|contract|"
        r"vollzeit|teilzeit|befristet)\s*$",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(
        r"^(?:senior|lead|principal|head\s+of)\s+",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    # German postings often lead with the engagement type instead of trailing
    # it. The model may only drop trailing words, so this must be handled here.
    cleaned = _LEADING_ENGAGEMENT_RE.sub("", cleaned)
    cleaned = re.sub(r"(?:\*in|:in)\s*$", "", cleaned, flags=re.IGNORECASE)
    # Repeat: "Data Analyst Internship (m/w/d)" leaves a trailing qualifier only
    # after the parenthetical has gone.
    previous = None
    while previous != cleaned:
        previous = cleaned
        cleaned = _TRAILING_ENGAGEMENT_RE.sub("", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" ,;:|-/")
    if not cleaned:
        raise ValueError(f"Could not derive a clean job title from: {original!r}")
    return cleaned


def extract_clean_job_title(job_description: str) -> str:
    """Read a clean title, repairing a visibly truncated first heading."""

    ignored = {
        "job description",
        "job posting",
        "about the job",
        "position",
    }
    ignored_labels = (
        "company:",
        "location:",
        "date posted:",
        "posting time:",
        "applicant info:",
        "source:",
        "imported:",
    )
    heading = ""
    for raw_line in job_description.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line or re.fullmatch(r"--- Page \d+ ---", line, flags=re.IGNORECASE):
            continue
        if line.casefold() in ignored or line.casefold().startswith(ignored_labels):
            continue
        heading = clean_job_title(line)
        break
    if not heading:
        raise ValueError("Could not find a job-title heading in the job description.")

    # LinkedIn's top-card text can be clipped by a character or two even when
    # the full title survives in a structured body field. Only replace the
    # heading when the body candidate is a strict extension of it; unrelated
    # prose can therefore never silently change the role.
    body_candidates: list[str] = []
    body_patterns = (
        r"(?im)^\s*Job\s+Title\s*:\s*([^\r\n]+)",
        r"(?i)\brole\s+for\s+an?\s+(.+?)\s+at\s+[^.\r\n]+",
    )
    for pattern in body_patterns:
        for match in re.finditer(pattern, job_description):
            try:
                candidate = clean_job_title(match.group(1))
            except ValueError:
                continue
            if candidate.casefold().startswith(heading.casefold()) and (
                len(candidate) > len(heading)
            ):
                body_candidates.append(candidate)
    if body_candidates:
        return max(body_candidates, key=len)
    return heading


def render_prompt(template: str, replacements: dict[str, str]) -> str:
    """Render exactly the pipeline's fixed nine-placeholder prompt contract."""

    expected = set(PROMPT_PLACEHOLDERS)
    supplied = set(replacements)
    if supplied != expected:
        missing = sorted(expected - supplied)
        extra = sorted(supplied - expected)
        details: list[str] = []
        if missing:
            details.append("missing replacements: " + ", ".join(missing))
        if extra:
            details.append("unexpected replacements: " + ", ".join(extra))
        raise ValueError("Invalid prompt replacement contract (" + "; ".join(details) + ").")

    found = _PLACEHOLDER_RE.findall(template)
    missing_in_template = sorted(expected - set(found))
    unexpected_in_template = sorted(set(found) - expected)
    if missing_in_template or unexpected_in_template:
        details = []
        if missing_in_template:
            details.append("missing placeholders: " + ", ".join(missing_in_template))
        if unexpected_in_template:
            details.append(
                "unexpected placeholders: " + ", ".join(unexpected_in_template)
            )
        raise ValueError("Prompt template contract violation (" + "; ".join(details) + ").")

    # A callback performs one pass, so placeholder-like text embedded inside a
    # source document is treated as data and cannot trigger a second replacement.
    return _PLACEHOLDER_RE.sub(lambda match: replacements[match.group(1)], template)


def build_request(
    paths: PipelinePaths,
    job_pdf: Path,
    output_dir: Path,
) -> str:
    """Read the current authorities and embed them in a complete AI request."""

    cv_template = read_text(paths.cv_template)
    cover_template = read_text(paths.cover_template)
    validate_cv_template(cv_template)
    validate_cover_template(cover_template)

    job_description = extract_pdf_text(Path(job_pdf))
    replacements = {
        "OUTPUT_DIR": str(Path(output_dir).resolve()),
        "CLEAN_JOB_TITLE": extract_clean_job_title(job_description),
        "CV_RULES": read_text(paths.cv_rules),
        "BULLET_LIBRARY": extract_docx_text(paths.bullet_library),
        "SKILLS_PROFILES": extract_docx_text(paths.skills_profiles),
        "CV_TEMPLATE": cv_template,
        "COVER_RULES": read_text(paths.cover_rules),
        "COVER_TEMPLATE": cover_template,
        "JOB_DESCRIPTION": job_description,
    }
    return render_prompt(read_text(paths.prompt_template), replacements)
