"""Boundary and structural validation for generated LaTeX documents."""

from __future__ import annotations

import re


CV_EDIT_REGIONS = (
    "SUMMARY",
    "EDUCATION_FAU_BULLETS",
    "EDUCATION_ISTANBUL_BULLETS",
    "EXPERIENCE_IAB_BULLETS",
    "EXPERIENCE_ZIRAAT_BULLETS",
    "PROJECT_THESIS_BULLETS",
    "PROJECT_NOSI_BULLETS",
    "PUBLICATION_POLISH_WORKFORCE_BULLETS",
    "SKILLS",
)

COVER_EDIT_REGIONS = (
    "COVER_HEADER",
    "SALUTATION",
    "PARA_1_HOOK_THESIS",
    "PARA_2_IAB",
    "PARA_3_FIT",
    "PARA_4_MOTIVATION",
    "PARA_5_CLOSE",
)

_MARKER_RE = re.compile(
    r"^[ \t]*%[ \t]*AI_EDIT_(START|END):[ \t]*([A-Z0-9_]+)[ \t]*$",
    flags=re.MULTILINE,
)


def _normalise_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")


def parse_edit_regions(
    tex: str, expected_regions: tuple[str, ...], *, document_name: str
) -> tuple[list[str], dict[str, str]]:
    """Split a marked template into immutable segments and editable bodies."""

    normalised = _normalise_newlines(tex)
    fixed_segments: list[str] = []
    regions: dict[str, str] = {}
    expected_index = 0
    cursor = 0
    open_name: str | None = None
    content_start = 0

    for match in _MARKER_RE.finditer(normalised):
        marker_type, name = match.groups()
        if marker_type == "START":
            if open_name is not None:
                raise ValueError(
                    f"{document_name} marker {name} starts before {open_name} ends."
                )
            if expected_index >= len(expected_regions) or name != expected_regions[expected_index]:
                expected = (
                    expected_regions[expected_index]
                    if expected_index < len(expected_regions)
                    else "no additional region"
                )
                raise ValueError(
                    f"Unexpected {document_name} edit region {name}; expected {expected}."
                )
            fixed_segments.append(normalised[cursor : match.end()])
            open_name = name
            content_start = match.end()
        else:
            if open_name != name:
                raise ValueError(
                    f"{document_name} marker {name} ends while "
                    f"{open_name or 'no region'} is open."
                )
            regions[name] = normalised[content_start : match.start()]
            cursor = match.start()
            open_name = None
            expected_index += 1

    if open_name is not None:
        raise ValueError(f"{document_name} edit region {open_name} has no end marker.")
    if expected_index != len(expected_regions):
        missing = ", ".join(expected_regions[expected_index:])
        raise ValueError(f"{document_name} template is missing edit regions: {missing}")

    fixed_segments.append(normalised[cursor:])
    return fixed_segments, regions


def parse_cv_regions(tex: str) -> tuple[list[str], dict[str, str]]:
    return parse_edit_regions(tex, CV_EDIT_REGIONS, document_name="CV")


def parse_cover_regions(tex: str) -> tuple[list[str], dict[str, str]]:
    return parse_edit_regions(tex, COVER_EDIT_REGIONS, document_name="cover letter")


def validate_cv_template(template_tex: str) -> None:
    parse_cv_regions(template_tex)


def validate_cover_template(template_tex: str) -> None:
    parse_cover_regions(template_tex)


def _is_escaped(text: str, index: int) -> bool:
    backslashes = 0
    index -= 1
    while index >= 0 and text[index] == "\\":
        backslashes += 1
        index -= 1
    return backslashes % 2 == 1


def _extract_braced_group(text: str, opening_brace: int) -> tuple[str, int]:
    if opening_brace >= len(text) or text[opening_brace] != "{":
        raise ValueError("Expected an opening LaTeX brace.")
    depth = 1
    index = opening_brace + 1
    while index < len(text) and depth:
        character = text[index]
        if not _is_escaped(text, index):
            if character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
        index += 1
    if depth:
        raise ValueError("LaTeX content contains unbalanced braces.")
    return text[opening_brace + 1 : index - 1], index


def _extract_top_level_calls(text: str, command: str) -> list[str]:
    """Require text to consist only of repeated brace-balanced calls."""

    arguments: list[str] = []
    cursor = 0
    while cursor < len(text):
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        if cursor >= len(text):
            break
        match = re.match(re.escape(command) + r"\s*\{", text[cursor:])
        if not match:
            raise ValueError(f"Content appears outside a {command} argument.")
        opening_brace = cursor + match.end() - 1
        argument, cursor = _extract_braced_group(text, opening_brace)
        arguments.append(argument)
    return arguments


def _extract_skills_items(skills: str) -> list[str]:
    start_wrapper = r"\resumeSubHeadingListStart"
    end_wrapper = r"\resumeSubHeadingListEnd"
    body = skills.strip()[len(start_wrapper) : -len(end_wrapper)]
    return _extract_top_level_calls(body, r"\item")


def _parse_skill_item(item: str, expected_label: str) -> str:
    stripped = item.strip()
    command_match = re.match(r"\\textbf\s*\{", stripped)
    if not command_match:
        raise ValueError("missing the required \\textbf label")

    label, cursor = _extract_braced_group(stripped, command_match.end() - 1)
    if label != expected_label:
        raise ValueError(f"expected label {expected_label}")

    while cursor < len(stripped) and stripped[cursor].isspace():
        cursor += 1
    if cursor >= len(stripped) or stripped[cursor] != "{":
        raise ValueError("missing the braced skill value")

    value_group, cursor = _extract_braced_group(stripped, cursor)
    if stripped[cursor:].strip():
        raise ValueError("contains content after its skill value")
    if not value_group.startswith(":"):
        raise ValueError("skill value must begin with a colon")
    value = value_group[1:].strip()
    if not value:
        raise ValueError("has an empty skill value")
    return value


def _assert_fixed_content(
    template_fixed: list[str],
    generated_fixed: list[str],
    regions: tuple[str, ...],
    *,
    document_name: str,
) -> list[str]:
    """Check content outside the edit regions; return non-fatal notes.

    A model sometimes leaves an extra blank line beside a marker. That cannot
    change what the reader sees, and the compile, page-count, and overfull-box
    checks downstream would catch it if it ever did, so it is reported instead
    of blocking an otherwise finished application. Any other difference is a
    real edit to protected content and still fails.
    """

    if template_fixed == generated_fixed:
        return []
    notes: list[str] = []
    for index, (expected, actual) in enumerate(
        zip(template_fixed, generated_fixed, strict=True)
    ):
        if expected == actual:
            continue
        adjacent = f"before {regions[0]}" if index == 0 else f"after {regions[index - 1]}"
        if expected.split() == actual.split():
            notes.append(
                f"Generated {document_name} changed only whitespace in fixed "
                f"template content {adjacent}."
            )
            continue
        raise ValueError(
            f"Generated {document_name} changed fixed template content {adjacent}."
        )
    if notes:
        return notes
    raise ValueError(f"Generated {document_name} changed fixed template content.")


def _meaningful_region(content: str) -> str:
    return "\n".join(
        line for line in content.splitlines() if line.strip() and not line.lstrip().startswith("%")
    ).strip()


def _contains_bracket_placeholder(text: str) -> bool:
    """Detect human-fillable ``[...]`` tokens without flagging LaTeX options."""

    for match in re.finditer(r"\[([^\[\]\r\n]+)\]", text):
        value = match.group(1).strip()
        if not value:
            continue
        # Normal placement specifiers, including combinations such as [htbp!].
        if re.fullmatch(r"[!htbpHc]+", value):
            continue
        # A complete numeric/dimension body is an option; merely containing a
        # digit is not enough because [Address Line 1] is still a placeholder.
        if re.fullmatch(
            r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)\s*(?:pt|pc|in|bp|cm|mm|dd|cc|sp|ex|em|%|\\(?:textwidth|linewidth|columnwidth|paperwidth|textheight|baselineskip))?",
            value,
            flags=re.IGNORECASE,
        ):
            continue
        if re.fullmatch(
            r"\\(?:textwidth|linewidth|columnwidth|paperwidth|textheight|baselineskip)",
            value,
        ):
            continue
        # Key/value option lists are syntactic even when they contain commas;
        # a prose token such as [City, Country] remains rejectable.
        if "=" in value:
            continue
        # Common one-word LaTeX option bodies that may legitimately occur in
        # an editable header. Natural-language labels remain rejected.
        if value.casefold() in {
            "utf8",
            "english",
            "german",
            "final",
            "draft",
            "portrait",
            "landscape",
            "oneside",
            "twoside",
        }:
            continue
        return True
    return False


def _normalise_greeting_for_check(greeting: str) -> str:
    """Remove harmless LaTeX indentation syntax before the Dear check."""

    candidate = greeting.strip()
    # Permit a single grouping brace around the complete greeting region.
    if candidate.startswith("{") and candidate.endswith("}"):
        candidate = candidate[1:-1].strip()
    candidate = re.sub(r"^(?:\\noindent\b\s*)+", "", candidate).lstrip()
    if candidate.startswith("{") and candidate.endswith("}"):
        candidate = candidate[1:-1].strip()
    return candidate


def validate_generated_cv(template_tex: str, generated_tex: str) -> list[str]:
    """Reject CVs that violate the nine-region template contract."""

    template_fixed, _ = parse_cv_regions(template_tex)
    generated_fixed, generated_regions = parse_cv_regions(generated_tex)
    notes = _assert_fixed_content(
        template_fixed,
        generated_fixed,
        CV_EDIT_REGIONS,
        document_name="CV",
    )

    for required_region in ("SUMMARY", "SKILLS"):
        if not _meaningful_region(generated_regions[required_region]):
            raise ValueError(f"Generated CV left required region {required_region} empty.")

    summary = generated_regions["SUMMARY"].strip()
    if not summary.startswith("{"):
        raise ValueError(r"SUMMARY must contain exactly one {\small ...} wrapper.")
    try:
        summary_body, summary_end = _extract_braced_group(summary, 0)
    except ValueError as error:
        raise ValueError(r"SUMMARY must contain exactly one {\small ...} wrapper.") from error
    summary_body = summary_body.lstrip()
    if (
        summary_end != len(summary)
        or not summary_body.startswith(r"\small")
        or len(summary_body) == len(r"\small")
        or not summary_body[len(r"\small")].isspace()
        or not summary_body[len(r"\small") :].strip()
    ):
        raise ValueError(r"SUMMARY must contain exactly one {\small ...} wrapper.")

    for name in CV_EDIT_REGIONS[1:-1]:
        content = generated_regions[name].strip()
        if not content:
            continue
        if content.count(r"\resumeItemListStart") != 1 or content.count(
            r"\resumeItemListEnd"
        ) != 1:
            raise ValueError(
                f"{name} must have exactly one bullet-list start and end wrapper."
            )
        if not content.startswith(r"\resumeItemListStart") or not content.endswith(
            r"\resumeItemListEnd"
        ):
            raise ValueError(f"{name} has content outside its bullet-list wrapper.")
        list_body = content[
            len(r"\resumeItemListStart") : -len(r"\resumeItemListEnd")
        ]
        try:
            bullets = _extract_top_level_calls(list_body, r"\resumeItemPlain")
        except ValueError as error:
            raise ValueError(
                f"{name} contains content outside its plain bullet commands."
            ) from error
        if not 1 <= len(bullets) <= 4:
            raise ValueError(f"{name} must contain between one and four plain bullets.")
        if any(not bullet.strip() for bullet in bullets):
            raise ValueError(f"{name} contains an empty plain bullet.")
        if r"\resumeItem{" in content:
            raise ValueError(f"{name} uses nested-bullet syntax instead of plain bullets.")

    skills = generated_regions["SKILLS"].strip()
    if (
        skills.count(r"\resumeSubHeadingListStart") != 1
        or skills.count(r"\resumeSubHeadingListEnd") != 1
        or not skills.startswith(r"\resumeSubHeadingListStart")
        or not skills.endswith(r"\resumeSubHeadingListEnd")
    ):
        raise ValueError("SKILLS must have exactly one resume subheading-list wrapper.")

    skill_items = _extract_skills_items(skills)
    skill_labels = ("Programming", "Methods", r"Tools \& Platforms", "Languages")
    if len(skill_items) != len(skill_labels):
        raise ValueError("SKILLS must contain exactly four labelled item entries.")
    for index, (item, label) in enumerate(
        zip(skill_items, skill_labels, strict=True), start=1
    ):
        try:
            value = _parse_skill_item(item, label)
        except ValueError as error:
            raise ValueError(f"SKILLS item {index} is malformed: {error}.") from error
        if index == 4 and value != "Turkish (Native), English (C1), German (B1)":
            raise ValueError("SKILLS must retain the required language levels and order.")

    editable_text = "\n".join(generated_regions.values())
    prohibited_patterns = {
        "Spark/PySpark": r"\b(?:py[\s_-]*)?spark\b",
        "Kubernetes": r"\bkubernetes\b",
    }
    prohibited = [
        tool
        for tool, pattern in prohibited_patterns.items()
        if re.search(pattern, editable_text, flags=re.IGNORECASE)
    ]
    if prohibited:
        raise ValueError(
            "Generated CV contains explicitly excluded tools: " + ", ".join(prohibited)
        )

    return notes


_LATEX_ESCAPES = {
    r"\&": "&",
    r"\%": "%",
    r"\$": "$",
    r"\#": "#",
    r"\_": "_",
    r"\{": "{",
    r"\}": "}",
}


def unescape_latex(text: str) -> str:
    """Undo the LaTeX escaping a generated document must apply.

    A posting titled "Data & Product Engineer" is written into the document as
    "Data \\& Product Engineer", which is correct LaTeX. Comparisons against
    the deterministic clean title have to see through that.
    """

    for escaped, plain in _LATEX_ESCAPES.items():
        text = text.replace(escaped, plain)
    return text


def _title_is_acceptable(used: str, expected: str) -> bool:
    """Allow the deterministic clean title, or a leading part of it.

    A posting may still carry a qualifier the cleaner does not know about, so
    the model may drop trailing words ("Data Analyst Summer Programme" ->
    "Data Analyst"). It may never add or reorder words, which would let an
    unearned seniority or an invented specialism back in.
    """

    used_words = unescape_latex(used).split()
    expected_words = unescape_latex(expected).split()
    if not used_words or len(used_words) > len(expected_words):
        return False
    return [word.casefold() for word in used_words] == [
        word.casefold() for word in expected_words[: len(used_words)]
    ]


_COVER_TEXT_ESCAPES = frozenset(_LATEX_ESCAPES)


def _strip_latex_comments(text: str) -> str:
    """Remove comments without treating an escaped percent sign as one."""

    uncommented: list[str] = []
    for line in _normalise_newlines(text).splitlines():
        comment_at = next(
            (
                index
                for index, character in enumerate(line)
                if character == "%" and not _is_escaped(line, index)
            ),
            None,
        )
        uncommented.append(line if comment_at is None else line[:comment_at])
    return "\n".join(uncommented)


def _latex_commands(text: str) -> list[str]:
    """Return LaTeX control words and control symbols in source order."""

    commands: list[str] = []
    source = _strip_latex_comments(text)
    index = 0
    while index < len(source):
        if source[index] != "\\":
            index += 1
            continue
        if index + 1 >= len(source):
            commands.append("\\")
            break
        following = source[index + 1]
        if following.isalpha() or following == "@":
            end = index + 2
            while end < len(source) and (
                source[end].isalpha() or source[end] == "@"
            ):
                end += 1
            commands.append(source[index:end])
            index = end
            continue
        commands.append(source[index : index + 2])
        index += 2
    return commands


def _assert_text_only_latex(
    text: str,
    *,
    context: str,
    allowed_commands: frozenset[str] = _COVER_TEXT_ESCAPES,
) -> None:
    """Reject commands that could alter typography or page layout."""

    prohibited = [
        command for command in _latex_commands(text) if command not in allowed_commands
    ]
    if prohibited:
        raise ValueError(
            f"{context} introduced a prohibited LaTeX formatting/layout command: "
            f"{prohibited[0]}."
        )


def _split_cover_header(header: str) -> tuple[str, str, str]:
    """Return title, company block, and a scaffold with both fields masked."""

    source = _normalise_newlines(header).strip()
    title_prefix = r"\textbf{\Large Cover Letter for "
    title_start = source.find(title_prefix)
    if title_start < 0:
        raise ValueError("COVER_HEADER changed the required title layout.")
    title_start += len(title_prefix)
    title_suffix = source.find(r"}\\", title_start)
    if title_suffix < 0:
        raise ValueError("COVER_HEADER changed the required title layout.")
    title = source[title_start:title_suffix]

    company_prefix_match = re.search(r"\\raggedright[ \t]*\n", source)
    if company_prefix_match is None:
        raise ValueError("COVER_HEADER changed the required company-block layout.")
    company_start = company_prefix_match.end()
    company_suffix_match = re.search(
        r"\n[ \t]*\\end\{minipage\}", source[company_start:]
    )
    if company_suffix_match is None:
        raise ValueError("COVER_HEADER changed the required company-block layout.")
    company_end = company_start + company_suffix_match.start()
    company_block = source[company_start:company_end]

    scaffold = (
        source[:title_start]
        + "<JOB-TITLE>"
        + source[title_suffix:company_start]
        + "<COMPANY-BLOCK>"
        + source[company_end:]
    )
    return title, company_block, scaffold


def _validate_company_header_block(company_block: str) -> None:
    """Allow one company line and up to two optional address lines."""

    lines = [line.strip() for line in company_block.splitlines() if line.strip()]
    if not 1 <= len(lines) <= 3:
        raise ValueError(
            "COVER_HEADER must contain a company name and at most two address lines."
        )
    for index, line in enumerate(lines):
        has_line_break = line.endswith(r"\\")
        value = line[:-2].rstrip() if has_line_break else line
        if not value:
            raise ValueError("COVER_HEADER contains an empty company/address line.")
        _assert_text_only_latex(value, context="COVER_HEADER company/address text")
        if index < len(lines) - 1 and not has_line_break:
            raise ValueError(
                "COVER_HEADER company/address lines must retain their line separators."
            )
        if index == len(lines) - 1 and has_line_break:
            raise ValueError(
                "COVER_HEADER final company/address line must not end with a line separator."
            )


def _validate_cover_header_layout(template_header: str, generated_header: str) -> None:
    """Keep the header scaffold fixed while allowing only its text tokens."""

    generated_title, generated_company, generated_scaffold = _split_cover_header(
        generated_header
    )
    _assert_text_only_latex(generated_title, context="COVER_HEADER job title")
    _validate_company_header_block(generated_company)

    if _meaningful_region(template_header):
        _template_title, _template_company, template_scaffold = _split_cover_header(
            template_header
        )
        if generated_scaffold != template_scaffold:
            raise ValueError(
                "COVER_HEADER changed the command or layout structure fixed by the template."
            )
        return

    # A small synthetic template is used by unit-level callers. Its generated
    # fixture still has a fixed scaffold, so validate it just as strictly rather
    # than falling back to the former substring checks.
    expected_scaffold = "\n".join(
        (
            r"\noindent\begin{minipage}{\textwidth}",
            r"\textbf{\Large Cover Letter for <JOB-TITLE>}\\",
            r"\end{minipage}",
            r"\begin{minipage}[t]{0.48\textwidth}",
            r"\raggedright",
            "<COMPANY-BLOCK>",
            r"\end{minipage}",
            r"\begin{minipage}[t]{0.45\textwidth}",
            r"Yigit Coskun\\",
            r"Zerzabelshofstrasse 9\\",
            r"90478 Nuremberg\\",
            r"contact@yigitcoskun.com\\",
            "+49 176 45819490",
            r"\end{minipage}",
        )
    )
    if generated_scaffold != expected_scaffold:
        raise ValueError(
            "COVER_HEADER changed the command or layout structure fixed by the template."
        )


def _validate_cover_region_commands(generated_regions: dict[str, str]) -> None:
    """Allow only the template's single paragraph command outside the header."""

    for name in COVER_EDIT_REGIONS[1:]:
        commands = [
            command
            for command in _latex_commands(generated_regions[name])
            if command not in _COVER_TEXT_ESCAPES
        ]
        if commands != [r"\noindent"]:
            unexpected = next(
                (command for command in commands if command != r"\noindent"),
                commands[0] if commands else "missing \\noindent",
            )
            raise ValueError(
                f"{name} introduced a prohibited LaTeX formatting/layout command: "
                f"{unexpected}."
            )


def validate_generated_cover(
    template_tex: str,
    generated_tex: str,
    *,
    expected_job_title: str | None = None,
) -> list[str]:
    """Reject cover letters that violate the seven-region tailoring contract."""

    template_fixed, template_regions = parse_cover_regions(template_tex)
    generated_fixed, generated_regions = parse_cover_regions(generated_tex)
    notes = _assert_fixed_content(
        template_fixed,
        generated_fixed,
        COVER_EDIT_REGIONS,
        document_name="cover letter",
    )

    meaningful: dict[str, str] = {}
    for name in COVER_EDIT_REGIONS:
        meaningful[name] = _meaningful_region(generated_regions[name])
        if not meaningful[name]:
            raise ValueError(f"Generated cover letter left required region {name} empty.")

    _validate_cover_header_layout(
        template_regions["COVER_HEADER"], generated_regions["COVER_HEADER"]
    )
    _validate_cover_region_commands(generated_regions)

    editable_text = "\n".join(generated_regions.values())
    if re.search(r"\{\{[^{}]+\}\}", editable_text):
        raise ValueError("Generated cover letter contains an unresolved {{...}} placeholder.")
    if _contains_bracket_placeholder(editable_text):
        raise ValueError("Generated cover letter contains an unresolved [...] placeholder.")
    if not _normalise_greeting_for_check(meaningful["SALUTATION"]).startswith("Dear"):
        raise ValueError("SALUTATION must begin with 'Dear'.")
    if "kind regards" not in _normalise_newlines(generated_tex).casefold():
        raise ValueError("The fixed cover-letter closing must contain 'Kind regards'.")

    header = meaningful["COVER_HEADER"]
    paragraph_regions = COVER_EDIT_REGIONS[2:]
    for name in paragraph_regions:
        paragraph = meaningful[name]
        if not paragraph.startswith(r"\noindent") or paragraph.count(r"\noindent") != 1:
            raise ValueError(f"{name} must remain exactly one \\noindent paragraph.")

    required_evidence = {
        "PARA_1_HOOK_THESIS": (
            "15 economies",
            "20 years",
            "27,000",
            "Google Trends",
            "69-month",
        ),
        "PARA_2_IAB": (
            "Institute for Employment Research (IAB)",
            "Statistical Methods (KEM)",
            "Migration and International Labour Studies (INTER)",
            "R and Stata",
            "44,000",
            "1975",
            "19,900",
            "Polish workers in Germany",
        ),
        "PARA_4_MOTIVATION": ("TensorFlow", "Python", "IAB"),
    }
    for name, required_items in required_evidence.items():
        missing = [item for item in required_items if item not in meaningful[name]]
        if missing:
            raise ValueError(
                f"{name} changed or removed fixed evidence: " + ", ".join(missing)
            )

    title_patterns = (
        (header, r"Cover Letter for\s+(.+?)\}\\\\"),
        (meaningful["PARA_1_HOOK_THESIS"], r"drew me to the\s+(.+?)\s+role\b"),
        (
            meaningful["PARA_4_MOTIVATION"],
            r"what I can do (?:as an?\s+(.+?)[.,]|in the\s+(.+?)\s+role\b)",
        ),
        (meaningful["PARA_5_CLOSE"], r"fit for the\s+(.+?)\s+role\b"),
    )
    titles: list[str] = []
    for text, pattern in title_patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            raise ValueError("Cover letter changed the required job-title sentence structure.")
        captured = next((group for group in match.groups() if group is not None), None)
        if captured is None:
            raise ValueError("Cover letter changed the required job-title sentence structure.")
        titles.append(re.sub(r"\s+", " ", captured).strip())
    if len({title.casefold() for title in titles}) != 1:
        raise ValueError("Cover letter uses inconsistent job-title values.")
    if expected_job_title is not None and not _title_is_acceptable(
        titles[0], expected_job_title
    ):
        raise ValueError(
            "Cover letter job title must be the deterministic clean title "
            f"{expected_job_title!r} or a leading part of it, not "
            f"{unescape_latex(titles[0])!r}."
        )
    if re.search(
        r"(?:\([mfwxd](?:(?:\s*[/|]\s*|\s+)[mfwxd]){1,4}\)|"
        r"\b(?:senior|lead|principal|head of|remote|hybrid|onsite|"
        r"full[- ]time|part[- ]time|contract)\b)",
        titles[0],
        flags=re.IGNORECASE,
    ):
        raise ValueError("Cover letter job title still contains logistics or unearned seniority.")

    company_patterns = (
        # The trailing "\\" is optional: COVER_LETTER_RULES.md requires an
        # unknown address or city line to be deleted along with its trailing
        # "\\", which leaves the company name as the last line of the block.
        # A posting without a street address is the norm, not an exception.
        (header, r"\\raggedright\s*\n\s*([^\n]+?)(?:\\\\)?[ \t]*\n"),
        (meaningful["PARA_3_FIT"], r"contribute to\s+(.+?)\s+and bring\b"),
        (meaningful["PARA_5_CLOSE"], r"experience to\s+(.+?)\s+and would\b"),
    )
    companies: list[str] = []
    for text, pattern in company_patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            raise ValueError("Cover letter changed the required company-name sentence structure.")
        companies.append(re.sub(r"\s+", " ", match.group(1)).strip())
    if len({company.casefold() for company in companies}) != 1:
        raise ValueError("Cover letter uses inconsistent company-name values.")

    # The role name and the company name are proper nouns quoted from the
    # posting, so the claim and house-style scans below read the surrounding
    # prose only. A posting titled "Data Visualization Analyst" keeps its
    # American spelling, and one titled "Big Data Engineer" is not a claim to
    # distributed experience; neither may be silently reworded.
    prose_text = re.sub(r"\s+", " ", editable_text)
    for proper_noun in (titles[0], companies[0]):
        if proper_noun:
            prose_text = prose_text.replace(proper_noun, " ")

    blocked_claims = {
        "deployment/MLOps claim": r"\b(?:MLOps|production pipeline|deployed model)\b",
        "distributed/big-data claim": r"\b(?:big data|distributed computing|Spark|Hadoop)\b",
        "removed supervision wording": r"eager to learn from experienced colleagues",
    }
    blocked = [
        label
        for label, pattern in blocked_claims.items()
        if re.search(pattern, prose_text, flags=re.IGNORECASE)
    ]
    if blocked:
        raise ValueError("Generated cover letter contains blocked claims: " + ", ".join(blocked))

    if "—" in editable_text:
        raise ValueError("Generated cover letter contains an em dash.")
    us_spellings = re.search(
        r"\b(?:analyz(?:e|es|ed|ing)|labor|visualiz(?:e|es|ed|ing|ation)|behavior|randomized|modeling)\b",
        prose_text,
        flags=re.IGNORECASE,
    )
    if us_spellings:
        raise ValueError(
            f"Generated cover letter is not consistently British English: {us_spellings.group(0)}."
        )

    for index, character in enumerate(editable_text):
        if character in "&%#$_" and not _is_escaped(editable_text, index):
            raise ValueError(
                f"Generated cover letter contains an unescaped LaTeX character: {character}"
            )

    return notes
