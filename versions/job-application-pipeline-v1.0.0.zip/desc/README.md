# LinkedIn Job Importer

This folder implements Stage 1 of the application workflow: importing selected
public LinkedIn job pages through Playwright as text-based PDFs. The root wrapper
stores disposable numbered PDFs in `.artifacts/linkedin_imports` and commits a
numbered copy to the sibling `Job_ad` folder:

```text
.artifacts/linkedin_imports/job_description_14.pdf
.artifacts/linkedin_imports/job_description_15.pdf
../Job_ad/job_description_14.pdf
../Job_ad/job_description_15.pdf
```

Importing never starts CV or cover-letter generation. Inspect `../Job_ad`
before running Stage 2 from the project root.

It can also discover and locally rank up to 100 public job results returned by
configured searches using LinkedIn's recent-post filter. The saved window is
24 hours by default. Discovery creates a review list only; it does not
automatically start CV generation.

Import metadata is kept in `desc/job_sources.csv`. The ledger prevents the
same live PDF from being imported twice and records which URL produced each
job-description number and archive file.

## Setup

From the project root on Windows, with the virtual environment active:

```powershell
python -m pip install -r .\desc\requirements.txt
```

The default browser is Microsoft Edge. No separate Playwright browser download
is needed when Edge is installed.

## Import Jobs

The primary workflow is to add one public LinkedIn job-view URL per line to
`desc/linkedin_urls.txt`, then run the root wrapper:

```powershell
.\create_job_descriptions.ps1
```

Each URL is handled independently. Successfully imported PDFs and ledger rows
remain committed if a later URL fails; a failed or incomplete page leaves no
partial staging or archive PDF. The command reports a failure status when any
URL fails, but a retry skips URLs whose recorded PDFs still exist. This makes it
safe to inspect and use the successful files in `../Job_ad`, or fix the list and
retry before Stage 2.

For advanced use, call the importer directly. Its defaults match the wrapper:
`desc/linkedin_urls.txt`, `.artifacts/linkedin_imports`, `../Job_ad`, and
`desc/job_sources.csv`.

```powershell
python .\desc\import_linkedin_jobs.py
```

You can also pass one or more URLs directly:

```powershell
python .\desc\import_linkedin_jobs.py --url "https://www.linkedin.com/jobs/view/1234567890/"
```

For troubleshooting, show the browser window:

```powershell
python .\desc\import_linkedin_jobs.py --headed
```

To use Playwright Chromium instead of Edge, install and select it explicitly:

```powershell
python -m playwright install chromium
python .\desc\import_linkedin_jobs.py --browser-channel chromium
```

## Discovering Jobs To Import

Finding and ranking recent postings is no longer part of this project. It now
lives in the sibling `job_fetch` project, which writes a shortlist of URLs:

```powershell
cd ..\job_fetch
.\fetch_jobs.ps1
```

Import that shortlist here:

```powershell
python .\desc\import_linkedin_jobs.py --url-file ..\job_fetch\data\shortlist_urls.txt
```

`job_fetch` can also read this importer's ledger, so postings already turned
into applications are marked in its report:

```powershell
.\fetch_jobs.ps1 --ledger ..\job_py\desc\job_sources.csv
```

See [../../job_fetch/README.md](../../job_fetch/README.md) for its options.


## Guardrails And Limitations

- Only HTTPS LinkedIn job-view URLs are accepted.
- Pages are loaded one at a time with a configurable delay.
- The importer does not log in, store cookies, solve CAPTCHAs, rotate proxies,
  or attempt to bypass access controls.
- Login walls, expired jobs, blocked requests, and incomplete descriptions are
  reported as failures and do not create PDFs.
- LinkedIn can change its markup at any time, so extraction is necessarily
  best effort.

LinkedIn's User Agreement and help documentation prohibit unauthorized
scraping and browser automation. Use this importer only after considering
those terms and the content owner's rights. Account-authenticated automation
is intentionally not implemented.
