from __future__ import annotations

import csv
import tempfile
import unittest
from pathlib import Path

from desc import import_linkedin_jobs as importer


SAMPLE_HTML = """
<!doctype html>
<html>
  <head>
    <meta property="og:title" content="Fallback title | LinkedIn">
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "name": "Unrelated"
        },
        {
          "@type": "JobPosting",
          "title": "Data Analyst",
          "datePosted": "2026-07-20",
          "hiringOrganization": {"@type": "Organization", "name": "Example GmbH"},
          "jobLocation": {
            "@type": "Place",
            "address": {
              "addressLocality": "Berlin",
              "addressCountry": {"name": "Germany"}
            }
          },
          "description": "<p>Build reliable reports &amp; explain results.</p><ul><li>Use Python and SQL</li><li>Check data quality</li></ul>"
        }
      ]
    }
    </script>
  </head>
  <body>
    <span class="posted-time-ago__text">3 hours ago</span>
    <figcaption class="num-applicants__caption">42 applicants</figcaption>
  </body>
</html>
"""


class UrlTests(unittest.TestCase):
    def test_browser_defaults_to_edge(self) -> None:
        self.assertEqual(importer.parse_arguments([]).browser_channel, "msedge")

    def test_defaults_use_artifact_cache_and_sibling_job_ad_archive(self) -> None:
        args = importer.parse_arguments([])
        self.assertEqual(
            args.output_dir,
            importer.PROJECT_DIR / ".artifacts" / "linkedin_imports",
        )
        self.assertEqual(args.archive_dir, importer.PROJECT_DIR.parent / "Job_ad")
        self.assertEqual(args.url_file, importer.DESC_DIR / "linkedin_urls.txt")

    def test_canonicalizes_slugged_job_url(self) -> None:
        url, job_id = importer.canonicalize_linkedin_url(
            "https://de.linkedin.com/jobs/view/data-analyst-at-example-1234567890/?refId=x"
        )
        self.assertEqual(job_id, "1234567890")
        self.assertEqual(url, "https://www.linkedin.com/jobs/view/1234567890/")

    def test_rejects_non_linkedin_and_non_https_urls(self) -> None:
        with self.assertRaises(ValueError):
            importer.canonicalize_linkedin_url(
                "https://example.com/jobs/view/1234567890/"
            )
        with self.assertRaises(ValueError):
            importer.canonicalize_linkedin_url(
                "http://www.linkedin.com/jobs/view/1234567890/"
            )


class ExtractionTests(unittest.TestCase):
    def test_extracts_nested_jobposting_json_ld(self) -> None:
        job = importer.extract_job_from_html(
            SAMPLE_HTML, "https://www.linkedin.com/jobs/view/1234567890/"
        )

        self.assertEqual(job.title, "Data Analyst")
        self.assertEqual(job.company, "Example GmbH")
        self.assertEqual(job.location, "Berlin, Germany")
        self.assertEqual(job.date_posted, "2026-07-20")
        self.assertEqual(job.posting_time, "3 hours ago")
        self.assertEqual(job.applicant_info, "42 applicants")
        self.assertIn("Build reliable reports & explain results.", job.description)
        self.assertIn("- Use Python and SQL", job.description)
        self.assertIn("- Check data quality", job.description)

    def test_splits_linkedin_fallback_hiring_title(self) -> None:
        page_html = """
        <html><head>
          <meta property="og:title" content="Example GmbH hiring Data Analyst in Berlin, Germany | LinkedIn">
        </head></html>
        """

        job = importer.extract_job_from_html(
            page_html, "https://www.linkedin.com/jobs/view/1234567890/"
        )

        self.assertEqual(job.title, "Data Analyst")
        self.assertEqual(job.company, "Example GmbH")
        self.assertEqual(job.location, "Berlin, Germany")

    def test_splits_linkedin_fallback_role_at_company_title(self) -> None:
        page_html = """
        <html><head>
          <meta property="og:title" content="Data Analyst at Example GmbH &#8212; Berlin, Germany | LinkedIn Jobs">
        </head></html>
        """

        job = importer.extract_job_from_html(
            page_html, "https://www.linkedin.com/jobs/view/1234567890/"
        )

        self.assertEqual(job.title, "Data Analyst")
        self.assertEqual(job.company, "Example GmbH")
        self.assertEqual(job.location, "Berlin, Germany")

    def test_cleans_scraped_role_company_and_remote_only_location(self) -> None:
        page_html = r"""
        <html><head>
          <script type="application/ld+json">
          {
            "@type": "JobPosting",
            "title": "Data Analyst (f/m/x) (Remote)",
            "hiringOrganization": {
              "@type": "Organization",
              "name": "Jobs Ai\nRemote (Work from Anywhere)"
            },
            "jobLocation": {
              "@type": "Place",
              "address": {"addressLocality": "Remote (Work from Anywhere)"}
            },
            "description": "<p>Analyze data.</p>"
          }
          </script>
        </head></html>
        """

        job = importer.extract_job_from_html(
            page_html, "https://www.linkedin.com/jobs/view/1234567890/"
        )

        self.assertEqual(job.title, "Data Analyst")
        self.assertEqual(job.company, "Jobs Ai")
        self.assertEqual(job.location, "")

    def test_extracts_activity_labels_from_combined_top_card_text(self) -> None:
        posting_time, applicant_info = importer.extract_activity_metadata(
            "Berlin, Germany · Reposted 2 days ago · Over 200 applicants"
        )

        self.assertEqual(posting_time, "Reposted 2 days ago")
        self.assertEqual(applicant_info, "Over 200 applicants")

    def test_metadata_cleanup_preserves_meaningful_role_and_physical_city(self) -> None:
        self.assertEqual(importer.clean_job_title("Data Analyst (Remote)"), "Data Analyst")
        self.assertEqual(importer.clean_job_title("Data Analyst (x m d)"), "Data Analyst")
        self.assertEqual(
            importer.clean_job_title("Risk Analyst (Credit Risk)"),
            "Risk Analyst (Credit Risk)",
        )
        self.assertEqual(
            importer.clean_job_title("Risk Analyst (Credit Risk) - Hybrid"),
            "Risk Analyst (Credit Risk)",
        )
        self.assertEqual(
            importer.clean_job_location("Berlin, Germany (Hybrid)"),
            "Berlin, Germany",
        )
        self.assertEqual(
            importer.clean_job_location("Remote - Germany"),
            "Germany",
        )


class NumberingAndLedgerTests(unittest.TestCase):
    def test_next_number_recognizes_canonical_and_legacy_names(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            (output / "job_description (4).pdf").touch()
            (output / "job_description_9.pdf").touch()
            (output / "other.pdf").touch()

            self.assertEqual(importer.next_job_number(output), 10)

    def test_next_number_also_considers_the_highest_ledger_number(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            (output / "job_description (9).pdf").touch()
            ledger_rows = [
                {"job_number": "41"},
                {"job_number": "not-a-number"},
                {"job_number": "0"},
            ]

            self.assertEqual(importer.next_job_number(output, ledger_rows), 42)

    def test_next_number_also_considers_final_job_ad_archive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            output = root / "cache"
            archive = root / "Job_ad"
            output.mkdir()
            archive.mkdir()
            (output / "job_description_7.pdf").touch()
            (archive / "job_description_58.pdf").touch()

            self.assertEqual(importer.next_job_number(output, (), archive), 59)

    def test_ledger_upsert_replaces_same_job(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = Path(temporary) / "job_sources.csv"
            rows: list[dict[str, str]] = []
            first = {field: "" for field in importer.LEDGER_FIELDS}
            first.update(
                {
                    "job_number": "1",
                    "pdf_name": "job_description (1).pdf",
                    "linkedin_job_id": "1234567890",
                    "source_url": "https://www.linkedin.com/jobs/view/1234567890/",
                }
            )
            second = dict(first)
            second.update(
                {"job_number": "8", "pdf_name": "job_description (8).pdf"}
            )

            importer.upsert_ledger(ledger, rows, first)
            importer.upsert_ledger(ledger, rows, second)

            with ledger.open("r", encoding="utf-8-sig", newline="") as handle:
                saved = list(csv.DictReader(handle))
            self.assertEqual(len(saved), 1)
            self.assertEqual(saved[0]["job_number"], "8")

    @unittest.skipUnless(importer.os.name == "nt", "Importer runtime is Windows-only")
    def test_existing_archive_skips_url_when_working_pdf_is_absent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            output = root / ".artifacts" / "linkedin_imports"
            archive_dir = root / "Job_ad"
            archive_dir.mkdir()
            archive = archive_dir / "Example GmbH.pdf"
            archive.write_bytes(b"%PDF-1.4 existing archived posting")
            ledger = root / "job_sources.csv"
            url_file = root / "urls.txt"
            url = "https://www.linkedin.com/jobs/view/1234567890/"
            url_file.write_text(url + "\n", encoding="utf-8")
            row = {field: "" for field in importer.LEDGER_FIELDS}
            row.update(
                {
                    "job_number": "41",
                    "pdf_name": "job_description (41).pdf",
                    "archive_file": str(archive),
                    "linkedin_job_id": "1234567890",
                    "source_url": url,
                    "company": "Example GmbH",
                }
            )
            rows: list[dict[str, str]] = []
            importer.upsert_ledger(ledger, rows, row)

            result = importer.run(
                [
                    "--url-file",
                    str(url_file),
                    "--output-dir",
                    str(output),
                    "--archive-dir",
                    str(archive_dir),
                    "--ledger",
                    str(ledger),
                ]
            )

            self.assertEqual(result, 0)
            self.assertFalse(output.exists())
            self.assertEqual(archive.read_bytes(), b"%PDF-1.4 existing archived posting")


class ArchiveTests(unittest.TestCase):
    def test_company_name_is_safe_for_windows(self) -> None:
        self.assertEqual(
            importer.company_archive_stem(" ACME: Data/AI. "),
            "ACME - Data - AI",
        )
        self.assertEqual(importer.company_archive_stem("CON"), "CON company")
        self.assertEqual(
            importer.company_archive_stem(""),
            "Unknown company",
        )
        self.assertEqual(
            importer.company_archive_stem(
                "Jobs Ai\nRemote (Work from Anywhere)"
            ),
            "Jobs Ai",
        )

    def test_archive_uses_exact_number_and_reuses_identical_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive = root / "Job_ad"
            first_source = root / "job_description (1).pdf"
            second_source = root / "job_description (2).pdf"
            first_source.write_bytes(b"%PDF-1.4 first advert")
            second_source.write_bytes(b"%PDF-1.4 second advert")

            first_archive, first_created = importer.archive_job_pdf(
                first_source, 1, archive
            )
            repeated_archive, repeated_created = importer.archive_job_pdf(
                first_source, 1, archive
            )
            second_archive, second_created = importer.archive_job_pdf(
                second_source, 2, archive
            )

            self.assertTrue(first_created)
            self.assertFalse(repeated_created)
            self.assertTrue(second_created)
            self.assertEqual(first_archive.name, "job_description_1.pdf")
            self.assertEqual(repeated_archive, first_archive)
            self.assertEqual(second_archive.name, "job_description_2.pdf")
            self.assertEqual(first_archive.read_bytes(), first_source.read_bytes())
            self.assertEqual(second_archive.read_bytes(), second_source.read_bytes())

    def test_archive_rejects_number_collision_with_different_content(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive = root / "Job_ad"
            first_source = root / "first.pdf"
            second_source = root / "second.pdf"
            first_source.write_bytes(b"%PDF-1.4 first advert")
            second_source.write_bytes(b"%PDF-1.4 second advert")
            importer.archive_job_pdf(first_source, 4, archive)

            with self.assertRaisesRegex(importer.ImporterError, "number 4 is already used"):
                importer.archive_job_pdf(second_source, 4, archive)

    def test_backfill_archives_ledger_pdf_and_records_path(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            output = root / "input"
            archive = root / "Job_ad"
            ledger = root / "job_sources.csv"
            output.mkdir()
            source = output / "job_description (4).pdf"
            source.write_bytes(b"%PDF-1.4 archived from ledger")
            row = {field: "" for field in importer.LEDGER_FIELDS}
            row.update(
                {
                    "job_number": "4",
                    "pdf_name": source.name,
                    "linkedin_job_id": "1234567890",
                    "source_url": "https://www.linkedin.com/jobs/view/1234567890/",
                    "company": "Example GmbH",
                }
            )
            rows: list[dict[str, str]] = []
            importer.upsert_ledger(ledger, rows, row)

            created, reused, failures = importer.backfill_archive_from_ledger(
                ledger, output, archive
            )
            saved_row = importer.read_ledger(ledger)[0]

            self.assertEqual((created, reused, failures), (1, 0, []))
            self.assertEqual(Path(saved_row["archive_file"]).name, "job_description_4.pdf")
            self.assertEqual(
                Path(saved_row["archive_file"]).read_bytes(), source.read_bytes()
            )


class PdfTests(unittest.TestCase):
    def test_created_pdf_contains_extractable_job_text(self) -> None:
        try:
            from pypdf import PdfReader
        except ImportError:
            self.skipTest("pypdf is unavailable in this test environment")

        job = importer.extract_job_from_html(
            SAMPLE_HTML, "https://www.linkedin.com/jobs/view/1234567890/"
        )
        job = importer.replace(job, imported_at_utc="2026-07-20T12:00:00+00:00")

        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "job_description (10).pdf"
            importer.write_job_pdf(job, destination)
            extracted = "\n".join(
                page.extract_text() or "" for page in PdfReader(destination).pages
            )

        self.assertIn("Data Analyst", extracted)
        self.assertIn("Example GmbH", extracted)
        self.assertIn("Posting time: 3 hours ago", extracted)
        self.assertIn("Applicant info: 42 applicants", extracted)
        self.assertIn("Use Python and SQL", extracted)

    def test_existing_pipeline_extractor_reads_created_pdf(self) -> None:
        try:
            import fitz  # noqa: F401
        except ImportError:
            self.skipTest("PyMuPDF is unavailable in this test environment")

        from job_application_pipeline.documents import extract_pdf_text

        job = importer.extract_job_from_html(
            SAMPLE_HTML, "https://www.linkedin.com/jobs/view/1234567890/"
        )
        job = importer.replace(job, imported_at_utc="2026-07-20T12:00:00+00:00")

        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "job_description (10).pdf"
            importer.write_job_pdf(job, destination)
            extracted = extract_pdf_text(destination)

        self.assertIn("Data Analyst", extracted)
        self.assertIn("Build reliable reports", extracted)


class NextJobNumberTests(unittest.TestCase):
    def test_an_import_continues_from_the_newest_completed_application(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            staging, archive, cvs = root / "cache", root / "Job_ad", root / "CVs"
            for directory in (staging, archive, cvs):
                directory.mkdir()
            # Completed applications exist, but their job ads were deleted.
            for number in (115, 116):
                (cvs / f"job_{number}").mkdir()

            # Without CVs the numbering would restart and collide with job_115.
            self.assertEqual(importer.next_job_number(staging, (), archive), 1)
            self.assertEqual(
                importer.next_job_number(staging, (), archive, cvs), 117
            )

    def test_a_missing_cvs_directory_is_tolerated(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            staging = root / "cache"
            staging.mkdir()
            self.assertEqual(
                importer.next_job_number(staging, (), None, root / "absent"), 1
            )

    def test_completed_numbers_ignore_files_and_odd_names(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            cvs = Path(temporary)
            (cvs / "job_12").mkdir()
            (cvs / "job_notanumber").mkdir()
            (cvs / "job_99.txt").write_text("not a folder", encoding="utf-8")
            self.assertEqual(importer.find_completed_job_numbers(cvs), {12})


if __name__ == "__main__":
    unittest.main()
