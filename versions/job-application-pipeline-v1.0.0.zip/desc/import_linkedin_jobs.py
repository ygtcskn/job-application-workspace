"""Import public LinkedIn job pages as numbered pipeline-ready PDFs.

The importer intentionally does not authenticate, bypass access controls, or
hide its browser automation. LinkedIn markup changes frequently, so structured
JobPosting data is preferred and visible-page selectors are only fallbacks.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import os
import re
import shutil
import sys
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Sequence
from urllib.parse import parse_qs, urlsplit


PROJECT_DIR = Path(__file__).resolve().parents[1]
DESC_DIR = Path(__file__).resolve().parent
DEFAULT_URL_FILE = DESC_DIR / "linkedin_urls.txt"
DEFAULT_LEDGER_FILE = DESC_DIR / "job_sources.csv"
DEFAULT_OUTPUT_DIR = PROJECT_DIR / ".artifacts" / "linkedin_imports"
DEFAULT_ARCHIVE_DIR = PROJECT_DIR.parent / "Job_ad"
# Completed applications, so an import never reuses a number one holds.
DEFAULT_CVS_DIR = PROJECT_DIR.parent / "CVs"

JOB_FILE_RE = re.compile(
    r"^job_description(?:\s*\((\d+)\)|_?(\d+))\.pdf$", re.IGNORECASE
)
JOB_VIEW_RE = re.compile(r"/jobs/view/(?:[^/?#]*-)?(\d+)(?:/|$)", re.IGNORECASE)
LINKEDIN_HIRING_TITLE_RE = re.compile(
    r"^(?P<company>.+?)\s+hiring\s+(?P<title>.+?)\s+in\s+(?P<location>.+)$",
    re.IGNORECASE,
)
LINKEDIN_ROLE_AT_TITLE_RE = re.compile(
    r"^(?P<title>.+?)\s+at\s+(?P<company>.+?)\s+"
    r"(?:\u2013|\u2014|-)\s+(?P<location>.+)$",
    re.IGNORECASE,
)
LEDGER_FIELDS = [
    "job_number",
    "pdf_name",
    "archive_file",
    "linkedin_job_id",
    "source_url",
    "title",
    "company",
    "location",
    "date_posted",
    "posting_time",
    "applicant_info",
    "imported_at_utc",
    "description_sha256",
]

DESCRIPTION_SELECTORS = (
    ".show-more-less-html__markup",
    ".description__text",
    "#job-details",
    ".jobs-description-content__text",
)
TITLE_SELECTORS = (
    "h1.top-card-layout__title",
    ".job-details-jobs-unified-top-card__job-title h1",
    "h1",
)
COMPANY_SELECTORS = (
    "a.topcard__org-name-link",
    ".topcard__flavor-row a",
    ".job-details-jobs-unified-top-card__company-name",
)
LOCATION_SELECTORS = (
    ".topcard__flavor--bullet",
    ".job-details-jobs-unified-top-card__primary-description-container",
)
POSTING_TIME_SELECTORS = (
    ".posted-time-ago__text",
    "time.job-search-card__listdate",
    "time.job-search-card__listdate--new",
    "[class*='posted-time-ago']",
)
APPLICANT_INFO_SELECTORS = (
    ".num-applicants__caption",
    ".jobs-unified-top-card__applicant-count",
    ".job-details-jobs-unified-top-card__applicant-count",
    "[class*='num-applicants']",
    "[class*='applicant-count']",
)
TOP_CARD_ACTIVITY_SELECTORS = (
    ".top-card-layout__second-subline",
    ".topcard__flavor-row",
    ".job-details-jobs-unified-top-card__primary-description-container",
)
POSTING_TIME_CLASS_MARKERS = ("posted-time-ago", "job-search-card__listdate")
APPLICANT_INFO_CLASS_MARKERS = ("num-applicants", "applicant-count")


class ImporterError(RuntimeError):
    """An expected, user-actionable import failure."""


@dataclass(frozen=True)
class JobPosting:
    source_url: str
    linkedin_job_id: str
    title: str
    company: str
    location: str
    description: str
    date_posted: str = ""
    posting_time: str = ""
    applicant_info: str = ""
    imported_at_utc: str = ""


class _PageMetadataParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.json_ld_blocks: list[str] = []
        self.meta: dict[str, str] = {}
        self._inside_json_ld = False
        self._json_parts: list[str] = []
        self.posting_time_parts: list[str] = []
        self.applicant_info_parts: list[str] = []
        self._posting_time_depth = 0
        self._applicant_info_depth = 0

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        attributes = {key.lower(): value or "" for key, value in attrs}
        tag = tag.lower()

        if tag == "script" and attributes.get("type", "").lower().startswith(
            "application/ld+json"
        ):
            self._inside_json_ld = True
            self._json_parts = []
            return

        if tag == "meta":
            key = (attributes.get("property") or attributes.get("name") or "").lower()
            content = attributes.get("content", "").strip()
            if key and content and key not in self.meta:
                self.meta[key] = content

        class_value = attributes.get("class", "").casefold()
        if self._posting_time_depth:
            self._posting_time_depth += 1
        elif any(marker in class_value for marker in POSTING_TIME_CLASS_MARKERS):
            self._posting_time_depth = 1

        if self._applicant_info_depth:
            self._applicant_info_depth += 1
        elif any(marker in class_value for marker in APPLICANT_INFO_CLASS_MARKERS):
            self._applicant_info_depth = 1

    def handle_data(self, data: str) -> None:
        if self._inside_json_ld:
            self._json_parts.append(data)
            return
        if self._posting_time_depth:
            self.posting_time_parts.append(data)
        if self._applicant_info_depth:
            self.applicant_info_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "script" and self._inside_json_ld:
            block = "".join(self._json_parts).strip()
            if block:
                self.json_ld_blocks.append(block)
            self._inside_json_ld = False
            self._json_parts = []
            return

        if self._posting_time_depth:
            self._posting_time_depth -= 1
        if self._applicant_info_depth:
            self._applicant_info_depth -= 1


class _HTMLTextParser(HTMLParser):
    BLOCK_TAGS = {
        "address",
        "article",
        "blockquote",
        "div",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "p",
        "section",
        "table",
        "tr",
        "ul",
        "ol",
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._ignored_depth = 0

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        del attrs
        tag = tag.lower()
        if tag in {"script", "style"}:
            self._ignored_depth += 1
            return
        if self._ignored_depth:
            return
        if tag == "br":
            self.parts.append("\n")
        elif tag == "li":
            self.parts.append("\n- ")
        elif tag in self.BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style"}:
            self._ignored_depth = max(0, self._ignored_depth - 1)
            return
        if not self._ignored_depth and (tag == "li" or tag in self.BLOCK_TAGS):
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._ignored_depth:
            self.parts.append(data)


def normalize_plain_text(value: str) -> str:
    """Normalize whitespace while retaining useful paragraph boundaries."""
    value = html.unescape(value).replace("\r\n", "\n").replace("\r", "\n")
    lines: list[str] = []
    previous_blank = False

    for raw_line in value.split("\n"):
        line = re.sub(r"[\t\f\v ]+", " ", raw_line).strip()
        if line:
            lines.append(line)
            previous_blank = False
        elif lines and not previous_blank:
            lines.append("")
            previous_blank = True

    return "\n".join(lines).strip()


_BRACKETED_METADATA_RE = re.compile(r"\s*[\(\[]([^()\[\]]+)[\)\]]")
_METADATA_SEPARATOR_RE = re.compile(
    r"\s*[|\u00b7\u2022]\s*|\s+[/\u2013\u2014-]\s+"
)
_WORK_ARRANGEMENT_PATTERNS = (
    r"\bwork\s+from\s+(?:home|anywhere)\b",
    r"\bhome\s*office\b",
    r"\b(?:100\s*%\s*)?(?:fully\s+)?remote(?:ly)?\b",
    r"\bhybrid\b",
    r"\bon[\s-]?site\b",
    r"\boffice[\s-]?based\b",
    r"\btele(?:work|commut(?:e|ing))\b",
    r"\bmobile\s+work(?:ing)?\b",
    r"\banywhere\b",
    r"\bworldwide\b",
)


def _single_line(value: str) -> str:
    return re.sub(r"\s+", " ", normalize_plain_text(value)).strip()


_ACTIVITY_SEPARATOR_RE = re.compile(r"\s*(?:\n|[|\u00b7\u2022])\s*")
_POSTING_TIME_RE = re.compile(
    r"^(?:(?:posted|reposted)\s+)?(?:(?:about|approximately)\s+)?"
    r"(?:(?:\d+|one|an)\s+(?:minute|hour|day|week|month|year)s?\s+ago|"
    r"just now|today|yesterday)$",
    re.IGNORECASE,
)
_APPLICANT_INFO_RE = re.compile(
    r"^(?:(?:over|more than|fewer than)\s+)?\d[\d,.\s]*\+?\s+"
    r"(?:applicants?|people clicked apply)$|"
    r"^be among (?:the )?first \d[\d,.\s]* applicants?$",
    re.IGNORECASE,
)


def extract_activity_metadata(*values: str) -> tuple[str, str]:
    """Extract visible posting-age and applicant labels from top-card text."""
    posting_time = ""
    applicant_info = ""

    for value in values:
        for segment in _ACTIVITY_SEPARATOR_RE.split(normalize_plain_text(value)):
            segment = _single_line(segment).strip(" -")
            if not segment:
                continue
            if not posting_time and _POSTING_TIME_RE.fullmatch(segment):
                posting_time = segment
            if not applicant_info and _APPLICANT_INFO_RE.fullmatch(segment):
                applicant_info = segment

    return posting_time, applicant_info


def _is_gender_marker(value: str) -> bool:
    candidate = _single_line(value).casefold().strip(" ()[]{}.,;:-")
    return bool(
        re.fullmatch(
            r"(?:[mfwxd](?:(?:\s*[/|]\s*|\s+)[mfwxd]){1,4}|"
            r"(?:all|any)\s+genders?|gender(?:\s+neutral)?|gn)",
            candidate,
        )
    )


def _is_work_arrangement(value: str) -> bool:
    candidate = _single_line(value).casefold().replace("&", " and ")
    matched = False
    for pattern in _WORK_ARRANGEMENT_PATTERNS:
        candidate, count = re.subn(pattern, " ", candidate, flags=re.IGNORECASE)
        matched = matched or bool(count)

    if not matched:
        return False

    candidate = re.sub(
        r"\b(?:and|or|only|option|optional|available|possible|"
        r"arrangement|arrangements|work|working|role|position)\b",
        " ",
        candidate,
    )
    return not re.sub(r"[^a-z0-9]+", "", candidate)


def _is_display_metadata(value: str, *, include_gender: bool) -> bool:
    return _is_work_arrangement(value) or (
        include_gender and _is_gender_marker(value)
    )


def _strip_bracketed_metadata(value: str, *, include_gender: bool) -> str:
    cleaned = value
    while True:
        updated = _BRACKETED_METADATA_RE.sub(
            lambda match: ""
            if _is_display_metadata(
                match.group(1), include_gender=include_gender
            )
            else match.group(0),
            cleaned,
        )
        if updated == cleaned:
            return updated
        cleaned = updated


def _strip_edge_metadata_words(
    value: str, *, from_start: bool, include_gender: bool
) -> str:
    words = value.split()
    if len(words) < 2:
        return value

    for count in range(min(5, len(words) - 1), 0, -1):
        candidate_words = words[:count] if from_start else words[-count:]
        candidate = " ".join(candidate_words).strip(" ()[]{}.,;:|/-")
        if _is_display_metadata(candidate, include_gender=include_gender):
            remaining = words[count:] if from_start else words[:-count]
            return " ".join(remaining)
    return value


def _clean_metadata_spacing(value: str) -> str:
    cleaned = re.sub(r"\s+", " ", value)
    cleaned = re.sub(r"\s+([,;:])", r"\1", cleaned)
    cleaned = re.sub(r"(?:\s*[|\u00b7\u2022\u2013\u2014-]\s*)+$", "", cleaned)
    return cleaned.strip(" ,;:|-/")


def clean_job_title(value: str) -> str:
    """Remove gender and work-arrangement tags without losing specializations."""
    original = _single_line(value)
    cleaned = _strip_bracketed_metadata(original, include_gender=True)
    while True:
        updated = _strip_edge_metadata_words(
            cleaned, from_start=False, include_gender=True
        )
        if updated == cleaned:
            break
        cleaned = updated
    return _clean_metadata_spacing(cleaned) or original


def clean_company_name(value: str) -> str:
    """Remove work-arrangement lines accidentally captured as company text."""
    kept_lines: list[str] = []
    for raw_line in normalize_plain_text(value).splitlines():
        line = _single_line(raw_line)
        if not line or _is_display_metadata(line, include_gender=True):
            continue
        line = _strip_bracketed_metadata(line, include_gender=True)
        while True:
            updated = _strip_edge_metadata_words(
                line, from_start=False, include_gender=True
            )
            if updated == line:
                break
            line = updated
        line = _clean_metadata_spacing(line)
        if line and not _is_display_metadata(line, include_gender=True):
            kept_lines.append(line)
    return _clean_metadata_spacing(" ".join(kept_lines))


def clean_job_location(value: str) -> str:
    """Keep physical locations and discard remote-work display labels."""
    normalized = normalize_plain_text(value)
    if not normalized:
        return ""

    joined = " | ".join(line for line in normalized.splitlines() if line.strip())
    physical_segments: list[str] = []
    for segment in _METADATA_SEPARATOR_RE.split(joined):
        segment = _strip_bracketed_metadata(segment, include_gender=False)
        comma_parts = [part.strip() for part in segment.split(",") if part.strip()]
        comma_parts = [part for part in comma_parts if not _is_work_arrangement(part)]
        segment = ", ".join(comma_parts)

        while True:
            updated = _strip_edge_metadata_words(
                segment, from_start=True, include_gender=False
            )
            updated = _strip_edge_metadata_words(
                updated, from_start=False, include_gender=False
            )
            if updated == segment:
                break
            segment = updated

        segment = _clean_metadata_spacing(segment)
        if segment and not _is_work_arrangement(segment):
            if segment not in physical_segments:
                physical_segments.append(segment)

    return " / ".join(physical_segments)


def clean_job_posting_metadata(job: JobPosting) -> JobPosting:
    """Normalize scraped display metadata before it reaches PDFs or reports."""
    return replace(
        job,
        title=clean_job_title(job.title),
        company=clean_company_name(job.company),
        location=clean_job_location(job.location),
    )


def html_to_text(value: str) -> str:
    parser = _HTMLTextParser()
    parser.feed(value)
    parser.close()
    return normalize_plain_text("".join(parser.parts))


def extract_linkedin_job_id(url: str) -> str:
    parts = urlsplit(url)
    match = JOB_VIEW_RE.search(parts.path.rstrip("/") + "/")
    if match:
        return match.group(1)

    query_id = parse_qs(parts.query).get("currentJobId", [""])[0]
    return query_id if query_id.isdigit() else ""


def canonicalize_linkedin_url(url: str) -> tuple[str, str]:
    """Validate a LinkedIn job-view URL and return its canonical form and ID."""
    value = url.strip()
    parts = urlsplit(value)
    host = (parts.hostname or "").lower().rstrip(".")

    if parts.scheme.lower() != "https":
        raise ValueError("only HTTPS URLs are accepted")
    if host != "linkedin.com" and not host.endswith(".linkedin.com"):
        raise ValueError("URL host must be linkedin.com")

    job_id = extract_linkedin_job_id(value)
    if not job_id and "/jobs/view/" not in parts.path.lower():
        raise ValueError("URL must be a LinkedIn /jobs/view/ page")

    if job_id:
        return f"https://www.linkedin.com/jobs/view/{job_id}/", job_id

    clean_path = parts.path.rstrip("/") + "/"
    return f"https://www.linkedin.com{clean_path}", ""


def _is_job_posting_type(value: Any) -> bool:
    if isinstance(value, str):
        return value.lower() == "jobposting"
    if isinstance(value, list):
        return any(_is_job_posting_type(item) for item in value)
    return False


def _find_job_posting(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if _is_job_posting_type(value.get("@type")):
            return value
        for child in value.values():
            found = _find_job_posting(child)
            if found is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _find_job_posting(child)
            if found is not None:
                return found
    return None


def _name_from_value(value: Any) -> str:
    if isinstance(value, str):
        return normalize_plain_text(value)
    if isinstance(value, dict):
        return normalize_plain_text(str(value.get("name") or value.get("value") or ""))
    return ""


def _format_address(address: Any) -> str:
    if not isinstance(address, dict):
        return _name_from_value(address)

    pieces: list[str] = []
    for key in ("addressLocality", "addressRegion", "addressCountry"):
        piece = _name_from_value(address.get(key))
        if piece and piece not in pieces:
            pieces.append(piece)
    return ", ".join(pieces)


def _format_job_location(value: Any) -> str:
    locations = value if isinstance(value, list) else [value]
    formatted: list[str] = []

    for location in locations:
        if isinstance(location, dict):
            text = _format_address(location.get("address")) or _name_from_value(location)
        else:
            text = _name_from_value(location)
        if text and text not in formatted:
            formatted.append(text)

    return " / ".join(formatted)


def split_linkedin_hiring_title(value: str) -> tuple[str, str, str]:
    """Split common LinkedIn fallback browser-title formats."""
    cleaned = re.sub(
        r"\s*[|\-]\s*LinkedIn(?:\s+Jobs)?\s*$",
        "",
        normalize_plain_text(value),
        flags=re.IGNORECASE,
    )
    match = LINKEDIN_HIRING_TITLE_RE.match(cleaned)
    if match:
        return (
            normalize_plain_text(match.group("title")),
            normalize_plain_text(match.group("company")),
            normalize_plain_text(match.group("location")),
        )

    match = LINKEDIN_ROLE_AT_TITLE_RE.match(cleaned)
    if not match:
        return cleaned, "", ""
    return (
        normalize_plain_text(match.group("title")),
        normalize_plain_text(match.group("company")),
        normalize_plain_text(match.group("location")),
    )


def extract_job_from_html(page_html: str, source_url: str) -> JobPosting:
    """Extract schema.org JobPosting data from a LinkedIn page snapshot."""
    metadata = _PageMetadataParser()
    metadata.feed(page_html)
    metadata.close()

    posting: dict[str, Any] = {}
    for block in metadata.json_ld_blocks:
        try:
            decoded = json.loads(block)
        except json.JSONDecodeError:
            continue
        found = _find_job_posting(decoded)
        if found is not None:
            posting = found
            break

    canonical_url, job_id = canonicalize_linkedin_url(source_url)
    title = normalize_plain_text(str(posting.get("title") or ""))
    company = _name_from_value(posting.get("hiringOrganization"))
    location = _format_job_location(posting.get("jobLocation"))
    description_raw = str(posting.get("description") or "")
    description = html_to_text(description_raw) if description_raw else ""
    date_posted = normalize_plain_text(str(posting.get("datePosted") or ""))
    posting_time, applicant_info = extract_activity_metadata(
        " ".join(metadata.posting_time_parts),
        " ".join(metadata.applicant_info_parts),
    )

    if not title:
        title, fallback_company, fallback_location = split_linkedin_hiring_title(
            metadata.meta.get("og:title", "")
        )
        company = company or fallback_company
        location = location or fallback_location

    return clean_job_posting_metadata(
        JobPosting(
            source_url=canonical_url,
            linkedin_job_id=job_id,
            title=title,
            company=company,
            location=location,
            description=description,
            date_posted=date_posted,
            posting_time=posting_time,
            applicant_info=applicant_info,
        )
    )


def _first_locator_text(page: Any, selectors: Sequence[str]) -> str:
    for selector in selectors:
        try:
            locator = page.locator(selector)
            if locator.count() < 1:
                continue
            value = locator.first.inner_text(timeout=2_000).strip()
            if value:
                return normalize_plain_text(value)
        except Exception:
            continue
    return ""


def fetch_job_posting(
    browser_context: Any,
    url: str,
    timeout_seconds: float,
    settle_seconds: float,
) -> JobPosting:
    """Load one public page and combine structured and visible-page fields."""
    page = browser_context.new_page()
    try:
        response = page.goto(
            url,
            wait_until="domcontentloaded",
            timeout=int(timeout_seconds * 1_000),
        )
        if response is not None and response.status >= 400:
            raise ImporterError(f"LinkedIn returned HTTP {response.status}")

        page.wait_for_timeout(int(settle_seconds * 1_000))
        final_url = page.url
        lowered_url = final_url.lower()
        if any(marker in lowered_url for marker in ("/login", "/checkpoint", "/authwall")):
            raise ImporterError("LinkedIn redirected to a login or verification page")

        posting = extract_job_from_html(page.content(), final_url)
        description = posting.description or _first_locator_text(
            page, DESCRIPTION_SELECTORS
        )
        title = posting.title or _first_locator_text(page, TITLE_SELECTORS)
        company = posting.company or _first_locator_text(page, COMPANY_SELECTORS)
        location = posting.location or _first_locator_text(page, LOCATION_SELECTORS)
        direct_posting_time = _first_locator_text(page, POSTING_TIME_SELECTORS)
        direct_applicant_info = _first_locator_text(page, APPLICANT_INFO_SELECTORS)
        activity_context = _first_locator_text(page, TOP_CARD_ACTIVITY_SELECTORS)
        detected_posting_time, detected_applicant_info = extract_activity_metadata(
            direct_posting_time,
            direct_applicant_info,
            activity_context,
        )

        if not title:
            title = f"LinkedIn job {posting.linkedin_job_id}".strip()

        return clean_job_posting_metadata(
            replace(
                posting,
                title=title,
                company=company,
                location=location,
                description=description,
                posting_time=posting.posting_time or detected_posting_time,
                applicant_info=posting.applicant_info or detected_applicant_info,
                imported_at_utc=datetime.now(timezone.utc).isoformat(
                    timespec="seconds"
                ),
            )
        )
    finally:
        page.close()


def find_existing_job_numbers(output_dir: Path) -> set[int]:
    numbers: set[int] = set()
    if not output_dir.exists():
        return numbers

    for path in output_dir.iterdir():
        if not path.is_file():
            continue
        match = JOB_FILE_RE.match(path.name)
        if match:
            numbers.add(int(match.group(1) or match.group(2)))
    return numbers


def find_completed_job_numbers(cvs_dir: Path) -> set[int]:
    """Read the numbers of applications already archived under ``CVs``."""

    numbers: set[int] = set()
    if not cvs_dir.exists():
        return numbers
    for path in cvs_dir.iterdir():
        match = re.fullmatch(r"job_(\d+)", path.name, flags=re.IGNORECASE)
        if match and path.is_dir():
            numbers.add(int(match.group(1)))
    return numbers


def next_job_number(
    output_dir: Path,
    ledger_rows: Iterable[dict[str, str]] = (),
    archive_dir: Path | None = None,
    cvs_dir: Path | None = None,
) -> int:
    """Choose a number unused by any stage of the workflow.

    A job ad and the application built from it share a number, so completed
    applications under ``CVs`` are counted too: an import continues from the
    newest one rather than reusing a number an application already holds.
    """

    numbers = find_existing_job_numbers(output_dir)
    if archive_dir is not None:
        numbers.update(find_existing_job_numbers(archive_dir))
    if cvs_dir is not None:
        numbers.update(find_completed_job_numbers(cvs_dir))
    for row in ledger_rows:
        try:
            number = int((row.get("job_number") or "").strip())
        except (TypeError, ValueError):
            continue
        if number > 0:
            numbers.add(number)
    return max(numbers, default=0) + 1


WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}


def company_archive_stem(company: str) -> str:
    """Return a readable company name that is safe as a Windows filename."""
    stem = clean_company_name(company) or "Unknown company"
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " - ", stem)
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    stem = stem[:120].rstrip(" .") or "Unknown company"
    if stem.upper() in WINDOWS_RESERVED_NAMES:
        stem += " company"
    return stem


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def files_have_same_content(first: Path, second: Path) -> bool:
    if not first.is_file() or not second.is_file():
        return False
    if first.stat().st_size != second.stat().st_size:
        return False
    return file_sha256(first) == file_sha256(second)


def is_valid_archived_pdf(path: Path | None) -> bool:
    """Return whether a ledger archive path is a usable PDF handoff file."""

    if path is None or path.suffix.casefold() != ".pdf":
        return False
    try:
        return path.is_file() and path.stat().st_size > 0
    except OSError:
        return False


def archive_job_pdf(
    source: Path, job_number: int, archive_dir: Path
) -> tuple[Path, bool]:
    """Copy a PDF to ``Job_ad/job_description_X.pdf`` atomically."""
    if not source.is_file():
        raise FileNotFoundError(f"Job-description PDF not found: {source}")
    if job_number < 1:
        raise ValueError("job_number must be a positive integer")

    archive_dir.mkdir(parents=True, exist_ok=True)
    destination = archive_dir / f"job_description_{job_number}.pdf"
    if destination.exists():
        if files_have_same_content(source, destination):
            return destination, False
        raise ImporterError(
            f"job-description number {job_number} is already used by {destination}"
        )

    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    temporary.unlink(missing_ok=True)
    try:
        shutil.copy2(source, temporary)
        if not files_have_same_content(source, temporary):
            raise ImporterError(f"archive copy verification failed for {destination}")
        temporary.replace(destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return destination, True


def _register_pdf_fonts() -> tuple[str, str]:
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    windows_fonts = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    regular_path = windows_fonts / "arial.ttf"
    bold_path = windows_fonts / "arialbd.ttf"
    if regular_path.exists() and bold_path.exists():
        regular_name = "JobDescriptionSans"
        bold_name = "JobDescriptionSansBold"
        if regular_name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(regular_name, str(regular_path)))
        if bold_name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(bold_name, str(bold_path)))
        return regular_name, bold_name

    return "Helvetica", "Helvetica-Bold"


def _description_flowables(description: str, style: Any) -> list[Any]:
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import Paragraph, Spacer

    bullet_style = ParagraphStyle(
        "JobDescriptionBullet",
        parent=style,
        leftIndent=12,
        firstLineIndent=-8,
        alignment=TA_LEFT,
    )
    flowables: list[Any] = []

    for block in re.split(r"\n\s*\n", description):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue

        if all(line.startswith("- ") for line in lines):
            for line in lines:
                flowables.append(
                    Paragraph("&bull; " + html.escape(line[2:]), bullet_style)
                )
        else:
            paragraph = "<br/>".join(html.escape(line) for line in lines)
            flowables.append(Paragraph(paragraph, style))
        flowables.append(Spacer(1, 5))

    return flowables


def write_job_pdf(job: JobPosting, destination: Path) -> None:
    """Create a text-based A4 PDF that the existing pipeline can extract."""
    try:
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import mm
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    except ImportError as exc:
        raise ImporterError(
            "ReportLab is not installed. Run: "
            "python -m pip install -r desc/requirements.txt"
        ) from exc

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    regular_font, bold_font = _register_pdf_fonts()
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "JobTitle",
        parent=styles["Title"],
        fontName=bold_font,
        fontSize=16,
        leading=20,
        alignment=TA_LEFT,
        spaceAfter=7,
    )
    meta_style = ParagraphStyle(
        "JobMeta",
        parent=styles["Normal"],
        fontName=regular_font,
        fontSize=9,
        leading=12,
        textColor="#444444",
    )
    heading_style = ParagraphStyle(
        "JobHeading",
        parent=styles["Heading2"],
        fontName=bold_font,
        fontSize=12,
        leading=15,
        spaceBefore=10,
        spaceAfter=6,
    )
    body_style = ParagraphStyle(
        "JobBody",
        parent=styles["BodyText"],
        fontName=regular_font,
        fontSize=9.5,
        leading=13,
        alignment=TA_LEFT,
        splitLongWords=True,
    )

    story: list[Any] = [Paragraph(html.escape(job.title), title_style)]
    for label, value in (
        ("Company", job.company),
        ("Location", job.location),
        ("Date posted", job.date_posted),
        ("Posting time", job.posting_time),
        ("Applicant info", job.applicant_info),
        ("Source", job.source_url),
        ("Imported", job.imported_at_utc),
    ):
        if value:
            story.append(
                Paragraph(
                    f"<b>{html.escape(label)}:</b> {html.escape(value)}", meta_style
                )
            )
    story.extend(
        [
            Spacer(1, 4),
            Paragraph("Job description", heading_style),
            *_description_flowables(job.description, body_style),
        ]
    )

    document = SimpleDocTemplate(
        str(temporary),
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title=job.title,
        author="CV pipeline LinkedIn importer",
        pageCompression=1,
    )
    try:
        document.build(story)
        temporary.replace(destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def read_url_file(path: Path) -> list[str]:
    if not path.exists():
        return []
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8-sig").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


def read_ledger(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def _ledger_key(job_id: str, source_url: str) -> str:
    return f"id:{job_id}" if job_id else f"url:{source_url.lower()}"


def ledger_index(rows: Iterable[dict[str, str]]) -> dict[str, dict[str, str]]:
    indexed: dict[str, dict[str, str]] = {}
    for row in rows:
        source_url = row.get("source_url", "")
        job_id = row.get("linkedin_job_id", "")
        if source_url or job_id:
            indexed[_ledger_key(job_id, source_url)] = row
    return indexed


def upsert_ledger(path: Path, rows: list[dict[str, str]], new_row: dict[str, str]) -> None:
    new_key = _ledger_key(
        new_row.get("linkedin_job_id", ""), new_row.get("source_url", "")
    )
    updated: list[dict[str, str]] = []
    replaced_existing = False

    for row in rows:
        row_key = _ledger_key(row.get("linkedin_job_id", ""), row.get("source_url", ""))
        if row_key == new_key:
            if not replaced_existing:
                updated.append(new_row)
                replaced_existing = True
        else:
            updated.append(row)
    if not replaced_existing:
        updated.append(new_row)

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=LEDGER_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(updated)
    temporary.replace(path)

    rows[:] = updated


def build_ledger_row(
    job: JobPosting,
    job_number: int,
    pdf_name: str,
    archive_file: Path | str | None = None,
) -> dict[str, str]:
    return {
        "job_number": str(job_number),
        "pdf_name": pdf_name,
        "archive_file": str(archive_file or ""),
        "linkedin_job_id": job.linkedin_job_id,
        "source_url": job.source_url,
        "title": job.title,
        "company": job.company,
        "location": job.location,
        "date_posted": job.date_posted,
        "posting_time": job.posting_time,
        "applicant_info": job.applicant_info,
        "imported_at_utc": job.imported_at_utc,
        "description_sha256": hashlib.sha256(
            job.description.encode("utf-8")
        ).hexdigest(),
    }


def backfill_archive_from_ledger(
    ledger_path: Path, output_dir: Path, archive_dir: Path
) -> tuple[int, int, list[str]]:
    """Restore numbered archive copies from already imported PDFs."""
    rows = read_ledger(ledger_path)
    created = 0
    reused = 0
    failures: list[str] = []

    for original_row in list(rows):
        pdf_name = original_row.get("pdf_name", "").strip()
        source = output_dir / pdf_name
        label = original_row.get("source_url", "") or pdf_name or "ledger row"
        if not source.is_file():
            failures.append(f"{label}: source PDF is missing: {source}")
            continue

        archive_value = original_row.get("archive_file", "").strip()
        existing_archive = Path(archive_value) if archive_value else None
        if existing_archive is not None and files_have_same_content(
            source, existing_archive
        ):
            reused += 1
            continue

        try:
            job_number = int((original_row.get("job_number") or "").strip())
            if job_number < 1:
                raise ValueError("job_number must be a positive integer")
            archive_path, was_created = archive_job_pdf(
                source, job_number, archive_dir
            )
            updated_row = dict(original_row)
            updated_row["archive_file"] = str(archive_path)
            upsert_ledger(ledger_path, rows, updated_row)
            if was_created:
                created += 1
            else:
                reused += 1
        except Exception as exc:
            failures.append(f"{label}: {exc}")

    return created, reused, failures


def parse_arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Import public LinkedIn job pages as numbered PDFs."
    )
    parser.add_argument(
        "--url",
        action="append",
        default=[],
        help="A LinkedIn job URL. May be supplied more than once.",
    )
    parser.add_argument(
        "--url-file",
        type=Path,
        default=DEFAULT_URL_FILE,
        help=f"Text file containing one URL per line (default: {DEFAULT_URL_FILE}).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help=f"Directory for numbered PDFs (default: {DEFAULT_OUTPUT_DIR}).",
    )
    parser.add_argument(
        "--archive-dir",
        type=Path,
        default=DEFAULT_ARCHIVE_DIR,
        help=f"Numbered job-description PDF archive (default: {DEFAULT_ARCHIVE_DIR}).",
    )
    parser.add_argument(
        "--ledger",
        type=Path,
        default=DEFAULT_LEDGER_FILE,
        help=f"CSV source ledger (default: {DEFAULT_LEDGER_FILE}).",
    )
    parser.add_argument(
        "--browser-channel",
        choices=("msedge", "chrome", "chromium"),
        default="msedge",
        help="Playwright browser channel (default: msedge).",
    )
    parser.add_argument(
        "--headed",
        action="store_true",
        help="Show the browser window while importing.",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=float,
        default=45.0,
        help="Navigation timeout for each page (default: 45).",
    )
    parser.add_argument(
        "--settle-seconds",
        type=float,
        default=2.0,
        help="Wait after initial page load before extraction (default: 2).",
    )
    parser.add_argument(
        "--delay-seconds",
        type=float,
        default=3.0,
        help="Delay between pages (default: 3).",
    )
    parser.add_argument(
        "--min-description-chars",
        type=int,
        default=200,
        help="Reject shorter descriptions as incomplete (default: 200).",
    )
    parser.add_argument(
        "--allow-duplicate",
        action="store_true",
        help="Import a URL again even when its recorded PDF still exists.",
    )
    parser.add_argument(
        "--backfill-archive",
        action="store_true",
        help="Restore Job_ad copies from the ledger without loading LinkedIn.",
    )
    return parser.parse_args(argv)


def _launch_browser(playwright: Any, channel: str, headed: bool) -> Any:
    launch_options: dict[str, Any] = {"headless": not headed}
    if channel != "chromium":
        launch_options["channel"] = channel

    try:
        return playwright.chromium.launch(**launch_options)
    except Exception as exc:
        hint = (
            "Install the selected browser or choose another --browser-channel. "
            "For bundled Chromium run: python -m playwright install chromium"
        )
        raise ImporterError(f"Could not start {channel}: {exc}\n{hint}") from exc


def run(argv: Sequence[str] | None = None) -> int:
    if os.name != "nt":
        print("Error: this importer supports Windows only.", file=sys.stderr)
        return 2

    args = parse_arguments(argv)
    if args.timeout_seconds <= 0 or args.settle_seconds < 0 or args.delay_seconds < 0:
        print("Error: timeout and delay values must be non-negative.", file=sys.stderr)
        return 2
    if args.min_description_chars < 1:
        print("Error: --min-description-chars must be at least 1.", file=sys.stderr)
        return 2

    output_dir = args.output_dir.resolve()
    archive_dir = args.archive_dir.resolve()
    ledger_path = args.ledger.resolve()

    if args.backfill_archive:
        created, reused, backfill_failures = backfill_archive_from_ledger(
            ledger_path, output_dir, archive_dir
        )
        for failure in backfill_failures:
            print(f"Error: {failure}", file=sys.stderr)
        print(
            f"Archive backfill complete: {created} created, {reused} reused, "
            f"{len(backfill_failures)} failed."
        )
        return 1 if backfill_failures else 0

    raw_urls = [*read_url_file(args.url_file), *args.url]
    if not raw_urls:
        print(
            f"No URLs found. Add LinkedIn job links to {args.url_file} or use --url.",
            file=sys.stderr,
        )
        return 2

    failures: list[str] = []
    normalized_urls: list[tuple[str, str]] = []
    queued_keys: set[str] = set()
    for raw_url in raw_urls:
        try:
            canonical_url, job_id = canonicalize_linkedin_url(raw_url)
        except ValueError as exc:
            failures.append(f"{raw_url}: {exc}")
            continue
        key = _ledger_key(job_id, canonical_url)
        if key not in queued_keys:
            normalized_urls.append((canonical_url, job_id))
            queued_keys.add(key)

    ledger_rows = read_ledger(ledger_path)
    recorded = ledger_index(ledger_rows)
    pending: list[tuple[str, str]] = []
    skipped = 0

    for canonical_url, job_id in normalized_urls:
        key = _ledger_key(job_id, canonical_url)
        row = recorded.get(key)
        recorded_pdf = output_dir / row.get("pdf_name", "") if row else None
        archive_value = row.get("archive_file", "").strip() if row else ""
        recorded_archive = Path(archive_value) if archive_value else None
        working_pdf_exists = recorded_pdf is not None and recorded_pdf.is_file()
        archive_pdf_exists = is_valid_archived_pdf(recorded_archive)
        if not args.allow_duplicate and row and (
            working_pdf_exists or archive_pdf_exists
        ):
            try:
                if working_pdf_exists and (
                    not archive_pdf_exists
                    or not files_have_same_content(recorded_pdf, recorded_archive)
                ):
                    job_number = int((row.get("job_number") or "").strip())
                    if job_number < 1:
                        raise ValueError("job_number must be a positive integer")
                    recorded_archive, _ = archive_job_pdf(
                        recorded_pdf,
                        job_number,
                        archive_dir,
                    )
                    repaired_row = dict(row or {})
                    repaired_row["archive_file"] = str(recorded_archive)
                    upsert_ledger(ledger_path, ledger_rows, repaired_row)
                    recorded[key] = repaired_row
                    print(f"Archived existing PDF: {recorded_archive}")
            except Exception as exc:
                failures.append(f"{canonical_url}: archive copy failed: {exc}")
            print(f"Skipping already imported URL: {canonical_url}")
            skipped += 1
        else:
            pending.append((canonical_url, job_id))

    print(f"Found {len(normalized_urls)} unique LinkedIn job URL(s).")
    if not pending:
        for failure in failures:
            print(f"Error: {failure}", file=sys.stderr)
        print(f"Nothing to import. Skipped {skipped} existing job(s).")
        return 1 if failures else 0

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print(
            "Error: Playwright is not installed. Run: "
            "python -m pip install -r .\\desc\\requirements.txt",
            file=sys.stderr,
        )
        return 2

    output_dir.mkdir(parents=True, exist_ok=True)
    number = next_job_number(output_dir, ledger_rows, archive_dir, DEFAULT_CVS_DIR)
    imported = 0

    try:
        with sync_playwright() as playwright:
            browser = _launch_browser(playwright, args.browser_channel, args.headed)
            try:
                context = browser.new_context(locale="en-US")
                for position, (url, expected_job_id) in enumerate(pending, start=1):
                    print(f"Importing {position}/{len(pending)}: {url}")
                    pdf_path: Path | None = None
                    archived_path: Path | None = None
                    archive_created = False
                    committed = False
                    try:
                        job = fetch_job_posting(
                            context,
                            url,
                            timeout_seconds=args.timeout_seconds,
                            settle_seconds=args.settle_seconds,
                        )
                        if expected_job_id and job.linkedin_job_id != expected_job_id:
                            raise ImporterError(
                                "the loaded page does not match the requested LinkedIn job ID"
                            )
                        if len(job.description) < args.min_description_chars:
                            raise ImporterError(
                                "description was missing or too short "
                                f"({len(job.description)} characters)"
                            )

                        while (
                            (output_dir / f"job_description_{number}.pdf").exists()
                            or (archive_dir / f"job_description_{number}.pdf").exists()
                        ):
                            number += 1
                        pdf_name = f"job_description_{number}.pdf"
                        pdf_path = output_dir / pdf_name
                        write_job_pdf(job, pdf_path)
                        archived_path, archive_created = archive_job_pdf(
                            pdf_path, number, archive_dir
                        )
                        row = build_ledger_row(
                            job, number, pdf_name, archive_file=archived_path
                        )
                        upsert_ledger(ledger_path, ledger_rows, row)
                        committed = True
                        recorded[_ledger_key(job.linkedin_job_id, job.source_url)] = row

                        print(f"Saved: {pdf_path}")
                        print(f"Archived: {archived_path}")
                        imported += 1
                        number += 1
                    except Exception as exc:
                        if not committed:
                            if pdf_path is not None:
                                pdf_path.unlink(missing_ok=True)
                            if archive_created and archived_path is not None:
                                archived_path.unlink(missing_ok=True)
                        failures.append(f"{url}: {exc}")

                    if position < len(pending) and args.delay_seconds:
                        time.sleep(args.delay_seconds)
            finally:
                browser.close()
    except ImporterError as exc:
        failures.append(str(exc))
    except Exception as exc:
        failures.append(f"browser session failed: {exc}")

    for failure in failures:
        print(f"Error: {failure}", file=sys.stderr)

    print(
        f"Import complete: {imported} created, {skipped} skipped, "
        f"{len(failures)} failed."
    )
    if imported:
        print(f"Source ledger: {ledger_path}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(run())
