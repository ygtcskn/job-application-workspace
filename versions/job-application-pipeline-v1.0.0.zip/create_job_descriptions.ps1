param(
    [switch] $Headed
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot
$VirtualEnvironmentPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$PythonCandidates = @()
if (-not [string]::IsNullOrWhiteSpace($env:JOB_PIPELINE_PYTHON)) {
    $PythonCandidates += $env:JOB_PIPELINE_PYTHON
}
if (Test-Path -LiteralPath $VirtualEnvironmentPython -PathType Leaf) {
    $PythonCandidates += $VirtualEnvironmentPython
}
$SystemPython = Get-Command "python" -ErrorAction SilentlyContinue
if ($SystemPython) {
    $PythonCandidates += $SystemPython.Source
}

$PythonExe = $null
foreach ($Candidate in $PythonCandidates | Select-Object -Unique) {
    try {
        & $Candidate -c "import sys; raise SystemExit(0)" *> $null
        if ($LASTEXITCODE -eq 0) {
            $PythonExe = $Candidate
            break
        }
    }
    catch {
        continue
    }
}
if (-not $PythonExe) {
    throw "No working Python interpreter was found. Recreate .venv or install Python 3.11+."
}

$ImporterArguments = @("-m", "desc.import_linkedin_jobs")
if ($Headed) {
    $ImporterArguments += "--headed"
}

$PreviousPythonPath = $env:PYTHONPATH
$PreviousPythonUtf8 = $env:PYTHONUTF8
$PreviousNoBytecode = $env:PYTHONDONTWRITEBYTECODE
$ExitCode = 1

Push-Location $ProjectRoot
try {
    $env:PYTHONPATH = if ([string]::IsNullOrWhiteSpace($PreviousPythonPath)) {
        $ProjectRoot
    }
    else {
        "$ProjectRoot$([System.IO.Path]::PathSeparator)$PreviousPythonPath"
    }
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"

    & $PythonExe @ImporterArguments
    $ExitCode = $LASTEXITCODE
}
finally {
    $env:PYTHONPATH = $PreviousPythonPath
    $env:PYTHONUTF8 = $PreviousPythonUtf8
    $env:PYTHONDONTWRITEBYTECODE = $PreviousNoBytecode
    Pop-Location
}

exit $ExitCode
