# Job Application Pipeline

This project imports selected public LinkedIn job pages into the sibling
`Job_ad` folder, then turns the reviewed job PDFs into evidence-grounded English
CV and cover-letter pairs. Application generation supports exactly two
providers: Claude CLI and Codex CLI. Successful document pairs are validated,
compiled, and archived under the sibling `CVs` folder.

The LinkedIn importer in `desc/` is Stage 1 of this workflow. Finding and
ranking postings happens before it, in the sibling `job_fetch` project, which
writes a shortlist this importer can read. The market analysis in
`job_mar_ana/` remains independent from application generation.

## Current status

The CV and cover-letter source packs are installed. Stage 2 can run once its
external job-ad folder and required CLI/LaTeX executables are available. The
approved cover-letter pack is:

```text
data/reference/cover_letter/COVER_LETTER_RULES.md
templates/cover_letter/yigit_coskun_cover_letter.tex
templates/cover_letter/yigit_coskun_cover_letter.pdf  # locked typography baseline
```

The cover rules use the same current skills profiles and bullet library as
evidence companions. There is no separate legacy cover profile and cover
material can never become CV evidence.

## How the system works

```mermaid
flowchart LR
    A[desc/linkedin_urls.txt] --> B[create_job_descriptions.ps1]
    B --> C[Public LinkedIn pages<br/>via Playwright]
    C --> D[Extracted text PDF]
    D --> E[../Job_ad/job_description_X.pdf]
    E --> F[Manual inspection]
    F --> G[run.ps1<br/>provider + optional model and effort]
    H[Approved CV and<br/>cover-letter sources] --> G
    G -->|claude| I[Claude CLI]
    G -->|codex| J[Codex CLI]
    I --> K[English CV + cover letter]
    J --> K
    K --> L[pdflatex + one-page cover check]
    L --> M[CV + cover structural, typography,<br/>PDF, ATS, provenance + JD checks]
    M --> N[JSON + XLSX validation report]
    N --> O{Validation verdict}
    O -->|ERROR: general attempt 1 or 2| P[Send exact failed checks<br/>to the selected AI]
    P --> S[Repair retained four outputs]
    S --> L
    O -->|Only late CL page or typography ERROR<br/>after general attempt 2| U[One reserved CL repair:<br/>shorten editable wording only]
    U --> L
    O -->|ERROR after allowed repair budget| T[Block archive and manifest;<br/>retain .artifacts/job_N]
    O -->|PASS or WARN| Q[Atomic archive: ../CVs/job_N]
    Q --> R[Update application_manifest.csv]
```

A numbered job ad is done when its archive folder exists. `CVs/job_117`
holding both PDFs means `job_description_117.pdf` is skipped, and no rule,
profile, prompt, library, or template change will rebuild it. To rebuild one,
delete its folder and run again.

Legacy company-named ads carry no number, so they still resume on the recorded
job-ad and source-bundle hashes: for those, changing a rule does create a new
application pair on the next run.

## Project layout

```text
job_py/
├── create_job_descriptions.ps1      # Stage 1 importer entry point
├── run.ps1                          # Stage 2 application entry point
├── pyproject.toml
├── requirements.txt
├── src/job_application_pipeline/  # extraction, prompts, validation, orchestration
├── config/prompts/                 # provider request template
├── data/reference/
│   ├── cv/                         # CV rules and approved evidence libraries
│   └── cover_letter/               # approved cover-letter rules
├── templates/
│   ├── cv/
│   └── cover_letter/
├── assets/portfolio/               # supporting portfolio artifact; not CV evidence
├── tests/
├── desc/                           # Stage 1 LinkedIn importer implementation
└── job_mar_ana/                    # independent market analysis

../Job_ad/                          # source postings; outside this project
../CVs/                             # final PDFs and manifest; outside this project
../job_fetch/                       # discovery and ranking; separate project
```

Runtime files are created under `.artifacts/`, including the disposable
`.artifacts/linkedin_imports` staging PDFs. Requests, review notes, and the
source job ad are copied into each final `CVs/job_N` audit folder.

## Source authority

The CV may use only:

- `data/reference/cv/CV_RULES.md`
- `data/reference/cv/bullet_library.docx`
- `data/reference/cv/skills_profiles.docx`
- `templates/cv/yigit_coskun_empty.tex`

Both documents get a read-back review before they are written. The provider
re-reads each finished document and repairs artefacts that token filling can
leave behind: a posting value repeated into itself (`Berlin, Berlin, Germany`
becomes `Berlin`), an article that no longer agrees (`as a Analytics Engineer`
becomes `as an Analytics Engineer`), a doubled word or space, or a sentence
whose grammar broke where a token landed. The review is proofreading only. It
may not change a fact, add a claim, or add, delete, merge, or reorder a
paragraph, and the company name and job title must stay identical everywhere
they appear because validation cross-checks them. Any correction is recorded
under `Cover Letter Choices` in `change_log.md`.

The cover letter may use only its approved rules, the current CV bullet library
and skills profiles as evidence companions, its template, and the job
description. Cover-letter material can never become CV evidence. The job
advertisement guides relevance and supplies employer/role details; it cannot
create candidate experience.

The single exception is the employer's postal address. LinkedIn postings carry
a city but no street address, so the provider may look one up online and use a
reliable published business address for `{{COMPANY-ADDRESS}}` and
`{{COMPANY-CITY}}`. If none is found, both lines are deleted. An address is the
only detail permitted from outside the approved sources, it never becomes
evidence about the candidate, and nothing else on either document may be
changed because of a fetched page.

To make that possible each provider is granted a narrow web capability:

| Provider | Granted | Not granted |
| --- | --- | --- |
| `claude` | `--allowed-tools WebSearch,WebFetch` | any other tool prompt-free |
| `codex` | `--config tools.web_search=true` | sandbox network access |

Codex enables its own search tool rather than
`sandbox_workspace_write.network_access`, so the commands it runs stay offline.
The `--allowed-tools` flag is variadic and is therefore emitted before the
other options: with the prompt as the final argument, a trailing
`--allowed-tools` would consume it as another tool name and the CLI would
reject the call.

## Setup

Requirements:

- Windows PowerShell
- Python 3.11 or newer
- MiKTeX or another distribution that provides `pdflatex`
- Claude CLI or Codex CLI
- Microsoft Edge, or a Playwright-managed Chromium installation, for Stage 1
- PyMuPDF for PDF inspection and `openpyxl` for validation workbooks; both are
  installed from `requirements.txt`

Install the Python dependencies for both stages:

```powershell
python -m pip install -r .\requirements.txt
```

The root wrappers use a working `.venv\Scripts\python.exe` when available and
fall back to `python` from `PATH`. Stage 1 uses Microsoft Edge by default; see
[desc/README.md](desc/README.md) for browser troubleshooting and the advanced
direct CLI.

Stage 2 uses PyMuPDF for PDF text and page inspection. Font checks are part of
the declared validator and report an inspection failure explicitly; the
pipeline does not silently skip them because of an undeclared Poppler command.

## Run

The workflow has exactly two stages.

### Stage 1: Create and inspect job descriptions

Add one public LinkedIn job-view URL per line to `desc/linkedin_urls.txt`, then
run the importer. The sibling `job_fetch` project can produce that URL list for
you; see [desc/README.md](desc/README.md).

```powershell
.\create_job_descriptions.ps1
```

The importer visits public pages one at a time through Playwright, creates
text-based staging PDFs under `.artifacts/linkedin_imports`, and archives new
postings as `../Job_ad/job_description_X.pdf`. It selects one number above the
highest number in the cache, final folder, or import ledger. Existing legacy
company-named PDFs are preserved. Inspect the new PDFs before continuing.

Stage 1 and Stage 2 are intentionally independent. A failure for one URL does
not remove PDFs already committed for other URLs, and the ledger prevents a
successful URL from being imported again by default. Failed or incomplete pages
leave no partial staging or archive PDF. The wrapper never starts CV generation,
so you can fix the URL list and retry Stage 1 or proceed later with only the
reviewed PDFs.

### Stage 2: Generate applications

After inspecting `../Job_ad`, choose Claude or Codex and, optionally, its model
and reasoning effort:

```powershell
.\run.ps1 claude -Model opus -Effort max
.\run.ps1 claude -Model opus -Effort high 7m42s

.\run.ps1 claude -Model opus -effort medium 5m42s

.\run.ps1 codex -Model gpt-5.6-sol -Effort xhigh
.\run.ps1 codex -Model gpt-5.6-sol -Effort high

.\run.ps1 codex -Model gpt-5.6-sol -Effort medium

```

For the setup shown in this repository, the normal command is:

```powershell
.\run.ps1 codex -Model gpt-5.6-sol -Effort high
```

Run it from the `job_py` folder. Do not add `-Fresh` when resuming the failed
`job_134`: the rebuilt request now contains the repaired full title, and the
pipeline decides safely whether the retained output still matches it.

Both options are independent. Omit either one to use the selected CLI's
configured default:

```powershell
.\run.ps1 claude
.\run.ps1 codex -Effort high
```

`-Model` is passed to the CLI verbatim and is only checked for a safe character
set, so any identifier the CLI understands is accepted. `-Effort` is checked
against the level vocabulary of the chosen provider:

| Provider | Accepted `-Effort` levels | How it is passed |
| --- | --- | --- |
| `claude` | `low`, `medium`, `high`, `xhigh`, `max` | `--effort <level>` |
| `codex` | `minimal`, `low`, `medium`, `high`, `xhigh` | `--config model_reasoning_effort="<level>"` |

The vocabularies overlap but are not interchangeable: `max` is Claude-only and
`minimal` is Codex-only. Neither CLI fails on an unrecognised level of its own
accord — Claude warns and silently falls back to its default, and Codex forwards
the value as-is — so the pipeline rejects a mismatched or misspelt level up
front, before any job ad is read or any executable is resolved. Levels are
matched without regard to case or surrounding whitespace.

The model and effort options apply only to jobs processed in that run; an
already-complete job/source pair remains skipped. Both providers always create
an English CV and English cover letter. There are no CV-only, German, OpenAI
API, auto-fallback, or compilation-mode switches.

### Watching a run

Stage 2 reports each step to the console as it happens, so a long run is
visibly alive:

```text
5 job ad(s) found: 5 to process, 0 already complete.
Provider: claude (model=fable, effort=max)

[1/5] job_description_115.pdf -> job_115
   1/6 request built (84 KB)
   2/6 running claude; output is captured, so this step is silent until it finishes
      claude still running (30s)
      claude still running (1m 00s)
      claude finished in 1m 18s
   3/6 provider returned all four files; validating LaTeX
   4/6 compiling CV -> yigit_coskun_CV.pdf
   5/6 compiling cover letter -> yigit_coskun_cover_letter.pdf
   6/6 archived -> ..\CVs\job_115  [READY: 41 pass, 0 warn, 0 error]
       yigit_coskun_CV.pdf
       yigit_coskun_cover_letter.pdf
       done in 1m 46s
```

The provider stage is the long one. Both CLIs are invoked with captured output
so the full transcript can be written to `.artifacts/job_N/provider.log`, which
means they print nothing while working; the periodic "still running" notice
distinguishes a working provider from a stalled one. Pass `--quiet` to the
Python module to suppress per-step reporting and print only the closing
summary. Progress reporting never aborts a run: a console that cannot encode a
character falls back to a replacement rather than failing.

Stage 2 checks every top-level PDF in `../Job_ad`, but gives numbered files
priority in ascending order: `job_description_57.pdf` is considered before
`job_description_58.pdf`. Legacy company-named PDFs remain supported and follow
the numbered files, newest first. Only the top level is scanned, so PDFs kept in
a subfolder such as `../Job_ad/old/` are ignored.

### Numbering

A numbered job ad and the application built from it always share a number.
`job_description_117.pdf` is archived as `../CVs/job_117`, whatever else is in
the folder and however many times it is regenerated. The number comes from the
file name, not from a counter, so the two never drift apart.

A folder that exists but is incomplete, missing either PDF after an
interrupted run, is rebuilt and replaced wholesale rather than merged into. The
previous folder is moved aside first and deleted only once the manifest
commits, so an interrupted run never loses both copies.

Only a legacy company-named ad, which carries no number, is given the next free
number instead: the highest number across the manifest, the `../CVs/job_N`
folders, and any `CV<N>`/`CL<N>` PDFs, plus one.

Stage 1 uses the same sequence, so an import continues from the newest completed
application. `next_job_number` takes the highest number across the staging
cache, `../Job_ad`, the import ledger, **and** the `../CVs/job_N` folders. That
last one matters when job ads are deleted: with `../CVs/job_116` present and
`../Job_ad` emptied, the next import is `job_description_117.pdf`, not
`job_description_1.pdf` overwriting an application that already exists. Numbers
are never reused, so deleting an ad leaves a gap rather than causing a
collision. The pipeline does not depend on a cursor text file. Instead,
`desc/job_sources.csv` records imported LinkedIn sources and
`../CVs/application_manifest.csv` records completed application pairs by job and
source-bundle hashes. This safely resumes older gaps, detects replaced PDFs, and
reprocesses a posting when approved rules or templates change.

The first heading in each numbered job PDF is cleaned deterministically before
the provider request is built. Work-mode text, gender markers, dash suffixes,
unearned seniority, and engagement types are removed, so `Data Analyst
(Remote)`, `Data Analyst (x m d)`, `Data Analyst Internships`, and `Working
Student Data Analyst` all become `Data Analyst`.

That clean title is given to Claude or Codex. If a posting still carries a
qualifier the cleaner does not recognise, the provider may drop trailing words
from it, so `Data Analyst Summer Programme` may be used as `Data Analyst`.
Cover-letter validation accepts the clean title or a leading part of it, and
rejects anything that adds, reorders, or substitutes a word: the provider can
shorten a title but can never introduce a seniority or specialism the posting
did not give.

Each completed application is stored as:

```text
../CVs/job_N/
├── yigit_coskun_CV.pdf
├── yigit_coskun_cover_letter.pdf
├── job_ad.pdf
├── application_request.md
├── change_log.md
├── match_notes.md
├── validation.json
└── validation.xlsx
```

The existing `../CVs/application_manifest.csv` is preserved and extended. Old
rows remain intact; new rows record the job hash, source-bundle hash, provider,
explicit model and effort when supplied, document number, and both output paths.
A manifest written before the `Effort` column existed gains it automatically as
an empty value, exactly as `SourceHash` and `Model` were added. The same
provider, model, and effort values are recorded in the `validation.json` and
`validation.xlsx` metadata for the pair.

## Validation and safety

Before an application is archived, the pipeline requires all of the following:

- all four requested provider files are fresh and non-empty
- the CV retains exactly nine ordered edit regions and unchanged fixed content.
  A difference outside the edit regions that is only whitespace, such as a blank
  line left beside a marker, is reported as a `WARN` rather than blocking: it
  cannot change the rendered page, and the compile, page-count, and
  overfull-box checks downstream would catch it if it ever did. Any other edit
  to protected content still fails
- the Summary, bullet lists, and four Skills lines follow their LaTeX grammar
- explicitly excluded CV tools are absent (Spark and Kubernetes; Power BI is an
  ordinary inventory tool and may be used freely, as is dashboard/BI wording)
- the cover retains exactly seven ordered edit regions and unchanged fixed content.
  Its header command scaffold, candidate details, column widths, and other layout
  structure must match the template; editable text cannot introduce font, size,
  spacing, margin, geometry, or page-break commands
- all cover regions are populated; tokens are resolved consistently; title and
  company values agree across the letter; fixed evidence is unchanged
- the employer address block is accepted either way: filled from the posting or
  an online lookup, or with both lines deleted when no reliable address exists.
  The company name is still cross-checked across the header and two paragraphs
- the cover uses English salutation/closing, British spelling, escaped LaTeX,
  and none of the blocked claims or removed wording. The job title and company
  name are exempt from the claim and British-spelling scans: they are proper
  nouns quoted from the posting, so a `Data Visualization Analyst` role keeps
  its American spelling and a `Big Data Engineer` role is not read as a claim
- both LaTeX documents compile successfully into `yigit_coskun_CV.pdf` and
  `yigit_coskun_cover_letter.pdf`
- the compiled cover letter has exactly one page, extractable greeting/closing
  text, and no overfull layout boxes
- the compiled cover letter uses the same visible font families, font sizes, and
  page dimensions as the locked approved template PDF
- the compiled CV is assessed for structural, ATS, bullet-provenance,
  skills-inventory, house-style, and job-description checks

For every application pair, the validation stage writes `validation.json`
and `validation.xlsx` as the combined CV-and-cover audit record. Its checks
include explicit
`CV_TEMPLATE_CONTRACT`, `COVER_TEMPLATE_CONTRACT`, `COVER_COMPILE`,
`COVER_PAGE_COUNT`, `COVER_TYPOGRAPHY_CONTRACT`, `COVER_PDF_TEXT`, and
`COVER_LAYOUT_WARNINGS` results in addition to CV ATS, provenance, and
job-description checks. Validation statuses have these effects:

- `ERROR` in generated content starts an automatic repair cycle instead of
  immediately ending the run. The same selected provider receives the exact
  failed check IDs, messages, rules, and evidence; it repairs the retained four
  outputs, and the pipeline reruns structural validation, compilation, page
  checks, PDF checks, and CV quality validation from the beginning. There are
  at most two general repair attempts per job. If both have been used and the
  only remaining error is a late cover-letter page-fit or compiled-typography
  check, one additional cover-only repair is reserved for that case. It must
  shorten permitted job-specific wording; changing formatting is forbidden.
  The absolute maximum is therefore three attempts, and CV, provider,
  configuration, or other failures cannot consume the reserved slot.
- Every repair is written to the normal `Checks` sheet and the dedicated
  `Repairs` sheet in `validation.xlsx`, as well as `validation.json`. The audit
  records the triggering checks, changed files, provider/model/effort, repair
  request, provider log, and the provider's `change_log.md` repair notes.
  Successful archives also retain `repair_request_N.md` and
  `provider_repair_N.log`.
- If the applicable repair budget is exhausted, `AI_REPAIR_EXHAUSTED` remains an `ERROR`, so
  `../CVs/job_N` and its manifest row are blocked. Reports, generated sources,
  provider logs, repair logs, and build logs remain under `.artifacts/job_N`.
  Configuration, dependency, validator-runtime, report-writing, and provider
  launch failures stop immediately because changing document text cannot repair
  them.
- A later run reuses retained output when its original embedded request still
  matches. Change a rule, template, or posting and the request differs, so the
  initial four outputs are regenerated. `-Fresh` forces that initial generation;
  a repair retry itself always preserves the files it was asked to fix.
- Once the archive and manifest are committed, a transient Windows sharing lock
  on the disposable artifact directory cannot turn that success into a pipeline
  failure. Cleanup is reported as deferred and retried automatically on later
  runs; other filesystem errors and unsafe cleanup paths still fail normally.
- `WARN` is visible in both reports but permits the complete CV/cover-letter pair
  and its reports to be archived atomically.
- `PASS` requires no manual action, although the final documents should still be
  reviewed before submission.

The JD tailoring and coverage percentages are diagnostic, non-blocking signals.
Tailoring asks how many posting terms supported by the candidate inventory are
surfaced on the CV; coverage also includes detected posting terms that may be
unsupported. A lower score never authorises adding an unverified claim and does
not by itself block archival.

The supplied `validate_cv.py` was adapted into the packaged validation and
reporting flow; it is not executed unchanged or treated as a separate authority.
`CV_RULES.md`, the bullet library, the skills profiles, and the fixed templates
remain the sources of truth.

All reference files and the active job PDF are byte-protected during provider
execution. If Claude or Codex changes one, the original bytes are restored and
the application attempt fails. Nothing is added to the manifest unless both
PDFs and every blocking validation gate pass.

Stage 1 accesses only public LinkedIn job-view pages. It does not log in, solve
CAPTCHAs, rotate proxies, or bypass access controls, and it spaces requests with
a configurable delay. Review LinkedIn's terms and the content owner's rights
before using browser automation; failed, blocked, expired, or incomplete pages
are reported rather than forced through the pipeline.

## Tests

Run the test suite from `job_py`:

```powershell
python -m unittest discover -s tests -v
python -m unittest discover -s desc\tests -v
```

The suite covers extraction, prompt authority, both template validators, source
protection, Claude/Codex command paths, compilation, CV quality checks, cover
structure/page/PDF/layout checks, combined JSON/XLSX report rendering,
error-versus-warning gates, failed-report retention, archive atomicity, legacy
manifest resume behaviour, LinkedIn URL/PDF handling, the Stage 1-to-Stage 2
handoff, and failure when the approved cover pack is absent.
