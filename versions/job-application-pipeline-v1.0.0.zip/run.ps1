param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet("claude", "codex")]
    [string] $Provider,

    [AllowEmptyString()]
    [string] $Model,

    [ValidateSet("minimal", "low", "medium", "high", "xhigh", "max")]
    [string] $Effort,

    [switch] $Fresh
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot
$PackageRoot = Join-Path $ProjectRoot "src"
$VirtualEnvironmentPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$PythonCandidates = @()
if (-not [string]::IsNullOrWhiteSpace($env:JOB_PIPELINE_PYTHON)) {
    $PythonCandidates += $env:JOB_PIPELINE_PYTHON
}
if (Test-Path -LiteralPath $VirtualEnvironmentPython -PathType Leaf) {
    $PythonCandidates += $VirtualEnvironmentPython
}
$SystemPython = Get-Command "python" -ErrorAction SilentlyContinue
if ($SystemPython) {
    $PythonCandidates += $SystemPython.Source
}

$PythonExe = $null
foreach ($Candidate in $PythonCandidates | Select-Object -Unique) {
    try {
        & $Candidate -c "import sys; raise SystemExit(0)" *> $null
        if ($LASTEXITCODE -eq 0) {
            $PythonExe = $Candidate
            break
        }
    }
    catch {
        continue
    }
}
if (-not $PythonExe) {
    throw "No working Python interpreter was found. Recreate .venv or install Python 3.11+."
}

$PreviousPythonPath = $env:PYTHONPATH
$PreviousPythonUtf8 = $env:PYTHONUTF8
$PreviousNoBytecode = $env:PYTHONDONTWRITEBYTECODE

try {
    $env:PYTHONPATH = if ([string]::IsNullOrWhiteSpace($PreviousPythonPath)) {
        $PackageRoot
    }
    else {
        "$PackageRoot$([System.IO.Path]::PathSeparator)$PreviousPythonPath"
    }
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"

    $PipelineArguments = @("-m", "job_application_pipeline", $Provider)
    if ($PSBoundParameters.ContainsKey("Model")) {
        $PipelineArguments += @("--model", $Model)
    }
    if ($PSBoundParameters.ContainsKey("Effort")) {
        $PipelineArguments += @("--effort", $Effort)
    }
    if ($Fresh) {
        $PipelineArguments += "--fresh"
    }

    & $PythonExe @PipelineArguments
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}
finally {
    $env:PYTHONPATH = $PreviousPythonPath
    $env:PYTHONUTF8 = $PreviousPythonUtf8
    $env:PYTHONDONTWRITEBYTECODE = $PreviousNoBytecode
}
