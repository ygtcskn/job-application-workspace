# CV_RULES.md

Rules for filling `yigit_coskun_empty.tex`. The AI writes **only** the summary, bullet points,
and skills. Everything else in the template is a fixed factual record.

Sources of truth: `skills_profiles.docx` (skills, tiers, skills-section format) and
`bullet_library.docx` (bullets, house style, placement). Re-read them every run — they change.

---

## 1. Scope — what the AI may touch

**R-01** — Edit only between `AI_EDIT_START` / `AI_EDIT_END` markers. Nine regions: summary,
six bullet regions, Ziraat, skills. Never move or delete a marker.

**R-02** — Never touch: the preamble, `\newcommand` definitions, the contact block, `\section`
names or their order, or any `\resumeSubheading` line (organisation, location, role, dates).

**R-03** — Never change a job title to match a posting. Student Assistant and Intern are facts.
The summary states the target role; the history states what happened.

**R-04** — Leaving a region empty is a valid outcome, not a failure:
- **Ziraat Bank** takes **zero bullets** unless the posting is banking, finance, insurance, or
  risk. Header only. Never delete the entry — leave the region empty.
- **University of Łódź** never takes bullets at all.

**R-05** — The thesis appears twice, complementary not duplicate: the **Education** line carries
title, chair, and grade; the **Projects** entry carries 3–4 content bullets and **no** grade.

**R-06** — **Bullet budget is a soft target: aim for 3–4 per entry, fewer is fine.** Take the
bullets that qualify for the profile and stop. Never pad an entry with off-profile bullets to
reach a count — a Data Scientist CV carrying `[DA]`-tagged bullets is exactly the dilution the
tier system exists to prevent. If an entry consistently comes up short, the fix is to write or
re-tag bullets in `bullet_library.docx`, never to pad at fill time.

---

## 2. Factual discipline

**R-07** — Never invent an employer, institution, date, metric, tool, dataset, or publication.
Only rephrase and re-weight what the source documents already contain.

**R-08** — Never name a tool absent from the master skills inventory, however common in postings.
Explicitly excluded: **Spark, Kubernetes**.

**R-09** — Never state an unmeasured figure and never round one upward. If no true number exists,
leave the claim unquantified.

**R-10** — Respect evidence tiers, read fresh from the source each run (they move between
revisions): **Tier 1** state confidently · **Tier 2** list as a skill, never as professional
experience · **Tier 3** only when the posting names it.

**R-11** — Honour scope limits attached to a skill. Gen AIs / LLMs = tool fluency only, not
building LLM applications or API integrations. AWS = certificate-level, no deployment. CUDA =
GPU-accelerated training, not hardware optimisation.

**R-12** — Never use two phrasings of the same bullet ID on one CV.

**R-13** — If honest matching leaves the posting's core requirements uncovered, report it as a
**weak fit**. Never stretch wording to hit a keyword count.

**R-14** — Never name internal file paths, drives, or individual-level data.

---

## 3. Synonym substitution

Permitted only when the new term points at the **identical act**. Keep the sentence structure and
every number — change the label, not the claim. Use the posting's exact string, once per concept.

**Permitted** — `cleaned and prepared` → data wrangling / preprocessing · `collected N series` →
web scraping / data acquisition · `benchmarked models` → model evaluation / comparison / selection ·
`LSTM` → deep learning / neural networks / sequence models · `MIDAS` → mixed-frequency modelling ·
`expanding-window forecasts, RMSE, Diebold–Mariano` → out-of-sample testing / backtesting ·
`panel and longitudinal survey data` → panel data analysis · `tables and figures` → data
visualisation / statistical reporting.

**Blocked** — `data pipeline` → production
pipeline / MLOps / model deployment · `large datasets` → big data / distributed computing ·
`randomised experiment` → A/B testing (unless the posting means offline experimental design) ·
`research support` → consulting / stakeholder management / project leadership.

**R-15** — After every substitution, re-read the whole bullet: grammar still works, numbers still
attach to the right thing, no term now repeats another bullet, claim unchanged. If it reads
awkwardly, keep the original — an unmatched keyword costs less than an incoherent bullet.

---

## 4. ATS and formatting

**R-16** — **Slot 4 of `\resumeSubheading` holds a date and nothing else.** No "(expected)", no
grade, no qualifier — trailing text breaks end-date extraction.

**R-17** — Slots stay positionally consistent across every section:
`{organisation}{location}{role or degree}{dates}`. Mixed orders make parsers mis-assign fields.

**R-18** — The name stands alone on its own text line. Contact details on one following line, in
the document body — never in a header or footer.

**R-19** — Accented characters as **literal UTF-8** (ü, ä, ß, Łódź). Never `\"u` / `\'o` / `\L{}` —
composite glyphs can carry incomplete ToUnicode maps and break text extraction.

**R-20** — `itemsep` never below **4pt**. At 2pt, `pdftotext` merges adjacent bullets onto one line.

**R-21** — Certificates use the flat one-line format, never `\resumeSubheading` — a four-slot
heading makes a certificate look like a job and parsers invent phantom work records.

**R-22** — Section headings must not strand at a page foot, and an entry header must not separate
from its bullets. `\Needspace*` must wrap `\section` itself; inside `\titleformat` it silently
does nothing.

**R-23** — **Skills section: exactly four labelled lines, this order** —
`Programming` · `Methods` · `Tools & Platforms` · `Languages`.
Never label a line "Skills". Never lead with tools. Statistical software (Stata, MATLAB/Dynare)
belongs on Programming. `Tools & Platforms` holds Tier 2–3 items, stays short, and includes only
what the posting asks for.

**R-24** — The compiled PDF must show: zero fonts missing Unicode maps · zero glued nested
bullets · every date field matching a date-range regex · no new overfull `\hbox`.

**Accepted limitations — do not chase these.** Top-level `•` bullets in Skills and Certifications
merge under `pdftotext` *raw* mode; no `itemsep` value fixes it (tested 4–12pt) and the geometry is
correct under `-layout`. A section heading beginning a page carries a `\f` prefix in extraction;
parsers strip control characters. One 3.1pt overfull box on the thesis title row sits inside the
true text width.

---

## 5. House style

**R-25** — British English: labour, analyse, visualisation, behaviour, randomised, modelling.

**R-26** — **No terminal punctuation on bullets.** Never end a bullet with a full stop.

**R-27** — Present tense for current roles (IAB, NOSI); past tense for everything finished.

**R-28** — Course, module, and dataset names in Title Case; general methods lower case
mid-sentence. Acronyms as the field writes them: LASSO, MIDAS, LSTM, RMSE, SHAP, ARIMA, VAR.

**R-29** — Digits with thousands separators (3,540 · 44,000+); percentages to one or two decimals
as measured (8.16%, 11.9%).

---

## 6. Pre-flight checklist

**Formatting / ATS**
- [ ] Slot 4 contains only a date, every entry
- [ ] Skills has exactly four lines, correct labels and order
- [ ] Name alone on the first extracted line
- [ ] Zero fonts missing Unicode maps · zero glued nested bullets · no new overfull box
- [ ] No section heading stranded at a page foot

**House style**
- [ ] No bullet ends in a full stop
- [ ] No US spellings (visualization, analyze, labor, randomized, modeling)
- [ ] IAB and NOSI in present tense, everything else past

**Factual**
- [ ] Every tool named exists in the master inventory; no Spark / Kubernetes
- [ ] No Tier 3 item unless the posting names it
- [ ] Every figure traces to a source document, none rounded up
- [ ] No two variants of one bullet ID

**Structure**
- [ ] Ziraat has zero bullets unless the posting is finance-related
- [ ] Łódź has zero bullets
- [ ] Thesis in Education *with* grade, in Projects *without*
- [ ] All nine marker pairs intact; nothing changed outside them

---

## 7. Settled decisions

- **Name — `Yigit Coskun`, always.** Decided 2026-08-20. The IAB publication is credited to
  *Ahmet Coskun* and nothing on the CV bridges the two; this is accepted. Do not "fix" it by
  expanding the header or altering how the publication is cited.
- **Bullet budget — soft.** See R-06. Aim 3–4, accept fewer, never pad off-profile.
- **Known gap this creates.** For Data Scientist, NOSI has one qualifying bullet (N2a) and
  Publications two (PB1, PB3). N1a and N3a are tagged `[DA]` but describe work that is squarely
  data-science relevant. **Recommended library fix: re-tag N1a and N3a as `[DA/DS]`** rather than
  padding at fill time, which R-06 forbids.
