# Cover-letter sources

The approved cover-letter rule source is:

- `COVER_LETTER_RULES.md`

It works with the current `data/reference/cv/skills_profiles.docx` and
`bullet_library.docx` as evidence companions plus the fixed cover template.
There is no separate legacy cover profile. The cover rules and template must
never be used as evidence for the CV.
