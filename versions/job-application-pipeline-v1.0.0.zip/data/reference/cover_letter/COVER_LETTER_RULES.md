# CL_RULES.md — Cover Letter Tailoring Rules

Rules for any AI system adapting `cover_letter_template.tex` to a specific job posting.
Companion documents: **Skills Profile** (what may be claimed and how strongly) and **CV Bullet Point Library** (the vetted sentences and house style). Where those documents and this one disagree, the Skills Profile's evidence tiers win.

---

## 1. Scope of work

Your job is narrow, in this order:

1. **Read the job description** (`job_description.pdf` or the supplied posting text).
2. **Fill every `{{TOKEN}}`** with content drawn from that posting.
3. **Optionally swap individual words** for the posting's own vocabulary, within the limits in §4.
4. **Run the pre-send checklist** in §8.

You are not rewriting the letter. The paragraphs are vetted and their claims are verified against real documents. Anything beyond token-filling and word-level substitution is out of scope unless the user explicitly asks.

---

## 2. Tokens

Six tokens, all hyphenated. Never introduce underscores — `_` is LaTeX subscript syntax and breaks compilation outside math mode.

| Token | Fill with |
|---|---|
| `{{JOB-TITLE}}` | The job title, after extraction (§3) |
| `{{COMPANY-NAME}}` | Company name exactly as the posting writes it |
| `{{COMPANY-ADDRESS}}` | Street address from the posting, or a reliable online lookup; delete the whole line if not found |
| `{{COMPANY-CITY}}` | Postal code and city from the posting, or a reliable online lookup; delete the whole line if not found |
| `{{TARGET-TASK}}` | The concrete task or business problem the role exists to solve, in the posting's words |
| `{{TARGET-DOMAIN}}` | The skill, domain, or responsibility the posting emphasises most |

`{{JOB-TITLE}}` appears five times (header, para 1, para 4, para 5 twice) and `{{COMPANY-NAME}}` four times (address block, para 3, para 5 twice). Fill every instance identically.

**Never leave an unfilled token.** Before output, grep for `{{` — zero matches required.

**Read the finished letter back.** After filling the tokens, read the whole letter as a human reader would and repair what reads as a mistake: a posting value repeated into itself (`Berlin, Berlin, Germany` should read `Berlin`), an article that no longer agrees (`as a Analytics Engineer` should read `as an Analytics Engineer`), a doubled word or space, or a sentence whose grammar broke where a token landed. Make the smallest correction that fixes it. This is proofreading, not rewriting: never change a fact, add a claim, or add, delete, merge, or reorder a paragraph, and keep the company name and job title identical everywhere they appear.

**Never invent an address.** If the posting gives no address, look one up online and use a reliable published business address for the employer. If no reliable address is found, remove the line and its trailing `\\` rather than guessing or writing a placeholder like "N/A". An address is the only detail that may come from outside the approved sources; it never becomes evidence about the candidate.

---

## 3. Job title extraction

Strip everything that is logistics rather than role:

- Location and work mode: Remote, Hybrid, Onsite, city names, "Standort Nürnberg"
- Employment terms: Vollzeit, Teilzeit, befristet, Full-time, Part-time, Contract
- German gender markers: (m/w/d), (w/m/d), (m/f/x), \*in, :in
- Reference numbers, requisition IDs, dates, salary bands
- Department or product suffixes after a dash or pipe
- **Seniority not earned**: Senior, Lead, Principal, Head of. Keep "Junior" if present.

Examples:
- "Data Analyst (m/w/d) – Remote – Vollzeit – Ref. 2847" → **Data Analyst**
- "Senior Data Scientist | Pricing Team" → **Data Scientist**
- "Werkstudent Datenanalyse (m/w/d)" → German compound; use the profile default (Data Scientist / Data Analyst / Applied economist) since it will not read as an English noun phrase in the sentence.

If the extracted title does not read grammatically in "…what I can do as a {{JOB-TITLE}}", use the profile default instead of forcing it.

---

## 4. Word substitution — what is allowed

You may replace individual words so the letter uses the posting's vocabulary. The test: **the words must point at the identical act.** Change the label, never the claim.

**Permitted** (same act, different label):
- cleaned and prepared → data wrangling · data preparation · data preprocessing
- analyse → statistical analysis · quantitative analysis
- benchmarked → model evaluation · model comparison · model validation
- LSTM neural network → deep learning model · sequence model
- large-scale datasets → large datasets · high-volume data
- forecasting workflow → forecasting pipeline · predictive modelling

**Blocked** (these change the claim):
- workflow / pipeline → production pipeline · MLOps · deployed model (nothing was deployed)
- large-scale → big data · distributed computing (no Spark, Hadoop, or cluster work)
- Any tool or technology name not already in the Skills Profile. Never add one to match a posting.

**Constraints on every substitution:**
- Use the posting's exact string, not a synonym of it. Parsers are literal.
- One term per concept. Do not stack "data wrangling, data preparation, and data cleansing".
- **Never touch numbers, employers, dates, institutions, or results.** 27,000 files, 44,000 respondents, 19,900 records, 15 economies, 69 months, 1975, IAB, KEM, INTER, Polish workers report — all fixed.
- **Re-read the whole sentence after each swap.** Verb phrases and noun phrases are not interchangeable ("cleaned and prepared" is a verb; "data wrangling" is a noun), so the sentence must be reshaped to fit. If the result reads awkwardly or the meaning drifts, keep the original wording. An unmatched keyword costs less than a broken sentence.

Aim for roughly 3–6 substitutions across the letter. More than that and you are rewriting, not tailoring.

---

## 5. Edit zones

Only text between `% AI_EDIT_START:` and `% AI_EDIT_END:` may change:

| Zone | May change |
|---|---|
| `COVER_HEADER` | Tokens only |
| `SALUTATION` | Named recipient if the posting gives one (§6) |
| `PARA_1_HOOK_THESIS` | Tokens, word swaps |
| `PARA_2_IAB` | Tokens, word swaps |
| `PARA_3_FIT` | Tokens, word swaps |
| `PARA_4_MOTIVATION` | Tokens, word swaps |
| `PARA_5_CLOSE` | Tokens, word swaps |

Everything outside these markers is fixed: preamble, geometry, layout, the contact block, the date line, the sign-off. Never edit the marker comments themselves, and never delete a paragraph or add a new one.

---

## 6. Salutation

- If the posting names a contact person, use it: "Dear Ms Schmidt," / "Dear Dr Weber,".
- German-language posting with a named contact: "Sehr geehrte Frau Schmidt," is acceptable if the rest of the letter is being sent in German. Do **not** mix languages in one letter.
- No name given: keep "Dear Hiring Team,".
- Never write "To Whom It May Concern" or "Dear Sir or Madam".

---

## 7. Hard limits

1. **Never fabricate.** No skill, tool, employer, result, date, or number that is not in the Skills Profile or Bullet Library. If the posting demands something absent from those documents, leave it absent.
2. **Respect evidence tiers.** Tier 1 claims may be stated confidently. Tier 2 (AWS, SQL, PyTorch, Docker, statsmodels, LightGBM, CUDA, A/B testing) must never be phrased as professional work experience. Tier 3 (Tableau, Seaborn/Plotly, SciPy, shiny) appears only if the posting explicitly asks, phrased as working knowledge.
3. **Escape LaTeX special characters** in any substituted text: `&` → `\&`, `%` → `\%`, `#` → `\#`, `$` → `\$`, `_` → `\_`. Company names containing `&` are the common case.
4. **British English throughout**: labour, analyse, visualisation, behaviour, randomised, modelling.
5. **No em dashes.** Use commas or restructure.
6. **One page.** The template fills a page as written; substitutions must not push it to two.
7. **Do not restore removed content.** "Eager to learn from experienced colleagues" and similar supervision-seeking phrasing was deliberately cut. Do not reintroduce it.
8. **Flag rather than stretch.** If the posting's core requirements are largely outside the Skills Profile, report it as a weak fit instead of producing a letter that overstates. A flagged posting is a useful result.

---

## 8. Pre-send checklist

Run every item. Report failures rather than silently fixing by rewriting.

- [ ] Zero `{{` sequences remain
- [ ] `{{JOB-TITLE}}` filled identically in all five places; `{{COMPANY-NAME}}` in all four
- [ ] Job title stripped of m/w/d, location, employment terms, reference numbers, unearned seniority
- [ ] Unknown address or city lines deleted cleanly, no dangling `\\`
- [ ] No number, employer, date, or institution altered anywhere
- [ ] No skill or tool introduced that is absent from the Skills Profile
- [ ] Every substituted sentence re-read and grammatical
- [ ] LaTeX special characters escaped in all substituted text
- [ ] British spelling; no em dashes
- [ ] Compiles with `pdflatex` to exactly one page
- [ ] Company name spelled as the posting spells it, including capitalisation

---

## 9. Known gaps

The template does not currently state the **earliest start date** or **German language level (B1)**. German employers commonly expect both. If the user asks for them, they belong in `PARA_5_CLOSE`; do not add them on your own initiative, as it changes paragraph content rather than wording.
