from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from tests.support import ROOT

from desc import import_linkedin_jobs as importer
from job_application_pipeline.paths import Paths
from job_application_pipeline.pipeline import ApplicationPipeline


POWERSHELL = shutil.which("powershell.exe") or shutil.which("pwsh")


class LinkedinHandoffTests(unittest.TestCase):
    def test_numbered_archive_is_top_level_stage_two_input_not_working_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "job_py"
            working = project / ".artifacts" / "linkedin_imports"
            job_ads = root / "Job_ad"
            working.mkdir(parents=True)
            source = working / "job_description (1).pdf"
            source.write_bytes(b"%PDF-1.4 LinkedIn working PDF")

            archived, created = importer.archive_job_pdf(source, 1, job_ads)
            paths = Paths(
                project_root=project,
                job_ads_dir=job_ads,
                cvs_dir=root / "CVs",
            )
            discovered = ApplicationPipeline(paths)._job_ads()  # noqa: SLF001

            self.assertTrue(created)
            self.assertEqual(archived, job_ads / "job_description_1.pdf")
            self.assertEqual(discovered, [archived.resolve()])
            self.assertNotIn(source.resolve(), discovered)

    def test_stage_two_orders_numbered_job_ads_by_ascending_number(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "job_py"
            job_ads = root / "Job_ad"
            job_ads.mkdir()
            for name in (
                "job_description_2.pdf",
                "Legacy Company.pdf",
                "job_description_11.pdf",
                "job_description_3.pdf",
            ):
                (job_ads / name).write_bytes(b"%PDF-1.4 job")

            discovered = ApplicationPipeline(
                Paths(
                    project_root=project,
                    job_ads_dir=job_ads,
                    cvs_dir=root / "CVs",
                )
            )._job_ads()  # noqa: SLF001

            # Ascending, and numerically rather than lexically, so the
            # document number each ad is archived under tracks its own number.
            self.assertEqual(
                [path.name for path in discovered],
                [
                    "job_description_2.pdf",
                    "job_description_3.pdf",
                    "job_description_11.pdf",
                    "Legacy Company.pdf",
                ],
            )

    @unittest.skipUnless(
        os.name == "nt" and POWERSHELL,
        "PowerShell wrapper test requires Windows PowerShell",
    )
    def test_root_wrapper_uses_module_defaults_and_preserves_exit_code(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            wrapper = root / "create_job_descriptions.ps1"
            shutil.copy2(ROOT / "create_job_descriptions.ps1", wrapper)
            tools = root / "tools"
            tools.mkdir()
            fake_python = tools / "python.cmd"
            fake_python.write_text(
                "@echo off\r\n"
                "if \"%~1\"==\"-c\" exit /b 0\r\n"
                "> \"%FAKE_CAPTURE%\" echo %*\r\n"
                "exit /b %FAKE_EXIT_CODE%\r\n",
                encoding="ascii",
            )
            broken_venv = root / ".venv" / "Scripts" / "python.exe"
            broken_venv.parent.mkdir(parents=True)
            broken_venv.write_bytes(b"not a Windows executable")
            capture = root / "arguments.txt"
            environment = os.environ.copy()
            environment.pop("JOB_PIPELINE_PYTHON", None)
            environment["PATH"] = str(tools) + os.pathsep + environment.get("PATH", "")
            environment["FAKE_CAPTURE"] = str(capture)

            environment["FAKE_EXIT_CODE"] = "0"
            default_result = self._run_wrapper(wrapper, environment)
            self.assertEqual(default_result.returncode, 0, default_result.stdout + default_result.stderr)
            self.assertEqual(
                capture.read_text(encoding="utf-8").strip(),
                "-m desc.import_linkedin_jobs",
            )

            environment["FAKE_EXIT_CODE"] = "7"
            headed_result = self._run_wrapper(wrapper, environment, "-Headed")
            self.assertEqual(headed_result.returncode, 7, headed_result.stdout + headed_result.stderr)
            self.assertEqual(
                capture.read_text(encoding="utf-8").strip(),
                "-m desc.import_linkedin_jobs --headed",
            )

    @staticmethod
    def _run_wrapper(
        wrapper: Path,
        environment: dict[str, str],
        *arguments: str,
    ) -> subprocess.CompletedProcess[str]:
        command = [str(POWERSHELL), "-NoLogo", "-NoProfile"]
        if Path(str(POWERSHELL)).name.casefold() == "powershell.exe":
            command.extend(("-ExecutionPolicy", "Bypass"))
        command.extend(("-File", str(wrapper), *arguments))
        return subprocess.run(
            command,
            cwd=wrapper.parent,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )


if __name__ == "__main__":
    unittest.main()
