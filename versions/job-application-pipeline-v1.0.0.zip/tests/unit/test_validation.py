from __future__ import annotations

import unittest

from tests.support import (
    COVER_REGIONS,
    CV_REGIONS,
    ROOT,
    fill_regions,
    valid_cover,
    valid_cv,
    valid_skills,
)

from job_application_pipeline.validation import (
    parse_cover_regions,
    parse_cv_regions,
    validate_generated_cover,
    validate_generated_cv,
)


def installed_tailored_cover(
    *,
    job_title: str = "Data Analyst",
    company_name: str = "Acme GmbH",
    company_address: str | None = "Example Street 1",
    company_city: str | None = "90402 Nuremberg",
) -> tuple[str, str]:
    """Fill the installed template while keeping its command scaffold intact."""

    template = (
        ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
    ).read_text(encoding="utf-8")
    generated = template
    values = {
        "{{JOB-TITLE}}": job_title,
        "{{COMPANY-NAME}}": company_name,
        "{{TARGET-TASK}}": "build reliable forecasts",
        "{{TARGET-DOMAIN}}": "quantitative analysis",
    }
    if company_address is not None:
        values["{{COMPANY-ADDRESS}}"] = company_address
    if company_city is not None:
        values["{{COMPANY-CITY}}"] = company_city

    for region in COVER_REGIONS:
        start_marker = f"% AI_EDIT_START: {region}"
        end_marker = f"% AI_EDIT_END: {region}"
        start = generated.index(start_marker) + len(start_marker)
        end = generated.index(end_marker, start)
        body = generated[start:end]
        if company_address is None and company_city is None:
            body = body.replace(
                "{{COMPANY-NAME}}\\\\\n{{COMPANY-ADDRESS}}\\\\\n{{COMPANY-CITY}}",
                "{{COMPANY-NAME}}",
            )
        for token, value in values.items():
            body = body.replace(token, value)
        generated = generated[:start] + body + generated[end:]
    return template, generated


class CvValidationTests(unittest.TestCase):
    def test_exact_nine_region_contract_accepts_valid_cv(self) -> None:
        template, generated = valid_cv()
        _, regions = parse_cv_regions(template)
        self.assertEqual(tuple(regions), CV_REGIONS)
        validate_generated_cv(template, generated)

    def test_fixed_content_change_is_rejected(self) -> None:
        template, generated = valid_cv()
        changed = generated.replace("% fixed CV header", "% changed CV header", 1)
        with self.assertRaisesRegex(ValueError, "fixed template content"):
            validate_generated_cv(template, changed)

    def test_a_blank_line_beside_a_marker_is_a_note_not_a_failure(self) -> None:
        # Models routinely leave an extra blank line next to an edit marker.
        # It cannot change the rendered page, and the compile, page-count, and
        # overfull-box checks downstream would catch it if it ever did.
        template, generated = valid_cv()
        spaced = generated.replace(
            "% AI_EDIT_END: SUMMARY\n", "% AI_EDIT_END: SUMMARY\n\n", 1
        )
        self.assertNotEqual(spaced, generated)
        notes = validate_generated_cv(template, spaced)
        self.assertEqual(len(notes), 1)
        self.assertIn("only whitespace", notes[0])
        self.assertIn("after SUMMARY", notes[0])

    def test_an_unchanged_cv_reports_no_notes(self) -> None:
        template, generated = valid_cv()
        self.assertEqual(validate_generated_cv(template, generated), [])

    def test_missing_or_reordered_region_is_rejected(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace("AI_EDIT_START: EDUCATION_FAU_BULLETS", "AI_EDIT_START: WRONG", 1)
        with self.assertRaisesRegex(ValueError, "Unexpected CV edit region"):
            validate_generated_cv(template, malformed)

    def test_malformed_skills_are_rejected(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace(
            r"\item{\textbf{Methods}{: Time-series analysis}}",
            r"\item{\textbf{Wrong label}{: Time-series analysis}}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "SKILLS item 2 is malformed"):
            validate_generated_cv(template, malformed)

    def test_stray_content_in_bullet_region_is_rejected(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace(
            r"\resumeItemPlain{Build reproducible Python analyses}",
            "stray text\n" + r"\resumeItemPlain{Build reproducible Python analyses}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "outside its plain bullet commands"):
            validate_generated_cv(template, malformed)

    def test_prohibited_tool_spelling_variants_are_rejected(self) -> None:
        for variant in ("Spark", "PySpark", "Py-Spark", "Kubernetes"):
            with self.subTest(variant=variant):
                template, generated = valid_cv(programming=f"Python, {variant}")
                with self.assertRaisesRegex(ValueError, "explicitly excluded tools"):
                    validate_generated_cv(template, generated)

    def test_power_bi_is_an_allowed_tool(self) -> None:
        # Power BI is in the skills inventory, so every spelling is accepted.
        for variant in ("Power BI", "PowerBI", "Power-BI", "power_bi"):
            with self.subTest(variant=variant):
                template, generated = valid_cv(programming=f"Python, {variant}")
                validate_generated_cv(template, generated)

    def test_summary_requires_single_small_wrapper(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace(
            r"{\small Data analyst with supported quantitative experience.}",
            "Data analyst with supported quantitative experience.",
            1,
        )
        with self.assertRaisesRegex(ValueError, "exactly one"):
            validate_generated_cv(template, malformed)


class CoverValidationTests(unittest.TestCase):
    def test_final_company_or_address_line_cannot_have_a_dangling_separator(
        self,
    ) -> None:
        template, generated = installed_tailored_cover(
            company_address=None,
            company_city=None,
        )
        dangling = generated.replace(
            "Acme GmbH\n\\end{minipage}",
            "Acme GmbH\\\\\n\\end{minipage}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "must not end with a line separator"):
            validate_generated_cover(template, dangling)

    def test_new_formatting_and_layout_commands_are_rejected_in_edit_regions(
        self,
    ) -> None:
        commands = (
            r"\Huge",
            r"\fontsize{18}{22}\selectfont",
            r"\linespread{2}",
            r"\setlength{\parskip}{2cm}",
            r"\vspace{1cm}",
            r"\hspace{1cm}",
            r"\geometry{margin=0cm}",
            r"\newgeometry{margin=0cm}",
            r"\pagebreak",
            r"\newpage",
        )
        for command in commands:
            with self.subTest(command=command):
                template, generated = valid_cover()
                injected = generated.replace(
                    "bring a quantitative perspective",
                    f"bring {command} a quantitative perspective",
                    1,
                )
                with self.assertRaisesRegex(ValueError, "formatting/layout command"):
                    validate_generated_cover(template, injected)

    def test_huge_is_rejected_when_injected_into_the_header_title(self) -> None:
        template, generated = installed_tailored_cover()
        injected = generated.replace(
            "Cover Letter for Data Analyst",
            r"Cover Letter for \Huge Data Analyst",
            1,
        )
        with self.assertRaisesRegex(ValueError, r"formatting/layout command: \\Huge"):
            validate_generated_cover(template, injected)

    def test_cover_header_layout_is_compared_with_the_template(self) -> None:
        template, generated = installed_tailored_cover()
        changed_width = generated.replace(
            r"\begin{minipage}[t]{0.48\textwidth}",
            r"\begin{minipage}[t]{0.60\textwidth}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "structure fixed by the template"):
            validate_generated_cover(template, changed_width)

    def test_header_tokens_allow_address_deletion_and_escaped_special_chars(
        self,
    ) -> None:
        template, generated = installed_tailored_cover(
            job_title=r"Data \& Product Analyst",
            company_name=r"Research \& Data GmbH",
            company_address=None,
            company_city=None,
        )
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data & Product Analyst",
        )

    def test_installed_cover_template_accepts_token_only_tailoring(self) -> None:
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Data Analyst",
            "{{COMPANY-NAME}}": "Acme GmbH",
            "{{COMPANY-ADDRESS}}": "Example Street 1",
            "{{COMPANY-CITY}}": "90402 Nuremberg",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        validate_generated_cover(template, generated)

    def test_installed_cover_template_accepts_a_posting_without_an_address(
        self,
    ) -> None:
        # COVER_LETTER_RULES.md requires an unknown address or city line to be
        # deleted together with its trailing "\\", leaving the company name as
        # the last line of the block. LinkedIn postings carry no street
        # address, so this is the normal case rather than an edge case.
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Junior Quant Researcher",
            "{{COMPANY-NAME}}": "BIT Capital",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            # Delete the unknown lines cleanly, leaving no dangling separator.
            body = body.replace(
                "{{COMPANY-NAME}}\\\\\n{{COMPANY-ADDRESS}}\\\\\n{{COMPANY-CITY}}",
                "{{COMPANY-NAME}}",
            )
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        # The template's comment block documents the tokens, so only the edit
        # regions are checked for unresolved ones.
        _fixed, generated_regions = parse_cover_regions(generated)
        self.assertNotIn("{{", "".join(generated_regions.values()))
        self.assertNotIn("BIT Capital\\\\", generated_regions["COVER_HEADER"])
        validate_generated_cover(template, generated)

    def test_installed_cover_template_accepts_a_looked_up_german_address(
        self,
    ) -> None:
        # The rules permit an online address lookup, and German street names
        # routinely carry an umlaut or a sharp s.
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Junior Quant Researcher",
            "{{COMPANY-NAME}}": "BIT Capital",
            "{{COMPANY-ADDRESS}}": "Dircksenstraße 4",
            "{{COMPANY-CITY}}": "10179 Nürnberg",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        validate_generated_cover(template, generated)

    def test_company_name_missing_from_the_header_is_still_rejected(self) -> None:
        template, generated = valid_cover()
        without_company = generated.replace("Acme GmbH\n", "")
        with self.assertRaises(ValueError):
            validate_generated_cover(template, without_company)

    def test_exact_seven_region_contract_accepts_valid_cover(self) -> None:
        template, generated = valid_cover()
        _, regions = parse_cover_regions(template)
        self.assertEqual(tuple(regions), COVER_REGIONS)
        validate_generated_cover(template, generated)

    def test_fixed_content_change_is_rejected(self) -> None:
        template, generated = valid_cover()
        changed = generated.replace("% fixed cover letter header", "% changed cover header", 1)
        with self.assertRaisesRegex(ValueError, "fixed template content"):
            validate_generated_cover(template, changed)

    def test_placeholders_are_rejected(self) -> None:
        for placeholder in (
            "{{COMPANY}}",
            "[Hiring Manager]",
            "[Company Address Line 1]",
            "[City, Country]",
        ):
            with self.subTest(placeholder=placeholder):
                template, generated = valid_cover()
                generated = generated.replace("Acme GmbH", placeholder, 1)
                with self.assertRaisesRegex(ValueError, "unresolved"):
                    validate_generated_cover(template, generated)

    def test_greeting_must_begin_with_dear(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("Dear Hiring Team,", "Hello Hiring Team,", 1)
        with self.assertRaisesRegex(ValueError, "begin with 'Dear'"):
            validate_generated_cover(template, generated)

    def test_noindent_dear_and_latex_position_option_are_accepted(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace(
            r"\noindent Dear Hiring Team,", r"{\noindent Dear Hiring Team,}", 1
        )
        validate_generated_cover(template, generated)

    def test_closing_must_contain_kind_regards(self) -> None:
        template, generated = valid_cover()
        template = template.replace("Kind regards", "Sincerely", 1)
        generated = generated.replace("Kind regards", "Sincerely", 1)
        with self.assertRaisesRegex(ValueError, "Kind regards"):
            validate_generated_cover(template, generated)

    def test_fixed_evidence_cannot_be_changed(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("44,000", "45,000", 1)
        with self.assertRaisesRegex(ValueError, "fixed evidence"):
            validate_generated_cover(template, generated)

    def test_job_title_and_company_values_must_be_consistent(self) -> None:
        template, generated = valid_cover()
        inconsistent_title = generated.replace(
            "fit for the Data Analyst role", "fit for the Data Scientist role", 1
        )
        with self.assertRaisesRegex(ValueError, "inconsistent job-title"):
            validate_generated_cover(template, inconsistent_title)

        inconsistent_company = generated.replace(
            "experience to Acme GmbH", "experience to Other GmbH", 1
        )
        with self.assertRaisesRegex(ValueError, "inconsistent company-name"):
            validate_generated_cover(template, inconsistent_company)

    def test_job_title_must_match_deterministic_clean_title(self) -> None:
        template, generated = valid_cover()
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data Analyst",
        )

        generated_with_suffix = generated.replace(
            "Data Analyst",
            "Data Analyst (Remote)",
        )
        with self.assertRaisesRegex(ValueError, "deterministic clean title"):
            validate_generated_cover(
                template,
                generated_with_suffix,
                expected_job_title="Data Analyst",
            )

    def test_cover_title_may_drop_trailing_words_but_not_add_them(self) -> None:
        template, generated = valid_cover()
        # The fixture letter uses "Data Analyst" in all four places.
        validate_generated_cover(
            template, generated, expected_job_title="Data Analyst Summer Programme"
        )
        validate_generated_cover(template, generated, expected_job_title="Data Analyst")

        for wrong in ("Analyst", "Senior Data Analyst", "Data Scientist", "Analyst Data"):
            with self.subTest(expected=wrong):
                with self.assertRaisesRegex(ValueError, "deterministic clean title"):
                    validate_generated_cover(
                        template, generated, expected_job_title=wrong
                    )

    def test_grammatical_in_the_role_title_sentence_is_accepted(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace(
            "what I can do as a Data Analyst.",
            "what I can do in the Data Analyst role.",
        )
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data Analyst",
        )

    def test_a_latex_escaped_title_matches_the_clean_title(self) -> None:
        # "Data & Product Engineer" must be written as "Data \\& Product
        # Engineer" to compile, so the comparison has to see through escaping.
        template, generated = valid_cover()
        escaped = generated.replace("Data Analyst", "Data \\& Product Engineer")
        validate_generated_cover(
            template, escaped, expected_job_title="Data & Product Engineer"
        )
        # Shortening still works through the escaping.
        validate_generated_cover(
            template,
            generated.replace("Data Analyst", "Data \\& Product"),
            expected_job_title="Data & Product Engineer",
        )
        # A different title is still rejected.
        with self.assertRaisesRegex(ValueError, "deterministic clean title"):
            validate_generated_cover(
                template, escaped, expected_job_title="Data & Platform Engineer"
            )

    def test_spaced_gender_marker_is_rejected_from_cover_title(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("Data Analyst", "Data Analyst (x m d)")
        with self.assertRaisesRegex(ValueError, "logistics or unearned seniority"):
            validate_generated_cover(template, generated)

    def test_blocked_claims_em_dash_and_unescaped_latex_are_rejected(self) -> None:
        for old, new, expected in (
            ("data analysis", "big data processing", "blocked claims"),
            ("data analysis", "MLOps work", "blocked claims"),
            ("data analysis", "data—analysis", "em dash"),
            ("Acme GmbH", "Acme & Partners", "unescaped LaTeX"),
        ):
            with self.subTest(new=new):
                template, generated = valid_cover()
                generated = generated.replace(old, new)
                with self.assertRaisesRegex(ValueError, expected):
                    validate_generated_cover(template, generated)

    def test_dashboard_and_bi_wording_is_allowed(self) -> None:
        # Power BI is in the skills inventory, and a posting may be about
        # dashboard work; the wording is no longer a blocked claim.
        template, generated = valid_cover()
        generated = generated.replace("data analysis", "dashboard and BI reporting")
        validate_generated_cover(template, generated)

    def test_posting_proper_nouns_are_exempt_from_claim_and_style_scans(self) -> None:
        # A role name is quoted from the posting. "Data Visualization Analyst"
        # keeps its American spelling and "Big Data Engineer" is not a claim to
        # distributed experience, but the same words in prose still fail.
        for role in ("Data Visualization Analyst", "Big Data Engineer"):
            with self.subTest(role=role):
                template, generated = valid_cover()
                titled = generated.replace("Data Analyst", role)
                validate_generated_cover(
                    template, titled, expected_job_title=role
                )

        template, generated = valid_cover()
        in_prose = generated.replace(
            "I built an inflation workflow", "I built big data visualization work"
        )
        with self.assertRaises(ValueError):
            validate_generated_cover(template, in_prose)


if __name__ == "__main__":
    unittest.main()
