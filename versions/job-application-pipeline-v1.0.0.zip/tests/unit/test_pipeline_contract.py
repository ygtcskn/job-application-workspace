from __future__ import annotations

import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from tests.support import ROOT, valid_cover, valid_cv

from job_application_pipeline import __main__ as cli
from job_application_pipeline.cv_quality import Severity
from job_application_pipeline.pipeline import (
    EFFORT_LEVELS,
    ApplicationPipeline,
    PipelineError,
    _default_resolver,
    _Heartbeat,
    format_duration,
    validate_effort,
    validate_model,
)
from job_application_pipeline.paths import Paths


class PipelineContractTests(unittest.TestCase):
    def test_only_claude_and_codex_are_provider_choices(self) -> None:
        pipeline = ApplicationPipeline(Paths())
        for invalid in ("openai", "auto", "gpt", ""):
            with self.subTest(provider=invalid):
                with self.assertRaisesRegex(ValueError, "claude.*codex"):
                    pipeline.run(invalid)  # type: ignore[arg-type]

    def test_claude_command_runs_through_injected_subprocess(self) -> None:
        self._assert_provider_command("claude")

    def test_codex_command_runs_through_injected_subprocess(self) -> None:
        self._assert_provider_command("codex")

    def test_claude_model_precedes_permission_flags(self) -> None:
        command = self._provider_command("claude", "claude-sonnet-4.5[1m]")
        model_index = command.index("--model")
        self.assertEqual(command[model_index + 1], "claude-sonnet-4.5[1m]")
        self.assertGreater(command.index("--permission-mode"), model_index)

    def test_codex_model_immediately_follows_exec(self) -> None:
        command = self._provider_command("codex", "openai/gpt-5.6_codex:v1")
        exec_index = command.index("exec")
        self.assertEqual(
            command[exec_index + 1 : exec_index + 3],
            ["--model", "openai/gpt-5.6_codex:v1"],
        )

    def test_omitted_model_does_not_add_model_flag(self) -> None:
        for provider in ("claude", "codex"):
            with self.subTest(provider=provider):
                self.assertNotIn("--model", self._provider_command(provider, None))

    def test_claude_effort_uses_the_dedicated_flag_after_the_model(self) -> None:
        command = self._provider_command("claude", "opus", "max")
        model_index = command.index("--model")
        self.assertEqual(
            command[model_index : model_index + 4],
            ["--model", "opus", "--effort", "max"],
        )
        self.assertGreater(command.index("--permission-mode"), command.index("--effort"))

    def test_codex_effort_uses_a_reasoning_config_override(self) -> None:
        command = self._provider_command("codex", "gpt-5.6-sol", "xhigh")
        exec_index = command.index("exec")
        self.assertEqual(
            command[exec_index + 1 : exec_index + 5],
            [
                "--model",
                "gpt-5.6-sol",
                "--config",
                'model_reasoning_effort="xhigh"',
            ],
        )
        self.assertGreater(command.index("--sandbox"), command.index("--config"))

    def test_effort_is_independent_of_model_selection(self) -> None:
        claude = self._provider_command("claude", None, "high")
        self.assertNotIn("--model", claude)
        effort_index = claude.index("--effort")
        self.assertEqual(claude[effort_index + 1], "high")

        codex = self._provider_command("codex", None, "high")
        self.assertNotIn("--model", codex)
        exec_index = codex.index("exec")
        self.assertEqual(
            codex[exec_index + 1 : exec_index + 3],
            ["--config", 'model_reasoning_effort="high"'],
        )

    def test_omitted_effort_does_not_add_effort_arguments(self) -> None:
        for provider in ("claude", "codex"):
            with self.subTest(provider=provider):
                command = self._provider_command(provider, "some-model", None)
                self.assertNotIn("--effort", command)
                self.assertFalse(
                    [item for item in command if "model_reasoning_effort" in item]
                )

    def test_effort_levels_are_validated_per_provider(self) -> None:
        for provider, levels in EFFORT_LEVELS.items():
            for level in levels:
                with self.subTest(provider=provider, effort=level):
                    self.assertEqual(validate_effort(provider, level), level)
            with self.subTest(provider=provider):
                self.assertIsNone(validate_effort(provider, None))

        # The two vocabularies overlap but are not interchangeable.
        self.assertEqual(validate_effort("claude", "max"), "max")
        self.assertEqual(validate_effort("codex", "minimal"), "minimal")
        with self.assertRaisesRegex(ValueError, "codex"):
            validate_effort("codex", "max")
        with self.assertRaisesRegex(ValueError, "claude"):
            validate_effort("claude", "minimal")

        for invalid in ("", "   ", "ultra", "high effort", "-high", "1"):
            with self.subTest(effort=repr(invalid)):
                with self.assertRaises(ValueError):
                    validate_effort("claude", invalid)

    def test_effort_case_and_padding_are_normalised(self) -> None:
        self.assertEqual(validate_effort("claude", "  XHigh "), "xhigh")
        command = self._provider_command("claude", None, "MAX")
        self.assertEqual(command[command.index("--effort") + 1], "max")

    def test_invalid_effort_is_rejected_before_layout_or_executable_checks(self) -> None:
        lookups: list[str] = []
        pipeline = ApplicationPipeline(
            Paths(), executable_resolver=lambda name: lookups.append(name) or name
        )
        with self.assertRaisesRegex(ValueError, "effort"):
            pipeline.run("codex", None, "max")
        self.assertEqual(lookups, [])

    @unittest.skipUnless(os.name == "nt", "PATHEXT resolution is Windows-specific")
    def test_resolver_prefers_a_launchable_variant_over_an_extensionless_shim(
        self,
    ) -> None:
        # npm installs a "#!/bin/sh" shim beside claude.cmd. CreateProcess
        # cannot start it, and only some Python versions skip it on their own.
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            (directory / "fakecli").write_text("#!/bin/sh\n", encoding="utf-8")
            (directory / "fakecli.cmd").write_text("@echo off\n", encoding="utf-8")
            (directory / "onlyshim").write_text("#!/bin/sh\n", encoding="utf-8")
            (directory / "realtool.exe").write_bytes(b"MZ")
            environment = {"PATH": str(directory), "PATHEXT": ".COM;.EXE;.BAT;.CMD"}

            with patch.dict(os.environ, environment):
                shimmed = _default_resolver("fakecli")
                already_launchable = _default_resolver("realtool")
                explicit_suffix = _default_resolver("fakecli.cmd")
                without_sibling = _default_resolver("onlyshim")
                missing = _default_resolver("no-such-executable-here")

        self.assertIsNotNone(shimmed)
        self.assertEqual(Path(shimmed).name.casefold(), "fakecli.cmd")
        self.assertIsNotNone(already_launchable)
        self.assertEqual(Path(already_launchable).name.casefold(), "realtool.exe")
        self.assertIsNotNone(explicit_suffix)
        self.assertEqual(Path(explicit_suffix).name.casefold(), "fakecli.cmd")
        # Nothing launchable exists under either name, so both report as
        # missing and the caller raises its actionable "not found" error
        # instead of failing later with WinError 193.
        self.assertIsNone(without_sibling)
        self.assertIsNone(missing)

    def test_duration_formatting_is_compact_at_every_scale(self) -> None:
        self.assertEqual(format_duration(0), "0s")
        self.assertEqual(format_duration(9.7), "9s")
        self.assertEqual(format_duration(65), "1m 05s")
        self.assertEqual(format_duration(3725), "1h 02m 05s")
        self.assertEqual(format_duration(-5), "0s")

    def test_heartbeat_reports_until_the_step_finishes(self) -> None:
        lines: list[str] = []
        with _Heartbeat(lines.append, "claude", interval=0.05) as heartbeat:
            deadline = time.monotonic() + 2.0
            while len(lines) < 2 and time.monotonic() < deadline:
                time.sleep(0.02)
            elapsed = heartbeat.elapsed

        self.assertGreaterEqual(len(lines), 2)
        for line in lines:
            self.assertIn("claude still running", line)
        self.assertGreater(elapsed, 0.0)

        # The thread must stop once the step is done, so a long run does not
        # accumulate reporters.
        settled = len(lines)
        time.sleep(0.2)
        self.assertEqual(len(lines), settled)

    def test_heartbeat_is_inert_without_a_reporter(self) -> None:
        with _Heartbeat(None, "codex", interval=0.01) as heartbeat:
            time.sleep(0.05)
            self.assertGreater(heartbeat.elapsed, 0.0)

    def test_provider_run_reports_completion_time(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = Paths(project_root=root / "job_py")
            lines: list[str] = []
            pipeline = ApplicationPipeline(paths, progress=lines.append)
            log = root / "provider.log"
            command_result = subprocess.CompletedProcess([], 0, stdout="done")

            with patch.object(
                pipeline, "_run_command", return_value=command_result
            ):
                pipeline._run_provider(  # noqa: SLF001
                    "claude",
                    root / "claude.exe",
                    root / "request.md",
                    root / "output",
                    log,
                    (),
                )
            logged = log.read_text(encoding="utf-8")

        self.assertTrue(any("claude finished in" in line for line in lines))
        self.assertEqual(logged, "done")

    def test_reporting_failure_never_aborts_the_run(self) -> None:
        def hostile(_message: str) -> None:
            raise RuntimeError("console gone")

        pipeline = ApplicationPipeline(Paths(), progress=hostile)
        pipeline._report("this must not raise")  # noqa: SLF001

    def test_both_providers_receive_a_narrow_web_lookup_capability(self) -> None:
        # The cover-letter rules allow looking up an employer address, which
        # neither CLI can do without being granted a tool.
        claude = self._provider_command("claude", "opus", "high")
        self.assertEqual(claude[1:3], ["--allowed-tools", "WebSearch,WebFetch"])
        # --allowed-tools is variadic: an option must follow its value, or the
        # prompt is consumed as another tool name and the CLI rejects the call.
        self.assertTrue(claude[3].startswith("-"))

        codex = self._provider_command("codex", "gpt-5.6-sol", "high")
        config_values = [
            codex[index + 1]
            for index, item in enumerate(codex)
            if item == "--config"
        ]
        self.assertIn("tools.web_search=true", config_values)
        # Sandbox network access stays closed; only the search tool is enabled.
        self.assertFalse([item for item in codex if "network_access" in item])

    def test_web_lookup_is_granted_even_without_model_or_effort(self) -> None:
        claude = self._provider_command("claude", None, None)
        self.assertEqual(claude[1:3], ["--allowed-tools", "WebSearch,WebFetch"])
        self.assertTrue(claude[3].startswith("-"))

        codex = self._provider_command("codex", None, None)
        self.assertIn("tools.web_search=true", codex)

    def test_model_identifier_validation(self) -> None:
        accepted = (
            "gpt-5.6",
            "provider/model:v1",
            "claude_opus-4.1[latest]",
            "a" * 256,
        )
        for model in accepted:
            with self.subTest(model=model):
                self.assertEqual(validate_model(model), model)
        self.assertIsNone(validate_model(None))

        rejected = (
            "",
            "-starts-like-an-option",
            "contains space",
            "contains\ttab",
            "contains\nnewline",
            "contains\x00control",
            "model@vendor",
            "a" * 257,
        )
        for model in rejected:
            with self.subTest(model=repr(model)):
                with self.assertRaises(ValueError):
                    validate_model(model)

    def test_python_cli_forwards_explicit_and_omitted_model(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(
                cli.main(["claude", "--model", "claude-sonnet-4.5"]),
                0,
            )
            pipeline_run.assert_called_once_with(
                "claude", "claude-sonnet-4.5", None, fresh=False, progress=cli.emit
            )

        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(["codex"]), 0)
            pipeline_run.assert_called_once_with(
                "codex", None, None, fresh=False, progress=cli.emit
            )

    def test_python_cli_forwards_explicit_and_omitted_effort(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(
                cli.main(["claude", "--model", "opus", "--effort", "max"]),
                0,
            )
            pipeline_run.assert_called_once_with(
                "claude", "opus", "max", fresh=False, progress=cli.emit
            )

        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(["codex", "--effort", "minimal"]), 0)
            pipeline_run.assert_called_once_with(
                "codex", None, "minimal", fresh=False, progress=cli.emit
            )

    def test_fresh_flag_is_forwarded(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(["claude", "--fresh"]), 0)
            pipeline_run.assert_called_once_with(
                "claude", None, None, fresh=True, progress=cli.emit
            )

    def test_powershell_runner_forwards_the_fresh_switch(self) -> None:
        script = (ROOT / "run.ps1").read_text(encoding="utf-8")
        self.assertIn("[switch] $Fresh", script)
        self.assertIn('$PipelineArguments += "--fresh"', script)

    def test_quiet_suppresses_progress_reporting(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(["claude", "--quiet"]), 0)
            pipeline_run.assert_called_once_with(
                "claude", None, None, fresh=False, progress=None
            )

    def test_progress_survives_a_console_that_cannot_encode_the_message(self) -> None:
        # A cp1252 console plus a job ad naming a Turkish company must not end
        # a multi-hour run.
        written: list[str] = []

        class NarrowStream:
            encoding = "cp1252"

            def write(self, text: str) -> int:
                text.encode("cp1252")  # raises for unsupported characters
                written.append(text)
                return len(text)

            def flush(self) -> None:
                return None

        with patch.object(cli.sys, "stdout", NarrowStream()):
            cli.emit("Eruygur Akademi ve Danışmanlık")

        self.assertEqual(len(written), 1)
        self.assertIn("Eruygur Akademi ve Dan", written[0])

    def test_python_cli_reports_an_unsupported_effort_without_running(self) -> None:
        self.assertEqual(cli.main(["codex", "--effort", "max"]), 1)

    def test_powershell_runner_forwards_model_only_when_explicitly_bound(self) -> None:
        script = (ROOT / "run.ps1").read_text(encoding="utf-8")
        self.assertIn('[string] $Model', script)
        self.assertIn('$PSBoundParameters.ContainsKey("Model")', script)
        self.assertIn('@("--model", $Model)', script)
        self.assertIn('& $PythonExe @PipelineArguments', script)

    def test_powershell_runner_forwards_effort_only_when_explicitly_bound(self) -> None:
        script = (ROOT / "run.ps1").read_text(encoding="utf-8")
        self.assertIn('[string] $Effort', script)
        self.assertIn('$PSBoundParameters.ContainsKey("Effort")', script)
        self.assertIn('@("--effort", $Effort)', script)
        # The wrapper validates the union; the provider pairing is enforced in Python.
        union = {level for levels in EFFORT_LEVELS.values() for level in levels}
        for level in sorted(union):
            with self.subTest(effort=level):
                self.assertIn(f'"{level}"', script)

    def test_invalid_model_is_rejected_before_layout_or_executable_checks(self) -> None:
        lookups: list[str] = []
        pipeline = ApplicationPipeline(
            Paths(), executable_resolver=lambda name: lookups.append(name) or name
        )
        with self.assertRaisesRegex(ValueError, "model"):
            pipeline.run("claude", "invalid model")
        self.assertEqual(lookups, [])

    @staticmethod
    def _provider_command(
        provider: str, model: str | None, effort: str | None = None
    ) -> list[str]:
        pipeline = ApplicationPipeline(Paths())
        return pipeline._provider_command(  # noqa: SLF001 - command contract
            provider,  # type: ignore[arg-type]
            Path(f"{provider}.exe"),
            Path("request.md"),
            Path("output"),
            model,
            effort,
        )

    def _assert_provider_command(self, provider: str) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = Paths(project_root=root / "job_py")
            pipeline = ApplicationPipeline(paths)
            executable = root / f"{provider}.exe"
            request = root / "request.md"
            output = root / "output"
            command = pipeline._provider_command(  # noqa: SLF001 - command contract
                provider, executable, request, output  # type: ignore[arg-type]
            )
            completed = subprocess.CompletedProcess(command, 0, stdout="ok")
            with patch(
                "job_application_pipeline.pipeline.subprocess.run",
                return_value=completed,
            ) as fake_subprocess:
                result = pipeline._run_command(command)  # noqa: SLF001

            self.assertEqual(result.returncode, 0)
            invoked = fake_subprocess.call_args.args[0]
            self.assertIn(str(executable), invoked)
            prompt = invoked[-1]
            self.assertIn(str(request.resolve()), prompt)
            self.assertIn(str(output.resolve()), prompt)
            self.assertIn("tailored_cv.tex", prompt)
            self.assertIn("cover_letter.tex", prompt)
            if provider == "claude":
                self.assertIn("--permission-mode", invoked)
                self.assertNotIn("exec", invoked)
            else:
                self.assertIn("exec", invoked)
                self.assertIn("--sandbox", invoked)

    def test_all_four_generation_outputs_are_required(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            template, generated_cv = valid_cv()
            _cover_template, generated_cover = valid_cover()
            del template
            (output / "tailored_cv.tex").write_text(generated_cv, encoding="utf-8")
            (output / "cover_letter.tex").write_text(generated_cover, encoding="utf-8")
            (output / "change_log.md").write_text("changes", encoding="utf-8")
            pipeline = ApplicationPipeline(Paths())

            with self.assertRaisesRegex(PipelineError, "match_notes.md"):
                pipeline._assert_fresh_outputs(output)  # noqa: SLF001

            (output / "match_notes.md").write_text("notes", encoding="utf-8")
            pipeline._assert_fresh_outputs(output)  # noqa: SLF001

    def test_cover_pdf_must_have_exactly_one_page(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            cover_pdf = Path(temporary) / "cover.pdf"
            cover_pdf.write_bytes(b"PDF fixture")
            pipeline = ApplicationPipeline(Paths())

            one_page = _FakeInspectedPdf(page_count=1)
            with patch.dict(
                "sys.modules",
                {"fitz": SimpleNamespace(open=lambda _path: one_page)},
            ):
                pipeline._assert_one_page(cover_pdf)  # noqa: SLF001
            self.assertTrue(one_page.closed)

            two_pages = _FakeInspectedPdf(page_count=2)
            with patch.dict(
                "sys.modules",
                {"fitz": SimpleNamespace(open=lambda _path: two_pages)},
            ):
                with self.assertRaisesRegex(PipelineError, "exactly one page; got 2"):
                    pipeline._assert_one_page(cover_pdf)  # noqa: SLF001
            self.assertTrue(two_pages.closed)

    def test_cover_postcompile_checks_pdf_text_and_overfull_layout(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cover_pdf = root / "cover.pdf"
            cover_pdf.write_bytes(b"PDF fixture")
            log = root / "cover.log"
            pipeline = ApplicationPipeline(Paths())

            log.write_text("clean LaTeX log\n", encoding="utf-8")
            clean_pdf = _FakeTextPdf("Dear Hiring Team,\nKind regards,\nYigit Coskun")
            with patch.dict(
                "sys.modules", {"fitz": SimpleNamespace(open=lambda _path: clean_pdf)}
            ):
                clean = pipeline._cover_postcompile_findings(  # noqa: SLF001
                    cover_pdf=cover_pdf, log_path=log
                )
            self.assertTrue(clean_pdf.closed)
            self.assertEqual([finding.severity for finding in clean], [Severity.PASS, Severity.PASS])

            log.write_text("Overfull \\hbox (4.0pt too wide)\n", encoding="utf-8")
            bad_pdf = _FakeTextPdf("body without the required closing")
            with patch.dict(
                "sys.modules", {"fitz": SimpleNamespace(open=lambda _path: bad_pdf)}
            ):
                bad = pipeline._cover_postcompile_findings(  # noqa: SLF001
                    cover_pdf=cover_pdf, log_path=log
                )
            self.assertEqual([finding.severity for finding in bad], [Severity.ERROR, Severity.ERROR])


class _FakeInspectedPdf:
    def __init__(self, *, page_count: int) -> None:
        self.page_count = page_count
        self.closed = False

    def close(self) -> None:
        self.closed = True


class _FakeTextPage:
    def __init__(self, text: str) -> None:
        self.text = text

    def get_text(self, mode: str, *, sort: bool) -> str:
        if mode != "text" or not sort:
            raise AssertionError("cover PDF extraction must request sorted text")
        return self.text


class _FakeTextPdf:
    def __init__(self, text: str) -> None:
        self.pages = (_FakeTextPage(text),)
        self.closed = False

    def __iter__(self):
        return iter(self.pages)

    def close(self) -> None:
        self.closed = True


if __name__ == "__main__":
    unittest.main()
