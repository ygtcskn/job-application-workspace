from __future__ import annotations

import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch

from tests.support import write_docx

from job_application_pipeline.documents import extract_docx_text, extract_pdf_text


class DocumentExtractionTests(unittest.TestCase):
    def test_docx_paragraphs_and_table_are_extracted_in_document_order(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "source.docx"
            write_docx(
                path,
                paragraphs=["First paragraph", "Second paragraph"],
                table=[["A1", "B1"], ["A2", "B2"]],
            )

            self.assertEqual(
                extract_docx_text(path),
                "First paragraph\nSecond paragraph\nA1 | B1\nA2 | B2",
            )

    def test_invalid_docx_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bad.docx"
            path.write_bytes(b"not a Word package")
            with self.assertRaisesRegex(ValueError, "valid DOCX"):
                extract_docx_text(path)

    def test_pdf_pages_are_extracted_with_page_boundaries(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "job.pdf"
            path.write_bytes(b"synthetic PDF fixture")
            pages = [
                SimpleNamespace(get_text=lambda _mode: "First page role"),
                SimpleNamespace(get_text=lambda _mode: "Second page requirements"),
            ]
            document = _FakePdfDocument(pages)

            with patch.dict("sys.modules", {"fitz": SimpleNamespace(open=lambda _path: document)}):
                extracted = extract_pdf_text(path)
            self.assertIn("--- Page 1 ---\nFirst page role", extracted)
            self.assertIn("--- Page 2 ---\nSecond page requirements", extracted)
            self.assertTrue(document.closed)

    def test_image_only_pdf_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "image-only.pdf"
            path.write_bytes(b"synthetic image-only PDF fixture")
            document = _FakePdfDocument([SimpleNamespace(get_text=lambda _mode: "")])
            with patch.dict("sys.modules", {"fitz": SimpleNamespace(open=lambda _path: document)}):
                with self.assertRaisesRegex(ValueError, "image-only"):
                    extract_pdf_text(path)
            self.assertTrue(document.closed)


class _FakePdfDocument:
    def __init__(self, pages: list[object]) -> None:
        self.pages = pages
        self.closed = False

    def __iter__(self):
        return iter(self.pages)

    def close(self) -> None:
        self.closed = True


if __name__ == "__main__":
    unittest.main()
