"""Tests for the job-application pipeline."""

