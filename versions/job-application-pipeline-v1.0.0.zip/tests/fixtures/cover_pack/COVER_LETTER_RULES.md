# Approved test-only cover-letter rules

Write one concise English page. Use only facts from the approved CV bullet and
skills sources. Preserve every character outside the seven editable regions.
