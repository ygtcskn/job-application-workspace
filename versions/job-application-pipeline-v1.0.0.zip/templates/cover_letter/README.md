# Cover-letter template

The approved English template is:

```text
yigit_coskun_cover_letter.tex
```

It retains seven ordered edit regions: `COVER_HEADER`, `SALUTATION`,
`PARA_1_HOOK_THESIS`, `PARA_2_IAB`, `PARA_3_FIT`, `PARA_4_MOTIVATION`, and
`PARA_5_CLOSE`.
