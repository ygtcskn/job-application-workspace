"""End-to-end CV and cover-letter generation pipeline."""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import threading
import time
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, NoReturn

from .cv_quality import (
    SCHEMA_VERSION,
    VALIDATOR_VERSION,
    QualityFinding,
    QualityReport,
    Severity,
    validate_cv_quality,
    write_quality_reports,
)
from .documents import (
    extract_docx_text,
    extract_pdf_text,
    read_text,
    sha256_bundle,
    sha256_file,
)
from .paths import PipelinePaths
from .request_builder import build_request, extract_clean_job_title
from .validation import validate_generated_cover, validate_generated_cv


Provider = Literal["claude", "codex"]
ExecutableResolver = Callable[[str], str | os.PathLike[str] | None]
ProgressReporter = Callable[[str], None]
# A provider call is silent for minutes, so report that it is still alive.
PROVIDER_HEARTBEAT_SECONDS = 30.0
MAX_AI_REPAIR_ATTEMPTS = 2
# General repairs are intentionally capped, but compilation can expose a cover-
# letter-only defect after those attempts have already fixed the CV. Keep one
# separate, bounded slot for that late validation stage.
MAX_COVER_POSTCOMPILE_REPAIR_ATTEMPTS = 1
_COVER_FONT_SIZE_TOLERANCE_PT = 0.05
_COVER_PAGE_SIZE_TOLERANCE_PT = 0.5
_PDF_FONT_SUBSET_PREFIX_RE = re.compile(r"^[A-Z]{6}\+", re.IGNORECASE)
# Windows can keep a just-closed provider/build directory handle alive briefly.
# Retry only the sharing-violation code, for less than one second in total.
_ARTIFACT_CLEANUP_RETRY_DELAYS_SECONDS = (0.05, 0.1, 0.2, 0.4)
_WINDOWS_SHARING_VIOLATION = 32
_MODEL_RE = re.compile(r"[A-Za-z0-9._:/\-\[\]]+")
_NUMBERED_JOB_AD_RE = re.compile(r"job_description_(\d+)\.pdf", re.IGNORECASE)

# Each CLI accepts its own closed set of reasoning-effort levels. They overlap
# but are not identical, so the level is checked against the selected provider
# before any job ad is processed.
EFFORT_LEVELS: Mapping[Provider, tuple[str, ...]] = {
    "claude": ("low", "medium", "high", "xhigh", "max"),
    "codex": ("minimal", "low", "medium", "high", "xhigh"),
}
_CODEX_EFFORT_KEY = "model_reasoning_effort"
# Web access is granted narrowly so the cover letter can carry a real employer
# address. Claude takes a tool allowlist; Codex enables its own search tool
# rather than opening sandbox network access to every command it runs.
_CLAUDE_WEB_TOOLS = "WebSearch,WebFetch"
_CODEX_WEB_SEARCH = "tools.web_search=true"

GENERATED_FILES = (
    "tailored_cv.tex",
    "cover_letter.tex",
    "change_log.md",
    "match_notes.md",
)
CV_PDF_NAME = "yigit_coskun_CV.pdf"
COVER_PDF_NAME = "yigit_coskun_cover_letter.pdf"
VALIDATION_JSON_NAME = "validation.json"
VALIDATION_XLSX_NAME = "validation.xlsx"
VALIDATION_FAILURE_MARKER_NAME = "validation.failure.txt"

_FRESH_MANIFEST_COLUMNS = (
    "JobIndex",
    "JobLabel",
    "JobFile",
    "JobHash",
    "SourceHash",
    "Mode",
    "DocumentNumber",
    "OutputFolder",
    "CvLabel",
    "ClLabel",
    "CvFile",
    "ClFile",
    "Status",
    "Result",
    "Date",
    "Provider",
    "Model",
    "Effort",
    "CompletedAt",
)


class PipelineError(RuntimeError):
    """A user-actionable pipeline failure."""


class _RepairableValidationError(PipelineError):
    """A generated-document failure that the selected provider may repair."""

    def __init__(
        self,
        message: str,
        *,
        report: QualityReport,
        artifact_dir: Path,
        job_ad: Path,
    ) -> None:
        super().__init__(message)
        self.report = report
        self.artifact_dir = artifact_dir.resolve()
        self.job_ad = job_ad.resolve()


@dataclass(frozen=True, slots=True)
class JobResult:
    job_ad: Path
    document_number: int
    archive_dir: Path


@dataclass(frozen=True, slots=True)
class RunSummary:
    provider: Provider
    processed: tuple[JobResult, ...]
    skipped: tuple[Path, ...]


@dataclass(frozen=True, slots=True)
class _Snapshot:
    path: Path
    content: bytes
    mode: int
    atime_ns: int
    mtime_ns: int


@dataclass(slots=True)
class _Manifest:
    fieldnames: list[str]
    rows: list[dict[str, str]]


@dataclass(frozen=True, slots=True)
class _CvQualityInputs:
    job_description: str
    clean_job_title: str
    cv_rules: str
    bullet_library: str
    skills_profiles: str
    hashes: Mapping[str, str]


def _pathext_suffixes() -> tuple[str, ...]:
    raw = os.environ.get("PATHEXT") or ".COM;.EXE;.BAT;.CMD"
    return tuple(
        suffix.casefold()
        for suffix in (entry.strip() for entry in raw.split(os.pathsep))
        if suffix.startswith(".")
    )


def _default_resolver(name: str) -> str | None:
    if os.name != "nt":
        return shutil.which(name)

    # npm installs an extensionless POSIX shim ("#!/bin/sh") beside claude.cmd.
    # Python 3.12.0 resolves that shim, which CreateProcess cannot start
    # (WinError 193); later versions skip it. Prefer a PATHEXT variant here so
    # the result does not depend on the interpreter that runs the pipeline.
    suffixes = _pathext_suffixes()
    if Path(name).suffix.casefold() in suffixes:
        return shutil.which(name)

    found = shutil.which(name)
    if found is not None:
        candidate = Path(found)
        if candidate.suffix.casefold() in suffixes:
            return found
        # The directory holding the shim already won the PATH search, so a
        # launchable sibling there outranks a match further along PATH.
        for suffix in suffixes:
            sibling = candidate.with_name(candidate.name + suffix)
            if sibling.is_file():
                return str(sibling)
    for suffix in suffixes:
        located = shutil.which(name + suffix)
        if located:
            return located
    # Any remaining match cannot be started, so report the executable as
    # missing and let the caller raise its actionable "not found" error.
    return None


def _snapshot_files(paths: Sequence[Path]) -> tuple[_Snapshot, ...]:
    snapshots: list[_Snapshot] = []
    for path in paths:
        path = Path(path).resolve()
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"Protected source file was not found: {path}")
        metadata = path.stat()
        snapshots.append(
            _Snapshot(
                path=path,
                content=path.read_bytes(),
                mode=stat.S_IMODE(metadata.st_mode),
                atime_ns=metadata.st_atime_ns,
                mtime_ns=metadata.st_mtime_ns,
            )
        )
    return tuple(snapshots)


def _restore_modified_files(snapshots: Sequence[_Snapshot]) -> list[Path]:
    """Restore changed/deleted protected files and return the changed paths."""

    changed: list[Path] = []
    for snapshot in snapshots:
        try:
            metadata = snapshot.path.stat()
            unchanged = (
                snapshot.path.is_file()
                and not snapshot.path.is_symlink()
                and snapshot.path.read_bytes() == snapshot.content
                and stat.S_IMODE(metadata.st_mode) == snapshot.mode
                and metadata.st_mtime_ns == snapshot.mtime_ns
            )
        except OSError:
            unchanged = False
        if unchanged:
            continue

        changed.append(snapshot.path)
        snapshot.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = snapshot.path.with_name(
            f".{snapshot.path.name}.{uuid.uuid4().hex}.restore"
        )
        try:
            temporary.write_bytes(snapshot.content)
            if snapshot.path.is_symlink():
                snapshot.path.unlink()
            elif snapshot.path.exists():
                if snapshot.path.is_dir():
                    shutil.rmtree(snapshot.path)
                else:
                    # Windows refuses to replace or unlink a read-only target.
                    # The original mode is restored immediately after replacement.
                    os.chmod(snapshot.path, stat.S_IWRITE)
                    snapshot.path.unlink()
            os.replace(temporary, snapshot.path)
            os.chmod(snapshot.path, snapshot.mode)
            os.utime(snapshot.path, ns=(snapshot.atime_ns, snapshot.mtime_ns))
        finally:
            if temporary.exists():
                temporary.unlink()
    return changed


def _is_nonempty_file(path: Path) -> bool:
    try:
        return path.is_file() and path.stat().st_size > 0
    except OSError:
        return False


def _tail(text: str, limit: int = 3000) -> str:
    text = text.strip()
    return text if len(text) <= limit else text[-limit:]


def format_duration(seconds: float) -> str:
    """Render an elapsed span as a compact, human-readable duration."""

    seconds = max(0.0, float(seconds))
    minutes, remainder = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {remainder:02d}s"
    if minutes:
        return f"{minutes}m {remainder:02d}s"
    return f"{remainder}s"


class _Heartbeat:
    """Report that a long, silent step is still running.

    ``claude --print`` emits nothing until it finishes, so without this the
    console cannot distinguish a working provider from a hung one.
    """

    def __init__(
        self,
        report: ProgressReporter | None,
        message: str,
        interval: float = PROVIDER_HEARTBEAT_SECONDS,
    ) -> None:
        self._report = report
        self._message = message
        self._interval = interval
        self._stop = threading.Event()
        self._started = time.monotonic()
        self._thread = threading.Thread(target=self._tick, daemon=True)

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self._started

    def _tick(self) -> None:
        while not self._stop.wait(self._interval):
            if self._report is not None:
                self._report(
                    f"      {self._message} still running "
                    f"({format_duration(self.elapsed)})"
                )

    def __enter__(self) -> "_Heartbeat":
        self._started = time.monotonic()
        if self._report is not None and self._interval > 0:
            self._thread.start()
        return self

    def __exit__(self, *exception: object) -> bool:
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=1.0)
        return False


def validate_model(model: str | None) -> str | None:
    """Validate an optional provider model identifier without rewriting it."""

    if model is None:
        return None
    if not isinstance(model, str):
        raise ValueError("model must be a string when supplied.")
    if not model:
        raise ValueError("model cannot be empty.")
    if len(model) > 256:
        raise ValueError("model cannot exceed 256 characters.")
    if model.startswith("-"):
        raise ValueError("model cannot start with '-'.")
    if _MODEL_RE.fullmatch(model) is None:
        raise ValueError(
            "model may contain only letters, digits, '.', '_', ':', '/', '-', "
            "'[' and ']', with no whitespace or control characters."
        )
    return model


def validate_effort(provider: Provider, effort: str | None) -> str | None:
    """Validate an optional reasoning-effort level for the selected provider.

    Surrounding whitespace and letter case are normalised because each CLI
    accepts a fixed lowercase vocabulary. Unlike model identifiers, the level
    is checked against a closed set so a typo fails before any provider run.
    """

    if effort is None:
        return None
    if not isinstance(effort, str):
        raise ValueError("effort must be a string when supplied.")
    allowed = EFFORT_LEVELS.get(provider)
    if allowed is None:
        raise ValueError("provider must be either 'claude' or 'codex'.")
    normalised = effort.strip().casefold()
    if not normalised:
        raise ValueError("effort cannot be empty.")
    if normalised not in allowed:
        raise ValueError(
            f"effort for {provider} must be one of: {', '.join(allowed)}. "
            f"Received {effort!r}."
        )
    return normalised


class ApplicationPipeline:
    """Generate, validate, compile, archive, and checkpoint applications."""

    def __init__(
        self,
        paths: PipelinePaths | None = None,
        *,
        executable_resolver: ExecutableResolver | None = None,
        env: Mapping[str, str] | None = None,
        progress: ProgressReporter | None = None,
    ) -> None:
        self.paths = paths or PipelinePaths()
        self._resolve_executable = executable_resolver or _default_resolver
        self._progress = progress
        self._env = os.environ.copy()
        if env is not None:
            self._env.update({str(key): str(value) for key, value in env.items()})
        self._max_repair_attempts = MAX_AI_REPAIR_ATTEMPTS
        self._repair_findings: dict[Path, list[QualityFinding]] = {}
        self._active_job_pdf: Path | None = None
        self._session_processed: list[JobResult] | None = None

    def run(
        self,
        provider: Provider,
        model: str | None = None,
        effort: str | None = None,
        *,
        fresh: bool = False,
    ) -> RunSummary:
        """Run the batch, automatically repairing generated validation failures."""

        if provider not in {"claude", "codex"}:
            raise ValueError("provider must be either 'claude' or 'codex'.")
        model = validate_model(model)
        effort = validate_effort(provider, effort)
        self._repair_findings = {}
        self._session_processed = []
        attempts: dict[Path, int] = {}
        reserved_cover_attempts: dict[Path, int] = {}
        retry_fresh = fresh
        try:
            while True:
                try:
                    summary = self._run_once(
                        provider,
                        model,
                        effort,
                        fresh=retry_fresh,
                    )
                except _RepairableValidationError as failure:
                    artifact_key = failure.artifact_dir.resolve()
                    attempt = attempts.get(artifact_key, 0) + 1
                    general_limit = max(0, self._max_repair_attempts)
                    # Setting the general budget to zero is the explicit test /
                    # caller opt-out for every automatic provider invocation.
                    reserved_limit = (
                        MAX_COVER_POSTCOMPILE_REPAIR_ATTEMPTS
                        if general_limit > 0
                        else 0
                    )
                    is_cover_postcompile = self._is_cover_postcompile_failure(failure)
                    uses_reserved_cover_slot = attempt > general_limit
                    reserved_used = reserved_cover_attempts.get(artifact_key, 0)
                    can_use_reserved_cover_slot = (
                        uses_reserved_cover_slot
                        and is_cover_postcompile
                        and reserved_used < reserved_limit
                    )
                    if general_limit <= 0:
                        raise
                    if uses_reserved_cover_slot and not can_use_reserved_cover_slot:
                        attempts_used = attempts.get(artifact_key, 0)
                        report = self._with_repair_history(
                            failure.report,
                            failure.artifact_dir,
                        ).with_findings(
                            QualityFinding(
                                check_id="AI_REPAIR_EXHAUSTED",
                                rule_ids=(),
                                category="ai-repair",
                                severity=Severity.ERROR,
                                message=(
                                    "Automatic repair stopped after "
                                    f"{attempts_used} unsuccessful attempt(s)."
                                ),
                                evidence={
                                    "attempt": attempts_used,
                                    "attempts": attempts_used,
                                    "general_attempt_limit": general_limit,
                                    "cover_postcompile_reserved_limit": reserved_limit,
                                    "cover_postcompile_reserved_used": reserved_used,
                                    "trigger_checks": [
                                        finding.check_id
                                        for finding in failure.report.findings
                                        if finding.severity is Severity.ERROR
                                    ],
                                },
                            )
                        )
                        self._write_cv_quality_reports(report, failure.artifact_dir)
                        remaining = ", ".join(
                            finding.check_id
                            for finding in failure.report.findings
                            if finding.severity is Severity.ERROR
                        )
                        raise PipelineError(
                            "Application validation still failed after "
                            f"{attempts_used} automatic repair attempt(s)"
                            + (f"; remaining checks: {remaining}. " if remaining else ". ")
                            + self._cv_quality_report_hint(failure.artifact_dir)
                        ) from failure

                    attempts[artifact_key] = attempt
                    repair_scope = "general"
                    attempt_limit = general_limit
                    if can_use_reserved_cover_slot:
                        reserved_used += 1
                        reserved_cover_attempts[artifact_key] = reserved_used
                        repair_scope = "cover-postcompile-reserved"
                        attempt_limit = general_limit + reserved_limit
                    self._report("")
                    self._report(
                        f"   validation failed; asking {provider} to repair the "
                        f"generated files (attempt {attempt}/"
                        f"{attempt_limit}"
                        + (
                            "; reserved cover-letter postcompile repair"
                            if can_use_reserved_cover_slot
                            else ""
                        )
                        + ")"
                    )
                    self._attempt_ai_repair(
                        provider=provider,
                        model=model,
                        effort=effort,
                        failure=failure,
                        attempt=attempt,
                        repair_scope=repair_scope,
                    )
                    # A retry must preserve the provider's repaired files even
                    # when the original invocation used -Fresh.
                    retry_fresh = False
                    continue

                processed = tuple(self._session_processed)
                processed_ads = {result.job_ad.resolve() for result in processed}
                skipped = tuple(
                    job_ad
                    for job_ad in summary.skipped
                    if job_ad.resolve() not in processed_ads
                )
                return RunSummary(
                    provider=summary.provider,
                    processed=processed,
                    skipped=skipped,
                )
        finally:
            self._active_job_pdf = None
            self._session_processed = None

    def _run_once(
        self,
        provider: Provider,
        model: str | None = None,
        effort: str | None = None,
        *,
        fresh: bool = False,
    ) -> RunSummary:
        """Run all unprocessed sibling ``Job_ad/*.pdf`` files."""

        if provider not in {"claude", "codex"}:
            raise ValueError("provider must be either 'claude' or 'codex'.")
        model = validate_model(model)
        effort = validate_effort(provider, effort)

        self._validate_layout()
        jobs = self._job_ads()
        if not jobs:
            raise PipelineError(f"No PDF job advertisements found in {self.paths.job_ads_dir}")

        source_hash = sha256_bundle(
            self._locked_source_paths(), base=self.paths.project_root
        )
        manifest = self._load_manifest()
        job_items = [
            (index, job_pdf, sha256_file(job_pdf))
            for index, job_pdf in enumerate(jobs, start=1)
        ]
        skipped = [
            job_pdf
            for _, job_pdf, job_hash in job_items
            if self._is_already_done(manifest, job_pdf, job_hash, source_hash)
        ]
        pending = [
            item
            for item in job_items
            if not self._is_already_done(manifest, item[1], item[2], source_hash)
        ]
        # A successful archive can outlive a Windows directory handle held by
        # an editor or terminal. Numbered jobs are authoritative by archive, so
        # use later runs to remove any artifact directory whose earlier
        # post-commit cleanup had to be deferred.
        self._cleanup_artifacts_for_skipped_numbered_jobs(skipped)
        if not pending:
            self._report(
                f"Nothing to do: all {len(jobs)} job ad(s) already have a "
                "complete application for the current sources."
            )
            return RunSummary(provider=provider, processed=(), skipped=tuple(skipped))

        selection = ", ".join(
            part
            for part in (
                f"model={model}" if model else "model=CLI default",
                f"effort={effort}" if effort else "effort=CLI default",
            )
        )
        self._report(
            f"{len(jobs)} job ad(s) found: {len(pending)} to process, "
            f"{len(skipped)} already complete."
        )
        self._report(f"Provider: {provider} ({selection})")
        provider_executable = self._require_executable(provider)
        pdflatex_executable = self._require_executable("pdflatex")
        self._report(f"Using {provider_executable}")
        self._report(f"Using {pdflatex_executable}")
        next_number = self._next_document_number(manifest)
        processed: list[JobResult] = []
        run_started = time.monotonic()
        total_pending = len(pending)

        for job_index, job_pdf, job_hash in pending:
            self._active_job_pdf = job_pdf
            # A previous item in this same run may have had identical bytes.
            # Recheck the updated in-memory manifest before allocating a number.
            if self._is_already_done(manifest, job_pdf, job_hash, source_hash):
                skipped.append(job_pdf)
                self._report(
                    f"   skipping {job_pdf.name}: already completed in this run"
                )
                continue
            # job_description_117.pdf always becomes CVs/job_117, however
            # often it is regenerated. Only a legacy company-named ad, which
            # carries no number, falls back to the running counter.
            numbered = _NUMBERED_JOB_AD_RE.fullmatch(job_pdf.name)
            document_number = (
                int(numbered.group(1)) if numbered else next_number
            )
            next_number = max(next_number, document_number + 1)
            position = len(processed) + 1
            job_started = time.monotonic()
            self._report("")
            self._report(
                f"[{position}/{total_pending}] {job_pdf.name} -> job_{document_number}"
            )
            quality_inputs = self._load_cv_quality_inputs(
                job_pdf=job_pdf,
                job_hash=job_hash,
                source_hash=source_hash,
            )
            artifact_dir = Path(self.paths.artifacts_dir).resolve() / f"job_{document_number}"
            output_dir = artifact_dir / "output"
            request_text = build_request(self.paths, job_pdf, output_dir)
            provider_log = artifact_dir / "provider.log"
            request_path = artifact_dir / "request.md"

            reused = not fresh and self._reusable_provider_output(
                artifact_dir, request_text
            )
            if reused:
                self._report(
                    f"   1/6 reusing the provider output already in {artifact_dir}"
                )
                self._report(
                    f"   2/6 skipping {provider}; its four files match the current "
                    "request"
                )
                if not provider_log.is_file():
                    provider_log.write_text(
                        "Reused from an earlier run; no provider log was retained.\n",
                        encoding="utf-8",
                        newline="\n",
                    )
            else:
                artifact_dir = self._recreate_artifact_dir(document_number)
                output_dir = artifact_dir / "output"
                output_dir.mkdir()
                request_path = artifact_dir / "request.md"
                provider_log = artifact_dir / "provider.log"
                request_path.write_text(
                    request_text,
                    encoding="utf-8",
                    newline="\n",
                )
                self._report(
                    f"   1/6 request built ({request_path.stat().st_size // 1024} KB)"
                )

                protected = _snapshot_files((*self._locked_source_paths(), job_pdf))
                self._report(
                    f"   2/6 running {provider}; output is captured, so this step is "
                    "silent until it finishes"
                )
                self._run_provider(
                    provider,
                    provider_executable,
                    request_path,
                    output_dir,
                    provider_log,
                    protected,
                    model=model,
                    effort=effort,
                )
            try:
                self._assert_fresh_outputs(output_dir)
            except PipelineError as error:
                failure_report = self._failure_quality_report(
                    check_id="PROVIDER_OUTPUT_CONTRACT",
                    category="provider",
                    message=str(error),
                    provider=provider,
                    model=model,
                    effort=effort,
                    hashes=quality_inputs.hashes,
                )
                self._raise_reported_failure(
                    error=error,
                    report=failure_report,
                    artifact_dir=artifact_dir,
                    repairable=True,
                )

            self._report(
                "   3/6 "
                + ("retained" if reused else "provider returned")
                + " all four files; validating LaTeX"
            )
            cv_tex = output_dir / "tailored_cv.tex"
            quality_report = self._run_cv_quality(
                tex_path=cv_tex,
                artifact_dir=artifact_dir,
                inputs=quality_inputs,
                provider=provider,
                model=model,
                effort=effort,
            )
            contract_findings = self._document_contract_findings(
                output_dir,
                expected_job_title=quality_inputs.clean_job_title,
            )
            quality_report = quality_report.with_findings(*contract_findings)
            contract_errors = [
                finding for finding in contract_findings if finding.severity is Severity.ERROR
            ]
            if contract_errors:
                error = PipelineError(
                    "Generated LaTeX validation failed: "
                    + "; ".join(finding.message for finding in contract_errors)
                )
                self._raise_reported_failure(
                    error=error,
                    report=quality_report,
                    artifact_dir=artifact_dir,
                    context="Generated LaTeX validation failed",
                    repairable=True,
                )
            self._raise_for_cv_quality_errors(quality_report, artifact_dir)

            build_dir = artifact_dir / "build"
            build_dir.mkdir(exist_ok=True)
            self._report(f"   4/6 compiling CV -> {CV_PDF_NAME}")
            try:
                cv_pdf = self._compile_latex(
                    cv_tex,
                    build_dir,
                    pdflatex_executable,
                    artifact_dir / "pdflatex_cv.log",
                )
            except PipelineError as error:
                quality_report = quality_report.with_findings(
                    QualityFinding(
                        check_id="CV_COMPILE",
                        rule_ids=("R-24",),
                        category="postcompile",
                        severity=Severity.ERROR,
                        message=str(error),
                        evidence={},
                    )
                )
                self._raise_reported_failure(
                    error=error,
                    report=quality_report,
                    artifact_dir=artifact_dir,
                    context="CV compilation failed",
                    repairable=not str(error).startswith("Could not start pdflatex"),
                )

            quality_report = self._run_cv_quality(
                tex_path=cv_tex,
                artifact_dir=artifact_dir,
                inputs=quality_inputs,
                provider=provider,
                model=model,
                effort=effort,
                pdf_path=cv_pdf,
                log_path=build_dir / "tailored_cv.log",
            )
            self._raise_for_cv_quality_errors(quality_report, artifact_dir)

            quality_report = quality_report.with_findings(*contract_findings)
            self._report(f"   5/6 compiling cover letter -> {COVER_PDF_NAME}")
            cover_tex = output_dir / "cover_letter.tex"
            try:
                cover_pdf = self._compile_latex(
                    cover_tex,
                    build_dir,
                    pdflatex_executable,
                    artifact_dir / "pdflatex_cover_letter.log",
                )
            except PipelineError as error:
                quality_report = quality_report.with_findings(
                    QualityFinding(
                        check_id="COVER_COMPILE",
                        rule_ids=("CL-7.6", "CL-8"),
                        category="cover-postcompile",
                        severity=Severity.ERROR,
                        message=str(error),
                        evidence={},
                    )
                )
                self._raise_reported_failure(
                    error=error,
                    report=quality_report,
                    artifact_dir=artifact_dir,
                    context="Cover-letter compilation failed",
                    repairable=not str(error).startswith("Could not start pdflatex"),
                )
            quality_report = quality_report.with_findings(
                QualityFinding(
                    check_id="COVER_COMPILE",
                    rule_ids=("CL-7.6", "CL-8"),
                    category="cover-postcompile",
                    severity=Severity.PASS,
                    message="Cover letter compiled successfully.",
                    evidence={"pdf": str(cover_pdf.resolve())},
                )
            )
            try:
                self._assert_one_page(cover_pdf)
            except PipelineError as error:
                quality_report = quality_report.with_findings(
                    QualityFinding(
                        check_id="COVER_PAGE_COUNT",
                        rule_ids=("CL-7.6", "CL-8"),
                        category="cover-postcompile",
                        severity=Severity.ERROR,
                        message=str(error),
                        evidence={},
                    )
                )
                self._raise_reported_failure(
                    error=error,
                    report=quality_report,
                    artifact_dir=artifact_dir,
                    context="Cover-letter page validation failed",
                    repairable=not str(error).startswith(
                        ("PyMuPDF is required", "Could not inspect cover letter PDF")
                    ),
                )
            quality_report = quality_report.with_findings(
                QualityFinding(
                    check_id="COVER_PAGE_COUNT",
                    rule_ids=("CL-7.6", "CL-8"),
                    category="cover-postcompile",
                    severity=Severity.PASS,
                    message="Cover letter has exactly one page.",
                    evidence={"pages": 1},
                ),
                self._cover_typography_contract_finding(cover_pdf),
                *self._cover_postcompile_findings(
                    cover_pdf=cover_pdf,
                    log_path=build_dir / "cover_letter.log",
                ),
            )
            self._write_cv_quality_reports(quality_report, artifact_dir)
            self._raise_for_cv_quality_errors(quality_report, artifact_dir)

            archive_dir, superseded = self._archive_atomically(
                document_number=document_number,
                job_pdf=job_pdf,
                request_path=request_path,
                output_dir=output_dir,
                build_dir=build_dir,
                provider_log=provider_log,
                cv_pdf=cv_pdf,
                cover_pdf=cover_pdf,
                artifact_dir=artifact_dir,
            )
            counts = quality_report.counts
            if superseded is not None:
                self._report(
                    f"       replacing the earlier job_{document_number}, "
                    "regenerated for the current sources"
                )
            self._report(
                f"   6/6 archived -> {archive_dir}  "
                f"[{quality_report.verdict}: {counts['PASS']} pass, "
                f"{counts['WARN']} warn, {counts['ERROR']} error]"
            )
            self._report(f"       {CV_PDF_NAME}")
            self._report(f"       {COVER_PDF_NAME}")
            row = self._manifest_row(
                job_index=job_index,
                job_pdf=job_pdf,
                job_hash=job_hash,
                source_hash=source_hash,
                provider=provider,
                model=model,
                effort=effort,
                document_number=document_number,
                archive_dir=archive_dir,
            )
            manifest.rows.append(row)
            try:
                self._write_manifest(manifest)
            except Exception as error:
                manifest.rows.pop()
                try:
                    self._remove_new_archive(archive_dir, document_number)
                    if superseded is not None:
                        os.replace(superseded, archive_dir)
                except Exception as cleanup_error:
                    raise PipelineError(
                        "Manifest commit failed and the new archive could not be "
                        f"rolled back: {cleanup_error}"
                    ) from error
                raise
            if superseded is not None:
                shutil.rmtree(superseded, ignore_errors=True)
            self._cleanup_committed_artifact_dir(
                artifact_dir,
                document_number=document_number,
            )
            result = JobResult(
                job_ad=job_pdf,
                document_number=document_number,
                archive_dir=archive_dir,
            )
            processed.append(result)
            if self._session_processed is not None:
                self._session_processed.append(result)
            self._report(
                f"       done in {format_duration(time.monotonic() - job_started)}"
            )

        if processed:
            self._report("")
            self._report(
                f"All {len(processed)} application(s) completed in "
                f"{format_duration(time.monotonic() - run_started)}."
            )
        return RunSummary(
            provider=provider,
            processed=tuple(processed),
            skipped=tuple(skipped),
        )

    def _report(self, message: str) -> None:
        """Emit one progress line; reporting must never break a run."""

        if self._progress is None:
            return
        try:
            self._progress(message)
        except Exception:  # noqa: BLE001 - console problems must not abort work
            pass

    def _validate_layout(self) -> None:
        missing = [path for path in self._locked_source_paths() if not path.is_file()]
        if missing:
            formatted = "\n".join(f"- {path}" for path in missing)
            raise PipelineError("Required pipeline sources are missing:\n" + formatted)
        if not Path(self.paths.job_ads_dir).is_dir():
            raise PipelineError(
                f"External job-ad folder was not found: {self.paths.job_ads_dir}"
            )
        Path(self.paths.cvs_dir).mkdir(parents=True, exist_ok=True)
        Path(self.paths.artifacts_dir).mkdir(parents=True, exist_ok=True)

    def _cover_typography_baseline_path(self) -> Path:
        """Return the approved compiled CL used for immutable visual metrics."""

        return self.paths.cover_template.with_suffix(".pdf")

    def _locked_source_paths(self) -> tuple[Path, ...]:
        """Return all provider-protected and resume-hashed application inputs."""

        return (*self.paths.source_paths, self._cover_typography_baseline_path())

    def _job_ads(self) -> list[Path]:
        def numbered_first(path: Path) -> tuple[int, int, str, str]:
            numbered = _NUMBERED_JOB_AD_RE.fullmatch(path.name)
            if numbered:
                # Ascending, so a numbered ad and the document number it is
                # archived under advance together: job_description_115.pdf is
                # processed first in a 115-119 batch and becomes CVs/job_115.
                return (0, int(numbered.group(1)), path.name.casefold(), path.name)
            try:
                modified = path.stat().st_mtime_ns
            except OSError:
                modified = 0
            return (1, -modified, path.name.casefold(), path.name)

        return sorted(
            (
                path.resolve()
                for path in Path(self.paths.job_ads_dir).iterdir()
                if path.is_file() and path.suffix.casefold() == ".pdf"
            ),
            key=numbered_first,
        )

    def _require_executable(self, name: str) -> Path:
        resolved = self._resolve_executable(name)
        if not resolved:
            raise PipelineError(
                f"Required executable '{name}' was not found. Install it and retry."
            )
        path = Path(resolved)
        if not path.is_absolute():
            located = shutil.which(str(path), path=self._env.get("PATH"))
            if located:
                path = Path(located)
        if path.is_absolute() and not path.is_file():
            raise PipelineError(f"Resolved executable '{name}' does not exist: {path}")
        return path

    def _load_manifest(self) -> _Manifest:
        path = self.paths.manifest
        if not path.is_file() or path.stat().st_size == 0:
            return _Manifest(fieldnames=list(_FRESH_MANIFEST_COLUMNS), rows=[])
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            fieldnames = list(reader.fieldnames or ())
            rows = [dict(row) for row in reader]
        if not fieldnames:
            fieldnames = list(_FRESH_MANIFEST_COLUMNS)
        else:
            for added_column in ("SourceHash", "Model", "Effort"):
                if added_column not in fieldnames:
                    fieldnames.append(added_column)
                    for row in rows:
                        row[added_column] = ""
        return _Manifest(fieldnames=fieldnames, rows=rows)

    def _manifest_pdf_exists(self, row: Mapping[str, str], field: str, fallback: Path) -> bool:
        candidates = [fallback]
        value = (row.get(field) or "").strip()
        if value:
            saved = Path(value)
            if not saved.is_absolute():
                saved = Path(self.paths.cvs_dir) / saved
            candidates.append(saved)
        return any(_is_nonempty_file(candidate) for candidate in candidates)

    def _completed_archive(self, job_pdf: Path) -> Path | None:
        """Return the finished archive for a numbered ad, if there is one.

        A numbered job ad owns its document number, so ``CVs/job_117`` holding
        both PDFs means ``job_description_117.pdf`` is done. That answer does
        not depend on the source bundle: changing a rule no longer regenerates
        work already archived. Delete the folder to rebuild that application.
        """

        numbered = _NUMBERED_JOB_AD_RE.fullmatch(job_pdf.name)
        if not numbered:
            return None
        folder = Path(self.paths.cvs_dir) / f"job_{int(numbered.group(1))}"
        if not folder.is_dir():
            return None
        # The folder itself is the answer. Archiving is atomic -- a staging
        # directory is moved into place in one step -- so the pipeline cannot
        # leave a half-written one behind, and renaming or recompiling a file
        # inside it afterwards does not make the application unfinished. An
        # empty directory is the one thing that cannot be a finished archive.
        return folder if any(folder.iterdir()) else None

    def _is_already_done(
        self,
        manifest: _Manifest,
        job_pdf: Path,
        job_hash: str,
        source_hash: str,
    ) -> bool:
        """Decide whether an advertisement still needs an application."""

        if self._completed_archive(job_pdf) is not None:
            return True
        # Legacy company-named ads carry no number, so they still resume on the
        # recorded job and source hashes.
        return self._has_complete_resume(manifest, job_hash, source_hash)

    def _has_complete_resume(
        self,
        manifest: _Manifest,
        job_hash: str,
        source_hash: str,
    ) -> bool:
        for row in manifest.rows:
            if (row.get("JobHash") or "").casefold() != job_hash.casefold():
                continue
            if (row.get("SourceHash") or "").casefold() != source_hash.casefold():
                continue
            try:
                number = int(row.get("DocumentNumber") or "")
            except ValueError:
                continue
            folder = Path(self.paths.cvs_dir) / f"job_{number}"
            if self._manifest_pdf_exists(row, "CvFile", folder / CV_PDF_NAME) and self._manifest_pdf_exists(
                row, "ClFile", folder / COVER_PDF_NAME
            ):
                return True
        return False

    def _next_document_number(self, manifest: _Manifest) -> int:
        highest = 0
        for row in manifest.rows:
            try:
                highest = max(highest, int(row.get("DocumentNumber") or ""))
            except ValueError:
                pass
        cvs_dir = Path(self.paths.cvs_dir)
        for path in cvs_dir.iterdir():
            match = re.fullmatch(r"job_(\d+)", path.name, flags=re.IGNORECASE)
            if path.is_dir() and match:
                highest = max(highest, int(match.group(1)))
        for path in cvs_dir.rglob("*.pdf"):
            match = re.search(r"(?:CV|CL)(\d+)", path.stem, flags=re.IGNORECASE)
            if match:
                highest = max(highest, int(match.group(1)))
        return highest + 1

    def _reusable_provider_output(self, artifact_dir: Path, request_text: str) -> bool:
        """Say whether a previous run's output can stand in for a new call.

        The request embeds every approved source and the job ad itself, so a
        retained request that still matches a freshly built one proves the
        outputs beside it were generated from exactly these inputs. Any change
        to a rule, template, or the posting makes the texts differ and the work
        is redone.
        """

        request_path = artifact_dir / "request.md"
        if not request_path.is_file():
            return False
        try:
            if request_path.read_text(encoding="utf-8") != request_text:
                return False
        except OSError:
            return False
        output_dir = artifact_dir / "output"
        return all(
            _is_nonempty_file(output_dir / name) for name in GENERATED_FILES
        )

    def _recreate_artifact_dir(self, document_number: int) -> Path:
        root = Path(self.paths.artifacts_dir).resolve()
        target = root / f"job_{document_number}"
        if target.parent.resolve() != root:
            raise PipelineError(f"Unsafe artifact path: {target}")
        if target.is_symlink():
            target.unlink()
        elif target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True)
        return target

    def _remove_artifact_dir(self, artifact_dir: Path) -> None:
        root = Path(self.paths.artifacts_dir).resolve()
        target = artifact_dir.resolve()
        if target.parent != root or not re.fullmatch(r"job_\d+", target.name):
            raise PipelineError(f"Unsafe artifact cleanup path: {target}")
        for attempt in range(len(_ARTIFACT_CLEANUP_RETRY_DELAYS_SECONDS) + 1):
            if target.is_symlink():
                target.unlink()
                return
            if not target.exists():
                return
            try:
                shutil.rmtree(target)
                return
            except OSError as error:
                retryable = (
                    getattr(error, "winerror", None) == _WINDOWS_SHARING_VIOLATION
                    and attempt < len(_ARTIFACT_CLEANUP_RETRY_DELAYS_SECONDS)
                )
                if not retryable:
                    raise
                time.sleep(_ARTIFACT_CLEANUP_RETRY_DELAYS_SECONDS[attempt])

    def _cleanup_committed_artifact_dir(
        self,
        artifact_dir: Path,
        *,
        document_number: int,
    ) -> bool:
        """Clean a safely archived job without undoing success for WinError 32.

        At this point the archive is authoritative (and, for a newly completed
        job, the manifest has already committed). A persistent Windows sharing
        lock is therefore cleanup debt rather than an application failure. The
        strict path check and every non-sharing filesystem error remain fatal.
        """

        try:
            self._remove_artifact_dir(artifact_dir)
        except OSError as error:
            if getattr(error, "winerror", None) != _WINDOWS_SHARING_VIOLATION:
                raise
            self._report(
                f"   WARNING: job_{document_number} is safely archived, but Windows "
                f"is still locking {artifact_dir.resolve()}. Artifact cleanup was "
                "deferred and will be retried on the next run; close any terminal or "
                "editor using that folder."
            )
            return False
        return True

    def _cleanup_artifacts_for_skipped_numbered_jobs(
        self,
        skipped: Sequence[Path],
    ) -> None:
        """Retry deferred cleanup for numbered ads with authoritative archives."""

        artifact_root = Path(self.paths.artifacts_dir).resolve()
        for job_pdf in skipped:
            numbered = _NUMBERED_JOB_AD_RE.fullmatch(job_pdf.name)
            if numbered is None or self._completed_archive(job_pdf) is None:
                continue
            document_number = int(numbered.group(1))
            artifact_dir = artifact_root / f"job_{document_number}"
            if not artifact_dir.exists() and not artifact_dir.is_symlink():
                continue
            removed = self._cleanup_committed_artifact_dir(
                artifact_dir,
                document_number=document_number,
            )
            if removed:
                self._report(
                    f"   removed deferred artifacts for archived job_{document_number}"
                )

    def _remove_new_archive(self, archive_dir: Path, document_number: int) -> None:
        root = Path(self.paths.cvs_dir).resolve()
        target = archive_dir.resolve()
        expected = root / f"job_{document_number}"
        if target != expected or target.parent != root:
            raise PipelineError(f"Unsafe archive rollback path: {target}")
        if target.is_symlink():
            target.unlink()
        elif target.exists():
            shutil.rmtree(target)

    def _provider_command(
        self,
        provider: Provider,
        executable: Path,
        request_path: Path,
        output_dir: Path,
        model: str | None = None,
        effort: str | None = None,
    ) -> list[str]:
        model = validate_model(model)
        effort = validate_effort(provider, effort)
        short_prompt = (
            f'Read and follow the complete request at "{request_path.resolve()}". '
            f'Create exactly tailored_cv.tex, cover_letter.tex, change_log.md, and '
            f'match_notes.md in "{output_dir.resolve()}". Do not compile PDFs or '
            "edit any source, template, prompt, or job-ad file."
        )
        if provider == "claude":
            # --allowed-tools is variadic, so it must be followed by another
            # option; it would otherwise swallow the prompt argument.
            command = [str(executable), "--allowed-tools", _CLAUDE_WEB_TOOLS]
            if model is not None:
                command.extend(("--model", model))
            if effort is not None:
                command.extend(("--effort", effort))
            command.extend((
                "--permission-mode",
                "acceptEdits",
                "--print",
                "--no-session-persistence",
                short_prompt,
            ))
            return command
        command = [
            str(executable),
            "--ask-for-approval",
            "never",
            "exec",
        ]
        if model is not None:
            command.extend(("--model", model))
        if effort is not None:
            # Codex exposes no effort flag; the level is a config override.
            command.extend(("--config", f'{_CODEX_EFFORT_KEY}="{effort}"'))
        command.extend(("--config", _CODEX_WEB_SEARCH))
        command.extend((
            "--sandbox",
            "workspace-write",
            "--skip-git-repo-check",
            short_prompt,
        ))
        return command

    def _run_command(self, command: Sequence[str]) -> subprocess.CompletedProcess[str]:
        command = list(command)
        if os.name == "nt" and Path(command[0]).suffix.casefold() in {".cmd", ".bat"}:
            command = [
                self._env.get("COMSPEC", "cmd.exe"),
                "/d",
                "/c",
                *command,
            ]
        return subprocess.run(
            command,
            cwd=self.paths.project_root,
            env=self._env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )

    def _run_provider(
        self,
        provider: Provider,
        executable: Path,
        request_path: Path,
        output_dir: Path,
        log_path: Path,
        snapshots: Sequence[_Snapshot],
        model: str | None = None,
        effort: str | None = None,
    ) -> None:
        command = self._provider_command(
            provider, executable, request_path, output_dir, model, effort
        )
        result: subprocess.CompletedProcess[str] | None = None
        launch_error: OSError | None = None
        try:
            try:
                with _Heartbeat(self._progress, provider) as heartbeat:
                    result = self._run_command(command)
                self._report(
                    f"       {provider} finished in "
                    f"{format_duration(heartbeat.elapsed)}"
                )
                log_path.write_text(result.stdout or "", encoding="utf-8", newline="\n")
            except OSError as error:
                launch_error = error
                log_path.write_text(str(error), encoding="utf-8", newline="\n")
        finally:
            changed = _restore_modified_files(snapshots)

        if changed:
            joined = "\n".join(f"- {path}" for path in changed)
            raise PipelineError(
                "The provider modified protected source files. Original bytes were restored:\n"
                + joined
            )
        if launch_error is not None:
            raise PipelineError(f"Could not start {provider}: {launch_error}") from launch_error
        assert result is not None
        if result.returncode != 0:
            raise PipelineError(
                f"{provider} exited with code {result.returncode}.\n{_tail(result.stdout or '')}"
            )

    def _assert_fresh_outputs(self, output_dir: Path) -> None:
        # The output directory is created inside a freshly recreated per-job
        # artifact directory, so any present file necessarily belongs to this run.
        missing = [name for name in GENERATED_FILES if not _is_nonempty_file(output_dir / name)]
        if missing:
            raise PipelineError(
                "The provider did not create all four fresh outputs: " + ", ".join(missing)
            )

    def _load_cv_quality_inputs(
        self,
        *,
        job_pdf: Path,
        job_hash: str,
        source_hash: str,
    ) -> _CvQualityInputs:
        try:
            job_description = extract_pdf_text(job_pdf)
            return _CvQualityInputs(
                job_description=job_description,
                clean_job_title=extract_clean_job_title(job_description),
                cv_rules=read_text(self.paths.cv_rules),
                bullet_library=extract_docx_text(self.paths.bullet_library),
                skills_profiles=extract_docx_text(self.paths.skills_profiles),
                hashes={
                    "job_sha256": job_hash,
                    "source_bundle_sha256": source_hash,
                },
            )
        except Exception as error:
            raise PipelineError(
                f"Could not prepare CV quality-validation inputs: {error}"
            ) from error

    @staticmethod
    def _cv_quality_report_paths(artifact_dir: Path) -> tuple[Path, Path]:
        return (
            artifact_dir / VALIDATION_JSON_NAME,
            artifact_dir / VALIDATION_XLSX_NAME,
        )

    @staticmethod
    def _cv_quality_failure_marker_path(artifact_dir: Path) -> Path:
        return artifact_dir / VALIDATION_FAILURE_MARKER_NAME

    @staticmethod
    def _failure_quality_report(
        *,
        check_id: str,
        category: str,
        message: str,
        provider: Provider,
        model: str | None,
        effort: str | None,
        hashes: Mapping[str, str],
    ) -> QualityReport:
        return QualityReport(
            schema_version=SCHEMA_VERSION,
            validator_version=VALIDATOR_VERSION,
            generated_at_utc=datetime.now(timezone.utc).isoformat(),
            provider=provider,
            model=model or "",
            effort=effort or "",
            hashes=dict(hashes),
            findings=(
                QualityFinding(
                    check_id=check_id,
                    rule_ids=(),
                    category=category,
                    severity=Severity.ERROR,
                    message=message,
                    evidence={},
                ),
            ),
            provenance=(),
            jd_metrics={},
            jd_matches=(),
        )

    @staticmethod
    def _concise_error(error: BaseException | str) -> str:
        return re.sub(r"\s+", " ", str(error)).strip()

    @staticmethod
    def _write_failure_marker(path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                newline="\n",
                prefix=f".{path.name}.",
                suffix=".tmp",
                dir=path.parent,
                delete=False,
            ) as stream:
                temporary_path = Path(stream.name)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary_path, path)
            temporary_path = None
        finally:
            if temporary_path is not None and temporary_path.exists():
                temporary_path.unlink()

    def _invalidate_cv_quality_reports(
        self,
        artifact_dir: Path,
        *,
        reason: str,
    ) -> tuple[Path, tuple[str, ...]]:
        cleanup_errors: list[str] = []
        for path in self._cv_quality_report_paths(artifact_dir):
            try:
                path.unlink(missing_ok=True)
            except OSError as error:
                cleanup_errors.append(f"{path.resolve()}: {self._concise_error(error)}")

        marker_path = self._cv_quality_failure_marker_path(artifact_dir)
        marker_lines = [
            "APPLICATION VALIDATION REPORTS ARE INVALID",
            "status: ERROR",
            "check_id: REPORT_WRITE",
            f"generated_at_utc: {datetime.now(timezone.utc).isoformat()}",
            f"reason: {reason}",
            "The canonical JSON/XLSX pair must not be used for this run.",
        ]
        if cleanup_errors:
            marker_lines.append("Canonical-file cleanup errors:")
            marker_lines.extend(f"- {item}" for item in cleanup_errors)
        self._write_failure_marker(marker_path, "\n".join(marker_lines) + "\n")
        return marker_path, tuple(cleanup_errors)

    def _write_cv_quality_reports(
        self,
        report: QualityReport,
        artifact_dir: Path,
    ) -> None:
        json_path, xlsx_path = self._cv_quality_report_paths(artifact_dir)
        try:
            write_quality_reports(
                report,
                json_path=json_path,
                xlsx_path=xlsx_path,
            )
        except Exception as error:
            report_write_finding = QualityFinding(
                check_id="REPORT_WRITE",
                rule_ids=(),
                category="reporting",
                severity=Severity.ERROR,
                message=f"Could not write the requested report pair: {error}",
                evidence={"error_type": type(error).__name__},
            )
            recovery_report = (
                report
                if any(
                    finding.check_id == "REPORT_WRITE"
                    and finding.severity is Severity.ERROR
                    for finding in report.findings
                )
                else report.with_findings(report_write_finding)
            )
            try:
                write_quality_reports(
                    recovery_report,
                    json_path=json_path,
                    xlsx_path=xlsx_path,
                )
            except Exception as recovery_error:
                reason = (
                    f"initial write failed: {self._concise_error(error)}; "
                    "REPORT_WRITE recovery failed: "
                    f"{self._concise_error(recovery_error)}"
                )
                try:
                    marker_path, cleanup_errors = self._invalidate_cv_quality_reports(
                        artifact_dir,
                        reason=reason,
                    )
                except Exception as marker_error:
                    marker_path = self._cv_quality_failure_marker_path(artifact_dir)
                    raise PipelineError(
                        "Could not write application validation reports: "
                        f"{self._concise_error(error)}. Recovery also failed: "
                        f"{self._concise_error(recovery_error)}. Could not create the "
                        f"failure marker at {marker_path.resolve()}: "
                        f"{self._concise_error(marker_error)}"
                    ) from error
                cleanup_note = (
                    f" {len(cleanup_errors)} locked canonical file(s) are explicitly "
                    "invalidated by that marker."
                    if cleanup_errors
                    else ""
                )
                raise PipelineError(
                    "Could not write application validation reports: "
                    f"{self._concise_error(error)}. Canonical reports were removed or "
                    f"marked invalid. Failure marker: {marker_path.resolve()}."
                    + cleanup_note
                ) from error

            raise PipelineError(
                "Could not write the original application validation reports: "
                f"{self._concise_error(error)}. A REPORT_WRITE ERROR report was "
                f"retained. {self._cv_quality_report_hint(artifact_dir)}"
            ) from error

        marker_path = self._cv_quality_failure_marker_path(artifact_dir)
        try:
            marker_path.unlink(missing_ok=True)
        except OSError as error:
            try:
                invalid_marker, cleanup_errors = self._invalidate_cv_quality_reports(
                    artifact_dir,
                    reason=(
                        "A stale failure marker could not be removed after report write: "
                        f"{self._concise_error(error)}"
                    ),
                )
            except Exception as marker_error:
                raise PipelineError(
                    "Application validation reports were written, but a stale failure marker "
                    f"could not be removed: {self._concise_error(error)}. Marker path: "
                    f"{marker_path.resolve()}. Marker refresh also failed: "
                    f"{self._concise_error(marker_error)}"
                ) from error
            cleanup_note = (
                f" {len(cleanup_errors)} locked canonical file(s) remain invalid."
                if cleanup_errors
                else ""
            )
            raise PipelineError(
                "Application validation reports were invalidated because a stale failure marker "
                f"could not be removed. Failure marker: {invalid_marker.resolve()}."
                + cleanup_note
            ) from error

    def _with_repair_history(
        self,
        report: QualityReport,
        artifact_dir: Path,
    ) -> QualityReport:
        """Attach this job's repair audit without duplicating earlier rows."""

        history = self._repair_findings.get(artifact_dir.resolve(), ())
        existing_ids = {finding.check_id for finding in report.findings}
        additions = tuple(
            finding for finding in history if finding.check_id not in existing_ids
        )
        return report.with_findings(*additions) if additions else report

    @staticmethod
    def _is_cover_postcompile_failure(
        failure: _RepairableValidationError,
    ) -> bool:
        """Return whether the current errors are solely from the late CL gate.

        The reserved attempt must never extend the budget for a CV, provider,
        or precompile contract failure. A mixed report therefore qualifies only
        when every current ERROR belongs to the cover-postcompile category.
        """

        errors = tuple(
            finding
            for finding in failure.report.findings
            if finding.severity is Severity.ERROR
        )
        return bool(errors) and all(
            finding.category == "cover-postcompile" for finding in errors
        )

    @staticmethod
    def _repair_change_log_notes(change_log: Path) -> str:
        if not change_log.is_file():
            return "The provider did not leave a non-empty change_log.md."
        text = change_log.read_text(encoding="utf-8", errors="replace")
        match = re.search(
            r"(?ims)^##\s+Validation Repairs\s*$\s*(.*?)(?=^##\s|\Z)",
            text,
        )
        if not match:
            return "No 'Validation Repairs' section was added to change_log.md."
        notes = match.group(1).strip()
        return notes[:2000] if notes else "The Validation Repairs section was empty."

    def _attempt_ai_repair(
        self,
        *,
        provider: Provider,
        model: str | None,
        effort: str | None,
        failure: _RepairableValidationError,
        attempt: int,
        repair_scope: str = "general",
    ) -> None:
        """Ask the selected provider for a minimal fix to retained outputs."""

        artifact_dir = failure.artifact_dir
        output_dir = artifact_dir / "output"
        request_path = artifact_dir / f"repair_request_{attempt}.md"
        log_path = artifact_dir / f"provider_repair_{attempt}.log"
        original_request = artifact_dir / "request.md"
        json_report, xlsx_report = self._cv_quality_report_paths(artifact_dir)
        errors = tuple(
            finding
            for finding in failure.report.findings
            if finding.severity is Severity.ERROR
        )
        trigger_ids = [finding.check_id for finding in errors]
        outputs = [output_dir / name for name in GENERATED_FILES]
        typography_triggers = {
            "COVER_PAGE_COUNT",
            "COVER_TYPOGRAPHY_CONTRACT",
        }.intersection(trigger_ids)
        cover_layout_guidance = (
            (
                "",
                "## Mandatory cover-letter layout repair",
                "",
                "- Preserve the approved cover-letter typography, font sizes, margins, "
                "page geometry, and spacing exactly.",
                "- Fix the page-fit problem only by shortening permitted job-specific "
                "wording inside existing edit regions. Never solve it by adding or "
                "changing formatting commands.",
            )
            if typography_triggers
            else ()
        )

        request = "\n".join(
            (
                "# Automated validation repair",
                "",
                "Repair the existing CV and cover-letter output pair. Read the original "
                "generation request and current validation report before editing.",
                "",
                f"Original generation request: {original_request.resolve()}",
                f"Validation JSON: {json_report.resolve()}",
                f"Validation workbook: {xlsx_report.resolve()}",
                f"Job advertisement: {failure.job_ad.resolve()}",
                f"Output directory: {output_dir.resolve()}",
                f"CV compiler log (when present): {(artifact_dir / 'pdflatex_cv.log').resolve()}",
                "Cover-letter compiler log (when present): "
                f"{(artifact_dir / 'pdflatex_cover_letter.log').resolve()}",
                "",
                "## Failed checks",
                "",
                "```json",
                json.dumps(
                    [finding.to_dict() for finding in errors],
                    ensure_ascii=False,
                    indent=2,
                ),
                "```",
                "",
                "## Repair contract",
                "",
                "- Diagnose every failed check above and make the smallest valid edit.",
                "- Edit only the four existing output files: tailored_cv.tex, "
                "cover_letter.tex, change_log.md, and match_notes.md.",
                "- Do not edit the original request, templates, rule files, source "
                "documents, job advertisement, validation reports, or build files.",
                "- Preserve all template contracts and use only evidence authorised by "
                "the original request.",
                "- In tailored_cv.tex, restore regions 1--8 from the supplied CV "
                "template if needed and never alter them; only SKILLS may change.",
                "- Do not compile. The pipeline will compile and run every validation "
                "gate again after you finish.",
                "- Append a `## Validation Repairs` section to change_log.md. Record "
                "the failed check IDs, diagnosis, files changed, and exact corrective "
                "edits. Keep prior notes.",
                "- Leave exactly the same four non-empty output files in the output "
                "directory and create no alternatives.",
                *cover_layout_guidance,
                "",
            )
        )

        before = {
            path.name: sha256_file(path) if _is_nonempty_file(path) else ""
            for path in outputs
        }
        try:
            request_path.write_text(request, encoding="utf-8", newline="\n")
            protected_paths = (
                *self._locked_source_paths(),
                failure.job_ad,
                original_request,
                json_report,
                xlsx_report,
                request_path,
            )
            snapshots = _snapshot_files(protected_paths)
            self._run_provider(
                provider,
                self._require_executable(provider),
                request_path,
                output_dir,
                log_path,
                snapshots,
                model=model,
                effort=effort,
            )
        except Exception as repair_error:
            report = self._with_repair_history(
                failure.report,
                artifact_dir,
            ).with_findings(
                QualityFinding(
                    check_id=f"AI_REPAIR_RUNTIME_{attempt}",
                    rule_ids=(),
                    category="ai-repair",
                    severity=Severity.ERROR,
                    message=(
                        f"Automatic repair attempt {attempt} could not run: "
                        f"{self._concise_error(repair_error)}"
                    ),
                    evidence={
                        "attempt": attempt,
                        "repair_scope": repair_scope,
                        "trigger_checks": trigger_ids,
                        "repair_request": str(request_path.resolve()),
                        "provider_log": str(log_path.resolve()),
                    },
                )
            )
            self._write_cv_quality_reports(report, artifact_dir)
            raise PipelineError(
                f"Automatic repair attempt {attempt} could not run: "
                f"{self._concise_error(repair_error)}. "
                + self._cv_quality_report_hint(artifact_dir)
            ) from repair_error

        after = {
            path.name: sha256_file(path) if _is_nonempty_file(path) else ""
            for path in outputs
        }
        changed_files = [name for name in before if before[name] != after[name]]
        finding = QualityFinding(
            check_id=f"AI_REPAIR_ATTEMPT_{attempt}",
            rule_ids=(),
            category="ai-repair",
            severity=Severity.WARN,
            message=(
                f"{provider} completed automatic repair attempt {attempt} for "
                f"{', '.join(trigger_ids) or 'the reported validation failure'}; "
                + (
                    "changed " + ", ".join(changed_files) + "."
                    if changed_files
                    else "no output-file byte changes were detected."
                )
            ),
            evidence={
                "attempt": attempt,
                "repair_scope": repair_scope,
                "trigger_checks": trigger_ids,
                "trigger_messages": [finding.message for finding in errors],
                "changed_files": changed_files,
                "provider": provider,
                "model": model or "",
                "effort": effort or "",
                "repair_request": str(request_path.resolve()),
                "provider_log": str(log_path.resolve()),
                "change_log_notes": self._repair_change_log_notes(
                    output_dir / "change_log.md"
                ),
            },
        )
        self._repair_findings.setdefault(artifact_dir.resolve(), []).append(finding)
        self._report(
            "       repair returned; rerunning document validation and compilation"
        )

    def _run_cv_quality(
        self,
        *,
        tex_path: Path,
        artifact_dir: Path,
        inputs: _CvQualityInputs,
        provider: Provider,
        model: str | None,
        effort: str | None,
        pdf_path: Path | None = None,
        log_path: Path | None = None,
    ) -> QualityReport:
        try:
            report = validate_cv_quality(
                tex_path=tex_path,
                job_description=inputs.job_description,
                cv_rules=inputs.cv_rules,
                bullet_library=inputs.bullet_library,
                skills_profiles=inputs.skills_profiles,
                expected_job_title=inputs.clean_job_title,
                pdf_path=pdf_path,
                log_path=log_path,
                provider=provider,
                model=model,
                effort=effort,
                hashes=inputs.hashes,
            )
            if not isinstance(report, QualityReport):
                raise TypeError(
                    "validate_cv_quality returned "
                    f"{type(report).__name__}, expected QualityReport"
                )
        except Exception as error:
            failure_report = self._failure_quality_report(
                check_id="VALIDATOR_RUNTIME",
                category="validator",
                message=f"Could not run CV quality validation: {error}",
                provider=provider,
                model=model,
                effort=effort,
                hashes=inputs.hashes,
            )
            self._raise_reported_failure(
                error=error,
                report=failure_report,
                artifact_dir=artifact_dir,
                context="Could not run CV quality validation",
            )
        report = self._with_repair_history(report, artifact_dir)
        self._write_cv_quality_reports(report, artifact_dir)
        return report

    def _raise_reported_failure(
        self,
        *,
        error: BaseException,
        report: QualityReport,
        artifact_dir: Path,
        context: str | None = None,
        repairable: bool = False,
    ) -> NoReturn:
        detail = self._concise_error(error)
        if context and not detail.casefold().startswith(context.casefold()):
            detail = f"{context}: {detail}"
        report = self._with_repair_history(report, artifact_dir)
        try:
            self._write_cv_quality_reports(report, artifact_dir)
        except PipelineError as report_error:
            raise PipelineError(
                f"{detail}. {self._concise_error(report_error)}"
            ) from error
        message = f"{detail}. {self._cv_quality_report_hint(artifact_dir)}"
        if repairable:
            if self._active_job_pdf is None:
                raise PipelineError(message) from error
            raise _RepairableValidationError(
                message,
                report=report,
                artifact_dir=artifact_dir,
                job_ad=self._active_job_pdf,
            ) from error
        raise PipelineError(message) from error

    def _cv_quality_report_hint(self, artifact_dir: Path) -> str:
        json_path, xlsx_path = self._cv_quality_report_paths(artifact_dir)
        return f"Reports: {json_path.resolve()} and {xlsx_path.resolve()}."

    def _raise_for_cv_quality_errors(
        self,
        report: QualityReport,
        artifact_dir: Path,
    ) -> None:
        if not report.has_errors:
            return
        errors = [
            finding
            for finding in report.findings
            if finding.severity is Severity.ERROR
        ]
        details = " | ".join(
            f"[{finding.check_id}] {finding.message}" for finding in errors[:3]
        )
        if len(errors) > 3:
            details += f" | and {len(errors) - 3} more"
        message = (
            f"Application validation failed with {len(errors)} ERROR finding(s): "
            f"{details}. "
            + self._cv_quality_report_hint(artifact_dir)
        )
        nonrepairable = any(
            finding.category in {"configuration", "validator", "reporting"}
            or finding.check_id in {"VALIDATOR_RUNTIME", "REPORT_WRITE"}
            or str(finding.evidence.get("error_type", ""))
            in {"ModuleNotFoundError", "ImportError", "FileNotFoundError", "PermissionError"}
            for finding in errors
        )
        if nonrepairable or self._active_job_pdf is None:
            raise PipelineError(message)
        raise _RepairableValidationError(
            message,
            report=self._with_repair_history(report, artifact_dir),
            artifact_dir=artifact_dir,
            job_ad=self._active_job_pdf,
        )

    def _document_contract_findings(
        self,
        output_dir: Path,
        *,
        expected_job_title: str,
    ) -> tuple[QualityFinding, ...]:
        def validate_cover(template: str, generated: str) -> list[str]:
            return validate_generated_cover(
                template,
                generated,
                expected_job_title=expected_job_title,
            )

        documents = (
            (
                "CV_TEMPLATE_CONTRACT",
                "CV",
                ("R-01", "R-02"),
                self.paths.cv_template,
                output_dir / "tailored_cv.tex",
                validate_generated_cv,
            ),
            (
                "COVER_TEMPLATE_CONTRACT",
                "cover letter",
                ("CL-1", "CL-5", "CL-7"),
                self.paths.cover_template,
                output_dir / "cover_letter.tex",
                validate_cover,
            ),
        )
        findings: list[QualityFinding] = []
        for check_id, label, rule_ids, template_path, generated_path, validator in documents:
            try:
                notes = validator(read_text(template_path), read_text(generated_path))
            except (OSError, ValueError) as error:
                findings.append(
                    QualityFinding(
                        check_id=check_id,
                        rule_ids=rule_ids,
                        category="structure",
                        severity=Severity.ERROR,
                        message=f"Generated {label} failed its template contract: {error}",
                        evidence={},
                    )
                )
            else:
                findings.append(
                    QualityFinding(
                        check_id=check_id,
                        rule_ids=rule_ids,
                        category="structure",
                        severity=Severity.WARN if notes else Severity.PASS,
                        message=(
                            f"Generated {label} satisfies its template contract, "
                            "with cosmetic differences: " + " ".join(notes)
                            if notes
                            else f"Generated {label} satisfies its template contract."
                        ),
                        evidence={"notes": list(notes)} if notes else {},
                    )
                )
        return tuple(findings)

    @staticmethod
    def _normalise_pdf_font_name(value: object) -> str:
        """Remove random PDF subset tags while retaining the real font name."""

        return _PDF_FONT_SUBSET_PREFIX_RE.sub("", str(value).strip())

    def _cover_pdf_typography_metrics(
        self,
        pdf_path: Path,
    ) -> tuple[tuple[tuple[float, float], ...], tuple[tuple[str, float], ...]]:
        """Read page dimensions and used visible-text font signatures."""

        import fitz

        document = fitz.open(pdf_path)
        try:
            page_sizes: list[tuple[float, float]] = []
            font_signatures: set[tuple[str, float]] = set()
            for page in document:
                box = getattr(page, "mediabox", None) or page.rect
                page_sizes.append((float(box.width), float(box.height)))
                payload = page.get_text("dict")
                for block in payload.get("blocks", ()):
                    for line in block.get("lines", ()):
                        for span in line.get("spans", ()):
                            if not str(span.get("text", "")).strip():
                                continue
                            name = self._normalise_pdf_font_name(span.get("font", ""))
                            size = float(span.get("size", 0.0))
                            font_signatures.add((name, size))
        finally:
            document.close()
        return tuple(page_sizes), tuple(
            sorted(font_signatures, key=lambda item: (item[0].casefold(), item[1]))
        )

    @staticmethod
    def _font_signature_is_allowed(
        signature: tuple[str, float],
        allowed: Sequence[tuple[str, float]],
    ) -> bool:
        name, size = signature
        return any(
            name.casefold() == allowed_name.casefold()
            and abs(size - allowed_size) <= _COVER_FONT_SIZE_TOLERANCE_PT
            for allowed_name, allowed_size in allowed
        )

    @staticmethod
    def _typography_evidence(
        page_sizes: Sequence[tuple[float, float]],
        fonts: Sequence[tuple[str, float]],
    ) -> dict[str, object]:
        return {
            "page_sizes_pt": [
                {"width": round(width, 3), "height": round(height, 3)}
                for width, height in page_sizes
            ],
            "fonts": [
                {"name": name, "size_pt": round(size, 3)}
                for name, size in fonts
            ],
        }

    def _cover_typography_contract_finding(
        self,
        cover_pdf: Path,
    ) -> QualityFinding:
        """Compare compiled CL fonts and page size with the locked PDF baseline."""

        baseline_pdf = self._cover_typography_baseline_path()
        try:
            expected_pages, expected_fonts = self._cover_pdf_typography_metrics(
                baseline_pdf
            )
        except Exception as error:
            return QualityFinding(
                check_id="COVER_TYPOGRAPHY_CONTRACT",
                rule_ids=("CL-1", "CL-7.6", "CL-8"),
                category="configuration",
                severity=Severity.ERROR,
                message=f"Could not inspect the locked cover-letter PDF baseline: {error}",
                evidence={
                    "baseline_pdf": str(baseline_pdf.resolve()),
                    "error_type": type(error).__name__,
                },
            )
        if len(expected_pages) != 1 or not expected_fonts:
            return QualityFinding(
                check_id="COVER_TYPOGRAPHY_CONTRACT",
                rule_ids=("CL-1", "CL-7.6", "CL-8"),
                category="configuration",
                severity=Severity.ERROR,
                message=(
                    "Locked cover-letter PDF baseline must contain exactly one page "
                    "and visible text-font metrics."
                ),
                evidence={
                    "baseline_pdf": str(baseline_pdf.resolve()),
                    "baseline": self._typography_evidence(
                        expected_pages, expected_fonts
                    ),
                },
            )

        try:
            actual_pages, actual_fonts = self._cover_pdf_typography_metrics(cover_pdf)
        except Exception as error:
            return QualityFinding(
                check_id="COVER_TYPOGRAPHY_CONTRACT",
                rule_ids=("CL-1", "CL-7.6", "CL-8"),
                category="cover-postcompile",
                severity=Severity.ERROR,
                message=f"Could not inspect generated cover-letter typography: {error}",
                evidence={
                    "baseline_pdf": str(baseline_pdf.resolve()),
                    "generated_pdf": str(cover_pdf.resolve()),
                    "error_type": type(error).__name__,
                },
            )

        baseline_size = expected_pages[0]
        wrong_page_sizes = [
            size
            for size in actual_pages
            if abs(size[0] - baseline_size[0]) > _COVER_PAGE_SIZE_TOLERANCE_PT
            or abs(size[1] - baseline_size[1]) > _COVER_PAGE_SIZE_TOLERANCE_PT
        ]
        unexpected_fonts = [
            signature
            for signature in actual_fonts
            if not self._font_signature_is_allowed(signature, expected_fonts)
        ]
        missing_fonts = [
            signature
            for signature in expected_fonts
            if not self._font_signature_is_allowed(signature, actual_fonts)
        ]
        mismatched = bool(
            len(actual_pages) != len(expected_pages)
            or wrong_page_sizes
            or unexpected_fonts
            or missing_fonts
        )
        evidence = {
            "baseline_pdf": str(baseline_pdf.resolve()),
            "generated_pdf": str(cover_pdf.resolve()),
            "font_size_tolerance_pt": _COVER_FONT_SIZE_TOLERANCE_PT,
            "page_size_tolerance_pt": _COVER_PAGE_SIZE_TOLERANCE_PT,
            "baseline": self._typography_evidence(expected_pages, expected_fonts),
            "generated": self._typography_evidence(actual_pages, actual_fonts),
            "unexpected_fonts": self._typography_evidence((), unexpected_fonts)[
                "fonts"
            ],
            "missing_fonts": self._typography_evidence((), missing_fonts)["fonts"],
        }
        return QualityFinding(
            check_id="COVER_TYPOGRAPHY_CONTRACT",
            rule_ids=("CL-1", "CL-7.6", "CL-8"),
            category="cover-postcompile",
            severity=Severity.ERROR if mismatched else Severity.PASS,
            message=(
                "Generated cover-letter font, font-size, or page-size metrics differ "
                "from the locked template PDF baseline."
                if mismatched
                else "Generated cover-letter typography and page size match the locked "
                "template PDF baseline."
            ),
            evidence=evidence,
        )

    def _cover_postcompile_findings(
        self,
        *,
        cover_pdf: Path,
        log_path: Path,
    ) -> tuple[QualityFinding, ...]:
        findings: list[QualityFinding] = []
        try:
            import fitz

            document = fitz.open(cover_pdf)
            try:
                extracted = "\n".join(page.get_text("text", sort=True) for page in document)
            finally:
                document.close()
            missing = [
                phrase
                for phrase in ("Dear", "Kind regards", "Yigit Coskun")
                if phrase.casefold() not in extracted.casefold()
            ]
            if not extracted.strip() or missing or "{{" in extracted:
                details = []
                if not extracted.strip():
                    details.append("no extractable text")
                if missing:
                    details.append("missing " + ", ".join(missing))
                if "{{" in extracted:
                    details.append("unresolved token text")
                findings.append(
                    QualityFinding(
                        check_id="COVER_PDF_TEXT",
                        rule_ids=("CL-2", "CL-6", "CL-8"),
                        category="cover-postcompile",
                        severity=Severity.ERROR,
                        message="Cover-letter PDF text validation failed: " + "; ".join(details),
                        evidence={},
                    )
                )
            else:
                findings.append(
                    QualityFinding(
                        check_id="COVER_PDF_TEXT",
                        rule_ids=("CL-2", "CL-6", "CL-8"),
                        category="cover-postcompile",
                        severity=Severity.PASS,
                        message="Cover-letter PDF contains extractable greeting and closing text.",
                        evidence={"characters": len(extracted)},
                    )
                )
        except Exception as error:
            findings.append(
                QualityFinding(
                    check_id="COVER_PDF_TEXT",
                    rule_ids=("CL-2", "CL-6", "CL-8"),
                    category="cover-postcompile",
                    severity=Severity.ERROR,
                    message=f"Could not inspect cover-letter PDF text: {error}",
                    evidence={"error_type": type(error).__name__},
                )
            )

        try:
            log_text = read_text(log_path)
        except OSError as error:
            findings.append(
                QualityFinding(
                    check_id="COVER_LAYOUT_WARNINGS",
                    rule_ids=("CL-7.6", "CL-8"),
                    category="cover-postcompile",
                    severity=Severity.ERROR,
                    message=f"Could not inspect the cover-letter LaTeX log: {error}",
                    evidence={"error_type": type(error).__name__},
                )
            )
        else:
            overfull = re.findall(r"Overfull \\hbox[^\n]*", log_text)
            findings.append(
                QualityFinding(
                    check_id="COVER_LAYOUT_WARNINGS",
                    rule_ids=("CL-7.6", "CL-8"),
                    category="cover-postcompile",
                    severity=Severity.ERROR if overfull else Severity.PASS,
                    message=(
                        "Cover-letter LaTeX log contains overfull boxes."
                        if overfull
                        else "Cover-letter LaTeX log contains no overfull boxes."
                    ),
                    evidence={"overfull": overfull},
                )
            )
        return tuple(findings)

    def _compile_latex(
        self,
        tex_path: Path,
        build_dir: Path,
        executable: Path,
        command_log: Path,
    ) -> Path:
        all_output: list[str] = []
        for pass_number in (1, 2):
            command = [
                str(executable),
                "-interaction=nonstopmode",
                "-halt-on-error",
                "-file-line-error",
                f"-output-directory={build_dir.resolve()}",
                str(tex_path.resolve()),
            ]
            try:
                result = self._run_command(command)
            except OSError as error:
                raise PipelineError(f"Could not start pdflatex: {error}") from error
            all_output.append(f"===== pass {pass_number} =====\n{result.stdout or ''}")
            if result.returncode != 0:
                command_log.write_text(
                    "\n".join(all_output), encoding="utf-8", newline="\n"
                )
                raise PipelineError(
                    f"pdflatex failed for {tex_path.name} on pass {pass_number} "
                    f"with code {result.returncode}.\n{_tail(result.stdout or '')}"
                )

        command_log.write_text("\n".join(all_output), encoding="utf-8", newline="\n")
        pdf_path = build_dir / f"{tex_path.stem}.pdf"
        if not _is_nonempty_file(pdf_path):
            raise PipelineError(f"pdflatex did not create a non-empty PDF: {pdf_path}")
        return pdf_path

    def _assert_one_page(self, cover_pdf: Path) -> None:
        try:
            import fitz
        except ImportError as error:  # pragma: no cover - installation dependent
            raise PipelineError("PyMuPDF is required to validate the cover letter PDF.") from error
        try:
            document = fitz.open(cover_pdf)
        except Exception as error:
            raise PipelineError(f"Could not inspect cover letter PDF: {error}") from error
        try:
            page_count = document.page_count
        finally:
            document.close()
        if page_count != 1:
            raise PipelineError(
                f"Cover letter must compile to exactly one page; got {page_count}."
            )

    def _archive_atomically(
        self,
        *,
        document_number: int,
        job_pdf: Path,
        request_path: Path,
        output_dir: Path,
        build_dir: Path,
        provider_log: Path,
        cv_pdf: Path,
        cover_pdf: Path,
        artifact_dir: Path,
    ) -> Path:
        cvs_dir = Path(self.paths.cvs_dir)
        destination = cvs_dir / f"job_{document_number}"
        if destination.is_symlink():
            raise PipelineError(f"Archive destination is a symlink: {destination}")

        staging = Path(tempfile.mkdtemp(prefix=f".job_{document_number}.", dir=cvs_dir))
        try:
            shutil.copy2(cv_pdf, staging / CV_PDF_NAME)
            shutil.copy2(cover_pdf, staging / COVER_PDF_NAME)
            shutil.copy2(job_pdf, staging / "job_ad.pdf")
            shutil.copy2(request_path, staging / "application_request.md")
            shutil.copy2(provider_log, staging / "provider.log")
            for name in (VALIDATION_JSON_NAME, VALIDATION_XLSX_NAME):
                shutil.copy2(artifact_dir / name, staging / name)
            for name in GENERATED_FILES:
                shutil.copy2(output_dir / name, staging / name)
            for name in (
                "tailored_cv.log",
                "cover_letter.log",
                "tailored_cv.aux",
                "cover_letter.aux",
            ):
                candidate = build_dir / name
                if candidate.is_file():
                    shutil.copy2(candidate, staging / name)
            for name in ("pdflatex_cv.log", "pdflatex_cover_letter.log"):
                candidate = artifact_dir / name
                if candidate.is_file():
                    shutil.copy2(candidate, staging / name)
            for pattern in ("repair_request_*.md", "provider_repair_*.log"):
                for candidate in sorted(artifact_dir.glob(pattern)):
                    if candidate.is_file():
                        shutil.copy2(candidate, staging / candidate.name)
            # An ad regenerated after a rule change replaces its own folder.
            # The previous one is moved aside first and only deleted once the
            # manifest commits, so a failure never loses both copies.
            superseded: Path | None = None
            if destination.exists():
                superseded = cvs_dir / f".superseded_job_{document_number}.{uuid.uuid4().hex}"
                os.replace(destination, superseded)
            try:
                os.replace(staging, destination)
            except Exception:
                if superseded is not None:
                    os.replace(superseded, destination)
                raise
        except Exception:
            if staging.exists():
                shutil.rmtree(staging)
            raise
        return destination.resolve(), superseded

    def _manifest_row(
        self,
        *,
        job_index: int,
        job_pdf: Path,
        job_hash: str,
        source_hash: str,
        provider: Provider,
        model: str | None,
        effort: str | None,
        document_number: int,
        archive_dir: Path,
    ) -> dict[str, str]:
        cv_file = archive_dir / CV_PDF_NAME
        cl_file = archive_dir / COVER_PDF_NAME
        now = datetime.now()
        return {
            "JobIndex": str(job_index),
            "JobLabel": job_pdf.stem,
            "JobFile": job_pdf.name,
            "JobHash": job_hash,
            "SourceHash": source_hash,
            "Mode": "cv-and-cover",
            "DocumentNumber": str(document_number),
            "OutputFolder": str(archive_dir),
            "CvLabel": f"CV{document_number}",
            "ClLabel": f"CL{document_number}",
            "CvFile": str(cv_file),
            "ClFile": str(cl_file),
            "Status": "Applied",
            "Result": "Waiting",
            "Date": f"{now:%B} {now.day}, {now:%Y}",
            "Provider": provider,
            "Model": model or "",
            "Effort": effort or "",
            "CompletedAt": datetime.now(timezone.utc).isoformat(),
        }

    def _write_manifest(self, manifest: _Manifest) -> None:
        path = self.paths.manifest
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8-sig",
                newline="",
                prefix=f".{path.name}.",
                suffix=".tmp",
                dir=path.parent,
                delete=False,
            ) as stream:
                temporary_path = Path(stream.name)
                writer = csv.DictWriter(
                    stream,
                    fieldnames=manifest.fieldnames,
                    extrasaction="ignore",
                    lineterminator="\n",
                )
                writer.writeheader()
                writer.writerows(manifest.rows)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary_path, path)
            temporary_path = None
        finally:
            if temporary_path is not None and temporary_path.exists():
                temporary_path.unlink()


def run(
    provider: Provider,
    model: str | None = None,
    effort: str | None = None,
    *,
    fresh: bool = False,
    paths: PipelinePaths | None = None,
    executable_resolver: ExecutableResolver | None = None,
    env: Mapping[str, str] | None = None,
    progress: ProgressReporter | None = None,
) -> RunSummary:
    """Functional entry point with injectable filesystem and runtime lookup."""

    return ApplicationPipeline(
        paths,
        executable_resolver=executable_resolver,
        env=env,
        progress=progress,
    ).run(provider, model, effort, fresh=fresh)
