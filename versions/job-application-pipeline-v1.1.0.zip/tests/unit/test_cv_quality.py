from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import types
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from openpyxl import load_workbook

from tests.support import cv_template, fill_regions, valid_skills

from job_application_pipeline.cv_quality import (
    QualityFinding,
    Severity,
    validate_cv_quality,
    write_quality_reports,
)


RULES = """# CV_RULES.md
R-05 keeps the grade in Education only.
R-10 controls evidence tiers.
R-12 prohibits duplicate bullet IDs.
R-25 requires British English.
R-26 prohibits terminal punctuation.
"""

SKILLS = """Skills Profile
1. Master Skills Inventory
Programming: Python, R, SciPy
Data & BI: SQL, Tableau
2. Profile: Data Analyst
5. Evidence Tiers
Tier 3 — Familiar
Tableau, Seaborn, Plotly, SciPy, Shiny
6. CV Skills Section Format
Line 1 — Programming: Python, R, SQL
Line 2 — Methods: Time Series Analysis
Line 3 — Tools & Platforms: Git, Tableau, Power BI
Line 4 — Languages: Turkish (Native), English (C1), German (B1)
7. Quick Adaptation Cheat Sheet
"""

BASE_BULLETS = (
    "E2-EDU [ALL · T1 · CORE] Master's thesis at the Chair of Statistics "
    "and Econometrics: Tracking Inflation (grade 1.3)\n"
    "I1a [ALL · T1 · CORE] Support quantitative labour market research\n"
    "P1a [DS/DA · T1 · CORE] Built an automated preprocessing pipeline\n"
)


def quality_tex(
    *,
    education: str = "Master's thesis at the Chair of Statistics and Econometrics: "
    "Tracking Inflation (grade 1.3)",
    iab: str = "Support quantitative labour market research",
    thesis: str = "Built an automated preprocessing pipeline",
    ziraat: str = "",
    programming: str = "Python",
    summary: str = r"{\small Data analyst with quantitative experience.}",
) -> str:
    def bullet_region(text: str) -> str:
        if not text:
            return ""
        return "\n".join(
            (
                r"\resumeItemListStart",
                rf"\resumeItemPlain{{{text}}}",
                r"\resumeItemListEnd",
            )
        )

    return fill_regions(
        cv_template(),
        {
            "SUMMARY": summary,
            "EDUCATION_FAU_BULLETS": bullet_region(education),
            "EXPERIENCE_IAB_BULLETS": bullet_region(iab),
            "EXPERIENCE_ZIRAAT_BULLETS": bullet_region(ziraat),
            "PROJECT_THESIS_BULLETS": bullet_region(thesis),
            "SKILLS": valid_skills(programming=programming),
        },
    )


def finding(report, check_id: str):
    return next(item for item in report.findings if item.check_id == check_id)


class CVQualitySourceTests(unittest.TestCase):
    def validate(self, directory: Path, tex: str, **overrides):
        tex_path = directory / "tailored_cv.tex"
        tex_path.write_text(tex, encoding="utf-8")
        values = {
            "tex_path": tex_path,
            "job_description": "Python data analyst",
            "cv_rules": RULES,
            "bullet_library": BASE_BULLETS,
            "skills_profiles": SKILLS,
            "generated_at": datetime(2026, 8, 20, 12, 30, tzinfo=timezone.utc),
        }
        values.update(overrides)
        return validate_cv_quality(**values)

    def test_clean_source_checks_have_no_errors(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(
                Path(temporary),
                quality_tex(),
                job_description="--- Page 1 ---\nPython data analyst",
            )

        self.assertFalse(report.has_errors)
        self.assertEqual(finding(report, "EDUCATION_GRADE").severity, Severity.PASS)
        self.assertEqual(finding(report, "EDUCATION_GRADE").rule_ids, ("R-06",))
        self.assertEqual(finding(report, "THESIS_PROJECT_GRADE").severity, Severity.PASS)
        self.assertEqual(finding(report, "THESIS_PROJECT_GRADE").rule_ids, ("R-06",))
        self.assertEqual(finding(report, "BULLET_TERMINAL_PERIOD").severity, Severity.PASS)
        self.assertEqual(finding(report, "US_SPELLING").severity, Severity.PASS)
        self.assertEqual(finding(report, "TIER3_SKILLS").severity, Severity.PASS)
        self.assertEqual(finding(report, "JD_COVERAGE").severity, Severity.PASS)

    def test_grade_placement_and_terminal_period_are_blocking(self) -> None:
        tex = quality_tex(
            education="Master's thesis without the result.",
            thesis="Built an automated preprocessing pipeline (grade 1.3)",
        )
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(Path(temporary), tex)

        self.assertEqual(finding(report, "EDUCATION_GRADE").severity, Severity.ERROR)
        self.assertEqual(finding(report, "THESIS_PROJECT_GRADE").severity, Severity.ERROR)
        self.assertEqual(
            finding(report, "BULLET_TERMINAL_PERIOD").severity, Severity.ERROR
        )

    def test_us_spelling_is_boundary_aware(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            allowed = self.validate(
                directory,
                quality_tex(summary=r"{\small Built a Python analyzer for labour data.}"),
            )
            blocked = self.validate(
                directory,
                quality_tex(summary=r"{\small Analyze labor market data.}"),
            )

        self.assertEqual(finding(allowed, "US_SPELLING").severity, Severity.PASS)
        blocked_check = finding(blocked, "US_SPELLING")
        self.assertEqual(blocked_check.severity, Severity.ERROR)
        self.assertEqual(blocked_check.evidence["terms"], ["analyze", "labor market"])

    def test_exact_posting_title_is_exempt_from_us_spelling_scan(self) -> None:
        title = "Data Scientist / Data Visualization Analyst"
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            allowed = self.validate(
                directory,
                quality_tex(summary=rf"{{\small {title} with quantitative experience.}}"),
                expected_job_title=title,
            )
            blocked = self.validate(
                directory,
                quality_tex(
                    summary=rf"{{\small {title} producing visualization outputs.}}"
                ),
                expected_job_title=title,
            )

        self.assertEqual(finding(allowed, "US_SPELLING").severity, Severity.PASS)
        self.assertEqual(finding(blocked, "US_SPELLING").severity, Severity.ERROR)

    def test_tier_three_skill_requires_explicit_jd_name(self) -> None:
        tex = quality_tex(programming="Python, SciPy")
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            unasked = self.validate(
                directory,
                tex,
                job_description="Scientific Python experience required",
            )
            asked = self.validate(
                directory,
                tex,
                job_description="Python and SciPy experience required",
            )

        self.assertEqual(finding(unasked, "TIER3_SKILLS").severity, Severity.ERROR)
        self.assertEqual(finding(asked, "TIER3_SKILLS").severity, Severity.PASS)

    def test_skills_inventory_blocks_unknown_terms_and_accepts_supported_aliases(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            unknown = self.validate(
                directory,
                quality_tex(programming="Python, TotallyInventedFramework"),
            )
            supported = self.validate(
                directory,
                quality_tex(programming=r"Python, R \& SQL, PowerBI"),
            )

        unknown_check = finding(unknown, "SKILLS_INVENTORY")
        self.assertEqual(unknown_check.severity, Severity.ERROR)
        self.assertEqual(
            unknown_check.evidence["unknown_terms"],
            ["TotallyInventedFramework"],
        )
        self.assertEqual(
            unknown_check.rule_ids,
            ("R-07", "R-08", "R-15", "R-23"),
        )
        self.assertEqual(finding(supported, "SKILLS_INVENTORY").severity, Severity.PASS)

    def test_skills_inventory_handles_compounds_qualifiers_and_source_aliases(
        self,
    ) -> None:
        expanded_source = SKILLS.replace(
            "2. Profile: Data Analyst",
            "\n".join(
                (
                    "Engineering & Cloud: AWS",
                    "Data & BI: Tableau, Excel",
                    "Time Series & Forecasting: Mixed-Frequency Modeling",
                    "Gen AIs / LLMs: Claude Code, ChatGPT Codex",
                    "2. Profile: Data Analyst",
                )
            ),
        )
        supported_value = (
            "Python, Tableau (working knowledge), "
            "AWS (Certificate-Level Knowledge), Generative AI / "
            "Large Language Models (LLMs) (Claude Code, ChatGPT Codex), "
            "Mixed-Frequency Modelling, Microsoft Excel"
        )
        rejected_value = (
            "Python, Polars, Java, Azure, Snowflake, "
            "Don't lead with a tools line"
        )
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            supported = self.validate(
                directory,
                quality_tex(programming=supported_value),
                skills_profiles=expanded_source,
                job_description=(
                    "Python Tableau AWS Generative AI Large Language Models "
                    "Mixed-Frequency Modelling Microsoft Excel"
                ),
            )
            rejected = self.validate(
                directory,
                quality_tex(programming=rejected_value),
                skills_profiles=expanded_source,
            )

        self.assertEqual(finding(supported, "SKILLS_INVENTORY").severity, Severity.PASS)
        rejected_check = finding(rejected, "SKILLS_INVENTORY")
        self.assertEqual(rejected_check.severity, Severity.ERROR)
        self.assertEqual(
            rejected_check.evidence["unknown_terms"],
            ["Polars", "Java", "Azure", "Snowflake", "Don't lead with a tools line"],
        )

    def test_tier_three_terms_follow_source_drift(self) -> None:
        changed_skills = SKILLS.replace(
            "Tableau, Seaborn, Plotly, SciPy, Shiny",
            "Looker",
        )
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            newly_tier_three = self.validate(
                directory,
                quality_tex(programming="Python, Looker"),
                skills_profiles=changed_skills,
            )
            removed_from_tier_three = self.validate(
                directory,
                quality_tex(programming="Python, SciPy"),
                skills_profiles=changed_skills,
            )

        self.assertEqual(
            finding(newly_tier_three, "TIER3_SKILLS").severity, Severity.ERROR
        )
        self.assertEqual(
            finding(removed_from_tier_three, "TIER3_SKILLS").severity,
            Severity.PASS,
        )

    def test_tier_three_slashes_split_but_a_b_remains_one_term(self) -> None:
        changed_skills = SKILLS.replace(
            "Tableau, Seaborn, Plotly, SciPy, Shiny",
            "Looker/Mode, A/B Testing",
        )
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(
                Path(temporary),
                quality_tex(programming="Python, Mode, A/B Testing"),
                job_description="Python and A/B Testing",
                skills_profiles=changed_skills,
            )

        check = finding(report, "TIER3_SKILLS")
        self.assertEqual(check.severity, Severity.ERROR)
        self.assertEqual(check.evidence["listed"], ["A/B Testing", "Mode"])
        self.assertEqual(check.evidence["not_explicitly_requested"], ["Mode"])

    def test_unparseable_tier_three_is_a_source_runtime_error_only(self) -> None:
        malformed_skills = SKILLS.replace(
            "Tier 3 — Familiar\nTableau, Seaborn, Plotly, SciPy, Shiny\n",
            "",
        )
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(
                Path(temporary),
                quality_tex(),
                skills_profiles=malformed_skills,
            )

        latex_findings = [
            item for item in report.findings if item.check_id == "LATEX_STRUCTURE"
        ]
        self.assertEqual(len(latex_findings), 1)
        self.assertEqual(latex_findings[0].severity, Severity.PASS)
        self.assertEqual(
            finding(report, "SOURCE_VALIDATION_RUNTIME").severity,
            Severity.ERROR,
        )

    def test_region_parse_failure_has_one_latex_structure_error(self) -> None:
        malformed = quality_tex().replace(
            "AI_EDIT_START: EDUCATION_FAU_BULLETS",
            "AI_EDIT_START: WRONG_REGION",
            1,
        )
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(Path(temporary), malformed)

        latex_findings = [
            item for item in report.findings if item.check_id == "LATEX_STRUCTURE"
        ]
        self.assertEqual(len(latex_findings), 1)
        self.assertEqual(latex_findings[0].severity, Severity.ERROR)
        self.assertFalse(
            any(item.check_id == "SOURCE_VALIDATION_RUNTIME" for item in report.findings)
        )

    def test_exact_normalised_duplicate_bullets_are_blocking(self) -> None:
        duplicate = "Support quantitative labour market research"
        tex = quality_tex(iab=duplicate, thesis=duplicate)
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(Path(temporary), tex)

        self.assertEqual(
            finding(report, "BULLET_EXACT_DUPLICATES").severity, Severity.ERROR
        )

    def test_heuristics_and_missing_source_ids_are_warning_only(self) -> None:
        tex = quality_tex(iab="Built a financial risk analysis", ziraat="")
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(
                Path(temporary),
                tex,
                job_description="Financial risk analyst",
                bullet_library="No parseable source identifiers in this fixture",
            )

        self.assertEqual(finding(report, "CURRENT_ROLE_TENSE").severity, Severity.WARN)
        self.assertEqual(finding(report, "ZIRAAT_RELEVANCE").severity, Severity.PASS)
        self.assertEqual(finding(report, "BULLET_PROVENANCE").severity, Severity.WARN)
        self.assertEqual(
            finding(report, "BULLET_PROVENANCE").rule_ids,
            ("R-06", "R-12"),
        )
        self.assertNotEqual(finding(report, "BULLET_PROVENANCE").severity, Severity.ERROR)

    def test_ziraat_bullets_are_blocking_for_every_posting(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate(
                Path(temporary),
                quality_tex(ziraat="Added a finance-specific banking bullet"),
                job_description="Banking and credit risk analyst",
            )

        check = finding(report, "ZIRAAT_RELEVANCE")
        self.assertEqual(check.severity, Severity.ERROR)
        self.assertEqual(check.evidence["ziraat_bullet_count"], 1)

    def test_pdf_and_log_must_be_supplied_together(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            tex_path = directory / "tailored_cv.tex"
            tex_path.write_text(quality_tex(), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "supplied together"):
                validate_cv_quality(
                    tex_path=tex_path,
                    job_description="Python",
                    cv_rules=RULES,
                    bullet_library=BASE_BULLETS,
                    skills_profiles=SKILLS,
                    pdf_path=directory / "tailored_cv.pdf",
                )


class _FakePage:
    def __init__(
        self,
        text: str,
        fonts: list[tuple[object, ...]],
        *,
        span_fonts: list[str] | None = None,
    ) -> None:
        self.text = text
        self.fonts = fonts
        if span_fonts is None:
            span_fonts = [
                re.sub(r"^[A-Za-z]{6}\+", "", str(fonts[0][3]))
                if fonts
                else ""
            ]
        self.span_fonts = span_fonts

    def get_text(self, mode: str, *, sort: bool):
        if sort is not True:
            raise AssertionError("deterministic extraction flags were not used")
        if mode == "text":
            return self.text
        if mode == "dict":
            return {
                "blocks": [
                    {
                        "lines": [
                            {
                                "spans": [
                                    {"text": self.text, "font": font}
                                    for font in self.span_fonts
                                ]
                            }
                        ]
                    }
                ]
            }
        raise AssertionError(f"unexpected text extraction mode: {mode}")

    def get_fonts(self, *, full: bool) -> list[tuple[object, ...]]:
        if not full:
            raise AssertionError("full font metadata was not requested")
        return self.fonts


class _FakeDocument:
    def __init__(
        self,
        pages: list[_FakePage],
        *,
        to_unicode: bool = True,
        mapped_xrefs: set[int] | None = None,
    ) -> None:
        self.pages = pages
        self.to_unicode = to_unicode
        self.mapped_xrefs = mapped_xrefs
        self.closed = False

    @property
    def page_count(self) -> int:
        return len(self.pages)

    def load_page(self, page_number: int) -> _FakePage:
        return self.pages[page_number]

    def xref_get_key(self, xref: int, key: str):
        self.assert_key = (xref, key)
        mapped = (
            xref in self.mapped_xrefs
            if self.mapped_xrefs is not None
            else self.to_unicode
        )
        return ("xref", "42 0 R") if mapped else ("null", "null")

    def close(self) -> None:
        self.closed = True


class CVQualityPostcompileTests(unittest.TestCase):
    def validate_post(
        self,
        directory: Path,
        document: _FakeDocument,
        *,
        log: str = "Compilation succeeded\n",
        tex: str | None = None,
    ):
        tex_path = directory / "tailored_cv.tex"
        pdf_path = directory / "tailored_cv.pdf"
        log_path = directory / "tailored_cv.log"
        tex_path.write_text(tex or quality_tex(), encoding="utf-8")
        pdf_path.write_bytes(b"%PDF-fake")
        log_path.write_text(log, encoding="utf-8")
        fake_fitz = types.SimpleNamespace(open=lambda path: document)
        with patch.dict(sys.modules, {"fitz": fake_fitz}):
            return validate_cv_quality(
                tex_path=tex_path,
                pdf_path=pdf_path,
                log_path=log_path,
                job_description="Python data analyst",
                cv_rules=RULES,
                bullet_library=BASE_BULLETS,
                skills_profiles=SKILLS,
            )

    def test_postcompile_checks_text_fonts_and_known_baseline(self) -> None:
        font = (10, "ttf", "Type0", "ABCDEF+EmbeddedFont", "F1", "Identity-H", 0)
        document = _FakeDocument([_FakePage("Yigit Coskun\nData analyst\n", [font])])
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate_post(
                Path(temporary),
                document,
                log="Overfull \\hbox (3.1pt too wide) in paragraph\n",
            )

        self.assertEqual(finding(report, "PDF_TEXT_EXTRACTION").severity, Severity.PASS)
        self.assertEqual(finding(report, "PDF_NAME_FIRST_LINE").severity, Severity.PASS)
        self.assertEqual(finding(report, "PDF_FONT_TOUNICODE").severity, Severity.PASS)
        self.assertEqual(finding(report, "LATEX_OVERFULL").severity, Severity.PASS)
        self.assertTrue(document.closed)

    def test_nfkc_equivalent_unicode_tokens_survive_extraction(self) -> None:
        font = (10, "ttf", "Type0", "ABCDEF+EmbeddedFont", "F1", "Identity-H", 0)
        document = _FakeDocument(
            [_FakePage("Yigit Coskun\nNu\u0308rnberg\n", [font])]
        )
        tex = quality_tex().replace("% fixed CV header", "% Nürnberg", 1)
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate_post(Path(temporary), document, tex=tex)

        self.assertEqual(
            finding(report, "PDF_UNICODE_TOKENS").severity,
            Severity.PASS,
        )

    def test_unused_font_resource_without_tounicode_does_not_block(self) -> None:
        used = (10, "ttf", "Type0", "ABCDEF+EmbeddedFont", "F1", "Identity-H", 0)
        unused = (20, "ttf", "Type0", "GHIJKL+UnusedFont", "F2", "Identity-H", 0)
        page = _FakePage(
            "Yigit Coskun\nData analyst\n",
            [used, unused],
            span_fonts=["EmbeddedFont"],
        )
        document = _FakeDocument([page], mapped_xrefs={10})
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate_post(Path(temporary), document)

        check = finding(report, "PDF_FONT_TOUNICODE")
        self.assertEqual(check.severity, Severity.PASS)
        self.assertEqual(check.evidence["fonts_inspected"], 1)
        self.assertEqual(check.evidence["missing"], [])

    def test_small_new_overfull_box_is_not_the_known_baseline(self) -> None:
        font = (10, "ttf", "Type0", "EmbeddedFont", "F1", "Identity-H", 0)
        document = _FakeDocument([_FakePage("Yigit Coskun\nData analyst\n", [font])])
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate_post(
                Path(temporary),
                document,
                log="Overfull \\hbox (1.0pt too wide) in paragraph\n",
            )

        self.assertEqual(finding(report, "LATEX_OVERFULL").severity, Severity.ERROR)

    def test_postcompile_failures_are_explicit_and_blocking(self) -> None:
        font = (10, "ttf", "Type0", "EmbeddedFont", "F1", "Identity-H", 0)
        pages = [
            _FakePage("Wrong Name\nNürnberg\nEducation\n", [font]),
            _FakePage("Second page\n◦ first ◦ second\n", [font]),
        ]
        document = _FakeDocument(pages, to_unicode=False)
        tex = quality_tex().replace("% fixed CV header", "% Nürnberg Łódź", 1)
        with tempfile.TemporaryDirectory() as temporary:
            report = self.validate_post(
                Path(temporary),
                document,
                tex=tex,
                log="Overfull \\hbox (4.0pt too wide)\n",
            )

        for check_id in (
            "PDF_NAME_FIRST_LINE",
            "PDF_UNICODE_TOKENS",
            "PDF_GLUED_BULLETS",
            "PDF_STRANDED_HEADING",
            "PDF_FONT_TOUNICODE",
            "LATEX_OVERFULL",
        ):
            with self.subTest(check_id=check_id):
                self.assertEqual(finding(report, check_id).severity, Severity.ERROR)


class CVQualityReportTests(unittest.TestCase):
    def test_json_and_xlsx_are_written_from_same_report_and_sanitized(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            tex_path = directory / "tailored_cv.tex"
            tex_path.write_text(quality_tex(), encoding="utf-8")
            report = validate_cv_quality(
                tex_path=tex_path,
                job_description="Python data analyst",
                cv_rules=RULES,
                bullet_library=BASE_BULLETS,
                skills_profiles=SKILLS,
                provider=" =2+2",
                model="test-model",
                generated_at=datetime(2026, 8, 20, 12, 30, tzinfo=timezone.utc),
            ).with_findings(
                QualityFinding(
                    check_id="AI_REPAIR_ATTEMPT_1",
                    rule_ids=(),
                    category="ai-repair",
                    severity=Severity.WARN,
                    message="Codex repaired the title sentence.",
                    evidence={
                        "attempt": 1,
                        "trigger_checks": ["COVER_TEMPLATE_CONTRACT"],
                        "changed_files": ["cover_letter.tex", "change_log.md"],
                        "change_log_notes": "Changed the title sentence.",
                        "provider_log": "provider_repair_1.log",
                    },
                ),
                QualityFinding(
                    check_id="COVER_TEMPLATE_CONTRACT",
                    rule_ids=("CL-1",),
                    category="cover-letter",
                    severity=Severity.WARN,
                    message=" =HYPERLINK(\"https://example.invalid\")",
                    evidence={"raw": "+SUM(1,1)"},
                )
            )
            json_path = directory / "validation.json"
            xlsx_path = directory / "validation.xlsx"

            write_quality_reports(report, json_path=json_path, xlsx_path=xlsx_path)

            payload = json.loads(json_path.read_text(encoding="utf-8"))
            workbook = load_workbook(xlsx_path, data_only=False)

        self.assertEqual(
            workbook.sheetnames,
            ["Summary", "Checks", "Repairs", "Bullets", "JDMatch"],
        )
        self.assertEqual(
            workbook.properties.title,
            "CV and cover-letter validation",
        )
        self.assertEqual(payload["verdict"], report.verdict)
        self.assertEqual(payload["counts"], report.counts)
        self.assertEqual(payload["metadata"]["provider"], " =2+2")
        self.assertEqual(
            payload["checks"][-1]["message"],
            " =HYPERLINK(\"https://example.invalid\")",
        )
        summary_values = {
            row[0].value: row[1].value
            for row in workbook["Summary"].iter_rows(min_row=2, max_col=2)
        }
        self.assertEqual(summary_values["Provider"], "' =2+2")
        checks = workbook["Checks"]
        self.assertEqual(checks.cell(checks.max_row, 1).value, "COVER_TEMPLATE_CONTRACT")
        self.assertEqual(checks.cell(checks.max_row, 5).value, "' =HYPERLINK(\"https://example.invalid\")")
        repairs = workbook["Repairs"]
        self.assertEqual(repairs.max_row, 2)
        self.assertEqual(repairs.cell(2, 1).value, 1)
        self.assertEqual(repairs.cell(2, 3).value, "COVER_TEMPLATE_CONTRACT")
        self.assertEqual(
            repairs.cell(2, 4).value,
            "cover_letter.tex, change_log.md",
        )
        self.assertFalse(list(Path(temporary).glob(".*.tmp")))

    def test_second_report_replace_failure_restores_previous_pair(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            tex_path = directory / "tailored_cv.tex"
            tex_path.write_text(quality_tex(), encoding="utf-8")
            report = validate_cv_quality(
                tex_path=tex_path,
                job_description="Python data analyst",
                cv_rules=RULES,
                bullet_library=BASE_BULLETS,
                skills_profiles=SKILLS,
            )
            json_path = directory / "validation.json"
            xlsx_path = directory / "validation.xlsx"
            write_quality_reports(report, json_path=json_path, xlsx_path=xlsx_path)
            previous_json = json_path.read_bytes()
            previous_xlsx = xlsx_path.read_bytes()
            changed = report.with_findings(
                QualityFinding(
                    check_id="CHANGED",
                    rule_ids=("R-01",),
                    category="test",
                    severity=Severity.WARN,
                    message="new report",
                    evidence={},
                )
            )

            original_replace = os.replace
            failed = False

            def fail_second_destination(source, destination):
                nonlocal failed
                if Path(destination) == xlsx_path and not failed:
                    failed = True
                    raise OSError("simulated second report replacement failure")
                return original_replace(source, destination)

            with patch(
                "job_application_pipeline.cv_quality.os.replace",
                side_effect=fail_second_destination,
            ):
                with self.assertRaisesRegex(OSError, "second report replacement"):
                    write_quality_reports(
                        changed,
                        json_path=json_path,
                        xlsx_path=xlsx_path,
                    )

            self.assertEqual(json_path.read_bytes(), previous_json)
            self.assertEqual(xlsx_path.read_bytes(), previous_xlsx)
            self.assertFalse(list(directory.glob(".*.tmp")))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
