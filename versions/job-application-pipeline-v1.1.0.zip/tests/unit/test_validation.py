from __future__ import annotations

import hashlib
import re
import unittest

from tests.support import (
    COVER_REGIONS,
    CV_REGIONS,
    ROOT,
    fill_regions,
    valid_cover,
    valid_cv,
    valid_skills,
)

from job_application_pipeline.validation import (
    CV_EDIT_REGIONS,
    CV_LOCKED_REGIONS,
    parse_cover_regions,
    parse_cv_regions,
    validate_generated_cover,
    validate_generated_cv,
)


def installed_tailored_cover(
    *,
    job_title: str = "Data Analyst",
    company_name: str = "Acme GmbH",
    company_address: str | None = "Example Street 1",
    company_city: str | None = "90402 Nuremberg",
) -> tuple[str, str]:
    """Fill the installed template while keeping its command scaffold intact."""

    template = (
        ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
    ).read_text(encoding="utf-8")
    generated = template
    values = {
        "{{JOB-TITLE}}": job_title,
        "{{COMPANY-NAME}}": company_name,
        "{{TARGET-TASK}}": "build reliable forecasts",
        "{{TARGET-DOMAIN}}": "quantitative analysis",
    }
    if company_address is not None:
        values["{{COMPANY-ADDRESS}}"] = company_address
    if company_city is not None:
        values["{{COMPANY-CITY}}"] = company_city

    for region in COVER_REGIONS:
        start_marker = f"% AI_EDIT_START: {region}"
        end_marker = f"% AI_EDIT_END: {region}"
        start = generated.index(start_marker) + len(start_marker)
        end = generated.index(end_marker, start)
        body = generated[start:end]
        if company_address is None and company_city is None:
            body = body.replace(
                "{{COMPANY-NAME}}\\\\\n{{COMPANY-ADDRESS}}\\\\\n{{COMPANY-CITY}}",
                "{{COMPANY-NAME}}",
            )
        for token, value in values.items():
            body = body.replace(token, value)
        generated = generated[:start] + body + generated[end:]
    return template, generated


class CvValidationTests(unittest.TestCase):
    def test_exact_nine_anchor_contract_accepts_skills_only_tailoring(self) -> None:
        template, generated = valid_cv()
        _, regions = parse_cv_regions(template)
        self.assertEqual(tuple(regions), CV_REGIONS)
        self.assertEqual(CV_LOCKED_REGIONS, CV_REGIONS[:-1])
        self.assertEqual(CV_EDIT_REGIONS, ("SKILLS",))
        validate_generated_cv(template, generated)

    def test_summary_and_bullet_bodies_are_locked_to_the_template(self) -> None:
        template, generated = valid_cv()
        ziraat = "\n".join(
            (
                r"\resumeItemListStart",
                r"\resumeItemPlain{Added a banking bullet}",
                r"\resumeItemListEnd",
            )
        )
        mutations = {
            "summary rewrite": (
                "Data analyst with supported quantitative experience.",
                "Data scientist with rewritten experience.",
                "SUMMARY",
            ),
            "bullet rewrite": (
                "Build reproducible Python analyses",
                "Built tailored Python pipelines",
                "EXPERIENCE_IAB_BULLETS",
            ),
            "bullet deletion": (
                r"\resumeItemPlain{Build reproducible Python analyses}",
                "",
                "EXPERIENCE_IAB_BULLETS",
            ),
            "bullet addition": (
                r"\resumeItemPlain{Build reproducible Python analyses}",
                r"\resumeItemPlain{Build reproducible Python analyses}"
                "\n"
                r"\resumeItemPlain{Added for this job}",
                "EXPERIENCE_IAB_BULLETS",
            ),
            "bullet internal whitespace": (
                "Build reproducible Python analyses",
                "Build reproducible\n\nPython analyses",
                "EXPERIENCE_IAB_BULLETS",
            ),
            "ziraat population": (
                "% AI_EDIT_START: EXPERIENCE_ZIRAAT_BULLETS",
                "% AI_EDIT_START: EXPERIENCE_ZIRAAT_BULLETS\n" + ziraat,
                "EXPERIENCE_ZIRAAT_BULLETS",
            ),
        }
        for label, (old, new, region) in mutations.items():
            with self.subTest(label=label):
                changed = generated.replace(old, new, 1)
                with self.assertRaisesRegex(
                    ValueError,
                    rf"protected region {region}; only SKILLS may be tailored",
                ):
                    validate_generated_cv(template, changed)

    def test_installed_template_contains_the_fixed_18_bullet_inventory(self) -> None:
        template = (ROOT / "templates" / "cv" / "yigit_coskun_empty.tex").read_text(
            encoding="utf-8"
        )
        _, regions = parse_cv_regions(template)
        expected_counts = {
            "EDUCATION_FAU_BULLETS": 4,
            "EDUCATION_ISTANBUL_BULLETS": 2,
            "EXPERIENCE_IAB_BULLETS": 2,
            "EXPERIENCE_ZIRAAT_BULLETS": 0,
            "PROJECT_THESIS_BULLETS": 4,
            "PROJECT_NOSI_BULLETS": 3,
            "PUBLICATION_POLISH_WORKFORCE_BULLETS": 3,
        }
        self.assertTrue(regions["SUMMARY"].strip().startswith(r"{\small Data Scientist"))
        self.assertEqual(
            {
                name: len(re.findall(r"\\resumeItemPlain\s*\{", regions[name]))
                for name in expected_counts
            },
            expected_counts,
        )
        for ordered_ids in (
            "E1b, E3b, E2-EDU, E5a",
            "B1, B2",
            "I1a, I2b",
            "P1a, P1b, P2a, P3a",
            "N1a, N2a, N3a",
            "PB1, PB3, PB4",
        ):
            self.assertIn(f"Fixed bullet IDs, in order: {ordered_ids}.", template)

        expected_locked_hashes = {
            "SUMMARY": "cab6ae017d3a88f4d5abed2ce97adbf40d2305904aa34b23a9ab5c5153263f5e",
            "EDUCATION_FAU_BULLETS": "b3f65f175da2f8c10c7b2c97a1291eddcfe55a2f1959edff2bc3a39cda7e931d",
            "EDUCATION_ISTANBUL_BULLETS": "9d6f656f77a735ecfe50ffabfed02692c56c162574cf5260a70f0aac1bab33f6",
            "EXPERIENCE_IAB_BULLETS": "965510a2f6a37f7aec39b59655c09c40d191c36d2317083a3a5663435d639736",
            "EXPERIENCE_ZIRAAT_BULLETS": "75a11da44c802486bc6f65640aa48a730f0f684c5c07a42ba3cd1735eb3fb070",
            "PROJECT_THESIS_BULLETS": "ab7ccafbaff0f051aa25acab871880f7336d2614f77a9d54938cd4ace4f0b94d",
            "PROJECT_NOSI_BULLETS": "0ed9a4a3b8ee22e0d0c73d3f07d50adb3c4091295aaa931fa6d04de6391d9939",
            "PUBLICATION_POLISH_WORKFORCE_BULLETS": "1da0bc694c4e107f37ddc7a48339d7b96d85a4a228a48f254a7af8c09d5bd683",
        }
        self.assertEqual(
            {
                name: hashlib.sha256(regions[name].encode("utf-8")).hexdigest()
                for name in CV_LOCKED_REGIONS
            },
            expected_locked_hashes,
        )

    def test_reordering_fixed_bullets_is_rejected(self) -> None:
        template = (ROOT / "templates" / "cv" / "yigit_coskun_empty.tex").read_text(
            encoding="utf-8"
        )
        generated = fill_regions(template, {"SKILLS": valid_skills()})
        _, regions = parse_cv_regions(generated)
        iab_bullets = re.findall(
            r"\\resumeItemPlain\s*\{.*\}",
            regions["EXPERIENCE_IAB_BULLETS"],
        )
        self.assertEqual(len(iab_bullets), 2)
        reordered = generated.replace(iab_bullets[0], "__FIRST_IAB_BULLET__", 1)
        reordered = reordered.replace(iab_bullets[1], iab_bullets[0], 1)
        reordered = reordered.replace("__FIRST_IAB_BULLET__", iab_bullets[1], 1)
        self.assertNotEqual(reordered, generated)

        with self.assertRaisesRegex(
            ValueError,
            r"protected region EXPERIENCE_IAB_BULLETS; only SKILLS may be tailored",
        ):
            validate_generated_cv(template, reordered)

    def test_fixed_content_change_is_rejected(self) -> None:
        template, generated = valid_cv()
        changed = generated.replace("% fixed CV header", "% changed CV header", 1)
        with self.assertRaisesRegex(ValueError, "fixed template content"):
            validate_generated_cv(template, changed)

    def test_a_blank_line_beside_a_marker_is_a_note_not_a_failure(self) -> None:
        # Models routinely leave an extra blank line next to an edit marker.
        # It cannot change the rendered page, and the compile, page-count, and
        # overfull-box checks downstream would catch it if it ever did.
        template, generated = valid_cv()
        spaced = generated.replace(
            "% AI_EDIT_END: SUMMARY\n", "% AI_EDIT_END: SUMMARY\n\n", 1
        )
        self.assertNotEqual(spaced, generated)
        notes = validate_generated_cv(template, spaced)
        self.assertEqual(len(notes), 1)
        self.assertIn("only whitespace", notes[0])
        self.assertIn("after SUMMARY", notes[0])

    def test_an_unchanged_cv_reports_no_notes(self) -> None:
        template, generated = valid_cv()
        self.assertEqual(validate_generated_cv(template, generated), [])

    def test_missing_or_reordered_region_is_rejected(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace("AI_EDIT_START: EDUCATION_FAU_BULLETS", "AI_EDIT_START: WRONG", 1)
        with self.assertRaisesRegex(ValueError, "Unexpected CV edit region"):
            validate_generated_cv(template, malformed)

    def test_malformed_skills_are_rejected(self) -> None:
        template, generated = valid_cv()
        malformed = generated.replace(
            r"\item{\textbf{Methods}{: Time-series analysis}}",
            r"\item{\textbf{Wrong label}{: Time-series analysis}}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "SKILLS item 2 is malformed"):
            validate_generated_cv(template, malformed)

    def test_skills_values_reject_layout_commands_placeholders_and_unescaped_latex(
        self,
    ) -> None:
        mutations = (
            ("Python", r"Python, \vspace{2cm}R", "formatting/layout command"),
            ("Python", r"Python, \newpage R", "formatting/layout command"),
            ("Python", "Python, {{TOOL}}", "unresolved placeholder"),
            ("Python", "Python, [TOOL]", "unresolved placeholder"),
            ("Python", "Python & R", "unescaped LaTeX character"),
        )
        for old, new, message in mutations:
            with self.subTest(value=new):
                template, generated = valid_cv()
                malformed = generated.replace(
                    rf"\textbf{{Programming}}{{: {old}}}",
                    rf"\textbf{{Programming}}{{: {new}}}",
                    1,
                )
                with self.assertRaisesRegex(ValueError, message):
                    validate_generated_cv(template, malformed)

    def test_skills_values_allow_required_text_escapes(self) -> None:
        template, generated = valid_cv()
        escaped = generated.replace(
            r"\textbf{Programming}{: Python}",
            r"\textbf{Programming}{: Python, R \& SQL, \textasciitilde{}27,000 files}",
            1,
        )
        validate_generated_cv(template, escaped)

    def test_stray_content_in_bullet_region_is_rejected(self) -> None:
        template, generated = valid_cv()
        malformed_template = template.replace(
            r"\resumeItemPlain{Build reproducible Python analyses}",
            "stray text\n" + r"\resumeItemPlain{Build reproducible Python analyses}",
            1,
        )
        malformed = generated.replace(
            r"\resumeItemPlain{Build reproducible Python analyses}",
            "stray text\n" + r"\resumeItemPlain{Build reproducible Python analyses}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "outside its plain bullet commands"):
            validate_generated_cv(malformed_template, malformed)

    def test_prohibited_tool_spelling_variants_are_rejected(self) -> None:
        for variant in ("Spark", "PySpark", "Py-Spark", "Kubernetes"):
            with self.subTest(variant=variant):
                template, generated = valid_cv(programming=f"Python, {variant}")
                with self.assertRaisesRegex(ValueError, "explicitly excluded tools"):
                    validate_generated_cv(template, generated)

    def test_power_bi_is_an_allowed_tool(self) -> None:
        # Power BI is in the skills inventory; an underscore still needs the
        # normal LaTeX escape when mirroring a posting's exact spelling.
        for variant in ("Power BI", "PowerBI", "Power-BI", r"power\_bi"):
            with self.subTest(variant=variant):
                template, generated = valid_cv(programming=f"Python, {variant}")
                validate_generated_cv(template, generated)

    def test_summary_requires_single_small_wrapper(self) -> None:
        template, generated = valid_cv()
        malformed_template = template.replace(
            r"{\small Data analyst with supported quantitative experience.}",
            "Data analyst with supported quantitative experience.",
            1,
        )
        malformed = generated.replace(
            r"{\small Data analyst with supported quantitative experience.}",
            "Data analyst with supported quantitative experience.",
            1,
        )
        with self.assertRaisesRegex(ValueError, "exactly one"):
            validate_generated_cv(malformed_template, malformed)


class CoverValidationTests(unittest.TestCase):
    def test_final_company_or_address_line_cannot_have_a_dangling_separator(
        self,
    ) -> None:
        template, generated = installed_tailored_cover(
            company_address=None,
            company_city=None,
        )
        dangling = generated.replace(
            "Acme GmbH\n\\end{minipage}",
            "Acme GmbH\\\\\n\\end{minipage}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "must not end with a line separator"):
            validate_generated_cover(template, dangling)

    def test_new_formatting_and_layout_commands_are_rejected_in_edit_regions(
        self,
    ) -> None:
        commands = (
            r"\Huge",
            r"\fontsize{18}{22}\selectfont",
            r"\linespread{2}",
            r"\setlength{\parskip}{2cm}",
            r"\vspace{1cm}",
            r"\hspace{1cm}",
            r"\geometry{margin=0cm}",
            r"\newgeometry{margin=0cm}",
            r"\pagebreak",
            r"\newpage",
        )
        for command in commands:
            with self.subTest(command=command):
                template, generated = valid_cover()
                injected = generated.replace(
                    "bring a quantitative perspective",
                    f"bring {command} a quantitative perspective",
                    1,
                )
                with self.assertRaisesRegex(ValueError, "formatting/layout command"):
                    validate_generated_cover(template, injected)

    def test_huge_is_rejected_when_injected_into_the_header_title(self) -> None:
        template, generated = installed_tailored_cover()
        injected = generated.replace(
            "Cover Letter for Data Analyst",
            r"Cover Letter for \Huge Data Analyst",
            1,
        )
        with self.assertRaisesRegex(ValueError, r"formatting/layout command: \\Huge"):
            validate_generated_cover(template, injected)

    def test_cover_header_layout_is_compared_with_the_template(self) -> None:
        template, generated = installed_tailored_cover()
        changed_width = generated.replace(
            r"\begin{minipage}[t]{0.48\textwidth}",
            r"\begin{minipage}[t]{0.60\textwidth}",
            1,
        )
        with self.assertRaisesRegex(ValueError, "structure fixed by the template"):
            validate_generated_cover(template, changed_width)

    def test_header_tokens_allow_address_deletion_and_escaped_special_chars(
        self,
    ) -> None:
        template, generated = installed_tailored_cover(
            job_title=r"Data \& Product Analyst",
            company_name=r"Research \& Data GmbH",
            company_address=None,
            company_city=None,
        )
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data & Product Analyst",
        )

    def test_installed_cover_template_accepts_token_only_tailoring(self) -> None:
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Data Analyst",
            "{{COMPANY-NAME}}": "Acme GmbH",
            "{{COMPANY-ADDRESS}}": "Example Street 1",
            "{{COMPANY-CITY}}": "90402 Nuremberg",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        validate_generated_cover(template, generated)

    def test_installed_cover_template_accepts_a_posting_without_an_address(
        self,
    ) -> None:
        # COVER_LETTER_RULES.md requires an unknown address or city line to be
        # deleted together with its trailing "\\", leaving the company name as
        # the last line of the block. LinkedIn postings carry no street
        # address, so this is the normal case rather than an edge case.
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Junior Quant Researcher",
            "{{COMPANY-NAME}}": "BIT Capital",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            # Delete the unknown lines cleanly, leaving no dangling separator.
            body = body.replace(
                "{{COMPANY-NAME}}\\\\\n{{COMPANY-ADDRESS}}\\\\\n{{COMPANY-CITY}}",
                "{{COMPANY-NAME}}",
            )
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        # The template's comment block documents the tokens, so only the edit
        # regions are checked for unresolved ones.
        _fixed, generated_regions = parse_cover_regions(generated)
        self.assertNotIn("{{", "".join(generated_regions.values()))
        self.assertNotIn("BIT Capital\\\\", generated_regions["COVER_HEADER"])
        validate_generated_cover(template, generated)

    def test_installed_cover_template_accepts_a_looked_up_german_address(
        self,
    ) -> None:
        # The rules permit an online address lookup, and German street names
        # routinely carry an umlaut or a sharp s.
        template = (
            ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
        ).read_text(encoding="utf-8")
        generated = template
        token_values = {
            "{{JOB-TITLE}}": "Junior Quant Researcher",
            "{{COMPANY-NAME}}": "BIT Capital",
            "{{COMPANY-ADDRESS}}": "Dircksenstraße 4",
            "{{COMPANY-CITY}}": "10179 Nürnberg",
            "{{TARGET-TASK}}": "build reliable forecasts",
            "{{TARGET-DOMAIN}}": "quantitative analysis",
        }
        for region in COVER_REGIONS:
            start_marker = f"% AI_EDIT_START: {region}"
            end_marker = f"% AI_EDIT_END: {region}"
            start = generated.index(start_marker) + len(start_marker)
            end = generated.index(end_marker, start)
            body = generated[start:end]
            for token, value in token_values.items():
                body = body.replace(token, value)
            generated = generated[:start] + body + generated[end:]

        validate_generated_cover(template, generated)

    def test_company_name_missing_from_the_header_is_still_rejected(self) -> None:
        template, generated = valid_cover()
        without_company = generated.replace("Acme GmbH\n", "")
        with self.assertRaises(ValueError):
            validate_generated_cover(template, without_company)

    def test_exact_seven_region_contract_accepts_valid_cover(self) -> None:
        template, generated = valid_cover()
        _, regions = parse_cover_regions(template)
        self.assertEqual(tuple(regions), COVER_REGIONS)
        validate_generated_cover(template, generated)

    def test_fixed_content_change_is_rejected(self) -> None:
        template, generated = valid_cover()
        changed = generated.replace("% fixed cover letter header", "% changed cover header", 1)
        with self.assertRaisesRegex(ValueError, "fixed template content"):
            validate_generated_cover(template, changed)

    def test_placeholders_are_rejected(self) -> None:
        for placeholder in (
            "{{COMPANY}}",
            "[Hiring Manager]",
            "[Company Address Line 1]",
            "[City, Country]",
        ):
            with self.subTest(placeholder=placeholder):
                template, generated = valid_cover()
                generated = generated.replace("Acme GmbH", placeholder, 1)
                with self.assertRaisesRegex(ValueError, "unresolved"):
                    validate_generated_cover(template, generated)

    def test_greeting_must_begin_with_dear(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("Dear Hiring Team,", "Hello Hiring Team,", 1)
        with self.assertRaisesRegex(ValueError, "begin with 'Dear'"):
            validate_generated_cover(template, generated)

    def test_noindent_dear_and_latex_position_option_are_accepted(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace(
            r"\noindent Dear Hiring Team,", r"{\noindent Dear Hiring Team,}", 1
        )
        validate_generated_cover(template, generated)

    def test_closing_must_contain_kind_regards(self) -> None:
        template, generated = valid_cover()
        template = template.replace("Kind regards", "Sincerely", 1)
        generated = generated.replace("Kind regards", "Sincerely", 1)
        with self.assertRaisesRegex(ValueError, "Kind regards"):
            validate_generated_cover(template, generated)

    def test_fixed_evidence_cannot_be_changed(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("44,000", "45,000", 1)
        with self.assertRaisesRegex(ValueError, "fixed evidence"):
            validate_generated_cover(template, generated)

    def test_job_title_and_company_values_must_be_consistent(self) -> None:
        template, generated = valid_cover()
        inconsistent_title = generated.replace(
            "fit for the Data Analyst role", "fit for the Data Scientist role", 1
        )
        with self.assertRaisesRegex(ValueError, "inconsistent job-title"):
            validate_generated_cover(template, inconsistent_title)

        inconsistent_company = generated.replace(
            "experience to Acme GmbH", "experience to Other GmbH", 1
        )
        with self.assertRaisesRegex(ValueError, "inconsistent company-name"):
            validate_generated_cover(template, inconsistent_company)

    def test_job_title_must_match_deterministic_clean_title(self) -> None:
        template, generated = valid_cover()
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data Analyst",
        )

        generated_with_suffix = generated.replace(
            "Data Analyst",
            "Data Analyst (Remote)",
        )
        with self.assertRaisesRegex(ValueError, "deterministic clean title"):
            validate_generated_cover(
                template,
                generated_with_suffix,
                expected_job_title="Data Analyst",
            )

    def test_cover_title_may_drop_trailing_words_but_not_add_them(self) -> None:
        template, generated = valid_cover()
        # The fixture letter uses "Data Analyst" in all four places.
        validate_generated_cover(
            template, generated, expected_job_title="Data Analyst Summer Programme"
        )
        validate_generated_cover(template, generated, expected_job_title="Data Analyst")

        for wrong in ("Analyst", "Senior Data Analyst", "Data Scientist", "Analyst Data"):
            with self.subTest(expected=wrong):
                with self.assertRaisesRegex(ValueError, "deterministic clean title"):
                    validate_generated_cover(
                        template, generated, expected_job_title=wrong
                    )

    def test_grammatical_in_the_role_title_sentence_is_accepted(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace(
            "what I can do as a Data Analyst.",
            "what I can do in the Data Analyst role.",
        )
        validate_generated_cover(
            template,
            generated,
            expected_job_title="Data Analyst",
        )

    def test_a_latex_escaped_title_matches_the_clean_title(self) -> None:
        # "Data & Product Engineer" must be written as "Data \\& Product
        # Engineer" to compile, so the comparison has to see through escaping.
        template, generated = valid_cover()
        escaped = generated.replace("Data Analyst", "Data \\& Product Engineer")
        validate_generated_cover(
            template, escaped, expected_job_title="Data & Product Engineer"
        )
        # Shortening still works through the escaping.
        validate_generated_cover(
            template,
            generated.replace("Data Analyst", "Data \\& Product"),
            expected_job_title="Data & Product Engineer",
        )
        # A different title is still rejected.
        with self.assertRaisesRegex(ValueError, "deterministic clean title"):
            validate_generated_cover(
                template, escaped, expected_job_title="Data & Platform Engineer"
            )

    def test_spaced_gender_marker_is_rejected_from_cover_title(self) -> None:
        template, generated = valid_cover()
        generated = generated.replace("Data Analyst", "Data Analyst (x m d)")
        with self.assertRaisesRegex(ValueError, "logistics or unearned seniority"):
            validate_generated_cover(template, generated)

    def test_blocked_claims_em_dash_and_unescaped_latex_are_rejected(self) -> None:
        for old, new, expected in (
            ("data analysis", "big data processing", "blocked claims"),
            ("data analysis", "MLOps work", "blocked claims"),
            ("data analysis", "data—analysis", "em dash"),
            ("Acme GmbH", "Acme & Partners", "unescaped LaTeX"),
        ):
            with self.subTest(new=new):
                template, generated = valid_cover()
                generated = generated.replace(old, new)
                with self.assertRaisesRegex(ValueError, expected):
                    validate_generated_cover(template, generated)

    def test_dashboard_and_bi_wording_is_allowed(self) -> None:
        # Power BI is in the skills inventory, and a posting may be about
        # dashboard work; the wording is no longer a blocked claim.
        template, generated = valid_cover()
        generated = generated.replace("data analysis", "dashboard and BI reporting")
        validate_generated_cover(template, generated)

    def test_posting_proper_nouns_are_exempt_from_claim_and_style_scans(self) -> None:
        # A role name is quoted from the posting. "Data Visualization Analyst"
        # keeps its American spelling and "Big Data Engineer" is not a claim to
        # distributed experience, but the same words in prose still fail.
        for role in ("Data Visualization Analyst", "Big Data Engineer"):
            with self.subTest(role=role):
                template, generated = valid_cover()
                titled = generated.replace("Data Analyst", role)
                validate_generated_cover(
                    template, titled, expected_job_title=role
                )

        template, generated = valid_cover()
        in_prose = generated.replace(
            "I built an inflation workflow", "I built big data visualization work"
        )
        with self.assertRaises(ValueError):
            validate_generated_cover(template, in_prose)


if __name__ == "__main__":
    unittest.main()
