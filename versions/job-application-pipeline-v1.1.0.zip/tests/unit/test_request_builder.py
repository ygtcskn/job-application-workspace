from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests.support import ROOT, write_project_source_pack

from job_application_pipeline.paths import Paths
from job_application_pipeline.request_builder import (
    build_request,
    clean_job_title,
    extract_clean_job_title,
)


class RequestBuilderTests(unittest.TestCase):
    def test_installed_request_contract_allows_only_skills_tailoring(self) -> None:
        prompt = (ROOT / "config" / "prompts" / "application.md").read_text(
            encoding="utf-8"
        )

        self.assertIn("Regions 1--8 are locked content anchors", prompt)
        self.assertIn("only CV body", prompt)
        self.assertIn("region 9, `SKILLS`", prompt)
        self.assertIn("fixed CV profile is Data Scientist", prompt)
        self.assertIn("Do not select, omit, add", prompt)
        self.assertNotIn("Current bullet and skill entry tags govern selection", prompt)

    def test_request_embeds_every_cv_cover_and_job_source(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "job_py"
            write_project_source_pack(project)
            paths = Paths(
                project_root=project,
                job_ads_dir=root / "Job_ad",
                cvs_dir=root / "CVs",
            )
            job_pdf = root / "Job_ad" / "Acme.pdf"
            job_pdf.parent.mkdir()
            job_pdf.write_bytes(b"job PDF fixture")
            output_dir = project / ".artifacts" / "job_1" / "output"

            with patch(
                "job_application_pipeline.request_builder.extract_pdf_text",
                return_value=(
                    "--- Page 1 ---\n"
                    "Data Analyst (Remote)\n"
                    "Company: Acme GmbH\n"
                    "EXTRACTED JOB DESCRIPTION"
                ),
            ):
                request = build_request(paths, job_pdf, output_dir)

            self.assertIn("Use only approved evidence.", request)
            self.assertIn("IAB1", request)
            self.assertIn("Build reproducible Python analyses", request)
            self.assertIn("APPROVED SKILLS PROFILE ENTRY", request)
            self.assertIn("AI_EDIT_START: SUMMARY", request)
            self.assertIn("Approved test-only cover-letter rules", request)
            self.assertIn("AI_EDIT_START: COVER_HEADER", request)
            self.assertIn("AI_EDIT_START: PARA_5_CLOSE", request)
            self.assertIn("EXTRACTED JOB DESCRIPTION", request)
            self.assertIn("CLEAN TITLE\nData Analyst", request)
            self.assertIn(str(output_dir.resolve()), request)
            self.assertNotRegex(
                request,
                r"\{\{(?:OUTPUT_DIR|CLEAN_JOB_TITLE|CV_RULES|BULLET_LIBRARY|"
                r"SKILLS_PROFILES|CV_TEMPLATE|COVER_RULES|COVER_TEMPLATE|"
                r"JOB_DESCRIPTION)\}\}",
            )

    def test_job_title_cleaner_removes_only_title_metadata(self) -> None:
        cases = {
            "Data Analyst (Remote)": "Data Analyst",
            "Data Analyst (x m d)": "Data Analyst",
            "Data Analyst (m/w/d)": "Data Analyst",
            "Senior Data Scientist | Pricing Team": "Data Scientist",
            "Risk Analyst (Credit Risk) - Hybrid": "Risk Analyst (Credit Risk)",
        }
        for source, expected in cases.items():
            with self.subTest(source=source):
                self.assertEqual(clean_job_title(source), expected)

    def test_job_title_cleaner_removes_engagement_qualifiers(self) -> None:
        # An engagement type describes the contract, not the role, and postings
        # put it before or after the role name.
        cases = {
            "Data Analyst Internships": "Data Analyst",
            "Data Analyst (Intern)": "Data Analyst",
            "Data Analyst Internship (m/w/d)": "Data Analyst",
            "Data Analyst - Werkstudent": "Data Analyst",
            "Data Scientist Trainee Programme": "Data Scientist",
            "Working Student Data Analyst": "Data Analyst",
            "Praktikum Data Analyst": "Data Analyst",
            "Internship Data Scientist": "Data Scientist",
            # A qualifier that is the whole title has no role name to keep.
            "Intern": "Intern",
            # An unrelated trailing word is not an engagement type.
            "Data Analyst Pricing": "Data Analyst Pricing",
        }
        for source, expected in cases.items():
            with self.subTest(source=source):
                self.assertEqual(clean_job_title(source), expected)

    def test_clean_title_comes_from_first_pdf_heading(self) -> None:
        extracted = (
            "--- Page 1 ---\n"
            "Data Analyst (x m d)\n"
            "Company: Acme GmbH\n"
            "Location: Remote\n"
        )
        self.assertEqual(extract_clean_job_title(extracted), "Data Analyst")

    def test_complete_body_title_repairs_a_truncated_heading(self) -> None:
        extracted = (
            "--- Page 1 ---\n"
            "Junior Data Analys\n"
            "Company: IoT-UC\n"
            "Role Description This is a part-time remote role for a "
            "Junior Data Analyst at IoT-UC. The Junior Data Analyst will help.\n"
        )
        self.assertEqual(extract_clean_job_title(extracted), "Junior Data Analyst")

    def test_missing_cover_pack_fails_before_job_pdf_extraction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "job_py"
            write_project_source_pack(project, include_cover=False)
            paths = Paths(project_root=project)
            job_pdf = root / "Job_ad" / "Acme.pdf"
            job_pdf.parent.mkdir()
            job_pdf.write_bytes(b"job PDF fixture")

            with patch(
                "job_application_pipeline.request_builder.extract_pdf_text"
            ) as pdf_extractor:
                with self.assertRaises(FileNotFoundError):
                    build_request(paths, job_pdf, project / ".artifacts" / "output")
            pdf_extractor.assert_not_called()


if __name__ == "__main__":
    unittest.main()
