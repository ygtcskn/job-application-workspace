from __future__ import annotations

import shutil
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

CV_REGIONS = (
    "SUMMARY",
    "EDUCATION_FAU_BULLETS",
    "EDUCATION_ISTANBUL_BULLETS",
    "EXPERIENCE_IAB_BULLETS",
    "EXPERIENCE_ZIRAAT_BULLETS",
    "PROJECT_THESIS_BULLETS",
    "PROJECT_NOSI_BULLETS",
    "PUBLICATION_POLISH_WORKFORCE_BULLETS",
    "SKILLS",
)

COVER_REGIONS = (
    "COVER_HEADER",
    "SALUTATION",
    "PARA_1_HOOK_THESIS",
    "PARA_2_IAB",
    "PARA_3_FIT",
    "PARA_4_MOTIVATION",
    "PARA_5_CLOSE",
)


def marked_template(regions: tuple[str, ...], *, title: str) -> str:
    parts = [r"\documentclass{article}", rf"% fixed {title} header", r"\begin{document}"]
    for name in regions:
        parts.extend(
            (
                f"% AI_EDIT_START: {name}",
                f"% AI_EDIT_END: {name}",
                rf"% fixed after {name}",
            )
        )
    parts.append(r"\end{document}")
    return "\n".join(parts) + "\n"


def fill_regions(template: str, replacements: dict[str, str]) -> str:
    generated = template
    for name, content in replacements.items():
        marker = f"% AI_EDIT_START: {name}"
        generated = generated.replace(marker, f"{marker}\n{content}", 1)
    return generated


def cv_template() -> str:
    return marked_template(CV_REGIONS, title="CV")


def valid_skills(*, programming: str = "Python") -> str:
    return "\n".join(
        (
            r"\resumeSubHeadingListStart",
            rf"\item{{\textbf{{Programming}}{{: {programming}}}}}",
            r"\item{\textbf{Methods}{: Time-series analysis}}",
            r"\item{\textbf{Tools \& Platforms}{: Git}}",
            r"\item{\textbf{Languages}{: Turkish (Native), English (C1), German (B1)}}",
            r"\resumeSubHeadingListEnd",
        )
    )


def valid_cv(*, programming: str = "Python") -> tuple[str, str]:
    template = fill_regions(
        cv_template(),
        {
            "SUMMARY": r"{\small Data analyst with supported quantitative experience.}",
            "EDUCATION_FAU_BULLETS": "\n".join(
                (
                    r"\resumeItemListStart",
                    r"\resumeItemPlain{Completed the Master's thesis with a grade of 1.7}",
                    r"\resumeItemListEnd",
                )
            ),
            "EXPERIENCE_IAB_BULLETS": "\n".join(
                (
                    r"\resumeItemListStart",
                    r"\resumeItemPlain{Build reproducible Python analyses}",
                    r"\resumeItemListEnd",
                )
            ),
            "PROJECT_THESIS_BULLETS": "\n".join(
                (
                    r"\resumeItemListStart",
                    r"\resumeItemPlain{Developed a supported quantitative thesis analysis}",
                    r"\resumeItemListEnd",
                )
            ),
        },
    )
    generated = fill_regions(
        template,
        {"SKILLS": valid_skills(programming=programming)},
    )
    return template, generated


def cover_template() -> str:
    return marked_template(COVER_REGIONS, title="cover letter").replace(
        r"\end{document}",
        "Kind regards,\\\\\nYigit Coskun\n" + r"\end{document}",
    )


def valid_cover_regions() -> dict[str, str]:
    return {
        "COVER_HEADER": "\n".join(
            (
                r"\noindent\begin{minipage}{\textwidth}",
                r"\textbf{\Large Cover Letter for Data Analyst}\\",
                r"\end{minipage}",
                r"\begin{minipage}[t]{0.48\textwidth}",
                r"\raggedright",
                r"Acme GmbH",
                r"\end{minipage}",
                r"\begin{minipage}[t]{0.45\textwidth}",
                r"Yigit Coskun\\",
                r"Zerzabelshofstrasse 9\\",
                r"90478 Nuremberg\\",
                r"contact@yigitcoskun.com\\",
                r"+49 176 45819490",
                r"\end{minipage}",
            )
        ),
        "SALUTATION": r"\noindent Dear Hiring Team,",
        "PARA_1_HOOK_THESIS": (
            r"\noindent I built an inflation workflow covering 15 economies and 20 years, "
            r"including 27,000 Google Trends files, and evaluated it over a 69-month period. "
            "This experience is what drew me to the Data Analyst role."
        ),
        "PARA_2_IAB": (
            r"\noindent I work at the Institute for Employment Research (IAB) across "
            "Statistical Methods (KEM) and Migration and International Labour Studies "
            "(INTER), using R and Stata with 44,000 respondents, histories since 1975, "
            "and 19,900 records, and contributing to work on Polish workers in Germany."
        ),
        "PARA_3_FIT": (
            r"\noindent I am motivated by the opportunity to contribute to Acme GmbH and "
            "bring a quantitative perspective to data analysis."
        ),
        "PARA_4_MOTIVATION": (
            r"\noindent I use TensorFlow, Python, and R in supported analysis at IAB, and "
            "I am steadily widening what I can do as a Data Analyst."
        ),
        "PARA_5_CLOSE": (
            r"\noindent I would bring my quantitative background and data experience to "
            "Acme GmbH and would welcome the opportunity to discuss my fit for the "
            "Data Analyst role."
        ),
    }


def valid_cover() -> tuple[str, str]:
    template = cover_template()
    generated = fill_regions(template, valid_cover_regions())
    return template, generated


def write_docx(path: Path, *, paragraphs: list[str], table: list[list[str]] | None = None) -> None:
    namespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    def paragraph(value: str) -> str:
        return f'<w:p><w:r><w:t xml:space="preserve">{value}</w:t></w:r></w:p>'

    blocks = [paragraph(value) for value in paragraphs]
    if table:
        rows = []
        for values in table:
            cells = "".join(f"<w:tc>{paragraph(value)}</w:tc>" for value in values)
            rows.append(f"<w:tr>{cells}</w:tr>")
        blocks.append(f"<w:tbl>{''.join(rows)}</w:tbl>")
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:document xmlns:w="{namespace}"><w:body>{"".join(blocks)}</w:body></w:document>'
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as package:
        package.writestr("word/document.xml", document)


def install_cover_fixture(project_root: Path) -> tuple[Path, Path]:
    fixture_root = ROOT / "tests" / "fixtures" / "cover_pack"
    reference_dir = project_root / "data" / "reference" / "cover_letter"
    template_dir = project_root / "templates" / "cover_letter"
    reference_dir.mkdir(parents=True, exist_ok=True)
    template_dir.mkdir(parents=True, exist_ok=True)
    rules = reference_dir / "COVER_LETTER_RULES.md"
    template = template_dir / "yigit_coskun_cover_letter.tex"
    shutil.copyfile(fixture_root / rules.name, rules)
    shutil.copyfile(fixture_root / template.name, template)
    return rules, template


def write_project_source_pack(project_root: Path, *, include_cover: bool = True) -> None:
    cv_reference = project_root / "data" / "reference" / "cv"
    cv_reference.mkdir(parents=True, exist_ok=True)
    (cv_reference / "CV_RULES.md").write_text(
        "# Test CV rules\nUse only approved evidence.\n",
        encoding="utf-8",
    )
    write_docx(
        cv_reference / "bullet_library.docx",
        paragraphs=[
            "FAU1 [DA · T1 · CORE] Completed the Master's thesis with a grade of 1.7",
            "IAB1 [DA · T1 · CORE] Build reproducible Python analyses",
            "TH1 [DA · T1 · CORE] Developed a supported quantitative thesis analysis",
        ],
    )
    write_docx(
        cv_reference / "skills_profiles.docx",
        paragraphs=["APPROVED SKILLS PROFILE ENTRY"],
    )
    cv_template_path = project_root / "templates" / "cv" / "yigit_coskun_empty.tex"
    cv_template_path.parent.mkdir(parents=True, exist_ok=True)
    locked_cv_template, _ = valid_cv()
    cv_template_path.write_text(locked_cv_template, encoding="utf-8")

    if include_cover:
        install_cover_fixture(project_root)

    prompt = project_root / "config" / "prompts" / "application.md"
    prompt.parent.mkdir(parents=True, exist_ok=True)
    prompt.write_text(
        "\n".join(
            (
                "OUTPUT={{OUTPUT_DIR}}",
                "CLEAN TITLE\n{{CLEAN_JOB_TITLE}}",
                "CV RULES\n{{CV_RULES}}",
                "BULLETS\n{{BULLET_LIBRARY}}",
                "SKILLS\n{{SKILLS_PROFILES}}",
                "CV TEMPLATE\n{{CV_TEMPLATE}}",
                "COVER RULES\n{{COVER_RULES}}",
                "COVER TEMPLATE\n{{COVER_TEMPLATE}}",
                "JOB\n{{JOB_DESCRIPTION}}",
            )
        )
        + "\n",
        encoding="utf-8",
    )
