# CV_RULES.md

Rules for filling `yigit_coskun_empty.tex`. The CV is a fixed Data Scientist
document. The AI writes **only the Skills region**; the installed summary and
all bullet points stay unchanged for every job advertisement.

Sources of truth:

- `yigit_coskun_empty.tex` owns the fixed S-DS summary and fixed bullet text,
  placement, and order.
- `skills_profiles.docx` owns the adaptive skills inventory, evidence tiers,
  scope limits, and four-line Skills format. Re-read it every run.
- `bullet_library.docx` remains evidence and provenance support for the fixed
  CV and the cover letter. Its older CV selection, variant, and keyword-
  substitution instructions do **not** authorise changing the fixed CV.

---

## 1. Scope -- what the AI may touch

**R-01** -- The template contains nine ordered `AI_EDIT_START` /
`AI_EDIT_END` marker pairs for validation and reporting. The first eight bodies
are protected content anchors. Only `SKILLS`, the ninth body, is editable.
Never move, rename, add, or delete a marker.

**R-02** -- Copy the complete template exactly outside `SKILLS`. This includes
the preamble, commands, contact block, section names and order, headings,
dates, S-DS summary, every bullet-list wrapper, every bullet, and the empty
Ziraat body.

**R-03** -- Only Skills may adapt to the job advertisement. Never select,
omit, add, reorder, rewrite, shorten, proofread, or keyword-substitute the
summary or a bullet. Never change a job title.

**R-04** -- The summary is permanently S-DS and starts with `Data Scientist`.
Do not replace it with the posting title or another profile.

**R-05** -- Ziraat Bank and the University of Łódź are permanently
header-only. Ziraat has an empty protected body even for banking, finance,
insurance, or risk postings. Łódź has no bullet region.

**R-06** -- The fixed bullet IDs and order are:

- FAU: `E1b`, `E3b`, `E2-EDU`, `E5a`
- Istanbul University: `B1`, `B2`
- IAB: `I1a`, `I2b`
- Ziraat Bank: none
- Master's Thesis: `P1a`, `P1b`, `P2a`, `P3a`
- NOSI: `N1a`, `N2a`, `N3a`
- Publication: `PB1`, `PB3`, `PB4`

`I2b` appears once. A repeated source ID is one bullet, not permission to
duplicate its text or invent a replacement.

---

## 2. Factual discipline for Skills

**R-07** -- Never invent or broaden a skill, method, tool, technology,
language level, or claim. The job description controls relevance, not evidence.

**R-08** -- Never name a tool absent from the master skills inventory, however
common it is in postings. Explicitly excluded: **Spark, PySpark, Kubernetes**.

**R-09** -- Do not add metrics or experience statements to Skills. All fixed
figures and claims remain exactly where the template places them.

**R-10** -- Respect evidence tiers, read fresh from `skills_profiles.docx`:
**Tier 1** state confidently; **Tier 2** list as a skill, never professional
experience; **Tier 3** include only when the posting explicitly names it.

**R-11** -- Honour every scope limit attached to a skill. Gen AIs / LLMs means
tool fluency only, not LLM application or API development. AWS means
certificate-level knowledge, not deployment. CUDA means GPU-accelerated
training, not hardware optimisation.

**R-12** -- The 18 fixed bullets are immutable and unique. Never duplicate one
or introduce a second phrasing of the same source ID.

**R-13** -- If the fixed CV plus honest Skills matching leaves core requirements
uncovered, record a **weak fit**. Never compensate by changing fixed prose.

**R-14** -- Never name internal file paths, drives, or individual-level data.

**R-15** -- Job-description vocabulary may be mirrored only in Skills, and only
when it names an identical evidenced skill. Use the posting's exact string;
never convert a supported concept into a broader claim.

---

## 3. ATS and formatting

**R-16** -- Slot 4 of every `\resumeSubheading` holds a date and nothing else.

**R-17** -- Heading slots stay positionally consistent:
`{organisation}{location}{role or degree}{dates}`.

**R-18** -- The name stays alone on the first extracted line. Contact details
stay on the following body line, never in a header or footer.

**R-19** -- Accented characters remain literal UTF-8 (`ü`, `ä`, `ß`, `Łódź`).
Never convert installed characters to LaTeX accent macros.

**R-20** -- `itemsep` never goes below **4pt**.

**R-21** -- Certificates keep the flat one-line format.

**R-22** -- Section headings and entry headers must stay attached to their
opening content; never change the installed `\Needspace*` behaviour.

**R-23** -- Skills contains exactly four labelled lines, in this order:
`Programming`, `Methods`, `Tools & Platforms`, `Languages`.

Within each line, put posting-relevant evidenced terms first and use the
posting's exact term when equivalent. Drop irrelevant skills instead of listing
everything. Statistical software (Stata, MATLAB/Dynare) stays on Programming.
`Tools & Platforms` contains Tier 2--3 items, stays short, and includes only
what the posting asks for. If the posting names no relevant platform or tool,
use `Git` as the evidenced baseline so the required line is not empty.
Languages remains exactly:
`Turkish (Native), English (C1), German (B1)`.

**R-24** -- The compiled PDF must show zero fonts missing Unicode maps, zero
glued nested bullets, date fields matching the date-range checks, and no new
overfull `\hbox`.

Accepted limitations remain unchanged: top-level bullets in Skills and
Certifications may merge in `pdftotext` raw mode while remaining geometrically
separate, and the known thesis-title row may produce its accepted baseline
overfull warning.

---

## 4. Fixed house style

**R-25** -- The protected prose uses its approved British-English wording.

**R-26** -- Fixed bullets have no terminal full stops.

**R-27** -- Current IAB and NOSI bullets use present tense; completed work uses
past tense.

**R-28** -- Installed capitalisation, acronyms, course names, dataset names,
and method names are fixed.

**R-29** -- Installed numbers, separators, and measured percentages are fixed.

These rules describe the locked baseline; they are not permission to
proofread it during generation.

---

## 5. Pre-flight checklist

**Template lock**

- [ ] Regions 1--8 match the supplied template text and order exactly
- [ ] Only `SKILLS` differs from the template
- [ ] All nine marker pairs remain intact and ordered
- [ ] Ziraat and Łódź remain header-only
- [ ] The S-DS summary still starts with `Data Scientist`

**Skills**

- [ ] Exactly four lines with the required labels and order
- [ ] Every term exists in the current master inventory
- [ ] No Tier 3 item unless the posting explicitly names it
- [ ] No Spark, PySpark, or Kubernetes
- [ ] Languages remain Turkish (Native), English (C1), German (B1)

**Formatting / ATS**

- [ ] Slot 4 contains only a date in every entry
- [ ] Name remains alone on the first extracted line
- [ ] Zero fonts missing Unicode maps and zero glued nested bullets
- [ ] No new overfull box or stranded section heading

---

## 6. Settled decisions

- **Name -- `Yigit Coskun`, always.** The IAB publication is credited to
  *Ahmet Coskun* and nothing on the CV bridges the two; this is accepted.
- **Profile -- S-DS, always.** The summary and bullet inventory no longer
  switch between DS, DA, and ER profiles.
- **Tailoring -- Skills only.** Cover letters remain job-specific under their
  separate contract; CV summary and bullet tailoring is retired.
- **Duplicate request -- one `I2b`.** The source library contains one `I2b`, so
  the repeated user line is represented once rather than duplicated.
