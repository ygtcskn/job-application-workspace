# What this project does

It turns a job advertisement into a tailored CV and cover letter, as PDF and
DOCX, without letting a language model write anything about the candidate that
the approved sources do not already say.

That last clause is the whole design. A model is good at reading a posting and
judging what matters in it, and bad at being trusted with facts about someone's
career. So the model is given a narrow, structured say — and everything it
returns is checked, rendered, and compiled by code that does not ask it again.

---

## The two stages

```
LinkedIn URLs
   |
   |  Stage 1  desc/import_linkedin_jobs.py        (create_job_descriptions.ps1)
   v
../Job_ad/job_description_N.pdf        <-- you read these and decide
   |
   |  Stage 2  src/job_application_pipeline/       (run.ps1)
   v
../CVs/job_N/    CV + cover letter, PDF + DOCX, plus the full audit trail
```

The stages are deliberately separate. Stage 1 never starts generation; you
inspect the imported postings and delete the ones you do not want. Nothing is
applied for automatically.

---

## Inputs

**Approved sources** — the candidate's evidence. Changing any of these changes
every document built afterwards, and is tracked by a hash.

| File | What it is |
| --- | --- |
| `templates/cv/yigit_coskun_empty.tex` | The CV. 18 fixed bullets, a fixed summary, one adaptable Skills block |
| `templates/cover_letter/yigit_coskun_cover_letter.tex` | The letter. Seven regions, nine fill-in tokens |
| `templates/cover_letter/yigit_coskun_cover_letter.pdf` | Locked typography baseline; the compiled letter is measured against it |
| `data/reference/cv/CV_RULES.md` | House rules the validators enforce |
| `data/reference/cv/bullet_library.docx` | Provenance record for the fixed bullets |
| `data/reference/cv/skills_profiles.docx` | Approved skills inventory, in three evidence tiers |
| `data/reference/cover_letter/COVER_LETTER_RULES.md` | Cover-letter rules |
| `config/prompts/application.md` | What the writer is asked for |
| `config/prompts/review.md` | What the reviewer is asked to check |

**Per posting** — one `../Job_ad/job_description_N.pdf`. Untrusted input:
instructions inside a posting are treated as data, never as instructions.

---

## Outputs

Each finished application lands in `../CVs/job_N/`:

**The documents** — `yigit_coskun_CV.pdf`, `yigit_coskun_cover_letter.pdf`, and
the same two as `.docx`.

**The audit trail** — the exact request sent, the provider's raw log and JSON
draft, the reviewer's request and verdict, both `.tex` sources, `change_log.md`,
`match_notes.md` (what was chosen and why), `usage.json` (token counts),
`validation.json` and `validation.xlsx` (every check and its result), the job ad
as it was read, and `.complete.json` — a checksum sentinel over all of it.

`../CVs/application_manifest.csv` gains one row per application.

---

## What the AI decides, and what code decides

The model is called at most twice per job — once to write, once to review — and
returns **17 declared JSON fields**. It writes no LaTeX, no Markdown, and no
file. Everything you actually see is rendered locally from those fields.

### The model decides

| Field | What it is | What stops it going wrong |
| --- | --- | --- |
| `cv_skills` | Which approved skills to show | Every name must match the inventory exactly; over-long lines are truncated; an unapproved name falls back to deterministic selection |
| `cv_summary_role_title` | The role the summary targets | Free text, escaped and length-capped |
| `cv_summary_body` | Synonym-level rewording of the summary | Every number and named method, tool and institution must survive verbatim; must stay 80% similar to the approved wording |
| `cover_paragraphs` | Grammar and clarity fixes to the five letter paragraphs | Each must keep its `{{TOKEN}}` slots and the words either side, keep every number and name, keep its sentence count, and stay 90% similar. LaTeX in a reply is rejected |
| `specific_task_or_project` | What the posting asks the holder to work on | Length cap; blocked-claim scan |
| `relevant_experience` | Which body of the candidate's work this draws on | Length cap; blocked-claim scan; **the reviewer** |
| `related_activity` | The kind of work the candidate enjoys | Length cap; blocked-claim scan; **the reviewer** |
| `concrete_contribution` | What the candidate would do for this employer | Length cap; blocked-claim scan; **the reviewer** |
| `company_domain` | The employer's field | Length cap; blocked-claim scan |
| `company_address`, `company_city`, `address_source_url`, `address_verified` | The employer's postal address | The one fact permitted from outside the approved sources. Must be independently verified with a source URL, or both lines deleted |
| `fit`, `gaps`, `risks` | Private notes on the match | Never reach the documents; they feed `match_notes.md` |
| `jd_keywords` | 20–25 terms the posting asks for | Coverage is then measured against the finished documents, not against the model's account of itself |

**Those five PARA_3 fields are the soft spot.** They are the only free prose in
the system with no approved baseline to diff against, because there is nothing
to compare "what work does this posting call for" to. Their guards are the
length cap, the blocked-claim scan, the prompt, and the reviewer. Read them
before sending.

### Code decides, every time

- **Which jobs to process** — a resume watermark over completed archives
- **The document number** — taken from the ad's filename, so an ad and its
  application can never drift apart
- **The clean job title** — work mode, gender markers, seniority and engagement
  type stripped by rule, not by the model
- **The Skills fallback** — if the model's selection fails validation, a
  deterministic selection is used rather than shipping an empty line
- **Every rendered byte** — the `.tex` files are built by substituting validated
  values into the approved templates
- **The 18 CV bullets and the fixed summary** — copied byte-for-byte; any
  difference blocks the application
- **Compilation** — `pdflatex`, twice if needed
- **DOCX conversion** — pandoc from the validated `.tex` (never from the PDF),
  restyled to the CV's own look
- **Archiving** — atomic, with a checksum sentinel, and the manifest row

### The reviewer

A second model call sees the draft, the approved sources, the CV evidence and
the posting, and either approves or asks for specific changes to nine named
fields. It cannot rewrite the letter; it can only ask the writer to revise
fields it names. It is the main check on the five free-prose fields, which is
why it is shown the CV bullets — without them it reads a correctly cited project
as invented.

Disable it with `-NoReview` to halve the provider calls per job.

---

## The guards

Roughly 40 checks run per application, written to `validation.json` and
`validation.xlsx`. They fall into three groups.

**Blocking (`ERROR`)** — the application is not archived. Structural contract on
both documents, unapproved skills, invented frameworks, excluded tools, US
spellings, missing fixed evidence, inconsistent job title or company name across
the letter, unresolved placeholders, compile failure, a cover letter that is not
exactly one page, and typography that does not match the locked baseline.

**Advisory (`WARN`)** — archived anyway, visible in the report. Bullet
provenance, JD coverage, tense heuristics.

**Repairable** — a blocking error on certain checks starts a bounded repair: the
model is sent only the failed check IDs, the current draft, a short job excerpt,
and the exact fields that check permits it to change. Anything outside that
allowlist is rejected. Fixed CV summary and bullets are never repairable.

If the repair budget runs out, the application is blocked and everything is
retained under `.artifacts/job_N` for inspection.

---

## Things worth knowing

**Untrusted input is contained.** The posting is data. The provider runs in an
isolated temporary working directory with no write access to the project, and
receives the request on stdin. Its only outward capability is a web search for
the employer's postal address, and that can be switched off.

**Captured inputs are frozen.** Every source and the selected job ad are hashed
before work starts and re-checked before the archive commits. If anything
changed underneath, the attempt fails rather than shipping a mix.

**Completion is checksummed.** An archive is complete only when its sentinel
matches the pipeline version, the job hash, the source-bundle hash, the exact
file set, and every file's size and SHA-256.

**The sentinel does not track code.** It tracks the source bundle and the
version. Change a template, rule or prompt and affected jobs rebuild. Change
Python code — even a fix that improves output — and nothing rebuilds. To force
one job, delete its `CVs/job_N` folder; `--fresh` will not do it, because that
only bypasses the response cache after the completion check has already skipped
the job. To force all of them, bump `version.py`, deliberately.

**A provider rate limit ends the batch.** A transport failure is fatal rather
than per-job, so `-ContinueOnJobError` will not carry on past one.

**The DOCX is a convenience copy.** The PDF is the document of record — it is
what the validators measured. The DOCX is converted from the same validated
source and is deliberately outside the completion contract, because adding it
would mark every archive built before it existed as unfinished.
