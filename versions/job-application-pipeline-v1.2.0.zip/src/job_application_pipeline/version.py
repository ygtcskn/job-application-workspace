"""Single source of truth for pipeline release provenance."""

from __future__ import annotations


__version__ = "1.2.0"


__all__ = ["__version__"]
