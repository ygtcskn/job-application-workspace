"""Compact, deterministic application-document generation.

The provider's only responsibility in the v1.2 contract is returning a small
JSON draft with two cover-letter token values, an optional address, and
diagnostic fit notes.  CV skill selection and all four output files are
rendered locally from authoritative sources.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import difflib
import html
import json
import re
import unicodedata
from collections.abc import Mapping, Sequence
from typing import Any
from urllib.parse import urlsplit

from .request_builder import clean_job_title, extract_clean_job_title
from .validation import (
    LANGUAGES_VALUE,
    parse_cover_regions,
    parse_cv_regions,
    validate_generated_cover,
    validate_generated_cv,
)


# The Skills block's adaptive lines, in render order. Languages is deliberately
# absent: it is fixed prose, not a selection. Every function that walks the
# lines uses this, so adding one is a change here rather than in nine places.
ADAPTIVE_SKILL_LINES = ("programming", "methods", "tools_platforms", "professional")
AI_DRAFT_FIELDS = (
    "specific_task_or_project",
    "relevant_experience",
    "related_activity",
    "concrete_contribution",
    "company_domain",
    "company_address",
    "company_city",
    "address_source_url",
    "address_verified",
    "fit",
    "gaps",
    "risks",
    "cv_summary_role_title",
    "cv_summary_body",
    "cv_skills",
    "cover_paragraphs",
    "jd_keywords",
)
COVER_PARAGRAPH_FIELDS = (
    "para_1_hook_thesis",
    "para_2_iab",
    "para_3_fit",
    "para_4_motivation",
    "para_5_close",
)
# Region names carry the PARA_ prefix; draft keys are their lowercase form.
COVER_PARAGRAPH_REGIONS = tuple(name.upper() for name in COVER_PARAGRAPH_FIELDS)
# How close an edited body must stay to the approved template wording. The CV
# summary tolerates synonym substitution; the cover letter is a clarity pass.
SUMMARY_BODY_MIN_SIMILARITY = 0.80
COVER_PARAGRAPH_MIN_SIMILARITY = 0.90
JD_KEYWORD_MINIMUM = 20
JD_KEYWORD_MAXIMUM = 25
_COVER_TOKENS = (
    "JOB-TITLE",
    "COMPANY-NAME",
    "COMPANY-ADDRESS",
    "COMPANY-CITY",
    "SPECIFIC-TASK-OR-PROJECT",
    "RELEVANT-EXPERIENCE",
    "RELATED-ACTIVITY",
    "CONCRETE-CONTRIBUTION",
    "COMPANY-DOMAIN",
)
# PARA_3 tokens map onto draft fields by lowercasing and swapping hyphens for
# underscores. Only these five carry free provider prose into the letter.
#
# The caps are the paragraph's one-page budget and are the single source for
# the JSON schema, the parser, and the renderer below. Their sum plus the
# paragraph's fixed prose must still compile to one page; raising them without
# recompiling a worst-case letter is how PARA_3 silently becomes page two.
#
# Measured, not guessed: at a 660-character total the letter runs to two pages
# once the employer block wraps (a long company name plus a two-line address),
# and the boundary is sensitive to where the words break, not just the total.
# 625 held on every header tried, so the extra room over the original 560 sits
# in the two slots that carry the most meaning.
_PARA_3_TOKEN_FIELDS = {
    "SPECIFIC-TASK-OR-PROJECT": ("specific_task_or_project", 160),
    "RELEVANT-EXPERIENCE": ("relevant_experience", 110),
    "RELATED-ACTIVITY": ("related_activity", 110),
    "CONCRETE-CONTRIBUTION": ("concrete_contribution", 160),
    "COMPANY-DOMAIN": ("company_domain", 85),
}
_TOKEN_RE = re.compile(r"\{\{([A-Z][A-Z-]*)\}\}")
_PLACEHOLDER_RE = re.compile(r"\{\{[^{}]+\}\}|\[[A-Za-z][^\]\r\n]{1,80}\]")
_PAGE_MARKER_RE = re.compile(r"^---\s*Page\s+\d+\s*---$", re.IGNORECASE)

AI_DRAFT_JSON_SCHEMA: dict[str, Any] = {
    # No "$schema" key: the Claude CLI validator rejects the 2020-12 meta-schema
    # URI ("no schema with key or ref"), and Codex does not need the annotation.
    # Both providers receive this exact object, so it stays dialect-neutral.
    "type": "object",
    "additionalProperties": False,
    "required": list(AI_DRAFT_FIELDS),
    "properties": {
        # PARA_3 free-text slots, capped by the one-page budget above.
        **{
            field: {"type": "string", "minLength": 1, "maxLength": limit}
            for field, limit in _PARA_3_TOKEN_FIELDS.values()
        },
        "company_address": {
            "type": ["string", "null"],
            "minLength": 1,
            "maxLength": 160,
        },
        "company_city": {
            "type": ["string", "null"],
            "minLength": 1,
            "maxLength": 120,
        },
        "address_source_url": {
            "type": ["string", "null"],
            "minLength": 1,
            "maxLength": 500,
        },
        "address_verified": {"type": "boolean"},
        "fit": {
            "type": "array",
            "maxItems": 3,
            "items": {"type": "string", "minLength": 1, "maxLength": 200},
        },
        "gaps": {
            "type": "array",
            "maxItems": 3,
            "items": {"type": "string", "minLength": 1, "maxLength": 200},
        },
        "risks": {
            "type": "array",
            "maxItems": 3,
            "items": {"type": "string", "minLength": 1, "maxLength": 200},
        },
        "cv_summary_role_title": {"type": "string", "minLength": 2, "maxLength": 60},
        "cv_summary_body": {"type": "string", "minLength": 200, "maxLength": 900},
        "cv_skills": {
            "type": "object",
            "additionalProperties": False,
            "required": list(ADAPTIVE_SKILL_LINES),
            "properties": {
                # Caps must clear the profile's always-include set with room to
                # spare. tools_platforms once capped at 4 against 4 mandatory
                # tools, so adding a tool the posting named meant dropping a
                # required one -- job_221 could not satisfy both.
                "programming": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 9,
                    "items": {"type": "string", "minLength": 1, "maxLength": 80},
                },
                "methods": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 7,
                    "items": {"type": "string", "minLength": 1, "maxLength": 80},
                },
                "tools_platforms": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 7,
                    "items": {"type": "string", "minLength": 1, "maxLength": 80},
                },
                # Working practices, rendered under the label "Skills". Capped
                # at six: these are longer phrases than a tool name, and the
                # line still has to fit without wrapping past two lines.
                "professional": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 6,
                    "items": {"type": "string", "minLength": 1, "maxLength": 80},
                },
            },
        },
        # Only the paragraphs the writer actually changed. An omitted key means
        # "unchanged" internally. Strict Structured Outputs requires every
        # declared property, so the provider represents an unchanged paragraph
        # with null and the parser below drops those nulls from the edit map.
        "cover_paragraphs": {
            "type": "object",
            "additionalProperties": False,
            "required": list(COVER_PARAGRAPH_FIELDS),
            "properties": {
                name: {
                    "type": ["string", "null"],
                    "minLength": 80,
                    "maxLength": 1600,
                }
                for name in COVER_PARAGRAPH_FIELDS
            },
        },
        "jd_keywords": {
            "type": "array",
            "minItems": JD_KEYWORD_MINIMUM,
            "maxItems": JD_KEYWORD_MAXIMUM,
            "items": {"type": "string", "minLength": 2, "maxLength": 60},
        },
    },
}

# Agent B returns a verdict and, when it withholds approval, the specific edits
# it wants. Naming the field keeps a revision scoped the same way a guard
# failure is, so a review of the summary cannot rewrite the cover letter.
REVIEWABLE_FIELDS = (
    "specific_task_or_project",
    "relevant_experience",
    "related_activity",
    "concrete_contribution",
    "company_domain",
    "cv_summary_role_title",
    "cv_summary_body",
    "cv_skills",
    "cover_paragraphs",
)
MAX_REVIEW_ISSUES = 6

REVIEW_JSON_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["approved", "issues"],
    "properties": {
        "approved": {"type": "boolean"},
        "issues": {
            "type": "array",
            "maxItems": MAX_REVIEW_ISSUES,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["field", "problem", "fix"],
                "properties": {
                    "field": {"type": "string", "enum": list(REVIEWABLE_FIELDS)},
                    "problem": {"type": "string", "minLength": 1, "maxLength": 300},
                    "fix": {"type": "string", "minLength": 1, "maxLength": 300},
                },
            },
        },
    },
}


@dataclass(frozen=True, slots=True)
class ReviewIssue:
    field: str
    problem: str
    fix: str

    def to_dict(self) -> dict[str, str]:
        return {"field": self.field, "problem": self.problem, "fix": self.fix}


@dataclass(frozen=True, slots=True)
class ReviewVerdict:
    """Agent B's structured answer: approved, plus what to change if not."""

    approved: bool
    issues: tuple[ReviewIssue, ...]

    @property
    def fields(self) -> tuple[str, ...]:
        seen: list[str] = []
        for issue in self.issues:
            if issue.field not in seen:
                seen.append(issue.field)
        return tuple(seen)

    def to_dict(self) -> dict[str, Any]:
        return {
            "approved": self.approved,
            "issues": [issue.to_dict() for issue in self.issues],
        }


def _decode_structured_object(payload: Any) -> Mapping[str, Any]:
    """Return the JSON object in a plain, fenced, or lightly wrapped reply."""

    if isinstance(payload, Mapping):
        return payload
    if isinstance(payload, bytes):
        try:
            text = payload.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise ValueError("Provider response is not valid UTF-8.") from error
    elif isinstance(payload, str):
        text = payload.lstrip("\ufeff")
    else:
        raise TypeError("Provider response must be text, UTF-8 bytes, or a mapping.")
    if not text.strip():
        raise ValueError("Provider response is empty.")
    fence = re.fullmatch(
        r"\s*```(?:json)?\s*(.*?)\s*```\s*",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if fence is not None:
        text = fence.group(1)
    decoder = json.JSONDecoder(object_pairs_hook=_unique_pairs)
    cursor = 0
    while True:
        opening = text.find("{", cursor)
        if opening < 0:
            break
        try:
            value, _end = decoder.raw_decode(text, opening)
        except ValueError:
            cursor = opening + 1
            continue
        if isinstance(value, Mapping):
            return value
        cursor = opening + 1
    raise ValueError("Provider response contains no JSON object.")


def parse_review_json(payload: Any) -> ReviewVerdict:
    """Validate Agent B's reply, tolerating a fenced or wrapped envelope."""

    value = _decode_structured_object(payload)
    missing = sorted({"approved", "issues"} - set(value))
    if missing:
        raise ValueError("Review reply is missing: " + ", ".join(missing))
    approved = value["approved"]
    if not isinstance(approved, bool):
        raise TypeError("approved must be a JSON boolean.")
    raw_issues = value["issues"]
    if not isinstance(raw_issues, list):
        raise TypeError("issues must be a JSON array.")
    issues: list[ReviewIssue] = []
    for index, item in enumerate(raw_issues[:MAX_REVIEW_ISSUES], start=1):
        if not isinstance(item, Mapping):
            raise TypeError(f"issues[{index}] must be a JSON object.")
        field = _one_line(item.get("field", ""), field=f"issues[{index}].field", max_length=40)
        if field not in REVIEWABLE_FIELDS:
            raise ValueError(
                f"issues[{index}].field must be one of: " + ", ".join(REVIEWABLE_FIELDS)
            )
        issues.append(
            ReviewIssue(
                field=field,
                problem=_one_line(
                    item.get("problem", ""), field=f"issues[{index}].problem", max_length=300
                ),
                fix=_one_line(
                    item.get("fix", ""), field=f"issues[{index}].fix", max_length=300
                ),
            )
        )
    # An "approved" verdict that still lists issues is treated as not approved:
    # the safe reading of a contradictory reply is the one that fixes things.
    return ReviewVerdict(approved=approved and not issues, issues=tuple(issues))


@dataclass(frozen=True, slots=True)
class JobMetadata:
    """Canonical metadata carried in an imported job-description PDF."""

    title: str
    company: str
    location: str | None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "title": self.title,
            "company": self.company,
            "location": self.location,
        }


@dataclass(frozen=True, slots=True)
class SkillSelection:
    """The three adaptive Skills values; Languages is deliberately fixed."""

    programming: tuple[str, ...]
    methods: tuple[str, ...]
    tools_platforms: tuple[str, ...]
    # Rendered under the label "Skills": the working practices a posting asks
    # for -- automation, reporting, stakeholder communication -- as distinct
    # from the tools and methods above. Deliberately without a default: a
    # construction site that forgets it should fail, not quietly ship a CV
    # with an empty line.
    professional: tuple[str, ...]

    @property
    def languages(self) -> str:
        return LANGUAGES_VALUE

    def to_dict(self) -> dict[str, list[str] | str]:
        return {
            "programming": list(self.programming),
            "methods": list(self.methods),
            "tools_platforms": list(self.tools_platforms),
            "professional": list(self.professional),
            "languages": self.languages,
        }


@dataclass(frozen=True, slots=True)
class AIDraft:
    """Validated provider response using exactly the compact declared schema."""

    specific_task_or_project: str
    relevant_experience: str
    related_activity: str
    concrete_contribution: str
    company_domain: str
    company_address: str | None
    company_city: str | None
    address_source_url: str | None
    address_verified: bool
    fit: tuple[str, ...]
    gaps: tuple[str, ...]
    risks: tuple[str, ...]
    cv_summary_role_title: str
    cv_summary_body: str
    cv_skills: SkillSelection
    cover_paragraphs: Mapping[str, str]
    jd_keywords: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "specific_task_or_project": self.specific_task_or_project,
            "relevant_experience": self.relevant_experience,
            "related_activity": self.related_activity,
            "concrete_contribution": self.concrete_contribution,
            "company_domain": self.company_domain,
            "company_address": self.company_address,
            "company_city": self.company_city,
            "address_source_url": self.address_source_url,
            "address_verified": self.address_verified,
            "fit": list(self.fit),
            "gaps": list(self.gaps),
            "risks": list(self.risks),
            "cv_summary_role_title": self.cv_summary_role_title,
            "cv_summary_body": self.cv_summary_body,
            # This object is persisted as the normalised provider response and
            # may be sent back in a repair request, so keep it schema-exact.
            # Languages is deterministic local output, not a provider field.
            "cv_skills": {
                "programming": list(self.cv_skills.programming),
                "methods": list(self.cv_skills.methods),
                "tools_platforms": list(self.cv_skills.tools_platforms),
                "professional": list(self.cv_skills.professional),
            },
            # The internal map contains edits only. Structured Outputs cannot
            # omit declared properties, so serialise unchanged paragraphs as
            # null when storing or re-sending the draft.
            "cover_paragraphs": {
                name: self.cover_paragraphs.get(name)
                for name in COVER_PARAGRAPH_FIELDS
            },
            "jd_keywords": list(self.jd_keywords),
        }


@dataclass(frozen=True, slots=True)
class GeneratedApplication:
    """All four pipeline outputs rendered without another provider call."""

    metadata: JobMetadata
    skills: SkillSelection
    draft: AIDraft
    tailored_cv_tex: str
    cover_letter_tex: str
    change_log_md: str
    match_notes_md: str

    def output_files(self) -> dict[str, str]:
        return {
            "tailored_cv.tex": self.tailored_cv_tex,
            "cover_letter.tex": self.cover_letter_tex,
            "change_log.md": self.change_log_md,
            "match_notes.md": self.match_notes_md,
        }


def _one_line(
    value: str,
    *,
    field: str,
    max_length: int,
    allow_empty: bool = False,
    allow_placeholders: bool = False,
) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{field} must be a string.")
    # Providers sometimes emit HTML entities ("Modelling &amp; Pricing").
    # Left alone the entity reaches the CV literally, since LaTeX escaping
    # then turns its ampersand into a printed "\&amp;".
    normalised = html.unescape(unicodedata.normalize("NFKC", value))
    normalised = normalised.replace("\u2014", " - ").replace("\u2013", "-")
    normalised = re.sub(r"[\x00-\x1f\x7f]+", " ", normalised)
    normalised = re.sub(r"\s+", " ", normalised).strip()
    if not normalised and not allow_empty:
        raise ValueError(f"{field} cannot be empty.")
    if len(normalised) > max_length:
        raise ValueError(f"{field} exceeds its {max_length}-character limit.")
    if not allow_placeholders and _PLACEHOLDER_RE.search(normalised):
        raise ValueError(f"{field} contains an unresolved placeholder.")
    return normalised


def _labelled_metadata(job_description: str) -> dict[str, str]:
    values: dict[str, str] = {}
    lines = job_description.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    recognised = {
        "company": "company",
        "location": "location",
    }
    for index, raw_line in enumerate(lines):
        line = re.sub(r"\s+", " ", raw_line).strip()
        match = re.match(r"^(Company|Location)\s*:\s*(.*)$", line, re.IGNORECASE)
        if match is None:
            continue
        key = recognised[match.group(1).casefold()]
        value = match.group(2).strip()
        if not value:
            for following in lines[index + 1 :]:
                candidate = re.sub(r"\s+", " ", following).strip()
                if not candidate or _PAGE_MARKER_RE.fullmatch(candidate):
                    continue
                if re.match(r"^[A-Za-z ]+\s*:", candidate):
                    break
                value = candidate
                break
        if value and key not in values:
            values[key] = value
    return values


# The shared marker pattern matches a whole line for validation; stripping
# markers out of running text needs the multiline form.
_PAGE_BREAK_RE = re.compile(r"^---\s*Page\s+\d+\s*---$", re.IGNORECASE | re.MULTILINE)


_ABOUT_COMPANY_RE = re.compile(
    r"About[\s]+(?:The[\s]+)?Compan(?:y|ies)|About[\s]+us|Über[\s]+uns",
    re.IGNORECASE,
)
_EMPLOYER_SENTENCE_RE = re.compile(
    r"^(.{2,90}?)\s+(?:is|ist)\s+(?:a|an|the|ein|eine)\s", re.IGNORECASE
)


def _unrelated_names(label: str, employer: str) -> bool:
    """Say whether two company names refer to different organisations.

    "JPMorganChase" and "J.P. Morgan" are the same firm written two ways,
    and the label is the canonical one. "Sundayy" and "DIS AG" share
    nothing, which is what an intermediary looks like.
    """

    def key(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", value.casefold())

    left, right = key(label), key(employer)
    if not left or not right:
        return True
    return left not in right and right not in left


def employer_from_body(job_description: str) -> str | None:
    """Read the employer from the advertisement's own "About the company" text.

    These postings open with "<Employer> is a ...", which is the only place the
    real company appears when a board holds the Company field.
    """

    # A page break can fall between the heading and the sentence, so the
    # extracted name would otherwise begin "Page 3 --- J.P. Morgan".
    text = _PAGE_BREAK_RE.sub(" ", job_description)
    match = _ABOUT_COMPANY_RE.search(text)
    if match is None:
        return None
    after = " ".join(text[match.end() :].split())
    sentence = _EMPLOYER_SENTENCE_RE.match(after)
    if sentence is None:
        return None
    name = sentence.group(1).strip(" .,:;-")
    if not name or "---" in name or len(name.split()) > 8:
        return None
    return name


def parse_job_metadata(job_description: str) -> JobMetadata:
    """Extract title, company, and location from importer-produced PDF text."""

    if not isinstance(job_description, str):
        raise TypeError("job_description must be a string.")
    if not job_description.strip():
        raise ValueError("job_description cannot be empty.")
    labelled = _labelled_metadata(job_description)
    if "company" not in labelled:
        raise ValueError("Job description is missing its imported Company metadata.")
    title = _one_line(
        extract_clean_job_title(job_description),
        field="job title",
        max_length=160,
    )
    company = _one_line(labelled["company"], field="company", max_length=160)
    # The Company label carries whoever posted the advertisement, which for a
    # hiring site or agency is not the company being applied to. When the ad
    # introduces itself -- "About the company: <X> is a ..." -- that name is
    # the employer, and across the archive it appears only in exactly the
    # postings whose label is an intermediary.
    employer = employer_from_body(job_description)
    if employer and _unrelated_names(company, employer):
        company = _one_line(employer, field="company", max_length=160)
    raw_location = labelled.get("location")
    location = (
        _one_line(raw_location, field="location", max_length=160)
        if raw_location
        else None
    )
    return JobMetadata(title=title, company=company, location=location)


def _split_top_level(value: str, separator: str = ",") -> list[str]:
    parts: list[str] = []
    depth = 0
    start = 0
    for index, character in enumerate(value):
        if character == "(":
            depth += 1
        elif character == ")":
            depth = max(0, depth - 1)
        elif character == separator and depth == 0:
            part = value[start:index].strip()
            if part:
                parts.append(part)
            start = index + 1
    tail = value[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def _split_slash(value: str) -> list[str]:
    protected = re.sub(r"(?i)(?<!\w)A\s*/\s*B(?!\w)", "A\u2044B", value)
    parts = [part.replace("A\u2044B", "A/B").strip() for part in protected.split("/")]
    return [part for part in parts if part]


def _flatten_skill_expression(expression: str) -> list[str]:
    expression = expression.strip()
    match = re.fullmatch(r"(.+?)\s*\(([^()]*)\)", expression)
    if match is None:
        return _split_slash(expression)
    root, children = match.groups()
    flattened = _split_slash(root)
    for child in _split_top_level(children):
        flattened.extend(_split_slash(child))
    return flattened


@dataclass(frozen=True, slots=True)
class SkillGroup:
    """One approved entry: a parent name and the children it may carry.

    The approved profile writes "Python (Pandas, NumPy, Statsmodels)", so a
    package belongs inside its language rather than beside it on the line.
    """

    name: str
    children: tuple[str, ...]

    def render(self, chosen: Sequence[str]) -> str:
        return f"{self.name} ({', '.join(chosen)})" if chosen else self.name


SKILL_TIERS = (1, 2, 3)
_TIER_RE = re.compile(
    r"Tier\s+([123])\s*[-\u2013\u2014]\s*"
    r"(.*?)(?=Tier\s+[123]\s*[-\u2013\u2014]|$)",
    re.DOTALL,
)


def parse_skill_tiers(skills_profiles: str) -> dict[int, tuple[str, ...]]:
    """Read the three evidence tiers from the standardised inventory.

    Each tier states its rule in prose and then lists its skills separated by
    semicolons. The list is the sentence carrying the semicolons, which keeps
    the parse stable when the surrounding guidance is reworded.
    """

    if not isinstance(skills_profiles, str):
        raise TypeError("skills_profiles must be a string.")
    tiers: dict[int, tuple[str, ...]] = {}
    for match in _TIER_RE.finditer(skills_profiles):
        number = int(match.group(1))
        if number in tiers:
            continue
        sentences = re.split(r"(?<=[.])\s+", match.group(2))
        listing = max(sentences, key=lambda part: part.count(";"), default="")
        if listing.count(";") < 2:
            continue
        entries: list[str] = []
        for raw in listing.split(";"):
            entry = raw.strip().rstrip(".").strip()
            if entry and entry not in entries:
                entries.append(entry)
        if entries:
            tiers[number] = tuple(entries)
    missing = [number for number in SKILL_TIERS if number not in tiers]
    if missing:
        raise ValueError(
            "skills_profiles is missing evidence tier(s): "
            + ", ".join(map(str, missing))
        )
    return tiers


def _parse_skill_groups(skills_profiles: str) -> dict[str, tuple[SkillGroup, ...]]:
    """Build the approved entries, keeping each parent's children attached.

    The profile assigns skills to lines in prose rather than by enumeration,
    so every line draws from one union and the writer places them. What stays
    deterministic is membership: a name outside the tiers is rejected.
    """

    entries: list[SkillGroup] = []
    for tier in SKILL_TIERS:
        for expression in parse_skill_tiers(skills_profiles)[tier]:
            match = re.fullmatch(r"(.+?)\s*\(([^()]*)\)", expression.strip())
            if match is None:
                entries.append(SkillGroup(name=expression.strip(), children=()))
                continue
            parent, children = match.groups()
            entries.append(
                SkillGroup(
                    name=parent.strip(),
                    children=tuple(
                        child.strip()
                        for child in _split_top_level(children)
                        if child.strip()
                    ),
                )
            )
    catalog = tuple(entries)
    return {line: catalog for line in ADAPTIVE_SKILL_LINES}


def _parse_skill_catalog(skills_profiles: str) -> dict[str, tuple[str, ...]]:
    """Flatten the tiers to atomic names, for protection and fallback selection."""

    values: list[str] = []
    for tier in SKILL_TIERS:
        for expression in parse_skill_tiers(skills_profiles)[tier]:
            values.extend(_flatten_skill_expression(expression))
    unique: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalised = _search_text(value)
        if normalised and normalised not in seen:
            seen.add(normalised)
            unique.append(value)
    if not unique:
        raise ValueError("skills_profiles lists no approved skills.")
    # Line membership is prose in this profile, so every line shares one set.
    return {line: tuple(unique) for line in ADAPTIVE_SKILL_LINES}


def _search_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold()
    value = value.replace(r"\&", " and ")
    value = value.replace("&", " and ")
    value = value.replace("/", " ")
    value = re.sub(r"[^a-z0-9+#]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


_SKILL_ALIASES: dict[str, tuple[str, ...]] = {
    "a b testing": ("ab testing", "a b test", "experimentation"),
    "gen ais": ("gen ai", "genai", "generative ai", "generative artificial intelligence"),
    "llms": ("llm", "large language model", "large language models"),
    "machine learning": ("ml",),
    "model evaluation": ("model validation", "model comparison"),
    "out of sample testing": ("out of sample evaluation", "oos testing"),
    "power bi": ("powerbi",),
    "scikit learn": ("sklearn",),
    "time series analysis and forecasting": (
        "time series",
        "time series forecasting",
        "forecasting",
    ),
}


_LINE_LABELS = (
    ("programming", "Programming"),
    ("methods", "Methods"),
    ("tools_platforms", "Tools & Platforms"),
    ("professional", "Skills"),
)


def mandatory_skills_by_line(skills_profiles: str) -> dict[str, tuple[str, ...]]:
    """Read each line's "Always include" set from the Required Skills output.

    The profile assigns Tier 1 to lines in prose. These are the names it says
    must appear on every CV, so they are also the safe deterministic answer
    when a provider selection cannot be used.
    """

    section = skills_profiles[skills_profiles.find("3. Required Skills output") :]
    assigned: dict[str, tuple[str, ...]] = {}
    for key, label in _LINE_LABELS:
        match = re.search(
            re.escape(label) + r":\s*Always include([^.]*)\.", section
        )
        if match is None:
            assigned[key] = ()
            continue
        listing = re.sub(r"\band\b", ",", match.group(1))
        names: list[str] = []
        for raw in _split_top_level(listing):
            name = raw.strip().strip(",").strip()
            if name and name not in names:
                names.append(name)
        assigned[key] = tuple(names)
    return assigned


def select_cv_skills(skills_profiles: str, job_description: str) -> SkillSelection:
    """Return the profile's mandatory skills, as the deterministic fallback.

    The profile requires every Tier 1 skill on every CV regardless of vacancy,
    so the safe answer when a provider selection cannot be used is exactly that
    set. Relevance is the provider's job; compliance is this one's.
    """

    if not isinstance(job_description, str):
        raise TypeError("job_description must be a string.")
    if not job_description.strip():
        raise ValueError("job_description cannot be empty.")
    assigned = mandatory_skills_by_line(skills_profiles)
    missing = sorted(name for name, terms in assigned.items() if not terms)
    if missing:
        raise ValueError(
            "skills_profiles does not state the always-include skills for: "
            + ", ".join(missing)
        )
    return SkillSelection(
        programming=assigned["programming"],
        methods=assigned["methods"],
        tools_platforms=assigned["tools_platforms"],
        professional=assigned["professional"],
    )


def skill_inventory(skills_profiles: str) -> frozenset[str]:
    """Every approved skill name, casefolded, for protection and validation."""

    catalog = _parse_skill_catalog(skills_profiles)
    return frozenset(
        term.casefold() for terms in catalog.values() for term in terms
    )


def format_skill_inventory(skills_profiles: str) -> str:
    """Render the tiers and the profile's own line rules for the prompt.

    Tier is the whole selection contract in this profile: Tier 1 is always
    included, Tier 2 is used when relevant, Tier 3 needs the posting to ask.
    """

    tiers = parse_skill_tiers(skills_profiles)
    labels = {
        1: "Tier 1 -- always include, on every CV",
        2: "Tier 2 -- include when relevant, stated confidently",
        3: "Tier 3 -- only when the posting asks for it",
    }
    blocks = [f"- {labels[n]}: " + "; ".join(tiers[n]) for n in SKILL_TIERS]
    rules = _profile_line_rules(skills_profiles)
    if rules:
        blocks.append("")
        blocks.append("Line rules from the profile:")
        blocks.append(rules)
    return "\n".join(blocks)


def _profile_line_rules(skills_profiles: str) -> str:
    """Quote the profile's Required Skills output section verbatim."""

    start = skills_profiles.find("3. Required Skills output")
    if start < 0:
        return ""
    end = skills_profiles.find("4. Universal", start)
    section = skills_profiles[start : end if end > 0 else None]
    body = section.split("\n", 1)[-1] if "\n" in section else section
    return " ".join(body.split())[:1200]










_SKILL_ALIASES: dict[str, tuple[str, ...]] = {
    "a b testing": ("ab testing", "a b test", "experimentation"),
    "gen ais": ("gen ai", "genai", "generative ai", "generative artificial intelligence"),
    "llms": ("llm", "large language model", "large language models"),
    "machine learning": ("ml",),
    "model evaluation": ("model validation", "model comparison"),
    "out of sample testing": ("out of sample evaluation", "oos testing"),
    "power bi": ("powerbi",),
    "scikit learn": ("sklearn",),
    "time series analysis and forecasting": (
        "time series",
        "time series forecasting",
        "forecasting",
    ),
}














# The profile names packages as their own entries but describes them in prose
# as belonging to a language -- "Select additional Python packages by vacancy",
# "Add R packages, including ggplot2". A package printed beside its own
# language reads as a separate language, so it is nested at render time.
LANGUAGE_PACKAGES: Mapping[str, tuple[str, ...]] = {
    "python": (
        "pandas",
        "NumPy",
        "scikit-learn",
        "TensorFlow/Keras",
        "Matplotlib",
        "PyTorch",
        "SciPy",
        "Seaborn",
        "Plotly",
        "Statsmodels",
    ),
    "r": ("ggplot2", "Tidyverse", "Glmnet", "Forecast", "Shiny", "Caret", "Plm"),
    "sql": ("PostgreSQL",),
}


def check_mandatory_skills(
    skills: SkillSelection, skills_profiles: str
) -> list[str]:
    """Verify every "Always include" skill actually reached its line.

    The profile calls Tier 1 mandatory on every CV. The provider is told so and
    usually complies, but nothing checked it, and job_197 shipped without
    AI/LLM Tools. A stated requirement that is never verified is a suggestion.
    """

    assigned = mandatory_skills_by_line(skills_profiles)
    problems: list[str] = []
    for line in ADAPTIVE_SKILL_LINES:
        present: set[str] = set()
        for entry in getattr(skills, line):
            parent, children = _split_skill_entry(entry)
            present.add(_search_text(parent))
            present.update(_search_text(child) for child in children)
        missing = [
            required
            for required in assigned.get(line, ())
            if _search_text(_split_skill_entry(required)[0]) not in present
        ]
        if missing:
            problems.append(
                f"cv_skills.{line} omits skills the profile requires on every "
                "CV: " + ", ".join(missing) + "."
            )
    return problems


def group_language_packages(skills: SkillSelection) -> SkillSelection:
    """Nest selected packages inside their language on the Programming line.

    Runs after tier filtering, never before: a restricted package such as
    PyTorch must be dropped on its own merits while it is still a top-level
    entry, not hidden inside Python where the tier gate cannot see it.
    """

    owners = {
        package.casefold(): language
        for language, packages in LANGUAGE_PACKAGES.items()
        for package in packages
    }
    entries = list(skills.programming)
    nested: dict[str, list[str]] = {}
    kept: list[str] = []
    for entry in entries:
        parent, children = _split_skill_entry(entry)
        language = owners.get(parent.casefold())
        if language is None or not any(
            _split_skill_entry(other)[0].casefold() == language for other in entries
        ):
            kept.append(entry)
            continue
        if children:
            kept.append(entry)
            continue
        nested.setdefault(language, []).append(parent)
    if not nested:
        return skills
    programming: list[str] = []
    for entry in kept:
        parent, children = _split_skill_entry(entry)
        packages = nested.get(parent.casefold())
        if packages and not children:
            programming.append(f"{parent} ({', '.join(packages)})")
        else:
            programming.append(entry)
    return SkillSelection(
        programming=tuple(programming),
        methods=skills.methods,
        tools_platforms=skills.tools_platforms,
        professional=skills.professional,
    )


def drop_unrequested_tier_three(
    skills: SkillSelection, skills_profiles: str, job_description: str
) -> SkillSelection:
    """Remove weakest-evidence skills the advertisement never asked for.

    The approved profile reserves these for postings that name them, and the
    quality gate makes that an error. Enforcing it here keeps a run alive: the
    provider is told the rule, but a dropped Tableau is not worth a repair
    round, let alone a failed application.
    """

    from .cv_quality import tier_three_terms

    # A restricted entry may be written with a qualifier -- "exploratory data
    # analysis (EDA)" -- while a selection names only its parent. Key on both,
    # or the gate misses it and the quality check fails the whole job.
    restricted: dict[str, str] = {}
    for term in tier_three_terms(skills_profiles):
        parent, _children = _split_skill_entry(term)
        restricted.setdefault(_search_text(term), term)
        restricted.setdefault(_search_text(parent), term)
    if not restricted:
        return skills
    asked = _search_text(job_description)

    def allowed(name: str) -> bool:
        key = _search_text(name)
        if key not in restricted:
            return True
        return re.search(rf"\b{re.escape(key)}\b", asked) is not None

    def gate(entry: str) -> str | None:
        """Drop a restricted entry, or the restricted children inside one.

        A package nested in its language -- "Python (pandas, PyTorch)" -- is
        invisible to a parent-only check, and the prompt now asks the provider
        to nest, so children must be gated on their own merits too.
        """

        parent, children = _split_skill_entry(entry)
        if not allowed(parent):
            return None
        kept = [child for child in children if allowed(child)]
        if list(children) == kept:
            return entry
        return f"{parent} ({', '.join(kept)})" if kept else parent

    filtered = {
        line: tuple(
            gated
            for entry in getattr(skills, line)
            if (gated := gate(entry)) is not None
        )
        for line in ADAPTIVE_SKILL_LINES
    }
    # Never empty a line: an unasked-for tool is dropped, a bare line is not.
    for line, entries in filtered.items():
        if not entries:
            filtered[line] = getattr(skills, line)
    return SkillSelection(
        programming=filtered["programming"],
        methods=filtered["methods"],
        tools_platforms=filtered["tools_platforms"],
        professional=filtered["professional"],
    )


def resolve_cv_skills(
    skills: SkillSelection, skills_profiles: str
) -> SkillSelection:
    """Map provider-chosen skills onto the approved inventory entries.

    The provider selects; the profile decides. An entry may name a parent with
    the children it wants -- "Python (Statsmodels, XGBoost)" -- because that is
    how the approved profile writes it, and a package listed beside its own
    language reads as a separate language.
    """

    groups = _parse_skill_groups(skills_profiles)
    resolved: dict[str, tuple[str, ...]] = {}
    unknown: list[str] = []
    for line in ADAPTIVE_SKILL_LINES:
        approved = {_search_text(group.name): group for group in groups[line]}
        # A language package the profile only ever writes nested -- "SQL
        # (PostgreSQL)" -- is still a legitimate thing to name on its own,
        # because grouping merges it back into its language at render time.
        # Only those: a child like XGBoost has no language to return to and
        # would print bare beside "machine learning".
        regroupable = {
            _search_text(package)
            for packages in LANGUAGE_PACKAGES.values()
            for package in packages
        }
        nested_only = {
            _search_text(child): child
            for group in groups[line]
            for child in group.children
            if _search_text(child) not in approved
            and _search_text(child) in regroupable
        }
        chosen: list[str] = []
        used: set[str] = set()
        for entry in getattr(skills, line):
            parent, children = _split_skill_entry(entry)
            group = approved.get(_search_text(parent))
            if group is None:
                canonical_child = nested_only.get(_search_text(parent))
                if canonical_child is not None and not children:
                    if canonical_child not in chosen:
                        chosen.append(canonical_child)
                    continue
                unknown.append(f"{line}: {entry}")
                continue
            allowed = {_search_text(child): child for child in group.children}
            # A language may also carry any approved package of its own, which
            # is how the rendered line reads even though the profile lists the
            # package as a separate entry.
            for package in LANGUAGE_PACKAGES.get(_search_text(group.name), ()):
                canonical_package = approved.get(_search_text(package))
                if canonical_package is not None:
                    allowed[_search_text(package)] = canonical_package.name
            selected: list[str] = []
            for child in children:
                canonical = allowed.get(_search_text(child))
                if canonical is None:
                    unknown.append(f"{line}: {group.name} ({child})")
                    continue
                if canonical not in selected:
                    selected.append(canonical)
            if _search_text(group.name) in used:
                continue
            used.add(_search_text(group.name))
            chosen.append(group.render(selected))
        resolved[line] = tuple(chosen)
    if unknown:
        raise ValueError(
            "cv_skills names that are not in the approved inventory: "
            + "; ".join(sorted(unknown))
        )
    empty = sorted(name for name, terms in resolved.items() if not terms)
    if empty:
        raise ValueError("cv_skills left these lines empty: " + ", ".join(empty))
    return SkillSelection(
        programming=resolved["programming"],
        methods=resolved["methods"],
        tools_platforms=resolved["tools_platforms"],
        professional=resolved["professional"],
    )


def _split_skill_entry(entry: str) -> tuple[str, tuple[str, ...]]:
    """Split "Python (Pandas, NumPy)" into its parent and its children."""

    match = re.fullmatch(r"(.+?)\s*\(([^()]*)\)", entry.strip())
    if match is None:
        return entry.strip(), ()
    parent, children = match.groups()
    return parent.strip(), tuple(
        child.strip() for child in _split_top_level(children) if child.strip()
    )


# Trademark marks sit outside the CM font repertoire, so pdfLaTeX substitutes
# a fallback face for them and the compiled letter no longer matches the locked
# typography baseline. They are also not written in running prose: a letter
# addressed to "tonies" is correct, one to "tonies(R)" is not.
_DROPPED_SYMBOLS = str.maketrans({"®": "", "™": "", "©": "", "℠": ""})


def _latex_escape(value: str, *, field: str, max_length: int) -> str:
    # Strip before normalising: NFKC turns U+2122 into the letters "TM", which
    # would then survive as text rather than being dropped.
    value = value.translate(_DROPPED_SYMBOLS) if isinstance(value, str) else value
    value = _one_line(value, field=field, max_length=max_length)
    # Keep provider/job text inert without introducing layout commands.  The
    # structural validators allow the seven ordinary one-character escapes.
    value = value.replace("\\", "/")
    value = value.replace("~", " approximately ").replace("^", " to the power of ")
    value = re.sub(r"\s+", " ", value).strip()
    escapes = {
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
    }
    return "".join(escapes.get(character, character) for character in value)


def _capitalise_entry(entry: str) -> str:
    """Raise the first letter of a listed skill, leaving the rest alone.

    The profile writes methods in running-prose case -- "machine learning",
    "feature engineering" -- which reads as a sentence fragment in a CV list.
    Only the leading character changes: nested package names keep the official
    casing the profile insists on, so "scikit-learn" and "pandas" stay as they
    are inside "Python (...)".
    """

    stripped = entry.lstrip()
    if not stripped:
        return entry
    lead = len(entry) - len(stripped)
    return entry[:lead] + stripped[0].upper() + stripped[1:]


def render_skills_region(skills: SkillSelection) -> str:
    """Render the mandatory four-line Skills grammar."""

    values = (
        skills.programming,
        skills.methods,
        skills.tools_platforms,
        skills.professional,
    )
    labels = ("Programming", "Methods", r"Tools \& Platforms", "Skills")
    for label, terms in zip(labels, values, strict=True):
        if not terms:
            raise ValueError(f"{label} cannot be empty.")
        if len({_search_text(term) for term in terms}) != len(terms):
            raise ValueError(f"{label} contains duplicate skills.")

    lines = [r"\resumeSubHeadingListStart"]
    for label, terms in zip(labels, values, strict=True):
        escaped = ", ".join(
            _latex_escape(
                _capitalise_entry(term), field=f"{label} skill", max_length=80
            )
            for term in terms
        )
        lines.append(rf"\item{{\textbf{{{label}}}{{: {escaped}}}}}")
    lines.append(
        rf"\item{{\textbf{{Languages}}{{: {LANGUAGES_VALUE}}}}}"
    )
    lines.append(r"\resumeSubHeadingListEnd")
    return "\n".join(lines)


def _replace_marked_region(template: str, region: str, body: str) -> str:
    marker_start = re.compile(
        rf"^[ \t]*%[ \t]*AI_EDIT_START:[ \t]*{re.escape(region)}[ \t]*\r?$",
        re.MULTILINE,
    )
    marker_end = re.compile(
        rf"^[ \t]*%[ \t]*AI_EDIT_END:[ \t]*{re.escape(region)}[ \t]*\r?$",
        re.MULTILINE,
    )
    starts = list(marker_start.finditer(template))
    ends = list(marker_end.finditer(template))
    if len(starts) != 1 or len(ends) != 1 or ends[0].start() <= starts[0].end():
        raise ValueError(f"Template must contain one ordered {region} marker pair.")
    newline = "\r\n" if "\r\n" in template else "\n"
    # The marker pattern consumes the carriage return of a CRLF template, so
    # the prefix must shed it before the chosen newline is appended again.
    prefix = template[: starts[0].end()].removesuffix("\r")
    return (
        prefix
        + newline
        + body.strip()
        + newline
        + template[ends[0].start() :]
    )


def template_summary_text(cv_template: str) -> str:
    """Return the template summary as plain text, without its small wrapper."""

    _fixed, regions = parse_cv_regions(cv_template)
    body = regions["SUMMARY"].strip()
    match = re.fullmatch(r"\{\s*\\small\s+(.*)\}", body, re.DOTALL)
    if match is None:
        raise ValueError(r"Template SUMMARY must be a single {\small ...} wrapper.")
    return unescape_latex_prose(" ".join(match.group(1).split()))


SUMMARY_TITLE_TOKEN = "{{JOB-TITLE}}"
# An article immediately before the slot is corrected with it.
_SUMMARY_TOKEN_RE = re.compile(
    r"(?:(?P<article>\b[Aa]n?)\s+)?" + re.escape(SUMMARY_TITLE_TOKEN)
)


def assert_summary_token(summary: str, *, field: str) -> None:
    """Require the role slot to appear exactly once."""

    found = summary.count(SUMMARY_TITLE_TOKEN)
    if found != 1:
        raise ValueError(
            f"{field} must contain {SUMMARY_TITLE_TOKEN} exactly once; found {found}."
        )


def fill_summary_title(summary: str, role_title: str) -> str:
    """Drop the advertised role into the summary's one slot.

    The article goes with it: the approved summary reads "a {{JOB-TITLE}}
    position", which is wrong the moment the posting is an Economic Advisory
    Analyst.
    """

    def replace(match: re.Match[str]) -> str:
        article = match.group("article")
        if not article:
            return role_title
        corrected = "an" if role_title[:1].upper() in "AEIOU" else "a"
        if article[0].isupper():
            corrected = corrected.capitalize()
        return f"{corrected} {role_title}"

    return _SUMMARY_TOKEN_RE.sub(replace, summary, count=1)


def format_summary_split(summary: str) -> str:
    """Render the approved summary for the prompt, token and all."""

    return (
        "- `cv_summary_body`, the approved summary. Keep "
        f"{SUMMARY_TITLE_TOKEN} exactly where it stands, with the words either "
        f"side of it unchanged:\n  {summary}\n"
        "- `cv_summary_role_title`, the advertised role. The pipeline drops it "
        f"into {SUMMARY_TITLE_TOKEN} and fixes the article; never write the "
        "role into the body yourself."
    )


def render_summary_region(role_title: str, body: str) -> str:
    """Render the summary wrapper from a provider role title and body.

    The title is reduced to a role noun phrase first. A posting title carries
    qualifiers ("Quantitative Analyst - Modelling & Pricing") that read badly
    once the summary continues "... with an economics background", and the
    cover letter already cleans its own title the same way.
    """

    try:
        role_title = clean_job_title(role_title)
    except ValueError as error:
        raise ValueError(f"cv_summary_role_title is not a role name: {error}") from error
    assert_summary_token(body, field="cv_summary_body")
    _one_line(role_title, field="cv_summary_role_title", max_length=60)
    # Fill the slot first, then escape once: the role is prose like the rest of
    # the sentence and needs the same treatment.
    filled = fill_summary_title(body, role_title)
    return r"{\small " + _latex_escape(
        filled, field="cv_summary_body", max_length=900
    ) + "}"


def check_summary_edit(
    cv_template: str,
    role_title: str,
    body: str,
    *,
    inventory: frozenset[str],
) -> list[str]:
    """Collect every reason a tailored summary is unacceptable."""

    problems: list[str] = []
    original_body = " ".join(template_summary_text(cv_template).split())
    try:
        clean_job_title(role_title)
    except ValueError as error:
        problems.append(f"cv_summary_role_title is not a role name: {error}")
    edited_body = " ".join(body.split())
    try:
        assert_summary_token(edited_body, field="cv_summary_body")
    except ValueError as error:
        problems.append(str(error))
        return problems
    for check in (
        # The words either side of the slot are part of the approved sentence.
        # Without this a reply turned "a {{JOB-TITLE}} position" into "a role",
        # dropping the advertised title from the CV entirely.
        lambda: _assert_token_context_kept(
            original_body, edited_body, field="cv_summary_body"
        ),
        lambda: assert_claims_preserved(
            original_body, edited_body, inventory=inventory, field="cv_summary_body"
        ),
        lambda: assert_similar_enough(
            original_body,
            edited_body,
            minimum=SUMMARY_BODY_MIN_SIMILARITY,
            field="cv_summary_body",
        ),
    ):
        try:
            check()
        except ValueError as error:
            problems.append(str(error))
            break
    return problems


def render_cv(
    cv_template: str,
    skills: SkillSelection,
    *,
    summary_role_title: str | None = None,
    summary_body: str | None = None,
    skill_names: frozenset[str] = frozenset(),
) -> str:
    """Copy the CV template, tailoring only SKILLS and, when given, SUMMARY."""

    generated = _replace_marked_region(
        cv_template,
        "SKILLS",
        render_skills_region(skills),
    )
    if summary_role_title is not None and summary_body is not None:
        # The opening is fixed; only the {{JOB-TITLE}} slot retargets. The body
        # keeps the slot and the words either side of it, so a reply cannot
        # quietly drop the advertised role by rewriting around it.
        original_body = " ".join(template_summary_text(cv_template).split())
        edited_body = " ".join(summary_body.split())
        assert_summary_token(edited_body, field="cv_summary_body")
        _assert_token_context_kept(
            original_body, edited_body, field="cv_summary_body"
        )
        assert_claims_preserved(
            original_body, edited_body, inventory=skill_names, field="cv_summary_body"
        )
        assert_similar_enough(
            original_body,
            edited_body,
            minimum=SUMMARY_BODY_MIN_SIMILARITY,
            field="cv_summary_body",
        )
        generated = _replace_marked_region(
            generated,
            "SUMMARY",
            render_summary_region(summary_role_title, summary_body),
        )
    validate_generated_cv(cv_template, generated)
    return generated


# A LaTeX percentage is written "8.16\%", so the escape is part of the claim.
_NUMBER_RE = re.compile(r"\d+(?:[.,]\d+)*(?:\s*\\?%)?")
_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9&+/.'-]*")


def _internal_capital(token: str) -> bool:
    """Say whether a token carries a capital anywhere but the first letter.

    This is what separates a name the edit must keep (``XGBoost``, ``LSTM``,
    ``IAB``, ``SHAP``) from an ordinary word that merely starts a sentence.
    """

    return any(character.isupper() for character in token[1:])


def protected_terms(text: str, inventory: frozenset[str]) -> set[str]:
    """Collect every claim an edit is forbidden to alter.

    Numbers carry the measurable claims, internally capitalised tokens carry
    the named methods and institutions (``XGBoost``, ``LSTM``, ``IAB``), and
    approved skill names matched as whole phrases cover plain words such as
    ``Python`` that neither rule would otherwise catch. Ordinary prose stays
    unprotected so synonym substitution remains possible.
    """

    protected = {
        _normalise_number(match.group(0)) for match in _NUMBER_RE.finditer(text)
    }
    for match in _WORD_RE.finditer(text):
        token = match.group(0)
        if _internal_capital(token):
            protected.add(token.casefold())
    flattened = " ".join(text.split()).casefold()
    for term in inventory:
        if re.search(r"\b" + re.escape(term) + r"\b", flattened):
            protected.add(term)
    return protected


def _normalise_number(value: str) -> str:
    return re.sub(r"\s+|\\", "", value)


def assert_claims_preserved(
    original: str,
    edited: str,
    *,
    inventory: frozenset[str],
    field: str,
) -> None:
    """Fail when an edit drops a number, a named method, or a named tool."""

    missing = sorted(
        protected_terms(original, inventory) - protected_terms(edited, inventory)
    )
    if missing:
        raise ValueError(
            f"{field} dropped protected content that must survive editing: "
            + ", ".join(missing)
        )


def _text_similarity(left: str, right: str) -> float:
    return difflib.SequenceMatcher(
        None, " ".join(left.split()).casefold(), " ".join(right.split()).casefold()
    ).ratio()


def assert_similar_enough(
    original: str,
    edited: str,
    *,
    minimum: float,
    field: str,
) -> None:
    """Fail when an edit rewrote more than the contract allows."""

    ratio = _text_similarity(original, edited)
    if ratio < minimum:
        raise ValueError(
            f"{field} was rewritten too heavily: similarity {ratio:.2f} is "
            f"below the required {minimum:.2f}."
        )


def _draft_string(
    value: Any, *, field: str, max_length: int, allow_placeholders: bool = False
) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{field} must be a string.")
    return _one_line(
        value,
        field=field,
        max_length=max_length,
        allow_placeholders=allow_placeholders,
    )


def _optional_draft_string(value: Any, *, field: str, max_length: int) -> str | None:
    if value is None:
        return None
    return _draft_string(value, field=field, max_length=max_length)


def _source_url(value: Any) -> str | None:
    source_url = _optional_draft_string(
        value,
        field="address_source_url",
        max_length=500,
    )
    if source_url is None:
        return None
    parsed = urlsplit(source_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("address_source_url must be an absolute http(s) URL.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("address_source_url must not contain credentials.")
    return source_url


def _draft_list(value: Any, *, field: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise TypeError(f"{field} must be a JSON array.")
    if len(value) > 5:
        raise ValueError(f"{field} may contain at most 5 entries.")
    # fit/gaps/risks are a private match report, never part of a document.
    # "the advertisement is an unfilled template ([Job Title])" is the right
    # observation to make, and job_198 lost a whole run for making it.
    items = tuple(
        _draft_string(
            item,
            field=f"{field}[{index}]",
            max_length=240,
            allow_placeholders=True,
        )
        for index, item in enumerate(value)
    )
    if len({item.casefold() for item in items}) != len(items):
        raise ValueError(f"{field} contains duplicate entries.")
    return items


def _draft_from_mapping(value: Mapping[str, Any]) -> AIDraft:
    supplied = set(value)
    expected = set(AI_DRAFT_FIELDS)
    if supplied != expected:
        missing = sorted(expected - supplied)
        extra = sorted(supplied - expected)
        details: list[str] = []
        if missing:
            details.append("missing: " + ", ".join(missing))
        if extra:
            details.append("unexpected: " + ", ".join(extra))
        raise ValueError("AI draft fields are invalid (" + "; ".join(details) + ").")
    address_verified = value["address_verified"]
    if not isinstance(address_verified, bool):
        raise TypeError("address_verified must be a JSON boolean.")
    draft = AIDraft(
        **{
            field: _draft_string(value[field], field=field, max_length=limit)
            for field, limit in _PARA_3_TOKEN_FIELDS.values()
        },
        company_address=_optional_draft_string(
            value["company_address"], field="company_address", max_length=160
        ),
        company_city=_optional_draft_string(
            value["company_city"], field="company_city", max_length=120
        ),
        address_source_url=_source_url(value["address_source_url"]),
        address_verified=address_verified,
        fit=_draft_list(value["fit"], field="fit"),
        gaps=_draft_list(value["gaps"], field="gaps"),
        risks=_draft_list(value["risks"], field="risks"),
        cv_summary_role_title=_draft_string(
            value["cv_summary_role_title"],
            field="cv_summary_role_title",
            max_length=60,
        ),
        cv_summary_body=_draft_paragraph(
            value["cv_summary_body"],
            field="cv_summary_body",
            max_length=900,
            # The summary keeps the template's own {{JOB-TITLE}} slot.
            allow_tokens=True,
        ),
        cv_skills=_draft_skills(value["cv_skills"]),
        cover_paragraphs=_draft_cover_paragraphs(value["cover_paragraphs"]),
        jd_keywords=_draft_keywords(value["jd_keywords"]),
    )
    blocked = re.compile(
        r"\b(?:MLOps|production pipeline|deployed model|big data|"
        r"distributed computing|Spark|PySpark|Hadoop|Kubernetes)\b",
        re.IGNORECASE,
    )
    # These five slots are free provider prose with no approved baseline to
    # diff against, so the blocked-claim scan is the guard that applies.
    for field, text in (
        ("specific_task_or_project", draft.specific_task_or_project),
        ("relevant_experience", draft.relevant_experience),
        ("related_activity", draft.related_activity),
        ("concrete_contribution", draft.concrete_contribution),
        ("company_domain", draft.company_domain),
    ):
        if blocked.search(text):
            raise ValueError(
                f"{field} turns an unsupported requirement into cover-letter prose; "
                "record it under gaps or risks instead."
            )
    # An inconsistent address is dropped rather than fatal. The invariant that
    # matters is that an unverified address never reaches the letter, and the
    # approved letter omits the block entirely when there is none. Raising here
    # instead failed the whole draft at parse time, where no repair can reach it.
    has_address = draft.company_address is not None or draft.company_city is not None
    verified = draft.address_verified and draft.address_source_url is not None
    if not has_address or not verified:
        draft = replace(
            draft,
            company_address=None,
            company_city=None,
            address_source_url=None,
            address_verified=False,
        )
    return draft


def _draft_paragraph(
    value: Any, *, field: str, max_length: int, allow_tokens: bool = False
) -> str:
    """Accept prose but keep it inert: one paragraph, no LaTeX, no placeholder."""

    if not isinstance(value, str):
        raise TypeError(f"{field} must be a string.")
    text = unicodedata.normalize("NFC", value).replace("\r\n", " ")
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        raise ValueError(f"{field} cannot be empty.")
    if len(text) > max_length:
        raise ValueError(f"{field} exceeds {max_length} characters.")
    # Cover paragraphs keep the template's own {{TOKEN}} slots; anything else
    # shaped like a placeholder is still an unfilled hole.
    residue = _TOKEN_RE.sub(" ", text) if allow_tokens else text
    if _PLACEHOLDER_RE.search(residue):
        raise ValueError(f"{field} still contains a placeholder.")
    if "\\" in text or re.search(r"\\[A-Za-z]", text):
        raise ValueError(f"{field} must not contain LaTeX commands.")
    return text


def _draft_keywords(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise TypeError("jd_keywords must be a JSON array.")
    keywords: list[str] = []
    seen: set[str] = set()
    for index, item in enumerate(value, start=1):
        term = _one_line(item, field=f"jd_keywords[{index}]", max_length=60)
        key = _search_text(term)
        if not key or key in seen:
            continue
        seen.add(key)
        keywords.append(term)
    if len(keywords) < JD_KEYWORD_MINIMUM:
        raise ValueError(
            f"jd_keywords needs at least {JD_KEYWORD_MINIMUM} distinct terms; "
            f"got {len(keywords)}."
        )
    return tuple(keywords[:JD_KEYWORD_MAXIMUM])


def _draft_skills(value: Any) -> SkillSelection:
    if not isinstance(value, Mapping):
        raise TypeError("cv_skills must be a JSON object.")
    missing = sorted(set(ADAPTIVE_SKILL_LINES) - set(value))
    if missing:
        raise ValueError("cv_skills is missing: " + ", ".join(missing))

    def line(name: str, maximum: int) -> tuple[str, ...]:
        items = value[name]
        if not isinstance(items, list):
            raise TypeError(f"cv_skills.{name} must be a JSON array.")
        terms: list[str] = []
        seen: set[str] = set()
        for index, item in enumerate(items, start=1):
            entry = _one_line(item, field=f"cv_skills.{name}[{index}]", max_length=160)
            # "Power BI, Tableau" in one string is two skills. No approved name
            # carries a comma outside parentheses, so splitting is unambiguous
            # -- and a slip here used to cost the whole tailored selection.
            for term in _split_top_level(entry) or [entry]:
                term = term.strip()
                key = _search_text(term)
                if not key or key in seen:
                    continue
                seen.add(key)
                terms.append(term)
        if not terms:
            raise ValueError(f"cv_skills.{name} cannot be empty.")
        return tuple(terms[:maximum])

    caps = AI_DRAFT_JSON_SCHEMA["properties"]["cv_skills"]["properties"]
    return SkillSelection(
        programming=line("programming", caps["programming"]["maxItems"]),
        methods=line("methods", caps["methods"]["maxItems"]),
        tools_platforms=line("tools_platforms", caps["tools_platforms"]["maxItems"]),
        professional=line("professional", caps["professional"]["maxItems"]),
    )


def _draft_cover_paragraphs(value: Any) -> dict[str, str]:
    if not isinstance(value, Mapping):
        raise TypeError("cover_paragraphs must be a JSON object.")
    unknown = sorted(set(value) - set(COVER_PARAGRAPH_FIELDS))
    if unknown:
        raise ValueError("cover_paragraphs has unknown keys: " + ", ".join(unknown))
    return {
        name: _draft_paragraph(
            value[name],
            field=f"cover_paragraphs.{name}",
            max_length=1600,
            allow_tokens=True,
        )
        for name in COVER_PARAGRAPH_FIELDS
        if name in value and value[name] is not None
    }


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Provider JSON repeats key {key!r}.")
        result[key] = value
    return result


def parse_provider_json(payload: str | bytes | Mapping[str, Any]) -> AIDraft:
    """Parse plain, fenced, or lightly wrapped provider JSON, then validate it."""

    if isinstance(payload, Mapping):
        return _draft_from_mapping(payload)
    if isinstance(payload, bytes):
        try:
            text = payload.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise ValueError("Provider response is not valid UTF-8.") from error
    elif isinstance(payload, str):
        text = payload.lstrip("\ufeff")
    else:
        raise TypeError("Provider response must be text, UTF-8 bytes, or a mapping.")
    if not text.strip():
        raise ValueError("Provider response is empty.")

    fence = re.fullmatch(
        r"\s*```(?:json)?\s*(.*?)\s*```\s*",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if fence is not None:
        text = fence.group(1)

    decoder = json.JSONDecoder(object_pairs_hook=_unique_pairs)
    candidates: list[AIDraft] = []
    errors: list[Exception] = []
    cursor = 0
    while True:
        opening = text.find("{", cursor)
        if opening < 0:
            break
        try:
            value, end = decoder.raw_decode(text, opening)
        except (json.JSONDecodeError, ValueError) as error:
            errors.append(error)
            cursor = opening + 1
            continue
        cursor = max(end, opening + 1)
        if not isinstance(value, Mapping):
            continue
        try:
            candidates.append(_draft_from_mapping(value))
        except (TypeError, ValueError) as error:
            errors.append(error)
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise ValueError("Provider response contains multiple valid AI draft objects.")
    detail = f" Last validation error: {errors[-1]}" if errors else ""
    raise ValueError("Provider response contains no valid AI draft JSON object." + detail)


def _render_company_block(
    template: str,
    *,
    company: str,
    address: str | None,
    city: str | None,
) -> str:
    newline = "\r\n" if "\r\n" in template else "\n"
    pattern = re.compile(
        r"^(?P<indent>[ \t]*)\{\{COMPANY-NAME\}\}\\\\[ \t]*\r?\n"
        r"(?P=indent)\{\{COMPANY-ADDRESS\}\}\\\\[ \t]*\r?\n"
        r"(?P=indent)\{\{COMPANY-CITY\}\}[ \t]*$",
        re.MULTILINE,
    )
    matches = list(pattern.finditer(template))
    if len(matches) != 1:
        raise ValueError(
            "Cover template must contain one canonical three-line company token block."
        )
    indent = matches[0].group("indent")
    values = [company]
    if address is not None:
        values.append(address)
    if city is not None:
        values.append(city)
    replacement = (r"\\" + newline).join(indent + value for value in values)
    return template[: matches[0].start()] + replacement + template[matches[0].end() :]


def _marked_body_spans(
    template: str,
    regions: Sequence[str],
) -> list[tuple[str, int, int]]:
    spans: list[tuple[str, int, int]] = []
    cursor = 0
    for region in regions:
        # \r is allowed before the line end: a template saved with Windows line
        # endings must not silently look like it has no markers at all.
        start_pattern = re.compile(
            rf"^[ \t]*%[ \t]*AI_EDIT_START:[ \t]*{re.escape(region)}[ \t\r]*$",
            re.MULTILINE,
        )
        end_pattern = re.compile(
            rf"^[ \t]*%[ \t]*AI_EDIT_END:[ \t]*{re.escape(region)}[ \t\r]*$",
            re.MULTILINE,
        )
        start = start_pattern.search(template, cursor)
        if start is None:
            raise ValueError(f"Cover template is missing the {region} start marker.")
        end = end_pattern.search(template, start.end())
        if end is None:
            raise ValueError(f"Cover template is missing the {region} end marker.")
        spans.append((region, start.end(), end.start()))
        cursor = end.end()
    return spans


def _replace_tokens_in_cover_regions(
    template: str,
    replacements: Mapping[str, str],
) -> str:
    regions = (
        "COVER_HEADER",
        "SALUTATION",
        "PARA_1_HOOK_THESIS",
        "PARA_2_IAB",
        "PARA_3_FIT",
        "PARA_4_MOTIVATION",
        "PARA_5_CLOSE",
    )
    spans = _marked_body_spans(template, regions)
    rendered: list[str] = []
    cursor = 0
    for _region, start, end in spans:
        rendered.append(template[cursor:start])
        rendered.append(
            _TOKEN_RE.sub(lambda match: replacements[match.group(1)], template[start:end])
        )
        cursor = end
    rendered.append(template[cursor:])
    return "".join(rendered)


_PARAGRAPH_PREFIX = r"\noindent "
_PROSE_ESCAPES = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
}


_UNESCAPE_RE = re.compile(r"\\([&%$#_{}])")


def unescape_latex_prose(text: str) -> str:
    """Turn approved LaTeX prose back into the plain text the provider edits.

    The provider is shown, and returns, ordinary prose. Handing it an escaped
    percentage would invite it back verbatim, and escaping the reply again
    would corrupt the claim.
    """

    return _UNESCAPE_RE.sub(lambda match: match.group(1), text)


def cover_paragraph_sources(cover_template: str) -> dict[str, str]:
    """Return each editable paragraph as plain prose, tokens left in place."""

    _fixed, regions = parse_cover_regions(cover_template)
    sources: dict[str, str] = {}
    for field, region in zip(
        COVER_PARAGRAPH_FIELDS, COVER_PARAGRAPH_REGIONS, strict=True
    ):
        body = regions[region].strip()
        if not body.startswith(_PARAGRAPH_PREFIX):
            raise ValueError(f"Cover region {region} must open with a paragraph command.")
        sources[field] = unescape_latex_prose(" ".join(body[len(_PARAGRAPH_PREFIX) :].split()))
    return sources


def _escape_prose(fragment: str) -> str:
    """Escape provider prose without disturbing the template's own tokens."""

    out: list[str] = []
    for character in fragment.translate(_DROPPED_SYMBOLS):
        if character == chr(92):
            out.append("/")
        elif character == "~":
            out.append(" approximately ")
        elif character == "^":
            out.append(" to the power of ")
        else:
            out.append(_PROSE_ESCAPES.get(character, character))
    return "".join(out)


def _escape_cover_paragraph(text: str) -> str:
    parts: list[str] = []
    cursor = 0
    for match in _TOKEN_RE.finditer(text):
        parts.append(_escape_prose(text[cursor : match.start()]))
        parts.append(match.group(0))
        cursor = match.end()
    parts.append(_escape_prose(text[cursor:]))
    return "".join(parts)


# How many words either side of a template token an edit must leave alone.
# The approved cover-letter validators key on those exact connectives -- for
# example "contribute to <company> and bring" -- so a proofreading pass that
# drops or pads them breaks the letter's structural contract.
_TOKEN_ANCHOR_WORDS = 2


def _token_anchors(text: str) -> list[tuple[str, str, str]]:
    """Return (token, words before, words after) for every token occurrence."""

    anchors: list[tuple[str, str, str]] = []
    for match in _TOKEN_RE.finditer(text):
        before = " ".join(text[: match.start()].split()[-_TOKEN_ANCHOR_WORDS :])
        after = " ".join(text[match.end() :].split()[: _TOKEN_ANCHOR_WORDS])
        anchors.append((match.group(0), before.casefold(), after.casefold()))
    return anchors


def cover_token_excerpts(text: str) -> list[str]:
    """Quote each token with its surrounding words, verbatim from the source."""

    excerpts: list[str] = []
    for match in _TOKEN_RE.finditer(text):
        before = text[: match.start()].split()[-_TOKEN_ANCHOR_WORDS :]
        after = text[match.end() :].split()[: _TOKEN_ANCHOR_WORDS]
        excerpts.append(" ".join([*before, match.group(0), *after]))
    return excerpts


def _assert_token_context_kept(original: str, edited: str, *, field: str) -> None:
    expected = _token_anchors(original)
    actual = _token_anchors(edited)
    if expected == actual:
        return
    wanted = "; ".join(cover_token_excerpts(original))
    raise ValueError(
        f"{field} changed the wording around a template token. Reproduce these "
        f"exactly, including the words either side: {wanted}"
    )


_SENTENCE_END_RE = re.compile(r"[.!?](?=\s|$)")


def _sentence_count(text: str) -> int:
    return len(_SENTENCE_END_RE.findall(text))


def _assert_sentence_count_kept(original: str, edited: str, *, field: str) -> None:
    """Forbid adding or removing a sentence.

    A similarity floor scales with paragraph length, so a long paragraph can
    absorb a whole invented sentence and still score above it. Proofreading
    never changes how many sentences there are, so this catches directly what
    the ratio only catches by accident.
    """

    expected = _sentence_count(original)
    actual = _sentence_count(edited)
    if actual != expected:
        raise ValueError(
            f"{field} must keep its {expected} sentences; it returned {actual}. "
            "Correct the existing sentences instead of adding or removing one."
        )


def check_cover_paragraph_edits(
    cover_template: str,
    paragraphs: Mapping[str, str],
    *,
    inventory: frozenset[str],
) -> list[str]:
    """Collect every reason a cover clarity pass is unacceptable."""

    problems: list[str] = []
    sources = cover_paragraph_sources(cover_template)
    for field in COVER_PARAGRAPH_FIELDS:
        original = sources[field]
        edited = paragraphs.get(field)
        if edited is None:
            continue
        for check in (
            lambda: _assert_expected_tokens(original, edited, field=f"cover_paragraphs.{field}"),
            lambda: _assert_token_context_kept(original, edited, field=f"cover_paragraphs.{field}"),
            lambda: _assert_sentence_count_kept(original, edited, field=f"cover_paragraphs.{field}"),
            lambda: assert_claims_preserved(
                original, edited, inventory=inventory, field=f"cover_paragraphs.{field}"
            ),
            lambda: assert_similar_enough(
                original,
                edited,
                minimum=COVER_PARAGRAPH_MIN_SIMILARITY,
                field=f"cover_paragraphs.{field}",
            ),
        ):
            try:
                check()
            except ValueError as error:
                problems.append(str(error))
                break
    return problems


def _assert_expected_tokens(original: str, edited: str, *, field: str) -> None:
    expected = sorted(_TOKEN_RE.findall(original))
    if sorted(_TOKEN_RE.findall(edited)) != expected:
        raise ValueError(
            f"{field} must keep exactly the template tokens: "
            + (", ".join(expected) or "none")
        )


def apply_cover_paragraph_edits(
    cover_template: str,
    paragraphs: Mapping[str, str],
    *,
    inventory: frozenset[str],
) -> str:
    """Apply a provider clarity pass to the five editable cover paragraphs.

    The edit is bounded four ways: every template token must still be there,
    the words around each token must be untouched, every number and named
    method must survive, and the wording must stay close to the approved
    letter.
    """

    problems = check_cover_paragraph_edits(
        cover_template, paragraphs, inventory=inventory
    )
    if problems:
        raise ValueError(" ".join(problems))
    sources = cover_paragraph_sources(cover_template)
    generated = cover_template
    for field, region in zip(
        COVER_PARAGRAPH_FIELDS, COVER_PARAGRAPH_REGIONS, strict=True
    ):
        body = paragraphs.get(field)
        if body is None:
            continue
        if " ".join(body.split()) == " ".join(sources[field].split()):
            continue
        generated = _replace_marked_region(
            generated,
            region,
            _PARAGRAPH_PREFIX + _escape_cover_paragraph(body),
        )
    return generated


def render_cover(
    cover_template: str,
    metadata: JobMetadata,
    draft: AIDraft,
    *,
    paragraph_edits: Mapping[str, str] | None = None,
    skill_names: frozenset[str] = frozenset(),
    job_description: str | None = None,
) -> str:
    """Fill the cover template's nine tokens, after any provider clarity pass."""

    if paragraph_edits is not None:
        cover_template = apply_cover_paragraph_edits(
            cover_template, paragraph_edits, inventory=skill_names
        )

    editable_bodies = "\n".join(
        cover_template[start:end]
        for _region, start, end in _marked_body_spans(
            cover_template,
            (
                "COVER_HEADER",
                "SALUTATION",
                "PARA_1_HOOK_THESIS",
                "PARA_2_IAB",
                "PARA_3_FIT",
                "PARA_4_MOTIVATION",
                "PARA_5_CLOSE",
            ),
        )
    )
    found = _TOKEN_RE.findall(editable_bodies)
    if set(found) != set(_COVER_TOKENS):
        missing = sorted(set(_COVER_TOKENS) - set(found))
        extra = sorted(set(found) - set(_COVER_TOKENS))
        details: list[str] = []
        if missing:
            details.append("missing: " + ", ".join(missing))
        if extra:
            details.append("unexpected: " + ", ".join(extra))
        raise ValueError("Cover token contract is invalid (" + "; ".join(details) + ").")

    escaped = {
        "JOB-TITLE": _latex_escape(metadata.title, field="job title", max_length=160),
        "COMPANY-NAME": _latex_escape(metadata.company, field="company", max_length=160),
        **{
            token: _latex_escape(
                getattr(draft, field), field=field, max_length=limit
            )
            for token, (field, limit) in _PARA_3_TOKEN_FIELDS.items()
        },
    }
    address = (
        _latex_escape(draft.company_address, field="company_address", max_length=160)
        if draft.company_address is not None
        else None
    )
    city = (
        _latex_escape(draft.company_city, field="company_city", max_length=120)
        if draft.company_city is not None
        else None
    )
    generated = _render_company_block(
        cover_template,
        company=escaped["COMPANY-NAME"],
        address=address,
        city=city,
    )
    generated = _replace_tokens_in_cover_regions(generated, escaped)
    remaining_editable_tokens = [
        token
        for _region, start, end in _marked_body_spans(
            generated,
            (
                "COVER_HEADER",
                "SALUTATION",
                "PARA_1_HOOK_THESIS",
                "PARA_2_IAB",
                "PARA_3_FIT",
                "PARA_4_MOTIVATION",
                "PARA_5_CLOSE",
            ),
        )
        for token in _TOKEN_RE.findall(generated[start:end])
    ]
    if remaining_editable_tokens:
        raise ValueError("Cover rendering left an unresolved token.")
    validate_generated_cover(
        cover_template,
        generated,
        expected_job_title=escaped["JOB-TITLE"],
        job_description=job_description,
    )
    return generated


def _markdown(value: str) -> str:
    return value.replace("|", r"\|")


def _bullet_section(title: str, entries: Sequence[str]) -> list[str]:
    lines = [f"## {title}", ""]
    lines.extend(f"- {_markdown(entry)}" for entry in entries)
    if not entries:
        lines.append("- None recorded")
    lines.append("")
    return lines


def render_change_log(
    metadata: JobMetadata,
    skills: SkillSelection,
    draft: AIDraft,
    *,
    skills_source: str = "provider",
) -> str:
    """Render the change record from deterministic inputs."""

    address = ", ".join(
        value for value in (draft.company_address, draft.company_city) if value
    ) or "omitted (not reliably available)"
    address_source = draft.address_source_url or "none"
    lines = [
        "# Application Change Log",
        "",
        "- Pipeline contract: guided tailoring (v1.2)",
        f"- Job title: {_markdown(metadata.title)}",
        f"- Company: {_markdown(metadata.company)}",
        "- CV protected content: eighteen approved bullets unchanged",
        f"- CV summary role title: {_markdown(draft.cv_summary_role_title)}",
        "- CV summary body: synonym-level edit; numbers and named methods kept",
        "- Cover letter: provider clarity pass within the five paragraphs",
        f"- Skills chosen by: {_markdown(skills_source)}",
        f"- JD keywords targeted: {_markdown(', '.join(draft.jd_keywords))}",
        f"- Programming: {_markdown(', '.join(skills.programming))}",
        f"- Methods: {_markdown(', '.join(skills.methods))}",
        f"- Tools & Platforms: {_markdown(', '.join(skills.tools_platforms))}",
        f"- Skills: {_markdown(', '.join(skills.professional))}",
        f"- Languages: {LANGUAGES_VALUE} (fixed)",
        f"- Cover role focus: {_markdown(draft.specific_task_or_project)}",
        f"- Cover experience cited: {_markdown(draft.relevant_experience)}",
        f"- Cover activity cited: {_markdown(draft.related_activity)}",
        f"- Cover contribution offered: {_markdown(draft.concrete_contribution)}",
        f"- Cover company domain: {_markdown(draft.company_domain)}",
        f"- Employer address: {_markdown(address)}",
        f"- Address verified: {'yes' if draft.address_verified else 'no'}",
        f"- Address source: {_markdown(address_source)}",
        "- Full CV, cover letter, and both reports were rendered locally",
        "",
    ]
    return "\n".join(lines)


def render_match_notes(
    metadata: JobMetadata,
    skills: SkillSelection,
    draft: AIDraft,
) -> str:
    """Render fit, gap, and risk notes without asking AI for prose files."""

    location = metadata.location or "not supplied"
    lines = [
        "# Match Notes",
        "",
        f"- Role: {_markdown(metadata.title)}",
        f"- Company: {_markdown(metadata.company)}",
        f"- Advertised location: {_markdown(location)}",
        f"- Deterministic CV skills: {_markdown(', '.join((*skills.programming, *skills.methods, *skills.tools_platforms)))}",
        "",
    ]
    lines.extend(_bullet_section("Fit", draft.fit))
    lines.extend(_bullet_section("Gaps", draft.gaps))
    lines.extend(_bullet_section("Risks", draft.risks))
    lines.extend(
        (
            "## Address Evidence",
            "",
            f"- Verified: {'yes' if draft.address_verified else 'no'}",
            f"- Source: {_markdown(draft.address_source_url or 'none')}",
            "",
        )
    )
    return "\n".join(lines).rstrip() + "\n"


def render_application_documents(
    *,
    cv_template: str,
    cover_template: str,
    skills_profiles: str,
    job_description: str,
    draft: AIDraft,
    allow_skill_fallback: bool = True,
) -> GeneratedApplication:
    """Parse, select, render, and structurally validate all four outputs."""

    metadata = parse_job_metadata(job_description)
    inventory = skill_inventory(skills_profiles)
    # The provider selects skills; the approved profile decides. Falling back to
    # its mandatory set keeps a run finishing when a selection cannot be used,
    # rather than shipping a CV with no Skills line.
    skills_source = "provider"
    try:
        skills = group_language_packages(
            drop_unrequested_tier_three(
                resolve_cv_skills(draft.cv_skills, skills_profiles),
                skills_profiles,
                job_description,
            )
        )
    except ValueError:
        if not allow_skill_fallback:
            raise
        skills = group_language_packages(
            select_cv_skills(skills_profiles, job_description)
        )
        skills_source = "deterministic fallback"

    # Report every guard failure at once. Surfacing one at a time meant a draft
    # with two problems needed two repair rounds, and the repair budget is two.
    problems = check_cover_paragraph_edits(
        cover_template, draft.cover_paragraphs, inventory=inventory
    )
    problems.extend(
        check_summary_edit(
            cv_template,
            draft.cv_summary_role_title,
            draft.cv_summary_body,
            inventory=inventory,
        )
    )
    if skills_source == "provider":
        problems.extend(check_mandatory_skills(skills, skills_profiles))
    if problems:
        raise ValueError(" ".join(problems))
    # The provider selects skills; the approved inventory decides. Falling back
    # to deterministic selection keeps a run finishing when repair cannot fix
    # the choice, rather than shipping a CV with no Skills line.
    tailored_cv = render_cv(
        cv_template,
        skills,
        summary_role_title=draft.cv_summary_role_title,
        summary_body=draft.cv_summary_body,
        skill_names=inventory,
    )
    cover_letter = render_cover(
        cover_template,
        metadata,
        draft,
        paragraph_edits=draft.cover_paragraphs,
        skill_names=inventory,
        job_description=job_description,
    )
    return GeneratedApplication(
        metadata=metadata,
        skills=skills,
        draft=draft,
        tailored_cv_tex=tailored_cv,
        cover_letter_tex=cover_letter,
        change_log_md=render_change_log(
            metadata, skills, draft, skills_source=skills_source
        ),
        match_notes_md=render_match_notes(metadata, skills, draft),
    )


__all__ = (
    "AI_DRAFT_FIELDS",
    "AI_DRAFT_JSON_SCHEMA",
    "REVIEW_JSON_SCHEMA",
    "REVIEWABLE_FIELDS",
    "LANGUAGES_VALUE",
    "AIDraft",
    "ReviewIssue",
    "ReviewVerdict",
    "GeneratedApplication",
    "JobMetadata",
    "SkillSelection",
    "check_cover_paragraph_edits",
    "check_mandatory_skills",
    "check_summary_edit",
    "cover_paragraph_sources",
    "drop_unrequested_tier_three",
    "group_language_packages",
    "cover_token_excerpts",
    "format_skill_inventory",
    "format_summary_split",
    "resolve_cv_skills",
    "skill_inventory",
    "SUMMARY_TITLE_TOKEN",
    "assert_summary_token",
    "fill_summary_title",
    "template_summary_text",
    "assert_claims_preserved",
    "assert_similar_enough",
    "protected_terms",
    "parse_job_metadata",
    "parse_provider_json",
    "parse_review_json",
    "render_application_documents",
    "render_change_log",
    "render_cover",
    "render_cv",
    "render_match_notes",
    "render_skills_region",
    "select_cv_skills",
)
