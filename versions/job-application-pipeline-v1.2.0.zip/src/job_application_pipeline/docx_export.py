"""Prepare approved LaTeX documents for DOCX conversion, and style the result.

The DOCX is converted from the same validated ``.tex`` the PDF is compiled
from. Two things stand between a faithful conversion and a usable file.

First, the CV's presentation macros. ``\\resumeSubHeadingListStart`` wraps the
whole document in an ``itemize``, which nests every bullet to level two and
indents the page; ``\\resumeSubheading`` lays an entry header out in a
``tabular*``, which becomes a two-column Word table whose first column is too
narrow for "Friedrich-Alexander-Universitaet Erlangen-Nuernberg". Both are
correct LaTeX and both convert badly, so they are flattened first.

Second, the styles. A converter emits its own defaults -- large blue headings
in a different family from the PDF -- so the produced file is restyled to the
CV's own look: black small-caps section headings over a rule, a serif body,
and links that print black as they do in the PDF.

Nothing here changes a claim, a number, or a name. Presentation only.
"""

from __future__ import annotations

import re
import shutil
import zipfile
from datetime import date
from pathlib import Path


# Applied only when the matching macros are present, so a template that stops
# using them converts unchanged rather than silently gaining stray definitions.
_CV_MACRO_OVERRIDES = r"""
\renewcommand{\resumeSubHeadingListStart}{}
\renewcommand{\resumeSubHeadingListEnd}{}
\renewcommand{\resumeItemListStart}{\begin{itemize}}
\renewcommand{\resumeItemListEnd}{\end{itemize}}
\renewcommand{\resumeItemPlain}[1]{\item #1}
\renewcommand{\resumeFlatItem}[1]{\item #1}
\renewcommand{\resumeSubheading}[4]{%
\par\noindent\textbf{#1}, #2\par\noindent\textit{#3}, #4\par}
"""

_REQUIRED_CV_MACROS = (
    r"\resumeSubHeadingListStart",
    r"\resumeSubheading",
    r"\resumeItemPlain",
)

_DOCUMENT_START = r"\begin{document}"
# The name is a sized, bolded line rather than a heading, so a converter has
# nothing to promote it with. Lifting it into the title gives it one.
_NAME_RE = re.compile(r"\\textbf\{\{\\LARGE\s+([^{}]+?)\}\}")
_TODAY_RE = re.compile(r"\\today\b")


def prepare_for_pandoc(tex: str, *, today: date | None = None) -> tuple[str, str | None]:
    """Return the source to convert and the document title, when there is one.

    The returned title is the candidate name lifted out of the CV heading. It
    is ``None`` for a document that does not carry one, such as the cover
    letter, whose own heading is already a real heading.
    """

    prepared = tex
    if all(macro in prepared for macro in _REQUIRED_CV_MACROS):
        if _DOCUMENT_START not in prepared:
            raise ValueError("LaTeX source has no \\begin{document} to insert before.")
        prepared = prepared.replace(
            _DOCUMENT_START, _CV_MACRO_OVERRIDES + "\n" + _DOCUMENT_START, 1
        )

    title: str | None = None
    match = _NAME_RE.search(prepared)
    if match is not None:
        title = " ".join(match.group(1).split())
        prepared = prepared.replace(match.group(0), "", 1)

    # A letter reads "7 September 2026", not an ISO stamp.
    if _TODAY_RE.search(prepared):
        stamp = (today or date.today()).strftime("%d %B %Y").lstrip("0")
        prepared = _TODAY_RE.sub(stamp.replace("\\", ""), prepared)
    return prepared, title


# Calibri: on every Word install since 2007 and standard on the parsing side,
# so an applicant tracking system reads it without substituting a fallback.
# Any swap here should stay inside that safe set -- Arial, Georgia, Cambria,
# Verdana -- rather than a font the reader may not have.
DOCX_FONT = "Calibri"
# Half-points. 21 = 10.5pt, which holds the CV to the PDF's two pages.
DOCX_BODY_HALF_POINTS = 21

_FONT = (
    f'w:ascii="{DOCX_FONT}" w:hAnsi="{DOCX_FONT}" w:cs="{DOCX_FONT}"'
)

# A4, matching the compiled PDF. Without this the file inherits US Letter,
# which is the wrong paper for the market these applications go to.
_PAGE_WIDTH_TWIPS = 11906
_PAGE_HEIGHT_TWIPS = 16838
_MARGIN_TWIPS = 1080  # 0.75in

_PAGE_SETUP = (
    f'<w:pgSz w:w="{_PAGE_WIDTH_TWIPS}" w:h="{_PAGE_HEIGHT_TWIPS}" />'
    f'<w:pgMar w:top="{_MARGIN_TWIPS}" w:right="{_MARGIN_TWIPS}" '
    f'w:bottom="{_MARGIN_TWIPS}" w:left="{_MARGIN_TWIPS}" '
    'w:header="0" w:footer="0" w:gutter="0" />'
)

_DEFAULT_REPLACEMENTS = (
    (re.compile(r'<w:rFonts w:asciiTheme="minorHAnsi"[^/]*/>'), f"<w:rFonts {_FONT} />"),
    (
        re.compile(r'<w:sz w:val="24" />\s*<w:szCs w:val="24" />'),
        f'<w:sz w:val="{DOCX_BODY_HALF_POINTS}" />'
        f'<w:szCs w:val="{DOCX_BODY_HALF_POINTS}" />',
    ),
    # British English throughout, matching the documents' house style.
    (
        re.compile(r'<w:lang w:val="en-US"([^/]*)/>'),
        r'<w:lang w:val="en-GB"\1/>',
    ),
    (
        re.compile(
            r"<w:pPrDefault>\s*<w:pPr>\s*<w:spacing w:after=\"200\" />"
            r"\s*</w:pPr>\s*</w:pPrDefault>",
            re.S,
        ),
        '<w:pPrDefault><w:pPr><w:spacing w:before="0" w:after="0" '
        'w:line="240" w:lineRule="auto" /></w:pPr></w:pPrDefault>',
    ),
)

_STYLE_OVERRIDES = {
    # Section headings: black, bold, letter-spaced small caps over a rule --
    # the sans-serif reading of the CV's \scshape heading and \titlerule.
    # keepNext stops a heading being stranded at the foot of a page.
    "Heading1": (
        '<w:pPr><w:keepNext /><w:keepLines />'
        '<w:spacing w:before="240" w:after="60" />'
        '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="3" w:color="000000" /></w:pBdr>'
        '<w:outlineLvl w:val="0" /></w:pPr>',
        f'<w:rPr><w:rFonts {_FONT} /><w:b /><w:smallCaps />'
        '<w:spacing w:val="20" /><w:color w:val="000000" />'
        '<w:sz w:val="24" /><w:szCs w:val="24" /></w:rPr>',
    ),
    "Title": (
        '<w:pPr><w:spacing w:after="40" w:line="240" w:lineRule="auto" />'
        "<w:contextualSpacing /></w:pPr>",
        f'<w:rPr><w:rFonts {_FONT} /><w:b /><w:color w:val="000000" />'
        '<w:sz w:val="40" /><w:szCs w:val="40" /></w:rPr>',
    ),
    "BodyText": ('<w:pPr><w:spacing w:before="0" w:after="80" /></w:pPr>', "<w:rPr></w:rPr>"),
    # Entry headers sit in Compact; keepNext ties one to the bullets under it.
    "Compact": (
        '<w:pPr><w:keepNext /><w:spacing w:before="60" w:after="20" /></w:pPr>',
        "<w:rPr></w:rPr>",
    ),
    # The PDF sets colorlinks=false, so the DOCX prints its links black too.
    # Matched by style rather than by colour value: the converter writes the
    # attributes of <w:color> in either order.
    "Hyperlink": (None, '<w:rPr><w:color w:val="000000" /></w:rPr>'),
}


def restyle_document_xml(styles_xml: str) -> str:
    """Apply the house styles to a converter's default ``styles.xml``."""

    styled = styles_xml
    for pattern, replacement in _DEFAULT_REPLACEMENTS:
        styled = pattern.sub(replacement, styled, count=1)
    for style_id, (paragraph, run) in _STYLE_OVERRIDES.items():
        block = re.search(
            rf'<w:style [^>]*w:styleId="{style_id}".*?</w:style>', styled, re.S
        )
        if block is None:
            continue
        body = block.group(0)
        if paragraph is not None:
            body = re.sub(r"<w:pPr>.*?</w:pPr>", paragraph, body, count=1, flags=re.S)
        body = re.sub(r"<w:rPr>.*?</w:rPr>", run, body, count=1, flags=re.S)
        styled = styled.replace(block.group(0), body, 1)
    return styled


_SECT_PR_RE = re.compile(r"<w:sectPr(?P<attrs>[^>]*)>(?P<body>.*?)</w:sectPr>", re.S)
_PAGE_TAG_RE = re.compile(r"<w:pgSz\b[^>]*/>|<w:pgMar\b[^>]*/>")


def apply_page_setup(document_xml: str) -> str:
    """Give the document an explicit A4 page and margins.

    A converter leaves the section properties without a page size, so the file
    inherits the reader's default -- US Letter in most installs -- even though
    the PDF beside it is A4.
    """

    def replace(match: re.Match[str]) -> str:
        body = _PAGE_TAG_RE.sub("", match.group("body"))
        return f'<w:sectPr{match.group("attrs")}>{_PAGE_SETUP}{body}</w:sectPr>'

    if _SECT_PR_RE.search(document_xml) is None:
        return document_xml.replace(
            "</w:body>", f"<w:sectPr>{_PAGE_SETUP}</w:sectPr></w:body>", 1
        )
    return _SECT_PR_RE.sub(replace, document_xml, count=1)


def set_core_properties(core_xml: str, *, title: str, author: str) -> str:
    """Fill the document title and author; some parsers read them."""

    for tag, value in (("dc:title", title), ("dc:creator", author)):
        pattern = re.compile(rf"<{tag}\b[^>]*>.*?</{tag}>|<{tag}\b[^>]*/>", re.S)
        replacement = f"<{tag}>{_escape_xml(value)}</{tag}>"
        if pattern.search(core_xml):
            core_xml = pattern.sub(replacement, core_xml, count=1)
        else:
            core_xml = core_xml.replace(
                "</cp:coreProperties>", replacement + "</cp:coreProperties>", 1
            )
    return core_xml


def _escape_xml(value: str) -> str:
    return (
        value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )


def apply_house_styles(
    docx_path: Path,
    *,
    scratch_dir: Path,
    title: str | None = None,
) -> Path:
    """Rewrite the styles, page setup, and metadata inside a converted DOCX."""

    docx_path = Path(docx_path)
    work = Path(scratch_dir) / f"{docx_path.stem}.unpacked"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    try:
        with zipfile.ZipFile(docx_path) as archive:
            archive.extractall(work)
        styles = work / "word" / "styles.xml"
        if styles.is_file():
            styles.write_text(
                restyle_document_xml(styles.read_text(encoding="utf-8")),
                encoding="utf-8",
            )
        document = work / "word" / "document.xml"
        if document.is_file():
            document.write_text(
                apply_page_setup(document.read_text(encoding="utf-8")),
                encoding="utf-8",
            )
        core = work / "docProps" / "core.xml"
        if title and core.is_file():
            core.write_text(
                set_core_properties(
                    core.read_text(encoding="utf-8"), title=title, author=title
                ),
                encoding="utf-8",
            )
        with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for item in sorted(work.rglob("*")):
                if item.is_file():
                    archive.write(item, item.relative_to(work).as_posix())
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return docx_path


__all__ = [
    "DOCX_FONT",
    "apply_house_styles",
    "apply_page_setup",
    "prepare_for_pandoc",
    "restyle_document_xml",
    "set_core_properties",
]
