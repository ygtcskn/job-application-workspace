"""Build one self-contained provider request for a job advertisement."""

from __future__ import annotations

import html
import re


# The job advertisement stays last so everything before it is a stable,
# cacheable prefix: the other three come from fixed project sources.
PROMPT_PLACEHOLDERS = (
    "SKILLS_INVENTORY",
    "CV_SUMMARY",
    "CV_EVIDENCE",
    "COVER_PARAGRAPHS",
    "JOB_DESCRIPTION",
)
_PLACEHOLDER_RE = re.compile(r"\{\{([A-Z0-9_]+)\}\}")

# A trailing engagement type is metadata about the contract, not part of the
# role noun phrase: "Data Analyst Internship" and "Data Analyst (Intern)" are
# both applications for "Data Analyst".
_ENGAGEMENT_WORDS = (
    r"intern(?:ship)?s?|praktikum|praktikant(?:in)?|working\s+student|"
    r"werkstudent(?:in)?|trainee(?:\s+programme?)?|graduate\s+(?:programme?|scheme)|"
    r"apprentice(?:ship)?|volontariat|thesis|abschlussarbeit"
)
_LEADING_ENGAGEMENT_RE = re.compile(
    rf"^(?:{_ENGAGEMENT_WORDS})[\s,:–—-]+(?=\S)", flags=re.IGNORECASE
)
_TRAILING_ENGAGEMENT_RE = re.compile(
    rf"[\s,\u2013\u2014-]+(?:{_ENGAGEMENT_WORDS})\s*$", flags=re.IGNORECASE
)


# A job title is a noun phrase ending in a role noun. Everything after that
# noun is recruiting metadata -- location, stack, SEO keywords -- and everything
# before it is either seniority (drop) or specialisation (keep). Truncating at
# the last role noun handles all three without a list of every city and tool.
_ROLE_NOUNS = frozenset(
    """
    analyst analytics scientist engineer developer manager consultant specialist
    architect researcher economist statistician strategist officer administrator
    designer director associate assistant modeller modeler actuary quant
    accountant auditor controller advisor adviser planner buyer
    """.split()
)
_SENIORITY_RE = re.compile(
    r"^(?:senior|junior|lead|principal|staff|head\s+of|chief|graduate|associate|"
    r"entry[-\s]level|jr\.?|sr\.?|mid[-\s]level)\s+",
    flags=re.IGNORECASE,
)


def _truncate_at_role_noun(value: str) -> str:
    """Drop everything after the last role noun.

    "Data Analyst Berlin SQL Python" is a "Data Analyst". Specialisation that
    belongs in the title sits before the role noun, as in "Credit Risk Analyst".
    """

    tokens = value.split()
    last = None
    for index, token in enumerate(tokens):
        if token.startswith("("):
            continue
        if token.strip("(),.").casefold() in _ROLE_NOUNS:
            last = index
    if last is None:
        return value
    return " ".join(tokens[: last + 1])


def clean_job_title(value: str) -> str:
    """Return the role noun phrase without work-mode or gender metadata."""

    # Decode entities first: a title arriving as "R&amp;D Analyst" must not
    # be judged on the semicolon its encoding introduced.
    original = re.sub(r"\s+", " ", html.unescape(value)).strip()
    cleaned = re.sub(r"^job\s*title\s*:\s*", "", original, flags=re.IGNORECASE)

    # A parenthetical is never the core role: "(m/w/d)", "(Remote)" and
    # "(Domain Models)" are all qualifiers on "Data Scientist". Specialisation
    # that matters sits before the role noun -- "Credit Risk Analyst".
    cleaned = re.sub(r"\([^()]*\)", " ", cleaned)
    # A dash/pipe suffix is metadata under the approved cover-letter rules.
    # A colon followed by whitespace is the same kind of subtitle separator;
    # requiring that whitespace preserves German gender forms such as ":in".
    cleaned = re.split(
        r"(?:\s+(?:[|\u2013\u2014]|-)\s+|:\s+)", cleaned, maxsplit=1
    )[0]
    # So is a comma suffix: "Business Analyst, Payments Experience" is an
    # application for "Business Analyst". Keeping it also broke the cover
    # letter, whose paragraph patterns terminate a captured title at a comma
    # and so disagreed about what the role was called.
    cleaned = cleaned.split(",", 1)[0]
    cleaned = re.sub(
        r"\s+(?:remote|hybrid|on[ -]?site|full[ -]?time|part[ -]?time|contract|"
        r"vollzeit|teilzeit|befristet)\s*$",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    # Seniority is metadata about the posting, not part of the role noun
    # phrase, in both directions: a CV that calls itself "Junior Data
    # Scientist" is applying for "Data Scientist".
    # Seniority is metadata about the posting, not part of the role noun
    # phrase, in both directions: "Junior Data Scientist" and "Senior Data
    # Scientist" are both applications for "Data Scientist".
    previous_seniority = None
    while previous_seniority != cleaned:
        previous_seniority = cleaned
        stripped = _SENIORITY_RE.sub("", cleaned).strip()
        if stripped:
            cleaned = stripped
    # German postings often lead with the engagement type instead of trailing
    # it. The model may only drop trailing words, so this must be handled here.
    cleaned = _LEADING_ENGAGEMENT_RE.sub("", cleaned)
    cleaned = re.sub(r"(?:\*in|:in)\s*$", "", cleaned, flags=re.IGNORECASE)
    # Repeat: "Data Analyst Internship (m/w/d)" leaves a trailing qualifier only
    # after the parenthetical has gone.
    previous = None
    while previous != cleaned:
        previous = cleaned
        cleaned = _TRAILING_ENGAGEMENT_RE.sub("", cleaned)
    cleaned = _truncate_at_role_noun(cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" ,;:|-/")
    if not cleaned:
        raise ValueError(f"Could not derive a clean job title from: {original!r}")
    # The title has to read naturally in "I am applying for the ... position."
    # A leftover clause or a sentence-length string means the strip missed.
    if len(cleaned.split()) > 6 or any(mark in cleaned for mark in ";:!?"):
        raise ValueError(
            f"Derived job title does not read as a role name: {cleaned!r}"
        )
    return cleaned


def extract_clean_job_title(job_description: str) -> str:
    """Read a clean title, repairing a visibly truncated first heading."""

    ignored = {
        "job description",
        "job posting",
        "about the job",
        "position",
    }
    ignored_labels = (
        "company:",
        "location:",
        "date posted:",
        "posting time:",
        "applicant info:",
        "source:",
        "imported:",
    )
    heading = ""
    for raw_line in job_description.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line or re.fullmatch(r"--- Page \d+ ---", line, flags=re.IGNORECASE):
            continue
        if line.casefold() in ignored or line.casefold().startswith(ignored_labels):
            continue
        heading = clean_job_title(line)
        break
    if not heading:
        raise ValueError("Could not find a job-title heading in the job description.")

    # LinkedIn's top-card text can be clipped by a character or two even when
    # the full title survives in a structured body field. Only replace the
    # heading when the body candidate is a strict extension of it; unrelated
    # prose can therefore never silently change the role.
    body_candidates: list[str] = []
    body_patterns = (
        r"(?im)^\s*Job\s+Title\s*:\s*([^\r\n]+)",
        r"(?i)\brole\s+for\s+an?\s+(.+?)\s+at\s+[^.\r\n]+",
    )
    for pattern in body_patterns:
        for match in re.finditer(pattern, job_description):
            try:
                candidate = clean_job_title(match.group(1))
            except ValueError:
                continue
            if candidate.casefold().startswith(heading.casefold()) and (
                len(candidate) > len(heading)
            ):
                body_candidates.append(candidate)
    if body_candidates:
        return max(body_candidates, key=len)
    return heading


def render_prompt(template: str, replacements: dict[str, str]) -> str:
    """Render exactly the compact prompt placeholder contract."""

    return _render(template, replacements, expected=set(PROMPT_PLACEHOLDERS))


def _render(
    template: str, replacements: dict[str, str], *, expected: set[str]
) -> str:
    supplied = set(replacements)
    if supplied != expected:
        missing = sorted(expected - supplied)
        extra = sorted(supplied - expected)
        details: list[str] = []
        if missing:
            details.append("missing replacements: " + ", ".join(missing))
        if extra:
            details.append("unexpected replacements: " + ", ".join(extra))
        raise ValueError("Invalid prompt replacement contract (" + "; ".join(details) + ").")

    found = _PLACEHOLDER_RE.findall(template)
    missing_in_template = sorted(expected - set(found))
    unexpected_in_template = sorted(set(found) - expected)
    if missing_in_template or unexpected_in_template:
        details = []
        if missing_in_template:
            details.append("missing placeholders: " + ", ".join(missing_in_template))
        if unexpected_in_template:
            details.append(
                "unexpected placeholders: " + ", ".join(unexpected_in_template)
            )
        raise ValueError("Prompt template contract violation (" + "; ".join(details) + ").")

    # A callback performs one pass, so placeholder-like text embedded inside a
    # source document is treated as data and cannot trigger a second replacement.
    return _PLACEHOLDER_RE.sub(lambda match: replacements[match.group(1)], template)


REVIEW_PLACEHOLDERS = ("APPROVED_SOURCES", "TAILORED_DRAFT", "JOB_DESCRIPTION")


def render_review_prompt(template: str, replacements: dict[str, str]) -> str:
    """Render Agent B's prompt under its own placeholder contract."""

    return _render(template, replacements, expected=set(REVIEW_PLACEHOLDERS))


def tier_three_note(skills_profiles: str) -> str:
    """Name the weakest-evidence skills so the model does not volunteer them."""

    from .cv_quality import tier_three_terms

    restricted = tier_three_terms(skills_profiles)
    if not restricted:
        return ""
    return (
        "\n\nThese are weakest-evidence skills. Include one only if the "
        "advertisement names it: " + ", ".join(restricted) + "."
    )


def format_cover_paragraphs(sources: dict[str, str]) -> str:
    """Render the editable paragraphs as a labelled block for the prompt."""

    return "\n\n".join(f"- `{name}`: {text}" for name, text in sources.items())
