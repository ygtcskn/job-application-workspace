"""Tailored CV and cover-letter generation."""

from .paths import Paths, PipelinePaths
from .pipeline import (
    EFFORT_LEVELS,
    ApplicationPipeline,
    JobFailure,
    JobResult,
    PipelineError,
    RunSummary,
    run,
    validate_effort,
    validate_model,
)
from .version import __version__

__all__ = [
    "EFFORT_LEVELS",
    "ApplicationPipeline",
    "JobFailure",
    "JobResult",
    "Paths",
    "PipelineError",
    "PipelinePaths",
    "RunSummary",
    "run",
    "validate_effort",
    "validate_model",
    "__version__",
]
