"""Command-line entry point for provider, model, and effort selection."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence

from .pipeline import EFFORT_LEVELS, PipelineError, run
from .version import __version__


def emit(message: str) -> None:
    """Print one progress line immediately.

    Output is flushed so the console reflects a run in real time, and a console
    that cannot represent a character (a cp1252 terminal and a job ad naming a
    company such as "Eruygur Akademi ve Danismanlik") must not end the run.
    """

    stream = sys.stdout
    try:
        stream.write(message + "\n")
    except UnicodeEncodeError:
        encoding = stream.encoding or "ascii"
        stream.write(message.encode(encoding, "replace").decode(encoding) + "\n")
    stream.flush()


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="job-application-pipeline",
        description="Generate English CV and cover-letter PDFs for every new job ad.",
    )
    parser.add_argument("provider", choices=("claude", "codex"))
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument("--model")
    parser.add_argument(
        "--effort",
        help=(
            "Reasoning-effort level for the selected provider. "
            + "; ".join(
                f"{provider}: {', '.join(levels)}"
                for provider, levels in EFFORT_LEVELS.items()
            )
            + ". Omit to use the CLI default."
        ),
    )
    parser.add_argument(
        "--fresh",
        action="store_true",
        help=(
            "Always call the provider, even when .artifacts already holds "
            "output built from an identical request."
        ),
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-step progress and print only the closing summary.",
    )
    parser.add_argument("--job", help="Process one job number, stem, or PDF filename.")
    parser.add_argument(
        "--limit",
        type=int,
        help="Process at most this many pending jobs after completion filtering.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Plan selected work without writes or executable/provider lookups.",
    )
    parser.add_argument(
        "--estimate-tokens",
        action="store_true",
        help="Estimate compact input tokens and exit without provider calls.",
    )
    parser.add_argument("--token-budget", type=int, help="Maximum estimated input tokens.")
    parser.add_argument(
        "--max-ai-repairs",
        type=int,
        help="Maximum structured repair calls per job (zero disables repairs).",
    )
    parser.add_argument(
        "--continue-on-job-error",
        action="store_true",
        help="Continue after job-content failures; fatal runtime errors still stop.",
    )
    parser.add_argument(
        "--provider-timeout",
        type=float,
        default=20 * 60.0,
        metavar="SECONDS",
        help="Provider wall-clock timeout (default: 1200).",
    )
    parser.add_argument(
        "--latex-timeout",
        type=float,
        default=120.0,
        metavar="SECONDS",
        help="Per-pass pdflatex timeout (default: 120).",
    )
    parser.add_argument(
        "--no-review",
        action="store_true",
        help=(
            "Skip the reviewer agent. Halves provider calls per job at the "
            "cost of the second opinion on fit, keywords, and clarity."
        ),
    )
    parser.add_argument(
        "--no-address-lookup",
        action="store_true",
        help="Disable provider web lookup for an employer postal address.",
    )
    args = parser.parse_args(argv)

    try:
        summary = run(
            args.provider,
            args.model,
            args.effort,
            fresh=args.fresh,
            job=args.job,
            limit=args.limit,
            dry_run=args.dry_run,
            estimate_tokens=args.estimate_tokens,
            token_budget=args.token_budget,
            max_ai_repairs=args.max_ai_repairs,
            continue_on_job_error=args.continue_on_job_error,
            address_lookup=not args.no_address_lookup,
            review=not args.no_review,
            provider_timeout_seconds=args.provider_timeout,
            latex_timeout_seconds=args.latex_timeout,
            progress=None if args.quiet else emit,
        )
    except (OSError, ValueError, PipelineError) as error:
        print(f"Pipeline failed: {error}", file=sys.stderr)
        return 1

    emit("")
    planned = tuple(getattr(summary, "planned", ()))
    estimated_input_tokens = int(getattr(summary, "estimated_input_tokens", 0))
    failed = tuple(getattr(summary, "failed", ()))
    if planned:
        emit(
            f"Planned {len(planned)} job ad(s); estimated compact input: "
            f"{estimated_input_tokens:,} tokens."
        )
        for job_ad in planned:
            emit(f"Would process: {job_ad.name}")
    for result in summary.processed:
        emit(
            f"Created job_{result.document_number} for {result.job_ad.name}: "
            f"{result.archive_dir}"
        )
    if summary.skipped:
        emit(f"Skipped {len(summary.skipped)} already-complete job ad(s).")
    for failure in failed:
        emit(f"Failed {failure.job_ad.name}: {failure.message}")
    emit(
        f"Finished: {len(summary.processed)} created, "
        f"{len(summary.skipped)} skipped, {len(failed)} failed."
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
