"""Cross-process safety, immutable snapshots, and usage accounting.

This module intentionally uses only the Python standard library.  It keeps the
pipeline's state-management primitives independent from document parsing and
provider-specific execution code so they can be tested without external tools.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import tempfile
import time
import uuid
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from .version import __version__


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_LEGACY_TOKENS_RE = re.compile(
    r"(?im)^\s*tokens\s+used\s*:?\s*(?:\r?\n\s*)?([0-9][0-9,_]*)\s*$"
)
_TOKEN_KEYS = frozenset(
    {
        "input_tokens",
        "prompt_tokens",
        "cached_input_tokens",
        "cache_read_input_tokens",
        "output_tokens",
        "completion_tokens",
        "reasoning_output_tokens",
        "reasoning_tokens",
        "total_tokens",
    }
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _format_utc(value: datetime) -> str:
    if value.tzinfo is None:
        raise ValueError("A timezone-aware timestamp is required.")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_utc(value: object, *, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty ISO-8601 timestamp.")
    normalised = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalised)
    except ValueError as error:
        raise ValueError(f"{field} is not a valid ISO-8601 timestamp: {value!r}") from error
    if parsed.tzinfo is None:
        raise ValueError(f"{field} must include a timezone.")
    return parsed.astimezone(timezone.utc)


def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _validate_sha256(value: object, *, field: str) -> str:
    if not isinstance(value, str) or _SHA256_RE.fullmatch(value) is None:
        raise ValueError(f"{field} must be a lowercase SHA-256 digest.")
    return value


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Atomically replace *path* with canonical UTF-8 JSON.

    The temporary file is created beside the destination, flushed, and synced
    before ``os.replace``.  Keeping both files on the same filesystem preserves
    the atomic replacement guarantee on Windows and POSIX.
    """

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = (
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        suffix=".tmp",
        dir=destination.parent,
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise


@dataclass(frozen=True, slots=True)
class LockOwner:
    """Identity recorded in an exclusive lock file."""

    pid: int
    hostname: str
    created_at: datetime
    token: str

    def __post_init__(self) -> None:
        if self.pid <= 0:
            raise ValueError("Lock PID must be positive.")
        if not self.hostname.strip():
            raise ValueError("Lock hostname must not be empty.")
        if not self.token.strip():
            raise ValueError("Lock ownership token must not be empty.")
        if self.created_at.tzinfo is None:
            raise ValueError("Lock timestamp must be timezone-aware.")

    def to_dict(self) -> dict[str, object]:
        return {
            "pid": self.pid,
            "hostname": self.hostname,
            "created_at": _format_utc(self.created_at),
            "token": self.token,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> LockOwner:
        pid = payload.get("pid")
        if isinstance(pid, bool) or not isinstance(pid, int):
            raise ValueError("Lock PID must be an integer.")
        hostname = payload.get("hostname")
        token = payload.get("token")
        if not isinstance(hostname, str) or not isinstance(token, str):
            raise ValueError("Lock hostname and token must be strings.")
        return cls(
            pid=pid,
            hostname=hostname,
            created_at=_parse_utc(payload.get("created_at"), field="created_at"),
            token=token,
        )


class LockError(RuntimeError):
    """Base class for exclusive-lock errors."""


class LockHeldError(LockError):
    """Raised when another owner holds the requested lock."""

    def __init__(self, path: Path, owner: LockOwner | None, detail: str) -> None:
        self.path = Path(path)
        self.owner = owner
        self.detail = detail
        identity = (
            f"PID {owner.pid} on {owner.hostname} since {_format_utc(owner.created_at)}"
            if owner
            else "an unknown owner"
        )
        super().__init__(f"Lock {self.path} is held by {identity}: {detail}")


class LockOwnershipError(LockError):
    """Raised rather than deleting a lock now owned by another process."""


def _pid_is_alive(pid: int) -> bool:
    """Conservatively report whether a local PID may still be alive."""

    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError as error:
        # Windows reports an invalid/nonexistent PID as WinError 87 on some
        # Python versions.  Unknown errors are treated as live for safety.
        if getattr(error, "winerror", None) == 87:
            return False
        return True
    return True


class ExclusiveFileLock:
    """An atomic, cross-process lock with conservative stale-lock recovery.

    A lock is reclaimable only when all of these conditions hold:

    * its metadata is valid;
    * it was created on the current host;
    * its PID is demonstrably no longer alive; and
    * it is at least ``stale_after_seconds`` old.

    Old locks owned by live processes, remote-host locks, and malformed lock
    files are never removed automatically.
    """

    def __init__(
        self,
        path: Path,
        *,
        stale_after_seconds: float = 24 * 60 * 60,
        poll_interval_seconds: float = 0.1,
        reclaim_stale: bool = True,
    ) -> None:
        if stale_after_seconds < 0:
            raise ValueError("stale_after_seconds must be non-negative.")
        if poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be positive.")
        self.path = Path(path)
        self.stale_after_seconds = float(stale_after_seconds)
        self.poll_interval_seconds = float(poll_interval_seconds)
        self.reclaim_stale = reclaim_stale
        self.owner: LockOwner | None = None
        self.reclaimed_owner: LockOwner | None = None

    @property
    def acquired(self) -> bool:
        return self.owner is not None

    def _create(self) -> LockOwner:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        owner = LockOwner(
            pid=os.getpid(),
            hostname=socket.gethostname(),
            created_at=_utc_now(),
            token=uuid.uuid4().hex,
        )
        descriptor = os.open(
            self.path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        try:
            content = (json.dumps(owner.to_dict(), sort_keys=True) + "\n").encode("utf-8")
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
        except BaseException:
            try:
                os.close(descriptor)
            except OSError:
                pass
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
            raise
        return owner

    def _read_existing(self) -> tuple[bytes, LockOwner | None, str | None]:
        try:
            raw = self.path.read_bytes()
        except FileNotFoundError:
            return b"", None, "lock disappeared"
        try:
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, Mapping):
                raise ValueError("metadata root is not an object")
            return raw, LockOwner.from_dict(payload), None
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            return raw, None, f"invalid lock metadata ({error})"

    def _stale_reason(self, owner: LockOwner | None) -> str | None:
        if owner is None:
            return None
        if owner.hostname.casefold() != socket.gethostname().casefold():
            return None
        if _pid_is_alive(owner.pid):
            return None
        age = max(0.0, (_utc_now() - owner.created_at).total_seconds())
        if age < self.stale_after_seconds:
            return None
        return f"owner PID is not alive and lock is {age:.1f} seconds old"

    def _remove_unchanged_stale_lock(self, raw: bytes, owner: LockOwner) -> bool:
        """Remove a stale lock only if its ownership bytes have not changed."""

        try:
            current = self.path.read_bytes()
        except FileNotFoundError:
            return False
        if current != raw:
            return False
        try:
            payload = json.loads(current.decode("utf-8"))
            current_owner = LockOwner.from_dict(payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError):
            return False
        if current_owner.token != owner.token or _pid_is_alive(current_owner.pid):
            return False
        try:
            self.path.unlink()
        except FileNotFoundError:
            return False
        self.reclaimed_owner = current_owner
        return True

    def acquire(self, *, timeout_seconds: float = 0.0) -> ExclusiveFileLock:
        """Acquire the lock or raise :class:`LockHeldError` after *timeout*."""

        if timeout_seconds < 0:
            raise ValueError("timeout_seconds must be non-negative.")
        if self.acquired:
            raise LockError(f"Lock {self.path} is already acquired by this object.")

        deadline = time.monotonic() + timeout_seconds
        last_owner: LockOwner | None = None
        last_detail = "another process owns the lock"
        while True:
            try:
                self.owner = self._create()
                return self
            except FileExistsError:
                raw, existing_owner, metadata_error = self._read_existing()
                if metadata_error == "lock disappeared":
                    continue
                last_owner = existing_owner
                stale_reason = self._stale_reason(existing_owner)
                if stale_reason and self.reclaim_stale:
                    if self._remove_unchanged_stale_lock(raw, existing_owner):
                        continue
                    last_detail = "stale lock changed while recovery was attempted"
                elif stale_reason:
                    last_detail = f"stale lock was not reclaimed ({stale_reason})"
                elif metadata_error:
                    last_detail = metadata_error
                elif existing_owner and _pid_is_alive(existing_owner.pid):
                    last_detail = "recorded owner PID is still alive"
                else:
                    last_detail = "lock is not yet old enough to reclaim safely"

            if time.monotonic() >= deadline:
                raise LockHeldError(self.path, last_owner, last_detail)
            time.sleep(min(self.poll_interval_seconds, max(0.0, deadline - time.monotonic())))

    def release(self) -> None:
        """Release this object's lock without deleting another owner's lock."""

        owner = self.owner
        if owner is None:
            return
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            current_owner = LockOwner.from_dict(payload)
        except FileNotFoundError as error:
            self.owner = None
            raise LockOwnershipError(f"Lock {self.path} disappeared before release.") from error
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError) as error:
            self.owner = None
            raise LockOwnershipError(
                f"Lock {self.path} metadata changed before release; it was not deleted."
            ) from error
        if current_owner.token != owner.token:
            self.owner = None
            raise LockOwnershipError(
                f"Lock {self.path} is now owned by another process; it was not deleted."
            )
        try:
            self.path.unlink()
        except FileNotFoundError as error:
            self.owner = None
            raise LockOwnershipError(f"Lock {self.path} disappeared before release.") from error
        self.owner = None

    def __enter__(self) -> ExclusiveFileLock:
        return self.acquire()

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.release()


@dataclass(frozen=True, slots=True)
class FileSnapshot:
    """Immutable content and digest captured by one file read."""

    path: Path
    label: str
    content: bytes
    sha256: str
    text: str | None = None

    @classmethod
    def capture(
        cls,
        path: Path,
        *,
        label: str | None = None,
        text_extractor: Callable[[bytes], str] | None = None,
    ) -> FileSnapshot:
        resolved = Path(path).resolve()
        if not resolved.is_file():
            raise FileNotFoundError(f"Snapshot source was not found: {resolved}")
        content = resolved.read_bytes()
        text: str | None
        if text_extractor is not None:
            text = text_extractor(content)
        else:
            try:
                text = content.decode("utf-8")
            except UnicodeDecodeError:
                text = None
        return cls(
            path=resolved,
            label=label or resolved.name,
            content=content,
            sha256=_sha256(content),
            text=text,
        )


def _bundle_digest(files: Sequence[FileSnapshot]) -> str:
    digest = hashlib.sha256()
    for snapshot in files:
        encoded_label = snapshot.label.encode("utf-8")
        digest.update(len(encoded_label).to_bytes(8, "big"))
        digest.update(encoded_label)
        digest.update(len(snapshot.content).to_bytes(8, "big"))
        digest.update(snapshot.content)
    return digest.hexdigest()


@dataclass(frozen=True, slots=True)
class SourceBundle:
    """An immutable, consistently hashed set of source files."""

    files: tuple[FileSnapshot, ...]
    sha256: str

    @classmethod
    def capture(
        cls,
        paths: Iterable[Path],
        *,
        base: Path | None = None,
        text_extractors: Mapping[Path, Callable[[bytes], str]] | None = None,
    ) -> SourceBundle:
        resolved_base = Path(base).resolve() if base else None
        extractor_by_path = {
            Path(path).resolve(): extractor for path, extractor in (text_extractors or {}).items()
        }
        snapshots: list[FileSnapshot] = []
        labels: set[str] = set()
        for raw_path in paths:
            path = Path(raw_path).resolve()
            try:
                label = path.relative_to(resolved_base).as_posix() if resolved_base else path.name
            except ValueError:
                label = path.as_posix()
            if label in labels:
                raise ValueError(f"Source bundle contains duplicate label: {label}")
            labels.add(label)
            snapshots.append(
                FileSnapshot.capture(
                    path,
                    label=label,
                    text_extractor=extractor_by_path.get(path),
                )
            )
        immutable_files = tuple(snapshots)
        return cls(files=immutable_files, sha256=_bundle_digest(immutable_files))

    def by_label(self, label: str) -> FileSnapshot:
        for snapshot in self.files:
            if snapshot.label == label:
                return snapshot
        raise KeyError(label)


@dataclass(frozen=True, slots=True)
class JobSnapshot:
    """Immutable job-ad bytes, extracted text, and digest from the same capture."""

    path: Path
    content: bytes
    sha256: str
    text: str | None

    @classmethod
    def capture(
        cls,
        path: Path,
        *,
        text_extractor: Callable[[bytes], str] | None = None,
    ) -> JobSnapshot:
        snapshot = FileSnapshot.capture(path, text_extractor=text_extractor)
        return cls(
            path=snapshot.path,
            content=snapshot.content,
            sha256=snapshot.sha256,
            text=snapshot.text,
        )


def _normalise_artifact_name(value: str) -> str:
    normalised = value.replace("\\", "/")
    path = PurePosixPath(normalised)
    if (
        not normalised
        or any(ord(character) < 32 for character in normalised)
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or any(":" in part for part in path.parts)
    ):
        raise ValueError(f"Artifact path must be a safe relative path: {value!r}")
    return path.as_posix()


@dataclass(frozen=True, slots=True)
class ArtifactChecksum:
    """Size and digest of one completed archive artifact."""

    path: str
    sha256: str
    size: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "path", _normalise_artifact_name(self.path))
        _validate_sha256(self.sha256, field=f"artifact {self.path} sha256")
        if self.size <= 0:
            raise ValueError("Completed artifacts must be non-empty.")

    def to_dict(self) -> dict[str, object]:
        return {"path": self.path, "sha256": self.sha256, "size": self.size}

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> ArtifactChecksum:
        path = payload.get("path")
        sha256 = payload.get("sha256")
        size = payload.get("size")
        if not isinstance(path, str) or not isinstance(sha256, str):
            raise ValueError("Artifact path and sha256 must be strings.")
        if isinstance(size, bool) or not isinstance(size, int):
            raise ValueError("Artifact size must be an integer.")
        return cls(path=path, sha256=sha256, size=size)


@dataclass(frozen=True, slots=True)
class CompletionSentinel:
    """Proof that an archive was completed from specific immutable inputs."""

    pipeline_version: str
    job_sha256: str
    source_bundle_sha256: str
    artifacts: tuple[ArtifactChecksum, ...]
    completed_at: datetime
    schema_version: int = 1

    def __post_init__(self) -> None:
        if self.schema_version != 1:
            raise ValueError(f"Unsupported completion sentinel schema: {self.schema_version}")
        if not self.pipeline_version.strip():
            raise ValueError("Pipeline version must not be empty.")
        _validate_sha256(self.job_sha256, field="job_sha256")
        _validate_sha256(self.source_bundle_sha256, field="source_bundle_sha256")
        if self.completed_at.tzinfo is None:
            raise ValueError("Completion timestamp must be timezone-aware.")
        if not self.artifacts:
            raise ValueError("Completion sentinel must contain at least one artifact.")
        names = [artifact.path for artifact in self.artifacts]
        if len(names) != len(set(names)):
            raise ValueError("Completion sentinel contains duplicate artifact paths.")

    @classmethod
    def create(
        cls,
        archive_dir: Path,
        artifact_paths: Iterable[Path],
        *,
        pipeline_version: str,
        job_sha256: str,
        source_bundle_sha256: str,
        completed_at: datetime | None = None,
    ) -> CompletionSentinel:
        root = Path(archive_dir).resolve()
        artifacts: list[ArtifactChecksum] = []
        for raw_path in artifact_paths:
            candidate = Path(raw_path)
            if not candidate.is_absolute():
                candidate = root / candidate
            resolved = candidate.resolve()
            try:
                relative = resolved.relative_to(root).as_posix()
            except ValueError as error:
                raise ValueError(f"Artifact is outside archive directory: {resolved}") from error
            if not resolved.is_file():
                raise FileNotFoundError(f"Completed artifact was not found: {resolved}")
            content = resolved.read_bytes()
            artifacts.append(
                ArtifactChecksum(path=relative, sha256=_sha256(content), size=len(content))
            )
        return cls(
            pipeline_version=pipeline_version,
            job_sha256=job_sha256,
            source_bundle_sha256=source_bundle_sha256,
            artifacts=tuple(sorted(artifacts, key=lambda item: item.path)),
            completed_at=completed_at or _utc_now(),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "pipeline_version": self.pipeline_version,
            "job_sha256": self.job_sha256,
            "source_bundle_sha256": self.source_bundle_sha256,
            "completed_at": _format_utc(self.completed_at),
            "artifacts": [artifact.to_dict() for artifact in self.artifacts],
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> CompletionSentinel:
        schema_version = payload.get("schema_version")
        if isinstance(schema_version, bool) or not isinstance(schema_version, int):
            raise ValueError("Completion sentinel schema_version must be an integer.")
        pipeline_version = payload.get("pipeline_version")
        job_sha256 = payload.get("job_sha256")
        source_hash = payload.get("source_bundle_sha256")
        raw_artifacts = payload.get("artifacts")
        if not all(isinstance(value, str) for value in (pipeline_version, job_sha256, source_hash)):
            raise ValueError("Completion sentinel version and hashes must be strings.")
        if not isinstance(raw_artifacts, list):
            raise ValueError("Completion sentinel artifacts must be a list.")
        artifacts: list[ArtifactChecksum] = []
        for item in raw_artifacts:
            if not isinstance(item, Mapping):
                raise ValueError("Each completion artifact must be an object.")
            artifacts.append(ArtifactChecksum.from_dict(item))
        return cls(
            schema_version=schema_version,
            pipeline_version=pipeline_version,  # type: ignore[arg-type]
            job_sha256=job_sha256,  # type: ignore[arg-type]
            source_bundle_sha256=source_hash,  # type: ignore[arg-type]
            artifacts=tuple(artifacts),
            completed_at=_parse_utc(payload.get("completed_at"), field="completed_at"),
        )


@dataclass(frozen=True, slots=True)
class CompletionVerification:
    """Result of verifying a completion sentinel and its artifacts."""

    valid: bool
    errors: tuple[str, ...]


def write_completion_sentinel(path: Path, sentinel: CompletionSentinel) -> None:
    atomic_write_json(path, sentinel.to_dict())


def read_completion_sentinel(path: Path) -> CompletionSentinel:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise ValueError(f"Completion sentinel is not valid JSON: {path}") from error
    if not isinstance(payload, Mapping):
        raise ValueError("Completion sentinel root must be an object.")
    return CompletionSentinel.from_dict(payload)


def verify_completion_sentinel(
    archive_dir: Path,
    sentinel: CompletionSentinel | Path,
    *,
    expected_pipeline_version: str | None = None,
    expected_job_sha256: str | None = None,
    expected_source_bundle_sha256: str | None = None,
    required_names: Iterable[str] | None = None,
) -> CompletionVerification:
    """Verify expected provenance plus every artifact size and SHA-256 digest."""

    root = Path(archive_dir).resolve()
    try:
        record = read_completion_sentinel(sentinel) if isinstance(sentinel, Path) else sentinel
    except (OSError, ValueError) as error:
        return CompletionVerification(False, (f"invalid completion sentinel: {error}",))

    errors: list[str] = []
    expected_fields = (
        ("pipeline version", expected_pipeline_version, record.pipeline_version),
        ("job SHA-256", expected_job_sha256, record.job_sha256),
        ("source-bundle SHA-256", expected_source_bundle_sha256, record.source_bundle_sha256),
    )
    for label, expected, actual in expected_fields:
        if expected is not None and expected != actual:
            errors.append(f"{label} mismatch: expected {expected}, found {actual}")

    if required_names is not None:
        try:
            required = {_normalise_artifact_name(name) for name in required_names}
        except ValueError as error:
            return CompletionVerification(False, (f"invalid required artifact name: {error}",))
        actual = {artifact.path for artifact in record.artifacts}
        for name in sorted(required - actual):
            errors.append(f"required artifact is absent from sentinel: {name}")
        for name in sorted(actual - required):
            errors.append(f"unexpected artifact is present in sentinel: {name}")

    for artifact in record.artifacts:
        candidate = (root / Path(artifact.path)).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            errors.append(f"artifact escapes archive directory: {artifact.path}")
            continue
        if not candidate.is_file():
            errors.append(f"artifact is missing: {artifact.path}")
            continue
        content = candidate.read_bytes()
        if len(content) != artifact.size:
            errors.append(
                f"artifact size mismatch for {artifact.path}: "
                f"expected {artifact.size}, found {len(content)}"
            )
        actual_hash = _sha256(content)
        if actual_hash != artifact.sha256:
            errors.append(
                f"artifact SHA-256 mismatch for {artifact.path}: "
                f"expected {artifact.sha256}, found {actual_hash}"
            )
    return CompletionVerification(not errors, tuple(errors))


class CommandTimeoutError(TimeoutError):
    """A subprocess exceeded its configured wall-clock timeout."""

    def __init__(
        self,
        command: Sequence[str],
        timeout_seconds: float,
        output: str,
    ) -> None:
        self.command = tuple(command)
        self.timeout_seconds = timeout_seconds
        self.output = output
        super().__init__(
            f"Command timed out after {timeout_seconds:g} seconds: " + " ".join(self.command)
        )


def _timeout_output(error: subprocess.TimeoutExpired) -> str:
    output = error.stdout if error.stdout is not None else error.output
    if output is None:
        return ""
    if isinstance(output, bytes):
        return output.decode("utf-8", errors="replace")
    return output


def _terminate_process_tree(
    process: subprocess.Popen[str], *, grace_seconds: float
) -> None:
    """Terminate the process and descendants created in its private group."""

    if process.poll() is not None:
        return

    if os.name == "nt":
        # CREATE_NEW_PROCESS_GROUP gives the provider a distinct process-group
        # identity.  taskkill /T is the Windows-native way to include every
        # descendant, including grandchildren launched by a CLI shim.
        try:
            taskkill = subprocess.run(
                ("taskkill", "/PID", str(process.pid), "/T", "/F"),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=max(1.0, grace_seconds),
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if taskkill.returncode != 0 and process.poll() is None:
                process.kill()
        except (OSError, subprocess.SubprocessError):
            try:
                process.kill()
            except OSError:
                pass
        try:
            process.wait(timeout=grace_seconds)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        return

    try:
        process_group = os.getpgid(process.pid)
    except (OSError, ProcessLookupError):
        try:
            process.kill()
        except OSError:
            pass
        return
    try:
        os.killpg(process_group, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        try:
            process.kill()
        except OSError:
            pass
        return
    try:
        process.wait(timeout=grace_seconds)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process_group, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            process.kill()
        process.wait()


def run_command_with_timeout(
    command: Sequence[str],
    *,
    timeout_seconds: float,
    cwd: Path | None = None,
    env: Mapping[str, str] | None = None,
    input_text: str | None = None,
    check: bool = False,
    termination_grace_seconds: float = 5.0,
) -> subprocess.CompletedProcess[str]:
    """Run a command in a private process group with a wall-clock timeout.

    On timeout, the provider process and its descendants are terminated before
    :class:`CommandTimeoutError` is raised.  This avoids leaving Codex/Claude or
    LaTeX child processes alive after the pipeline has moved on.
    """

    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive.")
    if termination_grace_seconds <= 0:
        raise ValueError("termination_grace_seconds must be positive.")
    normalised_command = tuple(str(part) for part in command)
    if not normalised_command:
        raise ValueError("command must not be empty.")
    popen_options: dict[str, object] = {}
    if os.name == "nt":
        popen_options["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        popen_options["start_new_session"] = True

    process = subprocess.Popen(
        normalised_command,
        cwd=cwd,
        env=dict(env) if env is not None else None,
        stdin=subprocess.PIPE if input_text is not None else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        **popen_options,
    )
    try:
        output, _ = process.communicate(input_text, timeout=timeout_seconds)
    except subprocess.TimeoutExpired as error:
        partial_output = _timeout_output(error)
        _terminate_process_tree(process, grace_seconds=termination_grace_seconds)
        try:
            final_output, _ = process.communicate(timeout=termination_grace_seconds)
        except subprocess.TimeoutExpired as final_error:
            final_output = _timeout_output(final_error)
            try:
                process.kill()
            except OSError:
                pass
            # A surviving descendant can keep the inherited pipe open even
            # after the immediate process dies.  Close our reader rather than
            # allowing timeout cleanup itself to hang indefinitely.
            if process.stdout is not None:
                process.stdout.close()
            try:
                process.wait(timeout=termination_grace_seconds)
            except subprocess.TimeoutExpired:
                pass
        # communicate() after termination normally returns the complete stream,
        # including bytes already present on TimeoutExpired.  Some Popen fakes
        # return only the tail, so preserve whichever representation is fuller.
        output = final_output if len(final_output or "") >= len(partial_output) else partial_output
        raise CommandTimeoutError(
            normalised_command,
            timeout_seconds,
            output or "",
        ) from error
    completed = subprocess.CompletedProcess(
        args=normalised_command,
        returncode=process.returncode,
        stdout=output or "",
    )
    if check:
        completed.check_returncode()
    return completed


def _token_integer(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, str):
        compact = value.replace(",", "").replace("_", "").strip()
        return int(compact) if compact.isdigit() else None
    return None


def _first_token(mapping: Mapping[str, object], *keys: str) -> int | None:
    for key in keys:
        parsed = _token_integer(mapping.get(key))
        if parsed is not None:
            return parsed
    return None


def _nested_token(
    mapping: Mapping[str, object], parent: str, *keys: str
) -> int | None:
    nested = mapping.get(parent)
    return _first_token(nested, *keys) if isinstance(nested, Mapping) else None


def _usage_mappings(value: object) -> Iterable[Mapping[str, object]]:
    if isinstance(value, Mapping):
        if any(key in value for key in _TOKEN_KEYS):
            yield value
            return
        for key, nested in value.items():
            if key in {"usage", "token_usage", "response", "result", "data"}:
                yield from _usage_mappings(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _usage_mappings(item)


@dataclass(frozen=True, slots=True)
class UsageMetrics:
    """Normalised provider token usage from one or more logged calls."""

    provider: str | None
    input_tokens: int | None
    cached_input_tokens: int | None
    output_tokens: int | None
    reasoning_tokens: int | None
    total_tokens: int | None
    calls: int
    source: str
    pipeline_version: str = __version__

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "pipeline_version": self.pipeline_version,
            "provider": self.provider,
            "input_tokens": self.input_tokens,
            "cached_input_tokens": self.cached_input_tokens,
            "output_tokens": self.output_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "total_tokens": self.total_tokens,
            "calls": self.calls,
            "source": self.source,
        }


def _sum_optional(values: Iterable[int | None]) -> int | None:
    present = [value for value in values if value is not None]
    return sum(present) if present else None


def parse_provider_usage(text: str, *, provider: str | None = None) -> UsageMetrics:
    """Parse Codex JSONL usage, falling back to legacy ``tokens used`` text."""

    records: list[tuple[int | None, int | None, int | None, int | None, int | None]] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("{"):
            continue
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        for usage in _usage_mappings(payload):
            input_tokens = _first_token(usage, "input_tokens", "prompt_tokens")
            cached_tokens = _first_token(
                usage, "cached_input_tokens", "cache_read_input_tokens"
            )
            if cached_tokens is None:
                cached_tokens = _nested_token(
                    usage, "input_tokens_details", "cached_tokens", "cached_input_tokens"
                )
            output_tokens = _first_token(usage, "output_tokens", "completion_tokens")
            reasoning_tokens = _first_token(
                usage, "reasoning_output_tokens", "reasoning_tokens"
            )
            if reasoning_tokens is None:
                reasoning_tokens = _nested_token(
                    usage, "output_tokens_details", "reasoning_tokens"
                )
            total_tokens = _first_token(usage, "total_tokens")
            if total_tokens is None and (input_tokens is not None or output_tokens is not None):
                total_tokens = (input_tokens or 0) + (output_tokens or 0)
            records.append(
                (
                    input_tokens,
                    cached_tokens,
                    output_tokens,
                    reasoning_tokens,
                    total_tokens,
                )
            )

    if records:
        return UsageMetrics(
            provider=provider,
            input_tokens=_sum_optional(record[0] for record in records),
            cached_input_tokens=_sum_optional(record[1] for record in records),
            output_tokens=_sum_optional(record[2] for record in records),
            reasoning_tokens=_sum_optional(record[3] for record in records),
            total_tokens=_sum_optional(record[4] for record in records),
            calls=len(records),
            source="codex_jsonl",
        )

    legacy_totals = [
        int(match.group(1).replace(",", "").replace("_", ""))
        for match in _LEGACY_TOKENS_RE.finditer(text)
    ]
    if legacy_totals:
        return UsageMetrics(
            provider=provider,
            input_tokens=None,
            cached_input_tokens=None,
            output_tokens=None,
            reasoning_tokens=None,
            total_tokens=sum(legacy_totals),
            calls=len(legacy_totals),
            source="legacy_tokens_used",
        )
    return UsageMetrics(
        provider=provider,
        input_tokens=None,
        cached_input_tokens=None,
        output_tokens=None,
        reasoning_tokens=None,
        total_tokens=None,
        calls=0,
        source="unavailable",
    )


def write_usage_metrics(path: Path, metrics: UsageMetrics) -> None:
    atomic_write_json(path, metrics.to_dict())


__all__ = [
    "ArtifactChecksum",
    "CommandTimeoutError",
    "CompletionSentinel",
    "CompletionVerification",
    "ExclusiveFileLock",
    "FileSnapshot",
    "JobSnapshot",
    "LockError",
    "LockHeldError",
    "LockOwner",
    "LockOwnershipError",
    "SourceBundle",
    "UsageMetrics",
    "atomic_write_json",
    "parse_provider_usage",
    "read_completion_sentinel",
    "run_command_with_timeout",
    "verify_completion_sentinel",
    "write_completion_sentinel",
    "write_usage_metrics",
]
