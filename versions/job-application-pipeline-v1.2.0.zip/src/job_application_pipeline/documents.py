"""Read source documents without mutating them."""

from __future__ import annotations

import io
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


_WORD_NAMESPACE = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_WORD = f"{{{_WORD_NAMESPACE}}}"


def read_text(path: Path) -> str:
    """Read a non-empty UTF-8 text source."""

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Required source file was not found: {path}")
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        raise ValueError(f"Required source file is empty: {path}")
    return text


def _paragraph_text(paragraph: ET.Element) -> str:
    parts: list[str] = []
    for element in paragraph.iter():
        if element.tag == f"{_WORD}t":
            parts.append(element.text or "")
        elif element.tag == f"{_WORD}tab":
            parts.append("\t")
        elif element.tag in {f"{_WORD}br", f"{_WORD}cr"}:
            parts.append("\n")
    return "".join(parts).strip()


def extract_docx_bytes(content: bytes, *, label: str = "DOCX source") -> str:
    """Extract document-order text from an immutable DOCX byte snapshot."""

    try:
        with zipfile.ZipFile(io.BytesIO(content)) as package:
            bad_member = package.testzip()
            if bad_member:
                raise ValueError(
                    f"The Word source is corrupt at package member {bad_member}: {label}"
                )
            try:
                document_xml = package.read("word/document.xml")
            except KeyError as error:
                raise ValueError(
                    f"The Word source does not contain word/document.xml: {label}"
                ) from error
    except zipfile.BadZipFile as error:
        raise ValueError(
            f"The Word source is not a valid DOCX package: {label}"
        ) from error

    try:
        root = ET.fromstring(document_xml)
    except ET.ParseError as error:
        raise ValueError(f"The Word document XML is invalid: {label}") from error

    body = root.find(f"{_WORD}body")
    if body is None:
        raise ValueError(f"The Word source has no document body: {label}")

    blocks: list[str] = []
    for child in body:
        if child.tag == f"{_WORD}p":
            text = _paragraph_text(child)
            if text:
                blocks.append(text)
        elif child.tag == f"{_WORD}tbl":
            rows: list[str] = []
            for row in child.findall(f"{_WORD}tr"):
                cells: list[str] = []
                for cell in row.findall(f"{_WORD}tc"):
                    paragraphs = (
                        _paragraph_text(paragraph)
                        for paragraph in cell.findall(f"{_WORD}p")
                    )
                    cells.append(" / ".join(text for text in paragraphs if text))
                rows.append(" | ".join(cells))
            if rows:
                blocks.append("\n".join(rows))

    extracted = "\n".join(blocks).strip()
    if not extracted:
        raise ValueError(f"No text could be extracted from the Word source: {label}")
    return extracted


def extract_docx_text(path: Path) -> str:
    """Extract paragraphs and tables from a DOCX package in document order."""

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Required Word source was not found: {path}")
    return extract_docx_bytes(path.read_bytes(), label=str(path))


def extract_pdf_bytes(content: bytes, *, label: str = "job description PDF") -> str:
    """Extract page-delimited text from an immutable PDF byte snapshot."""

    try:
        import fitz
    except ImportError as error:  # pragma: no cover - depends on installation
        raise RuntimeError(
            "PyMuPDF is required. Install the project dependencies first."
        ) from error

    document = fitz.open(stream=content, filetype="pdf")
    pages: list[str] = []
    try:
        for page_number, page in enumerate(document, start=1):
            page_text = page.get_text("text").strip()
            if page_text:
                pages.append(f"--- Page {page_number} ---\n{page_text}")
    finally:
        document.close()

    extracted = "\n\n".join(pages).strip()
    if not extracted:
        raise ValueError(
            f"No text could be extracted from {label}; it may be an image-only PDF."
        )
    return extracted


def extract_pdf_text(path: Path) -> str:
    """Extract text from a job-description PDF with page boundaries."""

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Job description PDF was not found: {path}")
    try:
        import fitz
    except ImportError as error:  # pragma: no cover - depends on installation
        raise RuntimeError(
            "PyMuPDF is required. Install the project dependencies first."
        ) from error
    document = fitz.open(path)
    pages: list[str] = []
    try:
        for page_number, page in enumerate(document, start=1):
            page_text = page.get_text("text").strip()
            if page_text:
                pages.append(f"--- Page {page_number} ---\n{page_text}")
    finally:
        document.close()
    extracted = "\n\n".join(pages).strip()
    if not extracted:
        raise ValueError(
            f"No text could be extracted from {path}; it may be an image-only PDF."
        )
    return extracted
