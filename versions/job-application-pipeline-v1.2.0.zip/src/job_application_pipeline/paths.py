"""Filesystem layout for the job application pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


def _default_project_root() -> Path:
    # .../job_py/src/job_application_pipeline/paths.py -> .../job_py
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True, slots=True)
class PipelinePaths:
    """Resolved project, source, working, and external archive paths.

    ``Job_ad`` and ``CVs`` intentionally live beside the project.  Tests and
    alternative installations can override any of the three top-level paths.
    """

    project_root: Path = field(default_factory=_default_project_root)
    job_ads_dir: Path | None = None
    cvs_dir: Path | None = None
    artifacts_dir: Path | None = None

    def __post_init__(self) -> None:
        project_root = Path(self.project_root).resolve()
        parent = project_root.parent
        object.__setattr__(self, "project_root", project_root)
        object.__setattr__(
            self,
            "job_ads_dir",
            Path(self.job_ads_dir).resolve() if self.job_ads_dir else parent / "Job_ad",
        )
        object.__setattr__(
            self,
            "cvs_dir",
            Path(self.cvs_dir).resolve() if self.cvs_dir else parent / "CVs",
        )
        object.__setattr__(
            self,
            "artifacts_dir",
            Path(self.artifacts_dir).resolve()
            if self.artifacts_dir
            else project_root / ".artifacts",
        )

    @property
    def cv_reference_dir(self) -> Path:
        return self.project_root / "data" / "reference" / "cv"

    @property
    def cover_reference_dir(self) -> Path:
        return self.project_root / "data" / "reference" / "cover_letter"

    @property
    def cv_rules(self) -> Path:
        return self.cv_reference_dir / "CV_RULES.md"

    @property
    def bullet_library(self) -> Path:
        return self.cv_reference_dir / "bullet_library.docx"

    @property
    def skills_profiles(self) -> Path:
        return self.cv_reference_dir / "skills_profiles.docx"

    @property
    def cv_template(self) -> Path:
        return self.project_root / "templates" / "cv" / "yigit_coskun_empty.tex"

    @property
    def cover_rules(self) -> Path:
        return self.cover_reference_dir / "COVER_LETTER_RULES.md"

    @property
    def cover_template(self) -> Path:
        return (
            self.project_root
            / "templates"
            / "cover_letter"
            / "yigit_coskun_cover_letter.tex"
        )

    @property
    def prompt_template(self) -> Path:
        return self.project_root / "config" / "prompts" / "application.md"

    @property
    def manifest(self) -> Path:
        return Path(self.cvs_dir) / "application_manifest.csv"

    @property
    def review_prompt(self) -> Path:
        return self.project_root / "config" / "prompts" / "review.md"

    @property
    def source_paths(self) -> tuple[Path, ...]:
        """Every non-job input that affects generated application documents."""

        return (
            self.cv_rules,
            self.bullet_library,
            self.skills_profiles,
            self.cv_template,
            self.cover_rules,
            self.cover_template,
            self.prompt_template,
            self.review_prompt,
        )


# A concise public name while retaining the explicit name used by callers and
# tests that inject a complete layout.
Paths = PipelinePaths
