from __future__ import annotations

import csv
import json
import os
import shutil
import tempfile
import unittest
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Iterator
from unittest.mock import patch

from tests.support import draft_payload, write_project_source_pack

from job_application_pipeline.pipeline import (
    COVER_PDF_NAME,
    CV_PDF_NAME,
    ApplicationPipeline,
    PipelineError,
    _FRESH_MANIFEST_COLUMNS,
)
from job_application_pipeline.paths import Paths
from job_application_pipeline.cv_quality import (
    QualityFinding,
    QualityReport,
    Severity,
)


def _quality_report(*severities: Severity) -> QualityReport:
    selected = severities or (Severity.PASS,)
    findings = tuple(
        QualityFinding(
            check_id=f"TEST_{severity.value}_{index}",
            rule_ids=("TEST",),
            category="integration",
            severity=severity,
            message=f"integration {severity.value.lower()} finding",
            evidence={},
        )
        for index, severity in enumerate(selected, start=1)
    )
    return QualityReport(
        schema_version="test",
        validator_version="test",
        generated_at_utc=datetime.now(timezone.utc).isoformat(),
        provider="test",
        model="",
        effort="",
        hashes={},
        findings=findings,
        provenance=(),
        jd_metrics={},
        jd_matches=(),
    )


def _quality_report_for(
    check_id: str,
    *,
    severity: Severity = Severity.ERROR,
    category: str = "cover-postcompile",
    message: str = "integration repairable cover finding",
) -> QualityReport:
    """Build a report whose check id maps to a structured draft field."""

    return QualityReport(
        schema_version="test",
        validator_version="test",
        generated_at_utc=datetime.now(timezone.utc).isoformat(),
        provider="test",
        model="",
        effort="",
        hashes={},
        findings=(
            QualityFinding(
                check_id=check_id,
                rule_ids=("TEST",),
                category=category,
                severity=severity,
                message=message,
                evidence={},
            ),
        ),
        provenance=(),
        jd_metrics={},
        jd_matches=(),
    )


def _without_region(text: str, name: str) -> str:
    """Return a marked template with one editable body normalised away."""

    start = f"% AI_EDIT_START: {name}"
    end = f"% AI_EDIT_END: {name}"
    prefix, separator, tail = text.partition(start)
    if not separator:
        raise AssertionError(f"missing start marker for {name}")
    _body, separator, suffix = tail.partition(end)
    if not separator:
        raise AssertionError(f"missing end marker for {name}")
    return prefix + start + "\n<EDITABLE>\n" + end + suffix


def _write_fake_quality_reports(
    report: QualityReport,
    *,
    json_path: Path,
    xlsx_path: Path,
) -> None:
    json_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    xlsx_path.write_bytes(b"PK\x03\x04fake integration workbook")


@contextmanager
def _patched_quality_gate(
    *reports: QualityReport | BaseException,
) -> Iterator[object]:
    validator_kwargs: dict[str, object] = {}
    if reports:
        validator_kwargs["side_effect"] = reports
    else:
        validator_kwargs["side_effect"] = lambda **_kwargs: _quality_report()
    with (
        patch(
            "job_application_pipeline.pipeline.extract_pdf_bytes",
            return_value=(
                "--- Page 1 ---\nData Analyst (Remote)\n"
                "Company: Acme GmbH\nExtracted Acme analyst job description"
            ),
        ),
        patch(
            "job_application_pipeline.pipeline.validate_cv_quality",
            **validator_kwargs,
        ) as validator,
        patch(
            "job_application_pipeline.pipeline.write_quality_reports",
            side_effect=_write_fake_quality_reports,
        ),
    ):
        yield validator


class PipelineIntegrationTests(unittest.TestCase):
    def test_missing_cover_pack_fails_preflight_before_executable_lookup(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            project = root / "job_py"
            job_ads = root / "Job_ad"
            job_ads.mkdir()
            (job_ads / "job_description_1.pdf").write_bytes(b"job fixture")
            write_project_source_pack(project, include_cover=False)
            lookups: list[str] = []

            def resolver(name: str) -> str:
                lookups.append(name)
                return str(root / "tools" / f"{name}.exe")

            pipeline = ApplicationPipeline(
                Paths(
                    project_root=project,
                    job_ads_dir=job_ads,
                    cvs_dir=root / "CVs",
                ),
                executable_resolver=resolver,
            )
            with self.assertRaisesRegex(PipelineError, "Required pipeline sources are missing"):
                pipeline.run("claude")

            self.assertEqual(lookups, [])
            self.assertFalse((root / "CVs" / "application_manifest.csv").exists())

    def test_a_numbered_job_ad_archives_under_its_own_number(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            # The default layout ad is company-named; add numbered ones.
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            for name in ("job_description_117.pdf", "job_description_120.pdf"):
                (paths.job_ads_dir / name).write_bytes(f"%PDF-1.4 {name}".encode())
            # A completed application already occupies a much higher number, so
            # a running counter would have produced 141 and 142.
            (paths.cvs_dir / "job_140").mkdir(parents=True)

            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                summary = pipeline.run("claude")

            numbers = sorted(result.document_number for result in summary.processed)
            self.assertEqual(numbers, [117, 120])
            self.assertTrue((paths.cvs_dir / "job_117" / "yigit_coskun_CV.pdf").is_file())
            self.assertTrue((paths.cvs_dir / "job_120" / "yigit_coskun_CV.pdf").is_file())
            self.assertFalse((paths.cvs_dir / "job_141").exists())

    def test_an_explicit_job_selector_reaches_below_the_watermark(self) -> None:
        """Otherwise a finished application could never be rebuilt."""

        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            for name in ("job_description_5.pdf", "job_description_9.pdf"):
                (paths.job_ads_dir / name).write_bytes(f"%PDF-1.4 {name}".encode())
            pipeline = _SuccessfulPipeline(paths, root)
            with _patched_quality_gate():
                pipeline.run("claude")
                # Everything is finished, so the watermark now sits past them all.
                (paths.cvs_dir / "job_5" / CV_PDF_NAME).unlink()
                redone = pipeline.run("claude", job="5")

            self.assertEqual([r.document_number for r in redone.processed], [5])
            self.assertTrue((paths.cvs_dir / "job_5" / CV_PDF_NAME).is_file())

    def test_an_unnumbered_job_ad_is_left_alone(self) -> None:
        """Numbering is the contract, so an ad without a number cannot join it."""

        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "Legacy Company.pdf").write_bytes(b"%PDF-1.4 legacy")
            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                summary = pipeline.run("claude")

            processed = [result.job_ad.name for result in summary.processed]
            self.assertEqual(processed, ["job_description_1.pdf"])
            self.assertNotIn("Legacy Company.pdf", processed)

    def test_a_finished_archive_is_not_reopened_when_sources_change(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            ad = paths.job_ads_dir / "job_description_117.pdf"
            ad.write_bytes(b"%PDF-1.4 first")

            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                first = pipeline.run("claude")
            self.assertEqual(first.processed[0].document_number, 117)
            archive = paths.cvs_dir / "job_117"
            marker = archive / "kept.txt"
            marker.write_text("the finished application", encoding="utf-8")

            # Both immutable inputs change. The completion sentinel is bound to
            # the exact job and versioned source hashes, so this is a rebuild.
            ad.write_bytes(b"%PDF-1.4 second")
            paths.cv_rules.write_text(
                paths.cv_rules.read_text(encoding="utf-8") + "\nA new rule.\n",
                encoding="utf-8",
            )
            with (
                _patched_quality_gate(),
            ):
                second = pipeline.run("claude")

            # The watermark moved past 117 the moment it archived cleanly, so
            # changed sources no longer reopen it. Deleting CVs/job_117 is how
            # a finished application is rebuilt.
            self.assertEqual(second.processed, ())
            self.assertEqual(pipeline.provider_calls, ["claude"])
            self.assertTrue(marker.exists())
            self.assertEqual((archive / "job_ad.pdf").read_bytes(), b"%PDF-1.4 first")

    def test_a_renamed_sentinel_artifact_makes_the_archive_unfinished(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(b"%PDF-1.4 ad")
            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                first = pipeline.run("claude")
                archive = first.processed[0].archive_dir
                canonical_cover = archive / COVER_PDF_NAME
                renamed_cover = archive / "yigit_coskun_CL.pdf"
                canonical_cover.rename(renamed_cover)
                summary = pipeline.run("claude")

            self.assertEqual(len(summary.processed), 1)
            self.assertEqual(summary.processed[0].document_number, 117)
            self.assertEqual(pipeline.provider_calls, ["claude", "claude"])
            self.assertFalse(renamed_cover.exists())
            self.assertTrue((archive / COVER_PDF_NAME).is_file())
            self.assertTrue((archive / ".complete.json").is_file())

    def test_an_empty_archive_folder_is_not_treated_as_finished(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(b"%PDF-1.4 ad")
            # A stray mkdir is the one folder that cannot be a finished archive.
            (paths.cvs_dir / "job_117").mkdir(parents=True)

            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                summary = pipeline.run("claude")

            self.assertEqual(summary.processed[0].document_number, 117)
            self.assertTrue((paths.cvs_dir / "job_117" / CV_PDF_NAME).is_file())
            self.assertEqual(list(paths.cvs_dir.glob(".superseded_*")), [])

    def test_edited_content_in_a_finished_archive_is_not_detected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(
                b"%PDF-1.4 sentinel integrity"
            )
            pipeline = _SuccessfulPipeline(paths, root)

            with _patched_quality_gate():
                first = pipeline.run("claude")
                archive = first.processed[0].archive_dir
                tailored_cv = archive / "tailored_cv.tex"
                tailored_cv.write_text(
                    tailored_cv.read_text(encoding="utf-8") + "% tampered\n",
                    encoding="utf-8",
                )
                second = pipeline.run("claude")

            # A structurally complete archive is past the watermark, so edited
            # content inside it is no longer detected. Only a missing or empty
            # required file reopens the number.
            self.assertEqual(second.processed, ())
            self.assertEqual(pipeline.provider_calls, ["claude"])
            self.assertIn(
                "% tampered",
                (archive / "tailored_cv.tex").read_text(encoding="utf-8"),
            )

    def test_retained_provider_output_is_reused_instead_of_calling_again(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(b"%PDF-1.4 ad")
            pipeline = _SuccessfulPipeline(paths, root)

            # A failing quality gate keeps .artifacts/job_117 for diagnosis,
            # which is the only way provider output survives a run.
            with (
                _patched_quality_gate(_quality_report(Severity.ERROR)),
            ):
                with self.assertRaises(PipelineError):
                    pipeline.run("claude")

            self.assertEqual(pipeline.provider_calls, ["claude"])
            artifact_dir = paths.artifacts_dir / "job_117"
            self.assertTrue((artifact_dir / "output" / "tailored_cv.tex").is_file())

            # The gate is fixed and the run repeated: the four files are still
            # valid for this request, so the provider is not called again.
            with _patched_quality_gate():
                summary = pipeline.run("claude")

            self.assertEqual(pipeline.provider_calls, ["claude"])
            self.assertEqual(summary.processed[0].document_number, 117)
            self.assertTrue((paths.cvs_dir / "job_117" / CV_PDF_NAME).is_file())

    def test_fresh_forces_the_provider_even_with_retained_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(b"%PDF-1.4 ad")
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(_quality_report(Severity.ERROR)),
            ):
                with self.assertRaises(PipelineError):
                    pipeline.run("claude")

            with _patched_quality_gate():
                pipeline.run("claude", fresh=True)

            self.assertEqual(pipeline.provider_calls, ["claude", "claude"])

    def test_a_changed_source_reuses_compact_draft_and_rerenders_locally(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            (paths.job_ads_dir / "job_description_117.pdf").write_bytes(b"%PDF-1.4 ad")
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(_quality_report(Severity.ERROR)),
            ):
                with self.assertRaises(PipelineError):
                    pipeline.run("claude")

            # The compact provider request contains the job ad, not the full
            # source pack. Source changes are applied by deterministic local
            # rendering, so the structured draft remains reusable.
            paths.cv_rules.write_text(
                paths.cv_rules.read_text(encoding="utf-8") + "\nA new rule.\n",
                encoding="utf-8",
            )
            with _patched_quality_gate():
                pipeline.run("claude")

            self.assertEqual(pipeline.provider_calls, ["claude"])

    def test_successful_archive_manifest_and_resume_are_end_to_end(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate() as quality_validator,
            ):
                first = pipeline.run("claude", "claude-sonnet-4.5[latest]", "max")
                # Provider and model deliberately differ: neither is resume identity.
                second = pipeline.run("codex", "openai/gpt-5.6_codex:v1", "xhigh")

            self.assertEqual(len(first.processed), 1)
            self.assertEqual(first.processed[0].document_number, 1)
            self.assertEqual(second.processed, ())
            self.assertEqual(second.skipped, (paths.job_ads_dir / "job_description_1.pdf",))
            archive = paths.cvs_dir / "job_1"
            self.assertTrue((archive / "yigit_coskun_CV.pdf").is_file())
            self.assertTrue((archive / "yigit_coskun_cover_letter.pdf").is_file())
            # Both documents also ship as DOCX, converted from the validated
            # .tex rather than from the PDF.
            self.assertTrue((archive / "yigit_coskun_CV.docx").is_file())
            self.assertTrue((archive / "yigit_coskun_cover_letter.docx").is_file())
            # Converted once, on the run that built the archive. The resume run
            # skips the job, so it does not convert again.
            self.assertEqual(
                pipeline.docx_conversions,
                ["yigit_coskun_CV.docx", "yigit_coskun_cover_letter.docx"],
            )
            self.assertTrue((archive / "tailored_cv.tex").is_file())
            self.assertTrue((archive / "cover_letter.tex").is_file())
            self.assertTrue((archive / "application_request.md").is_file())
            self.assertTrue((archive / "validation.json").is_file())
            self.assertTrue((archive / "validation.xlsx").is_file())
            sentinel_path = archive / ".complete.json"
            self.assertTrue(sentinel_path.is_file())
            self.assertTrue((archive / "usage.json").is_file())
            sentinel = json.loads(sentinel_path.read_text(encoding="utf-8"))
            self.assertEqual(sentinel["pipeline_version"], "1.2.0")
            self.assertEqual(
                {item["path"] for item in sentinel["artifacts"]},
                {
                    CV_PDF_NAME,
                    COVER_PDF_NAME,
                    "job_ad.pdf",
                    "application_request.md",
                    "provider.log",
                    "validation.json",
                    "validation.xlsx",
                    "tailored_cv.tex",
                    "cover_letter.tex",
                    "change_log.md",
                    "match_notes.md",
                    "usage.json",
                },
            )
            for item in sentinel["artifacts"]:
                self.assertGreater(item["size"], 0)
                self.assertRegex(item["sha256"], r"^[0-9a-f]{64}$")
            validation_payload = json.loads(
                (archive / "validation.json").read_text(encoding="utf-8")
            )
            checks = {check["id"]: check["status"] for check in validation_payload["checks"]}
            for check_id in (
                "CV_TEMPLATE_CONTRACT",
                "COVER_TEMPLATE_CONTRACT",
                "COVER_COMPILE",
                "COVER_PAGE_COUNT",
                "COVER_TYPOGRAPHY_CONTRACT",
                "COVER_PDF_TEXT",
                "COVER_LAYOUT_WARNINGS",
            ):
                self.assertEqual(checks[check_id], "PASS")
            self.assertTrue((archive / "tailored_cv.log").is_file())
            self.assertFalse((archive / "request.md").exists())
            self.assertEqual(pipeline.provider_calls, ["claude"])
            self.assertEqual(pipeline.provider_models, ["claude-sonnet-4.5[latest]"])
            self.assertEqual(pipeline.provider_efforts, ["max"])
            self.assertEqual(pipeline.one_page_checks, 1)
            self.assertFalse((paths.artifacts_dir / "job_1").exists())

            with paths.manifest.open("r", encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["JobFile"], "job_description_1.pdf")
            self.assertEqual(rows[0]["Mode"], "cv-and-cover")
            self.assertEqual(rows[0]["Provider"], "claude")
            self.assertEqual(rows[0]["Model"], "claude-sonnet-4.5[latest]")
            self.assertEqual(rows[0]["Effort"], "max")
            self.assertEqual(rows[0]["DocumentNumber"], "1")
            self.assertEqual(rows[0]["Status"], "Ready")
            self.assertEqual(rows[0]["Result"], "")
            self.assertEqual(rows[0]["PipelineVersion"], "1.2.0")
            self.assertRegex(rows[0]["Date"], r"^[A-Z][a-z]+ \d{1,2}, \d{4}$")
            self.assertTrue(rows[0]["JobHash"])
            self.assertTrue(rows[0]["SourceHash"])

            self.assertEqual(quality_validator.call_count, 2)
            pre_call, post_call = quality_validator.call_args_list
            self.assertEqual(
                pre_call.kwargs["job_description"],
                "--- Page 1 ---\nData Analyst (Remote)\n"
                "Company: Acme GmbH\nExtracted Acme analyst job description",
            )
            self.assertEqual(pre_call.kwargs["provider"], "claude")
            self.assertEqual(pre_call.kwargs["model"], "claude-sonnet-4.5[latest]")
            self.assertEqual(pre_call.kwargs["expected_job_title"], "Data Analyst")
            self.assertEqual(pre_call.kwargs["tex_path"].name, "tailored_cv.tex")
            self.assertIsNone(pre_call.kwargs["pdf_path"])
            self.assertIsNone(pre_call.kwargs["log_path"])
            self.assertEqual(post_call.kwargs["pdf_path"].name, "tailored_cv.pdf")
            self.assertEqual(post_call.kwargs["log_path"].name, "tailored_cv.log")
            self.assertIn("job_sha256", post_call.kwargs["hashes"])
            self.assertIn("source_bundle_sha256", post_call.kwargs["hashes"])

    def test_an_archive_without_docx_is_still_finished(self) -> None:
        """The DOCX pair must stay outside the completion contract.

        Every archive built before DOCX existed lacks the pair. If it were in
        _SENTINEL_ARTIFACT_NAMES, each of those would read as unfinished, the
        resume watermark would collapse to job_1, and the whole back catalogue
        would be rebuilt at provider cost.
        """

        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            with _patched_quality_gate():
                first = pipeline.run("claude")
            self.assertEqual(len(first.processed), 1)

            archive = paths.cvs_dir / "job_1"
            for name in ("yigit_coskun_CV.docx", "yigit_coskun_cover_letter.docx"):
                (archive / name).unlink()

            # Stands in for an archive produced before the DOCX step existed.
            with _patched_quality_gate():
                second = pipeline.run("claude")
            self.assertEqual(len(second.processed), 0)
            self.assertEqual(len(second.skipped), 1)

    def test_quality_warnings_are_nonblocking_and_archived(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            warning = _quality_report(Severity.WARN)

            with (
                _patched_quality_gate(warning, warning),
            ):
                summary = pipeline.run("codex")

            self.assertEqual(len(summary.processed), 1)
            archive = paths.cvs_dir / "job_1"
            report = json.loads(
                (archive / "validation.json").read_text(encoding="utf-8")
            )
            self.assertEqual(report["verdict"], "READY_WITH_WARNINGS")
            self.assertEqual(report["counts"]["WARN"], 1)
            self.assertTrue((archive / "validation.xlsx").is_file())
            self.assertTrue(paths.manifest.is_file())

    def test_validation_error_is_repaired_revalidated_and_audited(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            pipeline._max_repair_attempts = 2

            with (
                _patched_quality_gate(
                    _quality_report_for("COVER_PDF_TEXT"),
                    _quality_report(),
                    _quality_report(),
                ) as quality_validator,
            ):
                summary = pipeline.run("codex", "gpt-test", "high")

            self.assertEqual(len(summary.processed), 1)
            self.assertEqual(pipeline.provider_calls, ["codex", "codex"])
            self.assertEqual(quality_validator.call_count, 3)
            archive = paths.cvs_dir / "job_1"
            report = json.loads(
                (archive / "validation.json").read_text(encoding="utf-8")
            )
            repair_checks = [
                check
                for check in report["checks"]
                if check["id"] == "AI_REPAIR_ATTEMPT_1"
            ]
            self.assertEqual(len(repair_checks), 1)
            self.assertEqual(repair_checks[0]["status"], "WARN")
            self.assertEqual(
                repair_checks[0]["evidence"]["trigger_checks"],
                ["COVER_PDF_TEXT"],
            )
            self.assertTrue((archive / "repair_request_1.md").is_file())
            repair_request = (archive / "repair_request_1.md").read_text(
                encoding="utf-8"
            )
            self.assertIn(
                "Change only these allowed fields: company_domain, concrete_contribution, related_activity, relevant_experience, specific_task_or_project",
                repair_request,
            )
            self.assertNotIn("Build reproducible Python analyses", repair_request)
            self.assertTrue((archive / "provider_repair_1.log").is_file())
            self.assertTrue((archive / "validation.xlsx").is_file())
            self.assertFalse((paths.artifacts_dir / "job_1").exists())

    def test_targeted_cover_repair_never_changes_protected_cv_content(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            pipeline._max_repair_attempts = 1

            with (
                _patched_quality_gate(
                    _quality_report_for("COVER_PDF_TEXT"),
                    _quality_report(),
                    _quality_report(),
                ),
            ):
                summary = pipeline.run("codex", "gpt-test", "high")

            self.assertEqual(len(summary.processed), 1)
            self.assertEqual(pipeline.provider_calls, ["codex", "codex"])
            archive = paths.cvs_dir / "job_1"
            report = json.loads(
                (archive / "validation.json").read_text(encoding="utf-8")
            )
            repair = next(
                check
                for check in report["checks"]
                if check["id"] == "AI_REPAIR_ATTEMPT_1"
            )
            self.assertEqual(
                repair["evidence"]["trigger_checks"],
                ["COVER_PDF_TEXT"],
            )
            self.assertEqual(
                repair["evidence"]["allowed_fields"],
                [
                    "company_domain",
                    "concrete_contribution",
                    "related_activity",
                    "relevant_experience",
                    "specific_task_or_project",
                ],
            )
            template = paths.cv_template.read_text(encoding="utf-8")
            generated = (archive / "tailored_cv.tex").read_text(encoding="utf-8")
            # Both editable regions are excluded: SUMMARY differs from the
            # template by design now, because the role slot has been filled.
            self.assertEqual(
                _without_region(_without_region(generated, "SKILLS"), "SUMMARY"),
                _without_region(_without_region(template, "SKILLS"), "SUMMARY"),
            )
            self.assertIn("Build reproducible Python analyses", generated)
            self.assertNotEqual(generated, template)
            self.assertTrue((archive / "yigit_coskun_CV.pdf").is_file())

    def test_automatic_repair_is_bounded_and_retains_exhaustion_audit(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            pipeline._max_repair_attempts = 2

            with (
                _patched_quality_gate(
                    _quality_report_for("COVER_PDF_TEXT", category="integration"),
                    _quality_report_for("COVER_PDF_TEXT", category="integration"),
                    _quality_report_for("COVER_PDF_TEXT", category="integration"),
                ) as quality_validator,
            ):
                with self.assertRaisesRegex(
                    PipelineError,
                    "still failed after 2 automatic repair attempt",
                ):
                    pipeline.run("claude", "claude-test", "high")

            self.assertEqual(pipeline.provider_calls, ["claude", "claude", "claude"])
            self.assertEqual(quality_validator.call_count, 3)
            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            repair_statuses = {
                check["id"]: check["status"]
                for check in report["checks"]
                if check["id"].startswith("AI_REPAIR")
            }
            self.assertEqual(
                repair_statuses,
                {
                    "AI_REPAIR_ATTEMPT_1": "WARN",
                    "AI_REPAIR_ATTEMPT_2": "WARN",
                    "AI_REPAIR_EXHAUSTED": "ERROR",
                },
            )
            self.assertTrue((artifact / "repair_request_1.md").is_file())
            self.assertTrue((artifact / "repair_request_2.md").is_file())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_cover_postcompile_has_a_reserved_third_repair_and_layout_guidance(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _LateCoverPageFailurePipeline(paths, root)
            pipeline._max_repair_attempts = 2

            with (
                _patched_quality_gate(
                    _quality_report_for("COVER_PDF_TEXT"),
                    _quality_report_for("COVER_PDF_TEXT"),
                    _quality_report(),
                    _quality_report(),
                    _quality_report(),
                    _quality_report(),
                ) as quality_validator,
            ):
                summary = pipeline.run("codex", "gpt-test", "high")

            self.assertEqual(len(summary.processed), 1)
            self.assertEqual(quality_validator.call_count, 6)
            self.assertEqual(pipeline.provider_calls, ["codex"] * 4)
            archive = paths.cvs_dir / "job_1"
            report = json.loads(
                (archive / "validation.json").read_text(encoding="utf-8")
            )
            repairs = {
                check["id"]: check
                for check in report["checks"]
                if check["id"].startswith("AI_REPAIR_ATTEMPT_")
            }
            self.assertEqual(set(repairs), {
                "AI_REPAIR_ATTEMPT_1",
                "AI_REPAIR_ATTEMPT_2",
                "AI_REPAIR_ATTEMPT_3",
            })
            self.assertEqual(
                repairs["AI_REPAIR_ATTEMPT_3"]["evidence"]["repair_scope"],
                "cover-postcompile-reserved",
            )
            self.assertEqual(
                repairs["AI_REPAIR_ATTEMPT_3"]["evidence"]["trigger_checks"],
                ["COVER_PAGE_COUNT"],
            )
            request = (archive / "repair_request_3.md").read_text(encoding="utf-8")
            self.assertIn(
                "Change only these allowed fields: company_domain, concrete_contribution, related_activity, relevant_experience, specific_task_or_project",
                request,
            )
            self.assertIn('"check_id":"COVER_PAGE_COUNT"', request)
            self.assertIn("Use the shortest honest wording", request)
            self.assertNotIn("Build reproducible Python analyses", request)

    def test_reserved_cover_postcompile_repair_still_stops_after_third_attempt(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _CoverPageFailurePipeline(paths, root)
            pipeline._max_repair_attempts = 2

            with (
                _patched_quality_gate(*(_quality_report() for _ in range(8))),
            ):
                with self.assertRaisesRegex(
                    PipelineError,
                    "still failed after 3 automatic repair attempt",
                ):
                    pipeline.run("claude", "claude-test", "high")

            self.assertEqual(pipeline.provider_calls, ["claude"] * 4)
            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            exhausted = next(
                check
                for check in report["checks"]
                if check["id"] == "AI_REPAIR_EXHAUSTED"
            )
            self.assertEqual(exhausted["evidence"]["general_attempt_limit"], 2)
            self.assertEqual(
                exhausted["evidence"]["cover_postcompile_reserved_used"], 1
            )
            self.assertTrue((artifact / "repair_request_3.md").is_file())
            self.assertFalse((artifact / "repair_request_4.md").exists())

    def test_cover_typography_contract_uses_locked_fonts_sizes_and_page_size(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            generated_pdf = root / "generated-cover.pdf"
            generated_pdf.write_bytes(b"%PDF-1.4 generated")
            pipeline = ApplicationPipeline(paths)
            pipeline._cover_typography_baseline = (  # noqa: SLF001
                ((595.276, 841.89),),
                (("CMBX12", 14.3462), ("CMR10", 10.9091)),
            )

            cases = (
                (
                    "different subset tags",
                    _FakeTypographyPdf(
                        width=595.276,
                        height=841.89,
                        fonts=(("UVWXYZ+CMBX12", 14.3462), ("UVWXYZ+CMR10", 10.9091)),
                    ),
                    Severity.PASS,
                ),
                (
                    "font family",
                    _FakeTypographyPdf(
                        width=595.276,
                        height=841.89,
                        fonts=(("CMBX12", 14.3462), ("Times-Roman", 10.9091)),
                    ),
                    Severity.ERROR,
                ),
                (
                    "font size",
                    _FakeTypographyPdf(
                        width=595.276,
                        height=841.89,
                        fonts=(("CMBX12", 14.3462), ("CMR10", 12.0)),
                    ),
                    Severity.ERROR,
                ),
                (
                    "page size",
                    _FakeTypographyPdf(
                        width=612.0,
                        height=792.0,
                        fonts=(("CMBX12", 14.3462), ("CMR10", 10.9091)),
                    ),
                    Severity.ERROR,
                ),
            )
            for label, generated, expected in cases:
                with self.subTest(label=label), patch.dict(
                    "sys.modules",
                    {
                        "fitz": SimpleNamespace(
                            open=lambda _path, generated=generated: generated
                        )
                    },
                ):
                    finding = pipeline._cover_typography_contract_finding(  # noqa: SLF001
                        generated_pdf
                    )
                self.assertEqual(finding.check_id, "COVER_TYPOGRAPHY_CONTRACT")
                self.assertEqual(finding.severity, expected)
                if expected is Severity.PASS:
                    recorded = finding.evidence["generated"]["fonts"]
                    self.assertEqual(
                        {entry["name"] for entry in recorded}, {"CMBX12", "CMR10"}
                    )

    def test_precompile_quality_error_blocks_archive_and_retains_reports(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(
                    _quality_report(Severity.ERROR)
                ) as quality_validator,
            ):
                with self.assertRaises(PipelineError) as raised:
                    pipeline.run("claude")

            message = str(raised.exception)
            self.assertIn("1 ERROR finding", message)
            self.assertIn("validation.json", message)
            self.assertIn("validation.xlsx", message)
            self.assertNotIn("\n", message)
            self.assertEqual(quality_validator.call_count, 1)
            artifact = paths.artifacts_dir / "job_1"
            self.assertTrue((artifact / "validation.json").is_file())
            self.assertTrue((artifact / "validation.xlsx").is_file())
            self.assertFalse((artifact / "build").exists())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_postcompile_quality_error_blocks_archive_and_retains_reports(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(
                    _quality_report(),
                    _quality_report(Severity.ERROR),
                ) as quality_validator,
            ):
                with self.assertRaisesRegex(
                    PipelineError, "Application validation failed with 1 ERROR"
                ):
                    pipeline.run("codex")

            self.assertEqual(quality_validator.call_count, 2)
            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            self.assertEqual(report["verdict"], "NOT_READY")
            self.assertTrue((artifact / "build" / "tailored_cv.pdf").is_file())
            self.assertFalse((artifact / "build" / "cover_letter.pdf").exists())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_missing_structured_draft_retains_minimal_error_report(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _MissingDraftPipeline(paths, root)

            with (
                _patched_quality_gate() as quality_validator,
            ):
                with self.assertRaises(PipelineError) as raised:
                    pipeline.run("claude", "claude-test-model")

            message = str(raised.exception)
            self.assertIn(
                "did not create all four fresh outputs: tailored_cv.tex, "
                "cover_letter.tex, change_log.md, match_notes.md",
                message,
            )
            self.assertIn("validation.json", message)
            self.assertIn("validation.xlsx", message)
            self.assertNotIn("\n", message)
            self.assertEqual(quality_validator.call_count, 0)

            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            self.assertEqual(report["verdict"], "NOT_READY")
            self.assertEqual(report["metadata"]["provider"], "claude")
            self.assertEqual(report["metadata"]["model"], "claude-test-model")
            self.assertTrue(report["metadata"]["hashes"]["job_sha256"])
            self.assertTrue(report["metadata"]["hashes"]["source_bundle_sha256"])
            provider_checks = [
                check
                for check in report["checks"]
                if check["id"] == "PROVIDER_OUTPUT_CONTRACT"
            ]
            self.assertEqual(len(provider_checks), 1)
            self.assertEqual(provider_checks[0]["status"], "ERROR")
            self.assertFalse((artifact / "draft_response.json").exists())
            self.assertTrue((artifact / "validation.xlsx").is_file())
            self.assertFalse((artifact / "validation.failure.txt").exists())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_empty_structured_draft_retains_minimal_error_report(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _MissingDraftPipeline(paths, root, leave_empty=True)

            with (
                _patched_quality_gate() as quality_validator,
            ):
                with self.assertRaisesRegex(
                    PipelineError,
                    "did not create all four fresh outputs: tailored_cv.tex, "
                    "cover_letter.tex, change_log.md, match_notes.md",
                ):
                    pipeline.run("codex")

            self.assertEqual(quality_validator.call_count, 0)
            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                [(check["id"], check["status"]) for check in report["checks"]],
                [("PROVIDER_OUTPUT_CONTRACT", "ERROR")],
            )
            self.assertTrue((artifact / "validation.xlsx").is_file())
            self.assertEqual((artifact / "draft_response.json").stat().st_size, 0)
            self.assertEqual(list((artifact / "output").iterdir()), [])
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_post_validator_runtime_replaces_precompile_pass_report(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(
                    _quality_report(),
                    RuntimeError("post validator exploded"),
                ) as quality_validator,
            ):
                with self.assertRaises(PipelineError) as raised:
                    pipeline.run("codex", "codex-test-model")

            message = str(raised.exception)
            self.assertIn("Could not run CV quality validation", message)
            self.assertIn("post validator exploded", message)
            self.assertIn("validation.json", message)
            self.assertNotIn("\n", message)
            self.assertEqual(quality_validator.call_count, 2)

            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            self.assertEqual(report["verdict"], "NOT_READY")
            self.assertEqual(report["metadata"]["provider"], "codex")
            self.assertEqual(report["metadata"]["model"], "codex-test-model")
            self.assertEqual(
                [(check["id"], check["status"]) for check in report["checks"]],
                [("VALIDATOR_RUNTIME", "ERROR")],
            )
            self.assertTrue((artifact / "validation.xlsx").is_file())
            self.assertFalse((artifact / "validation.failure.txt").exists())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_transient_report_write_failure_retains_report_write_error(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            write_calls = 0

            def fail_once_then_write(report, *, json_path, xlsx_path):
                nonlocal write_calls
                write_calls += 1
                if write_calls == 1:
                    raise OSError("transient report write failure")
                _write_fake_quality_reports(
                    report,
                    json_path=json_path,
                    xlsx_path=xlsx_path,
                )

            with (
                patch(
                    "job_application_pipeline.pipeline.extract_pdf_bytes",
                    return_value=(
                        "--- Page 1 ---\nData Analyst (Remote)\n"
                        "Company: Acme GmbH\nExtracted Acme analyst job description"
                    ),
                ),
                patch(
                    "job_application_pipeline.pipeline.validate_cv_quality",
                    return_value=_quality_report(),
                ) as quality_validator,
                patch(
                    "job_application_pipeline.pipeline.write_quality_reports",
                    side_effect=fail_once_then_write,
                ),
            ):
                with self.assertRaises(PipelineError) as raised:
                    pipeline.run("claude")

            message = str(raised.exception)
            self.assertIn("transient report write failure", message)
            self.assertIn("REPORT_WRITE ERROR report was retained", message)
            self.assertIn("validation.json", message)
            # Reports are now persisted only once after both CV validation
            # stages have passed; the failed final write is then recovered.
            self.assertEqual(quality_validator.call_count, 2)
            self.assertEqual(write_calls, 2)

            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            report_write_checks = [
                check for check in report["checks"] if check["id"] == "REPORT_WRITE"
            ]
            self.assertEqual(len(report_write_checks), 1)
            self.assertEqual(report_write_checks[0]["status"], "ERROR")
            self.assertTrue((artifact / "validation.xlsx").is_file())
            self.assertFalse((artifact / "validation.failure.txt").exists())
            self.assertTrue((artifact / "build" / "tailored_cv.pdf").is_file())
            self.assertTrue((artifact / "build" / "cover_letter.pdf").is_file())
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_persistent_runtime_report_write_failure_invalidates_precompile_pass_pair(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            write_calls = 0

            def always_fail(report, *, json_path, xlsx_path):
                nonlocal write_calls
                del report, json_path, xlsx_path
                write_calls += 1
                raise OSError("locked report destination")

            with (
                patch(
                    "job_application_pipeline.pipeline.extract_pdf_bytes",
                    return_value=(
                        "--- Page 1 ---\nData Analyst (Remote)\n"
                        "Company: Acme GmbH\nExtracted Acme analyst job description"
                    ),
                ),
                patch(
                    "job_application_pipeline.pipeline.validate_cv_quality",
                    side_effect=(
                        _quality_report(),
                        RuntimeError("post validator runtime failure"),
                    ),
                ) as quality_validator,
                patch(
                    "job_application_pipeline.pipeline.write_quality_reports",
                    side_effect=always_fail,
                ),
            ):
                with self.assertRaises(PipelineError) as raised:
                    pipeline.run("codex")

            message = str(raised.exception)
            self.assertIn("post validator runtime failure", message)
            self.assertIn("locked report destination", message)
            self.assertIn("Failure marker:", message)
            self.assertIn("validation.failure.txt", message)
            self.assertEqual(quality_validator.call_count, 2)
            self.assertEqual(write_calls, 2)

            artifact = paths.artifacts_dir / "job_1"
            self.assertFalse((artifact / "validation.json").exists())
            self.assertFalse((artifact / "validation.xlsx").exists())
            marker = artifact / "validation.failure.txt"
            self.assertTrue(marker.is_file())
            marker_text = marker.read_text(encoding="utf-8")
            self.assertIn("APPLICATION VALIDATION REPORTS ARE INVALID", marker_text)
            self.assertIn("check_id: REPORT_WRITE", marker_text)
            self.assertIn("locked report destination", marker_text)
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_strict_cv_and_cover_failures_are_added_to_retained_reports(self) -> None:
        for document in ("cv", "cover"):
            with self.subTest(document=document), tempfile.TemporaryDirectory() as temporary:
                root, paths = self._layout(Path(temporary))
                pipeline = _StrictFailurePipeline(paths, root, document=document)

                with (
                    _patched_quality_gate(_quality_report()),
                ):
                    with self.assertRaisesRegex(
                        PipelineError, "Generated LaTeX validation failed"
                    ) as raised:
                        pipeline.run("claude")

                self.assertNotIn("\n", str(raised.exception))
                artifact = paths.artifacts_dir / "job_1"
                report = json.loads(
                    (artifact / "validation.json").read_text(encoding="utf-8")
                )
                structure = [
                    check
                    for check in report["checks"]
                    if check["id"]
                    == ("CV_TEMPLATE_CONTRACT" if document == "cv" else "COVER_TEMPLATE_CONTRACT")
                ]
                self.assertEqual(len(structure), 1)
                self.assertEqual(structure[0]["status"], "ERROR")
                self.assertFalse((paths.cvs_dir / "job_1").exists())
                self.assertFalse(paths.manifest.exists())

    def test_cv_compile_failure_rewrites_retained_reports_as_error(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _CvCompileFailurePipeline(paths, root)

            with (
                _patched_quality_gate(_quality_report()),
            ):
                with self.assertRaisesRegex(PipelineError, "CV compilation failed") as raised:
                    pipeline.run("claude")

            self.assertNotIn("\n", str(raised.exception))
            artifact = paths.artifacts_dir / "job_1"
            report = json.loads(
                (artifact / "validation.json").read_text(encoding="utf-8")
            )
            compile_checks = [
                check for check in report["checks"] if check["id"] == "CV_COMPILE"
            ]
            self.assertEqual(len(compile_checks), 1)
            self.assertEqual(compile_checks[0]["status"], "ERROR")
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertFalse(paths.manifest.exists())

    def test_cover_compile_page_and_pdf_quality_failures_block_archive(self) -> None:
        cases = (
            (_CoverCompileFailurePipeline, "COVER_COMPILE", "compilation failed"),
            (_CoverPageFailurePipeline, "COVER_PAGE_COUNT", "page validation failed"),
            (_CoverQualityFailurePipeline, "COVER_PDF_TEXT", "Application validation failed"),
        )
        for pipeline_class, check_id, expected_message in cases:
            with self.subTest(check_id=check_id), tempfile.TemporaryDirectory() as temporary:
                root, paths = self._layout(Path(temporary))
                pipeline = pipeline_class(paths, root)
                with (
                    _patched_quality_gate(),
                ):
                    with self.assertRaisesRegex(PipelineError, expected_message):
                        pipeline.run("claude")

                artifact = paths.artifacts_dir / "job_1"
                report = json.loads(
                    (artifact / "validation.json").read_text(encoding="utf-8")
                )
                matching = [check for check in report["checks"] if check["id"] == check_id]
                self.assertEqual(len(matching), 1)
                self.assertEqual(matching[0]["status"], "ERROR")
                self.assertFalse((paths.cvs_dir / "job_1").exists())
                self.assertFalse(paths.manifest.exists())

    def test_resume_rebuilds_when_required_sentinel_reports_are_absent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate() as quality_validator,
            ):
                pipeline.run("codex")
                archive = paths.cvs_dir / "job_1"
                (archive / "validation.json").unlink()
                (archive / "validation.xlsx").unlink()
                resumed = pipeline.run("claude")

            self.assertEqual(len(resumed.processed), 1)
            self.assertEqual(resumed.processed[0].document_number, 1)
            self.assertEqual(resumed.skipped, ())
            self.assertEqual(pipeline.provider_calls, ["codex", "claude"])
            self.assertEqual(quality_validator.call_count, 4)
            self.assertTrue((paths.cvs_dir / "job_1" / ".complete.json").is_file())

    def test_identical_bytes_under_two_numbers_are_two_applications(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            acme = paths.job_ads_dir / "job_description_1.pdf"
            duplicate = paths.job_ads_dir / "job_description_2.pdf"
            duplicate.write_bytes(acme.read_bytes())
            os.utime(acme, ns=(1_000_000_000, 1_000_000_000))
            os.utime(duplicate, ns=(2_000_000_000, 2_000_000_000))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(),
            ):
                summary = pipeline.run("codex")

            # The number is the identity, not the bytes: two numbered ads are
            # two applications even when their content is identical.
            self.assertEqual(len(summary.processed), 2)
            self.assertEqual(
                [result.document_number for result in summary.processed], [1, 2]
            )
            self.assertEqual(summary.skipped, ())
            self.assertEqual(pipeline.provider_calls, ["codex", "codex"])
            with paths.manifest.open("r", encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(rows[0]["Model"], "")
            self.assertEqual(rows[0]["Effort"], "")
            self.assertTrue((paths.cvs_dir / "job_1").is_dir())
            self.assertTrue((paths.cvs_dir / "job_2").is_dir())

    def test_resume_requires_both_nonempty_archived_pdfs(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)
            with (
                _patched_quality_gate(),
            ):
                pipeline.run("codex")
                (paths.cvs_dir / "job_1" / "yigit_coskun_cover_letter.pdf").write_bytes(b"")
                repaired = pipeline.run("codex")

            # An empty PDF leaves the archive unfinished, so it does not raise
            # the watermark and the same number is rebuilt in place.
            self.assertEqual(len(repaired.processed), 1)
            self.assertEqual(repaired.processed[0].document_number, 1)
            self.assertTrue(
                (paths.cvs_dir / "job_1" / "yigit_coskun_cover_letter.pdf").stat().st_size
            )

    def test_source_mutation_aborts_commit_and_preserves_the_newer_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            source = paths.cv_rules
            original = source.read_bytes()
            newer = original + b"\nnewer user-authored rule\n"
            pipeline = _SourceMutatingPipeline(
                paths,
                root,
                source_to_mutate=source,
                replacement=newer,
            )

            with _patched_quality_gate():
                with self.assertRaisesRegex(
                    PipelineError,
                    "Captured input changed during the run.*newer bytes were preserved",
                ):
                    pipeline.run("claude")

            self.assertEqual(source.read_bytes(), newer)
            self.assertNotEqual(source.read_bytes(), original)
            self.assertFalse((paths.cvs_dir / "job_1").exists())
            self.assertTrue((paths.artifacts_dir / "job_1").is_dir())

    def test_archive_failure_leaves_no_partial_destination_or_staging_folder(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = ApplicationPipeline(paths)
            artifact = root / "artifact"
            output = artifact / "output"
            build = artifact / "build"
            output.mkdir(parents=True)
            build.mkdir()
            job = root / "job.pdf"
            request = artifact / "request.md"
            provider_log = artifact / "provider.log"
            cv_pdf = build / "tailored_cv.pdf"
            missing_cover_pdf = build / "cover_letter.pdf"
            for path in (job, request, provider_log, cv_pdf):
                path.write_bytes(b"content")
            for name in ("tailored_cv.tex", "cover_letter.tex", "change_log.md", "match_notes.md"):
                (output / name).write_text(name, encoding="utf-8")

            with self.assertRaises(FileNotFoundError):
                pipeline._archive_atomically(  # noqa: SLF001 - atomicity contract
                    document_number=7,
                    job_pdf=job,
                    request_path=request,
                    output_dir=output,
                    build_dir=build,
                    provider_log=provider_log,
                    cv_pdf=cv_pdf,
                    cover_pdf=missing_cover_pdf,
                    artifact_dir=artifact,
                )

            self.assertFalse((paths.cvs_dir / "job_7").exists())
            self.assertEqual(list(paths.cvs_dir.glob(".job_7.*")), [])

    def test_artifact_cleanup_retries_only_a_transient_windows_sharing_lock(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = ApplicationPipeline(paths)
            artifact = paths.artifacts_dir / "job_7"
            (artifact / "output").mkdir(parents=True)
            (artifact / "output" / "retained.txt").write_text(
                "archived already", encoding="utf-8"
            )
            real_rmtree = shutil.rmtree
            calls = 0

            def transiently_locked(path: Path) -> None:
                nonlocal calls
                calls += 1
                if calls <= 2:
                    error = PermissionError("simulated sharing violation")
                    error.winerror = 32
                    raise error
                real_rmtree(path)

            with (
                patch(
                    "job_application_pipeline.pipeline.shutil.rmtree",
                    side_effect=transiently_locked,
                ),
                patch("job_application_pipeline.pipeline.time.sleep") as sleep,
            ):
                pipeline._remove_artifact_dir(artifact)  # noqa: SLF001

            self.assertEqual(calls, 3)
            self.assertEqual(
                [call.args[0] for call in sleep.call_args_list],
                [0.05, 0.1],
            )
            self.assertFalse(artifact.exists())

            unsafe = paths.artifacts_dir / "job_7" / "nested"
            with patch("job_application_pipeline.pipeline.shutil.rmtree") as remove:
                with self.assertRaisesRegex(PipelineError, "Unsafe artifact cleanup path"):
                    pipeline._remove_artifact_dir(unsafe)  # noqa: SLF001
            remove.assert_not_called()

    def test_persistent_postcommit_lock_is_warned_and_cleaned_on_later_skip(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            (paths.job_ads_dir / "job_description_1.pdf").unlink()
            job_ad = paths.job_ads_dir / "job_description_7.pdf"
            job_ad.write_bytes(b"%PDF-1.4 locked cleanup job")
            progress: list[str] = []
            pipeline = _SuccessfulPipeline(paths, root)
            pipeline._progress = progress.append
            delete_calls = 0

            def persistently_locked(_path: Path) -> None:
                nonlocal delete_calls
                delete_calls += 1
                error = PermissionError("simulated persistent sharing violation")
                error.winerror = 32
                raise error

            with (
                _patched_quality_gate(),
                patch(
                    "job_application_pipeline.pipeline.shutil.rmtree",
                    side_effect=persistently_locked,
                ),
                patch("job_application_pipeline.pipeline.time.sleep"),
            ):
                first = pipeline.run("codex")

            self.assertEqual(len(first.processed), 1)
            self.assertEqual(delete_calls, 5)
            archive = paths.cvs_dir / "job_7"
            artifact = paths.artifacts_dir / "job_7"
            self.assertTrue(archive.is_dir())
            self.assertTrue(paths.manifest.is_file())
            self.assertTrue(artifact.is_dir())
            warning = "\n".join(progress)
            self.assertIn("WARNING: job_7 is safely archived", warning)
            self.assertIn("Artifact cleanup was deferred", warning)
            self.assertIn("retried on the next run", warning)

            progress.clear()
            with (
                _patched_quality_gate(),
            ):
                second = pipeline.run("codex")

            self.assertEqual(second.processed, ())
            self.assertEqual(second.skipped, (job_ad.resolve(),))
            self.assertFalse(artifact.exists())
            self.assertIn(
                "removed deferred artifacts for archived job_7",
                "\n".join(progress),
            )

    def test_postcommit_cleanup_keeps_nonsharing_errors_fatal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            _root, paths = self._layout(Path(temporary))
            pipeline = ApplicationPipeline(paths)
            artifact = paths.artifacts_dir / "job_8"
            artifact.mkdir(parents=True)
            error = PermissionError("simulated non-sharing access failure")
            error.winerror = 5

            with patch.object(
                pipeline,
                "_remove_artifact_dir",
                side_effect=error,
            ):
                with self.assertRaises(PermissionError) as raised:
                    pipeline._cleanup_committed_artifact_dir(  # noqa: SLF001
                        artifact,
                        document_number=8,
                    )

            self.assertIs(raised.exception, error)
            self.assertTrue(artifact.exists())

    def test_missing_quality_report_rolls_back_atomic_archive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = ApplicationPipeline(paths)
            artifact = root / "artifact"
            output = artifact / "output"
            build = artifact / "build"
            output.mkdir(parents=True)
            build.mkdir()
            job = root / "job.pdf"
            request = artifact / "request.md"
            provider_log = artifact / "provider.log"
            cv_pdf = build / "tailored_cv.pdf"
            cover_pdf = build / "cover_letter.pdf"
            for path in (job, request, provider_log, cv_pdf, cover_pdf):
                path.write_bytes(b"content")
            for name in ("tailored_cv.tex", "cover_letter.tex", "change_log.md", "match_notes.md"):
                (output / name).write_text(name, encoding="utf-8")
            (artifact / "validation.json").write_text("{}", encoding="utf-8")

            with self.assertRaises(FileNotFoundError):
                pipeline._archive_atomically(  # noqa: SLF001 - atomicity contract
                    document_number=8,
                    job_pdf=job,
                    request_path=request,
                    output_dir=output,
                    build_dir=build,
                    provider_log=provider_log,
                    cv_pdf=cv_pdf,
                    cover_pdf=cover_pdf,
                    artifact_dir=artifact,
                )

            self.assertFalse((paths.cvs_dir / "job_8").exists())
            self.assertEqual(list(paths.cvs_dir.glob(".job_8.*")), [])

    def test_manifest_replace_failure_preserves_previous_manifest_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = ApplicationPipeline(paths)
            paths.manifest.write_text("DocumentNumber,Status\n41,Applied\n", encoding="utf-8")
            before = paths.manifest.read_bytes()
            manifest = pipeline._load_manifest()  # noqa: SLF001
            manifest.rows.append({"DocumentNumber": "42", "Status": ""})

            with patch(
                "job_application_pipeline.pipeline.os.replace",
                side_effect=OSError("simulated atomic replace failure"),
            ):
                with self.assertRaisesRegex(OSError, "simulated"):
                    pipeline._write_manifest(manifest)  # noqa: SLF001

            self.assertEqual(paths.manifest.read_bytes(), before)
            self.assertEqual(list(paths.cvs_dir.glob(".application_manifest.csv.*.tmp")), [])

    def test_legacy_manifest_round_trip_preserves_rows_custom_columns_and_manual_fields(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            fieldnames = [
                name
                for name in _FRESH_MANIFEST_COLUMNS
                if name not in {"SourceHash", "Model", "Effort"}
            ] + ["ReviewerNotes"]
            legacy_row = {name: "" for name in fieldnames}
            legacy_row.update(
                {
                    "JobIndex": "8",
                    "JobFile": "legacy_job.pdf",
                    "DocumentNumber": "73",
                    "Status": "Interviewing",
                    "Result": "Positive",
                    "Date": "July 13, 2026",
                    "ReviewerNotes": "Keep this manual note exactly",
                }
            )
            with paths.manifest.open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerow(legacy_row)

            pipeline = ApplicationPipeline(paths)
            manifest = pipeline._load_manifest()  # noqa: SLF001
            self.assertIn("SourceHash", manifest.fieldnames)
            self.assertIn("Model", manifest.fieldnames)
            self.assertIn("Effort", manifest.fieldnames)
            self.assertIn("ReviewerNotes", manifest.fieldnames)
            self.assertEqual(manifest.rows[0]["SourceHash"], "")
            self.assertEqual(manifest.rows[0]["Model"], "")
            self.assertEqual(manifest.rows[0]["Effort"], "")
            pipeline._write_manifest(manifest)  # noqa: SLF001

            with paths.manifest.open("r", encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream)
                saved_rows = list(reader)
                saved_fields = list(reader.fieldnames or ())
            self.assertIn("SourceHash", saved_fields)
            self.assertIn("Model", saved_fields)
            self.assertIn("Effort", saved_fields)
            self.assertIn("ReviewerNotes", saved_fields)
            self.assertEqual(len(saved_rows), 1)
            self.assertEqual(saved_rows[0]["Status"], "Interviewing")
            self.assertEqual(saved_rows[0]["Result"], "Positive")
            self.assertEqual(saved_rows[0]["Date"], "July 13, 2026")
            self.assertEqual(saved_rows[0]["ReviewerNotes"], "Keep this manual note exactly")

    def test_manifest_commit_failure_rolls_back_new_archive_but_retains_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root, paths = self._layout(Path(temporary))
            pipeline = _SuccessfulPipeline(paths, root)

            with (
                _patched_quality_gate(),
                patch.object(
                    pipeline,
                    "_write_manifest",
                    side_effect=OSError("simulated manifest commit failure"),
                ),
            ):
                with self.assertRaisesRegex(OSError, "manifest commit failure"):
                    pipeline.run("claude")

            self.assertFalse((paths.cvs_dir / "job_1").exists())
            artifact = paths.artifacts_dir / "job_1"
            self.assertTrue(artifact.is_dir())
            self.assertTrue((artifact / "output" / "tailored_cv.tex").is_file())
            self.assertTrue((artifact / "build" / "cover_letter.pdf").is_file())
            self.assertTrue((artifact / "validation.json").is_file())
            self.assertTrue((artifact / "validation.xlsx").is_file())

    @staticmethod
    def _layout(root: Path) -> tuple[Path, Paths]:
        project = root / "job_py"
        job_ads = root / "Job_ad"
        cvs = root / "CVs"
        job_ads.mkdir()
        cvs.mkdir()
        (job_ads / "job_description_1.pdf").write_bytes(b"job fixture")
        write_project_source_pack(project)
        # Production locks a compiled PDF beside the LaTeX cover template so
        # postcompile typography can be compared with approved visual metrics.
        (project / "templates" / "cover_letter" / "yigit_coskun_cover_letter.pdf").write_bytes(
            b"%PDF-1.4 fake locked typography baseline"
        )
        return root, Paths(
            project_root=project,
            job_ads_dir=job_ads,
            cvs_dir=cvs,
            artifacts_dir=project / ".artifacts",
        )


class _SuccessfulPipeline(ApplicationPipeline):
    def __init__(self, paths: Paths, root: Path) -> None:
        tools = root / "tools"
        tools.mkdir()
        for name in ("claude", "codex", "pdflatex", "pandoc"):
            (tools / f"{name}.exe").write_bytes(b"test executable placeholder")
        super().__init__(
            paths,
            executable_resolver=lambda name: tools / f"{name}.exe",
        )
        self.provider_calls: list[str] = []
        self.review_calls: list[str] = []
        self.provider_models: list[str | None] = []
        self.provider_efforts: list[str | None] = []
        self.one_page_checks = 0
        self.docx_conversions: list[str] = []
        # Most integration tests assert the original single-failure boundary.
        # Tests that exercise automatic repair opt in explicitly.
        self._max_repair_attempts = 0

    def _run_provider(
        self,
        provider,
        executable,
        request_path,
        output_dir,
        log_path,
        model=None,
        effort=None,
        **kwargs,
    ) -> None:
        del executable, output_dir
        # Agent B: answer the review call and leave the draft untouched.
        if kwargs.get("response_path") is not None:
            self.review_calls.append(provider)
            Path(kwargs["response_path"]).write_text(
                json.dumps({"approved": True, "issues": []}), encoding="utf-8"
            )
            log_path.write_text(f"fake {provider} review\n", encoding="utf-8")
            return
        self.provider_calls.append(provider)
        self.provider_models.append(model)
        self.provider_efforts.append(effort)
        (request_path.parent / "draft_response.json").write_text(
            json.dumps(
                draft_payload(
                    cv_template_text=self.paths.cv_template.read_text(encoding="utf-8"),
                    cover_template_text=self.paths.cover_template.read_text(
                        encoding="utf-8"
                    ),
                    specific_task_or_project="analysing labour-market data",
                    concrete_contribution="supporting applied data science",
                    fit=["Relevant quantitative analysis experience"],
                )
            ),
            encoding="utf-8",
        )
        log_path.write_text(f"fake {provider} completed\n", encoding="utf-8")

    def _compile_latex(self, tex_path, build_dir, executable, command_log):
        del executable
        pdf = build_dir / f"{tex_path.stem}.pdf"
        pdf.write_bytes(b"%PDF-1.4 fake one-page output")
        (build_dir / f"{tex_path.stem}.log").write_text(
            "fake TeX log without warnings\n",
            encoding="utf-8",
        )
        command_log.write_text("fake pdflatex completed\n", encoding="utf-8")
        return pdf

    def _convert_to_docx(self, tex_path, docx_path, executable, command_log):
        del executable, tex_path
        self.docx_conversions.append(docx_path.name)
        docx_path.write_bytes(b"PK\x03\x04 fake docx output")
        command_log.write_text("fake pandoc completed\n", encoding="utf-8")
        return docx_path

    def _assert_one_page(self, cover_pdf: Path) -> None:
        self.assert_nonempty_cover(cover_pdf)
        self.one_page_checks += 1

    def _cover_postcompile_findings(self, *, cover_pdf: Path, log_path: Path):
        self.assert_nonempty_cover(cover_pdf)
        if not log_path.is_file():
            raise AssertionError("cover postcompile gate did not receive the LaTeX log")
        return (
            QualityFinding(
                check_id="COVER_PDF_TEXT",
                rule_ids=("CL-8",),
                category="cover-postcompile",
                severity=Severity.PASS,
                message="fake cover PDF text passed",
                evidence={},
            ),
            QualityFinding(
                check_id="COVER_LAYOUT_WARNINGS",
                rule_ids=("CL-8",),
                category="cover-postcompile",
                severity=Severity.PASS,
                message="fake cover layout passed",
                evidence={},
            ),
        )

    def _cover_typography_contract_finding(self, cover_pdf: Path):
        self.assert_nonempty_cover(cover_pdf)
        return QualityFinding(
            check_id="COVER_TYPOGRAPHY_CONTRACT",
            rule_ids=("CL-8",),
            category="cover-postcompile",
            severity=Severity.PASS,
            message="fake cover typography passed",
            evidence={},
        )

    @staticmethod
    def assert_nonempty_cover(cover_pdf: Path) -> None:
        if cover_pdf.name != "cover_letter.pdf" or not cover_pdf.read_bytes():
            raise AssertionError("cover one-page gate received the wrong PDF")


class _StrictFailurePipeline(_SuccessfulPipeline):
    def __init__(self, paths: Paths, root: Path, *, document: str) -> None:
        super().__init__(paths, root)
        self.document = document

    def _render_structured_outputs(
        self,
        *,
        response_path,
        output_dir,
        source_bundle,
        job_snapshot,
    ) -> None:
        super()._render_structured_outputs(
            response_path=response_path,
            output_dir=output_dir,
            source_bundle=source_bundle,
            job_snapshot=job_snapshot,
        )
        if self.document == "cv":
            path = output_dir / "tailored_cv.tex"
            path.write_text(
                path.read_text(encoding="utf-8").replace(
                    "Build reproducible Python analyses",
                    "Rewrite the protected bullet for this posting",
                    1,
                ),
                encoding="utf-8",
            )
        else:
            path = output_dir / "cover_letter.tex"
            path.write_text(
                path.read_text(encoding="utf-8").replace(
                    r"\documentclass[11pt]{article}",
                    r"\documentclass[12pt]{article}",
                    1,
                ),
                encoding="utf-8",
            )


class _CvCompileFailurePipeline(_SuccessfulPipeline):
    def _compile_latex(self, tex_path, build_dir, executable, command_log):
        if tex_path.name == "tailored_cv.tex":
            command_log.write_text("simulated pdflatex failure\n", encoding="utf-8")
            raise PipelineError("simulated pdflatex failure\nfull compiler detail")
        return super()._compile_latex(tex_path, build_dir, executable, command_log)


class _CoverCompileFailurePipeline(_SuccessfulPipeline):
    def _compile_latex(self, tex_path, build_dir, executable, command_log):
        if tex_path.name == "cover_letter.tex":
            command_log.write_text("simulated cover pdflatex failure\n", encoding="utf-8")
            raise PipelineError("simulated cover compilation failed")
        return super()._compile_latex(tex_path, build_dir, executable, command_log)


class _CoverPageFailurePipeline(_SuccessfulPipeline):
    def _assert_one_page(self, cover_pdf: Path) -> None:
        self.assert_nonempty_cover(cover_pdf)
        raise PipelineError("simulated cover page validation failed")


class _LateCoverPageFailurePipeline(_SuccessfulPipeline):
    """Reach the CL gate only after two earlier CV-driven repair attempts."""

    def __init__(self, paths: Paths, root: Path) -> None:
        super().__init__(paths, root)
        self._late_page_failure_remaining = True

    def _assert_one_page(self, cover_pdf: Path) -> None:
        super()._assert_one_page(cover_pdf)
        if self._late_page_failure_remaining:
            self._late_page_failure_remaining = False
            raise PipelineError("simulated cover page validation failed")


class _CoverQualityFailurePipeline(_SuccessfulPipeline):
    def _cover_postcompile_findings(self, *, cover_pdf: Path, log_path: Path):
        self.assert_nonempty_cover(cover_pdf)
        return (
            QualityFinding(
                check_id="COVER_PDF_TEXT",
                rule_ids=("CL-8",),
                category="cover-postcompile",
                severity=Severity.ERROR,
                message="simulated cover PDF text failure",
                evidence={},
            ),
        )


class _FakeTypographyPage:
    def __init__(
        self,
        *,
        width: float,
        height: float,
        fonts: tuple[tuple[str, float], ...],
    ) -> None:
        self.mediabox = SimpleNamespace(width=width, height=height)
        self._fonts = fonts

    def get_text(self, mode: str) -> dict[str, object]:
        if mode != "dict":
            raise AssertionError("typography inspection must request span dictionaries")
        spans = [
            {"text": f"visible {index}", "font": font, "size": size}
            for index, (font, size) in enumerate(self._fonts, start=1)
        ]
        return {"blocks": [{"lines": [{"spans": spans}]}]}


class _FakeTypographyPdf:
    def __init__(
        self,
        *,
        width: float,
        height: float,
        fonts: tuple[tuple[str, float], ...],
    ) -> None:
        self._pages = (
            _FakeTypographyPage(width=width, height=height, fonts=fonts),
        )
        self.closed = False

    def __iter__(self):
        return iter(self._pages)

    def close(self) -> None:
        self.closed = True


class _MissingDraftPipeline(_SuccessfulPipeline):
    def __init__(
        self,
        paths: Paths,
        root: Path,
        *,
        leave_empty: bool = False,
    ) -> None:
        super().__init__(paths, root)
        self.leave_empty = leave_empty

    def _run_provider(
        self,
        provider,
        executable,
        request_path,
        output_dir,
        log_path,
        model=None,
        effort=None,
        **kwargs,
    ) -> None:
        super()._run_provider(
            provider,
            executable,
            request_path,
            output_dir,
            log_path,
            model,
            effort,
            **kwargs,
        )
        if kwargs.get("response_path") is not None:
            return
        missing_path = request_path.parent / "draft_response.json"
        if self.leave_empty:
            missing_path.write_bytes(b"")
        else:
            missing_path.unlink()


class _SourceMutatingPipeline(_SuccessfulPipeline):
    def __init__(
        self,
        paths: Paths,
        root: Path,
        *,
        source_to_mutate: Path,
        replacement: bytes,
    ) -> None:
        super().__init__(paths, root)
        self.source_to_mutate = source_to_mutate
        self.replacement = replacement

    def _run_provider(self, *args, **kwargs) -> None:
        super()._run_provider(*args, **kwargs)
        self.source_to_mutate.write_bytes(self.replacement)


if __name__ == "__main__":
    unittest.main()
