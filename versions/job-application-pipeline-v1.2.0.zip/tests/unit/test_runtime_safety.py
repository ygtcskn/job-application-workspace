from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from unittest.mock import Mock

from job_application_pipeline import runtime_safety
from job_application_pipeline.runtime_safety import (
    ArtifactChecksum,
    CommandTimeoutError,
    CompletionSentinel,
    ExclusiveFileLock,
    JobSnapshot,
    LockHeldError,
    LockOwner,
    LockOwnershipError,
    SourceBundle,
    parse_provider_usage,
    read_completion_sentinel,
    run_command_with_timeout,
    verify_completion_sentinel,
    write_completion_sentinel,
    write_usage_metrics,
)


class ExclusiveFileLockTests(unittest.TestCase):
    def test_context_manager_creates_owner_metadata_and_releases(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock_path = Path(temporary) / "pipeline.lock"
            lock = ExclusiveFileLock(lock_path)
            with lock:
                self.assertTrue(lock.acquired)
                payload = json.loads(lock_path.read_text(encoding="utf-8"))
                self.assertEqual(payload["pid"], os.getpid())
                self.assertTrue(payload["hostname"])
                self.assertEqual(payload["token"], lock.owner.token)
                self.assertTrue(payload["created_at"].endswith("Z"))
            self.assertFalse(lock.acquired)
            self.assertFalse(lock_path.exists())

    def test_second_owner_cannot_take_a_live_lock_even_when_it_is_old(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock_path = Path(temporary) / "pipeline.lock"
            old_owner = LockOwner(
                pid=os.getpid(),
                hostname=__import__("socket").gethostname(),
                created_at=datetime.now(timezone.utc) - timedelta(days=30),
                token="live-owner",
            )
            original = json.dumps(old_owner.to_dict()).encode("utf-8")
            lock_path.write_bytes(original)

            with self.assertRaisesRegex(LockHeldError, "still alive"):
                ExclusiveFileLock(lock_path, stale_after_seconds=0).acquire()
            self.assertEqual(lock_path.read_bytes(), original)

    def test_dead_old_local_lock_is_reclaimed_and_reported(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock_path = Path(temporary) / "pipeline.lock"
            stale_owner = LockOwner(
                pid=987_654_321,
                hostname=__import__("socket").gethostname(),
                created_at=datetime.now(timezone.utc) - timedelta(days=2),
                token="dead-owner",
            )
            lock_path.write_text(json.dumps(stale_owner.to_dict()), encoding="utf-8")

            lock = ExclusiveFileLock(lock_path, stale_after_seconds=60)
            with patch(
                "job_application_pipeline.runtime_safety._pid_is_alive",
                return_value=False,
            ):
                lock.acquire()
            self.assertEqual(lock.reclaimed_owner, stale_owner)
            self.assertNotEqual(
                json.loads(lock_path.read_text(encoding="utf-8"))["token"],
                stale_owner.token,
            )
            lock.release()

    def test_malformed_lock_is_not_automatically_deleted(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock_path = Path(temporary) / "pipeline.lock"
            lock_path.write_text("not JSON", encoding="utf-8")
            with self.assertRaisesRegex(LockHeldError, "invalid lock metadata"):
                ExclusiveFileLock(lock_path, stale_after_seconds=0).acquire()
            self.assertEqual(lock_path.read_text(encoding="utf-8"), "not JSON")

    def test_release_refuses_to_delete_a_replaced_lock(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            lock_path = Path(temporary) / "pipeline.lock"
            lock = ExclusiveFileLock(lock_path).acquire()
            replacement = LockOwner(
                pid=os.getpid(),
                hostname=lock.owner.hostname,
                created_at=datetime.now(timezone.utc),
                token="replacement-owner",
            )
            lock_path.write_text(json.dumps(replacement.to_dict()), encoding="utf-8")

            with self.assertRaisesRegex(LockOwnershipError, "another process"):
                lock.release()
            self.assertTrue(lock_path.exists())
            self.assertEqual(
                json.loads(lock_path.read_text(encoding="utf-8"))["token"],
                replacement.token,
            )


class SnapshotTests(unittest.TestCase):
    def test_source_bundle_hashes_the_exact_retained_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = root / "first.txt"
            second = root / "second.txt"
            first.write_text("alpha", encoding="utf-8")
            second.write_text("beta", encoding="utf-8")

            bundle = SourceBundle.capture((first, second), base=root)
            first.write_text("changed after capture", encoding="utf-8")

            # Restate the digest contract independently: each file contributes
            # its length-prefixed label and its length-prefixed bytes, so no
            # relabelling or re-splitting of the same bytes can collide.
            expected = hashlib.sha256()
            for label, content in (("first.txt", b"alpha"), ("second.txt", b"beta")):
                encoded = label.encode("utf-8")
                expected.update(len(encoded).to_bytes(8, "big"))
                expected.update(encoded)
                expected.update(len(content).to_bytes(8, "big"))
                expected.update(content)

            self.assertEqual(bundle.sha256, expected.hexdigest())
            self.assertEqual(bundle.by_label("first.txt").content, b"alpha")
            self.assertEqual(bundle.by_label("first.txt").text, "alpha")
            self.assertEqual(
                bundle.by_label("first.txt").sha256,
                hashlib.sha256(b"alpha").hexdigest(),
            )

    def test_job_text_extractor_receives_the_captured_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            job = Path(temporary) / "job.pdf"
            job.write_bytes(b"fake-pdf-content")
            seen: list[bytes] = []

            def extract(content: bytes) -> str:
                seen.append(content)
                return "extracted job"

            snapshot = JobSnapshot.capture(job, text_extractor=extract)
            job.write_bytes(b"later content")

            self.assertEqual(seen, [b"fake-pdf-content"])
            self.assertEqual(snapshot.content, b"fake-pdf-content")
            self.assertEqual(snapshot.text, "extracted job")
            self.assertEqual(
                snapshot.sha256,
                hashlib.sha256(b"fake-pdf-content").hexdigest(),
            )

    def test_bundle_rejects_duplicate_labels(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            left = root / "left" / "same.txt"
            right = root / "right" / "same.txt"
            left.parent.mkdir()
            right.parent.mkdir()
            left.write_text("left", encoding="utf-8")
            right.write_text("right", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "duplicate label"):
                SourceBundle.capture((left, right))


class CompletionSentinelTests(unittest.TestCase):
    def test_round_trip_and_verify_artifact_provenance(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            archive = Path(temporary)
            cv = archive / "tailored_cv.pdf"
            cover = archive / "cover_letter.pdf"
            cv.write_bytes(b"cv-pdf")
            cover.write_bytes(b"cover-pdf")
            sentinel = CompletionSentinel.create(
                archive,
                (cv, Path("cover_letter.pdf")),
                pipeline_version="1.2.0",
                job_sha256="a" * 64,
                source_bundle_sha256="b" * 64,
            )
            sentinel_path = archive / ".complete.json"
            write_completion_sentinel(sentinel_path, sentinel)

            loaded = read_completion_sentinel(sentinel_path)
            verification = verify_completion_sentinel(
                archive,
                sentinel_path,
                expected_pipeline_version="1.2.0",
                expected_job_sha256="a" * 64,
                expected_source_bundle_sha256="b" * 64,
                required_names=("tailored_cv.pdf", "cover_letter.pdf"),
            )
            self.assertEqual(loaded, sentinel)
            self.assertTrue(verification.valid, verification.errors)
            self.assertEqual(
                [artifact.path for artifact in loaded.artifacts],
                ["cover_letter.pdf", "tailored_cv.pdf"],
            )

    def test_tampering_and_expected_metadata_mismatch_are_reported(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            archive = Path(temporary)
            artifact = archive / "result.pdf"
            artifact.write_bytes(b"original")
            sentinel = CompletionSentinel.create(
                archive,
                (artifact,),
                pipeline_version="1.2.0",
                job_sha256="a" * 64,
                source_bundle_sha256="b" * 64,
            )
            artifact.write_bytes(b"tampered")

            verification = verify_completion_sentinel(
                archive,
                sentinel,
                expected_job_sha256="c" * 64,
            )
            self.assertFalse(verification.valid)
            self.assertTrue(
                any("job SHA-256 mismatch" in error for error in verification.errors)
            )
            self.assertTrue(
                any("artifact SHA-256 mismatch" in error for error in verification.errors)
            )

    def test_empty_artifact_set_and_inexact_required_names_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            archive = Path(temporary)
            with self.assertRaisesRegex(ValueError, "at least one artifact"):
                CompletionSentinel.create(
                    archive,
                    (),
                    pipeline_version="1.2.0",
                    job_sha256="a" * 64,
                    source_bundle_sha256="b" * 64,
                )

            artifact = archive / "tailored_cv.pdf"
            artifact.write_bytes(b"cv")
            sentinel = CompletionSentinel.create(
                archive,
                (artifact,),
                pipeline_version="1.2.0",
                job_sha256="a" * 64,
                source_bundle_sha256="b" * 64,
            )
            verification = verify_completion_sentinel(
                archive,
                sentinel,
                required_names=("tailored_cv.pdf", "cover_letter.pdf"),
            )
            self.assertFalse(verification.valid)
            self.assertIn(
                "required artifact is absent from sentinel: cover_letter.pdf",
                verification.errors,
            )

            exact_subset = verify_completion_sentinel(
                archive,
                sentinel,
                required_names=("cover_letter.pdf",),
            )
            self.assertIn(
                "unexpected artifact is present in sentinel: tailored_cv.pdf",
                exact_subset.errors,
            )

    def test_artifact_paths_must_be_safe_and_inside_the_archive(self) -> None:
        with self.assertRaisesRegex(ValueError, "safe relative path"):
            ArtifactChecksum(path="../escape.pdf", sha256="a" * 64, size=1)

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive = root / "archive"
            archive.mkdir()
            outside = root / "outside.pdf"
            outside.write_bytes(b"outside")
            with self.assertRaisesRegex(ValueError, "outside archive"):
                CompletionSentinel.create(
                    archive,
                    (outside,),
                    pipeline_version="1.2.0",
                    job_sha256="a" * 64,
                    source_bundle_sha256="b" * 64,
                )


class CommandTimeoutTests(unittest.TestCase):
    @unittest.skipUnless(os.name == "nt", "Windows-specific taskkill contract")
    def test_windows_tree_termination_uses_taskkill_recursive_flag(self) -> None:
        process = Mock()
        process.pid = 4321
        process.poll.return_value = None
        process.wait.return_value = 0
        taskkill_result = subprocess.CompletedProcess([], 0)
        with patch(
            "job_application_pipeline.runtime_safety.subprocess.run",
            return_value=taskkill_result,
        ) as taskkill:
            runtime_safety._terminate_process_tree(process, grace_seconds=2)

        self.assertEqual(
            taskkill.call_args.args[0],
            ("taskkill", "/PID", "4321", "/T", "/F"),
        )
        process.wait.assert_called_once_with(timeout=2)
        process.kill.assert_not_called()

    def test_timeout_terminates_process_tree_and_preserves_output(self) -> None:
        expired = subprocess.TimeoutExpired(
            cmd=("provider", "run"),
            timeout=12,
            output=b"partial provider output",
        )
        process = Mock()
        process.communicate.side_effect = [expired, ("partial provider output", None)]
        process.returncode = -1
        with patch(
            "job_application_pipeline.runtime_safety.subprocess.Popen",
            return_value=process,
        ) as mocked_popen, patch(
            "job_application_pipeline.runtime_safety._terminate_process_tree"
        ) as terminate_tree:
            with self.assertRaises(CommandTimeoutError) as raised:
                run_command_with_timeout(
                    ("provider", "run"),
                    timeout_seconds=12,
                    termination_grace_seconds=3,
                    cwd=Path("work"),
                )

        self.assertEqual(raised.exception.command, ("provider", "run"))
        self.assertEqual(raised.exception.timeout_seconds, 12)
        self.assertEqual(raised.exception.output, "partial provider output")
        process.communicate.assert_any_call(None, timeout=12)
        terminate_tree.assert_called_once_with(process, grace_seconds=3)
        self.assertEqual(mocked_popen.call_args.kwargs["stderr"], subprocess.STDOUT)
        if os.name == "nt":
            self.assertIn("creationflags", mocked_popen.call_args.kwargs)
        else:
            self.assertTrue(mocked_popen.call_args.kwargs["start_new_session"])

    def test_successful_command_is_returned_as_completed_process(self) -> None:
        process = Mock()
        process.communicate.return_value = ("done", None)
        process.returncode = 0
        with patch(
            "job_application_pipeline.runtime_safety.subprocess.Popen",
            return_value=process,
        ):
            completed = run_command_with_timeout(
                ("provider", "run"), timeout_seconds=12, input_text="request"
            )
        self.assertEqual(completed.returncode, 0)
        self.assertEqual(completed.stdout, "done")
        process.communicate.assert_called_once_with("request", timeout=12)

    def test_timeout_must_be_positive(self) -> None:
        with self.assertRaisesRegex(ValueError, "positive"):
            run_command_with_timeout(("provider",), timeout_seconds=0)


class UsageMetricsTests(unittest.TestCase):
    def test_codex_jsonl_usage_records_are_normalised_and_summed(self) -> None:
        log = "\n".join(
            (
                json.dumps({"type": "thread.started", "thread_id": "abc"}),
                json.dumps(
                    {
                        "type": "turn.completed",
                        "usage": {
                            "input_tokens": 100,
                            "cached_input_tokens": 60,
                            "output_tokens": 20,
                            "output_tokens_details": {"reasoning_tokens": 7},
                        },
                    }
                ),
                json.dumps(
                    {
                        "type": "turn.completed",
                        "usage": {
                            "prompt_tokens": "200",
                            "completion_tokens": 30,
                            "total_tokens": 230,
                        },
                    }
                ),
            )
        )
        metrics = parse_provider_usage(log, provider="codex")

        self.assertEqual(metrics.provider, "codex")
        self.assertEqual(metrics.input_tokens, 300)
        self.assertEqual(metrics.cached_input_tokens, 60)
        self.assertEqual(metrics.output_tokens, 50)
        self.assertEqual(metrics.reasoning_tokens, 7)
        self.assertEqual(metrics.total_tokens, 350)
        self.assertEqual(metrics.calls, 2)
        self.assertEqual(metrics.source, "codex_jsonl")

    def test_legacy_tokens_used_and_unavailable_logs(self) -> None:
        metrics = parse_provider_usage(
            "work output\ntokens used\n126,361\nmore\ntokens used: 1_200\n",
            provider="codex",
        )
        self.assertEqual(metrics.total_tokens, 127_561)
        self.assertEqual(metrics.calls, 2)
        self.assertEqual(metrics.source, "legacy_tokens_used")

        empty = parse_provider_usage("provider returned no accounting")
        self.assertIsNone(empty.total_tokens)
        self.assertEqual(empty.calls, 0)
        self.assertEqual(empty.source, "unavailable")

    def test_usage_json_is_written_atomically(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / "usage.json"
            metrics = parse_provider_usage("tokens used\n42", provider="codex")
            write_usage_metrics(destination, metrics)

            payload = json.loads(destination.read_text(encoding="utf-8"))
            self.assertEqual(payload["schema_version"], 1)
            self.assertEqual(payload["provider"], "codex")
            self.assertEqual(payload["total_tokens"], 42)
            self.assertFalse(list(destination.parent.glob(".usage.json.*.tmp")))


if __name__ == "__main__":
    unittest.main()
