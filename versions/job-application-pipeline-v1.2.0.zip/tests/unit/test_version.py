from __future__ import annotations

import io
import tempfile
import tomllib
import unittest
from contextlib import redirect_stdout
from pathlib import Path

import job_application_pipeline
from job_application_pipeline.__main__ import main
from job_application_pipeline.cv_quality import QualityReport
from job_application_pipeline.paths import PipelinePaths
from job_application_pipeline.pipeline import ApplicationPipeline
from job_application_pipeline.runtime_safety import UsageMetrics
from job_application_pipeline.version import __version__


ROOT = Path(__file__).resolve().parents[2]
EXPECTED_VERSION = "1.2.0"


class VersionContractTests(unittest.TestCase):
    def test_version_has_one_runtime_source_and_dynamic_project_metadata(self) -> None:
        self.assertEqual(__version__, EXPECTED_VERSION)
        self.assertEqual(job_application_pipeline.__version__, __version__)

        project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
        self.assertIn("version", project["project"]["dynamic"])
        self.assertEqual(
            project["tool"]["setuptools"]["dynamic"]["version"]["attr"],
            "job_application_pipeline.version.__version__",
        )

    def test_cli_prints_active_version_without_requiring_a_provider(self) -> None:
        output = io.StringIO()
        with redirect_stdout(output), self.assertRaises(SystemExit) as stopped:
            main(["--version"])

        self.assertEqual(stopped.exception.code, 0)
        self.assertEqual(
            output.getvalue().strip(),
            f"job-application-pipeline {EXPECTED_VERSION}",
        )

    def test_quality_and_usage_metadata_default_to_active_version(self) -> None:
        report = QualityReport(
            schema_version="test",
            validator_version="test",
            generated_at_utc="2026-08-29T00:00:00Z",
            provider="codex",
            model="",
            effort="",
            hashes={},
            findings=(),
            provenance=(),
            jd_metrics={},
            jd_matches=(),
        )
        usage = UsageMetrics(
            provider="codex",
            input_tokens=10,
            cached_input_tokens=2,
            output_tokens=3,
            reasoning_tokens=1,
            total_tokens=13,
            calls=1,
            source="test",
        )

        self.assertEqual(report.to_dict()["metadata"]["pipeline_version"], __version__)
        self.assertEqual(usage.to_dict()["pipeline_version"], __version__)

    def test_new_manifest_rows_record_active_version(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            pipeline = ApplicationPipeline(
                PipelinePaths(
                    project_root=root / "project",
                    job_ads_dir=root / "Job_ad",
                    cvs_dir=root / "CVs",
                    artifacts_dir=root / "artifacts",
                )
            )
            row = pipeline._manifest_row(
                job_index=1,
                job_pdf=root / "Job_ad" / "job_description_1.pdf",
                job_hash="a" * 64,
                source_hash="b" * 64,
                provider="codex",
                model=None,
                effort=None,
                document_number=1,
                archive_dir=root / "CVs" / "job_1",
            )

        self.assertEqual(row["PipelineVersion"], __version__)
        self.assertEqual(row["Status"], "Ready")


if __name__ == "__main__":
    unittest.main()
