from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tests.support import ROOT

from job_application_pipeline.paths import Paths


class PathsTests(unittest.TestCase):
    def test_defaults_resolve_external_inputs_and_archive_exactly(self) -> None:
        paths = Paths()

        self.assertEqual(paths.project_root, ROOT.resolve())
        self.assertEqual(paths.job_ads_dir, ROOT.parent / "Job_ad")
        self.assertEqual(paths.cvs_dir, ROOT.parent / "CVs")
        self.assertEqual(paths.manifest, ROOT.parent / "CVs" / "application_manifest.csv")
        self.assertEqual(paths.artifacts_dir, ROOT / ".artifacts")
        self.assertEqual(
            paths.prompt_template,
            ROOT / "config" / "prompts" / "application.md",
        )

    def test_all_top_level_paths_can_be_overridden(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            paths = Paths(
                project_root=base / "project",
                job_ads_dir=base / "incoming",
                cvs_dir=base / "archive",
                artifacts_dir=base / "work",
            )

            self.assertEqual(paths.project_root, (base / "project").resolve())
            self.assertEqual(paths.job_ads_dir, (base / "incoming").resolve())
            self.assertEqual(paths.cvs_dir, (base / "archive").resolve())
            self.assertEqual(paths.manifest, (base / "archive" / "application_manifest.csv").resolve())
            self.assertEqual(paths.artifacts_dir, (base / "work").resolve())
            self.assertEqual(
                paths.cover_template,
                (base / "project" / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex").resolve(),
            )

    def test_source_paths_include_both_document_packs_and_prompt(self) -> None:
        paths = Paths(project_root=ROOT)
        self.assertEqual(
            paths.source_paths,
            (
                paths.cv_rules,
                paths.bullet_library,
                paths.skills_profiles,
                paths.cv_template,
                paths.cover_rules,
                paths.cover_template,
                paths.prompt_template,
                paths.review_prompt,
            ),
        )


if __name__ == "__main__":
    unittest.main()
