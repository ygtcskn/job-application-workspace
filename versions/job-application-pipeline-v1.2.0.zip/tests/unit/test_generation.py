from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from tests.support import (
    ROOT,
    draft_payload,
    fill_regions,
    skill_selection,
    valid_cv,
    valid_skills,
)

from job_application_pipeline.cv_quality import Severity, validate_cv_quality
from job_application_pipeline.documents import extract_docx_text
from job_application_pipeline.generation import (
    AI_DRAFT_FIELDS,
    AI_DRAFT_JSON_SCHEMA,
    AIDraft,
    COVER_PARAGRAPH_FIELDS,
    REVIEW_JSON_SCHEMA,
    employer_from_body,
    parse_job_metadata,
    parse_provider_json,
    parse_review_json,
    apply_cover_paragraph_edits,
    assert_claims_preserved,
    check_mandatory_skills,
    cover_paragraph_sources,
    drop_unrequested_tier_three,
    group_language_packages,
    render_application_documents,
    render_cover,
    render_cv,
    _draft_list,
    _escape_prose,
    _latex_escape,
    _draft_skills,
    _one_line,
    _parse_skill_groups,
    render_skills_region,
    resolve_cv_skills,
    assert_summary_token,
    fill_summary_title,
    mandatory_skills_by_line,
    select_cv_skills,
    skill_inventory,
    template_summary_text,
)
from job_application_pipeline.validation import (
    CV_LOCKED_REGIONS,
    parse_cover_regions,
    parse_cv_regions,
)


CV_TEMPLATE = ROOT / "templates" / "cv" / "yigit_coskun_empty.tex"
COVER_TEMPLATE = ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
SKILLS_PROFILES = ROOT / "data" / "reference" / "cv" / "skills_profiles.docx"
BULLET_LIBRARY = ROOT / "data" / "reference" / "cv" / "bullet_library.docx"
CV_RULES = ROOT / "data" / "reference" / "cv" / "CV_RULES.md"


def job_text(description: str = "") -> str:
    return "\n".join(
        (
            "--- Page 1 ---",
            "Senior Data Scientist (m/w/d) - Hybrid",
            "Company: Acme & Co",
            "Location: Berlin, Germany",
            "Job description",
            description,
        )
    )


def draft(*, with_address: bool = False, **overrides: object) -> AIDraft:
    return parse_provider_json(
        draft_payload(with_address=with_address, **overrides)
    )


class CompactGenerationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.cv_template = CV_TEMPLATE.read_text(encoding="utf-8")
        cls.cover_template = COVER_TEMPLATE.read_text(encoding="utf-8")
        cls.skills_profiles = extract_docx_text(SKILLS_PROFILES)

    def test_runtime_schemas_recursively_require_every_object_property(self) -> None:
        """Every object must satisfy the Structured Outputs strict subset."""

        def assert_strict_objects(node: object, path: str) -> None:
            if isinstance(node, dict):
                if node.get("type") == "object":
                    properties = node.get("properties")
                    self.assertIsInstance(properties, dict, path)
                    self.assertEqual(
                        set(node.get("required", ())),
                        set(properties or {}),
                        path,
                    )
                    self.assertIs(node.get("additionalProperties"), False, path)
                for name, child in node.items():
                    assert_strict_objects(child, f"{path}.{name}")
            elif isinstance(node, list):
                for index, child in enumerate(node):
                    assert_strict_objects(child, f"{path}[{index}]")

        for name, schema in (
            ("AI_DRAFT_JSON_SCHEMA", AI_DRAFT_JSON_SCHEMA),
            ("REVIEW_JSON_SCHEMA", REVIEW_JSON_SCHEMA),
        ):
            with self.subTest(schema=name):
                json.dumps(schema, sort_keys=True)
                assert_strict_objects(schema, name)

        self.assertEqual(
            set(AI_DRAFT_JSON_SCHEMA["required"]),
            set(AI_DRAFT_FIELDS),
        )

    def test_cover_paragraph_schema_requires_nullable_values(self) -> None:
        cover_schema = AI_DRAFT_JSON_SCHEMA["properties"]["cover_paragraphs"]
        self.assertEqual(
            cover_schema["required"],
            list(COVER_PARAGRAPH_FIELDS),
        )
        for name in COVER_PARAGRAPH_FIELDS:
            with self.subTest(name=name):
                self.assertEqual(
                    cover_schema["properties"][name]["type"],
                    ["string", "null"],
                )

    def test_null_cover_paragraphs_round_trip_as_unchanged(self) -> None:
        payload = draft_payload(cover_template_text=self.cover_template)
        payload["cover_paragraphs"] = {
            name: None for name in COVER_PARAGRAPH_FIELDS
        }

        parsed = parse_provider_json(payload)
        self.assertEqual(parsed.cover_paragraphs, {})

        serialised = parsed.to_dict()
        self.assertEqual(
            serialised["cover_paragraphs"],
            {name: None for name in COVER_PARAGRAPH_FIELDS},
        )
        self.assertEqual(
            set(serialised["cv_skills"]),
            set(AI_DRAFT_JSON_SCHEMA["properties"]["cv_skills"]["properties"]),
        )
        self.assertEqual(
            parse_provider_json(serialised).cover_paragraphs,
            {},
        )

    def test_sparse_legacy_cover_paragraphs_round_trip_through_nulls(self) -> None:
        paragraph = cover_paragraph_sources(self.cover_template)["para_5_close"]
        payload = draft_payload(cover_template_text=self.cover_template)
        payload["cover_paragraphs"] = {"para_5_close": paragraph}

        parsed = parse_provider_json(payload)
        self.assertEqual(parsed.cover_paragraphs, {"para_5_close": paragraph})

        serialised = parsed.to_dict()
        self.assertEqual(
            serialised["cover_paragraphs"],
            {
                **{name: None for name in COVER_PARAGRAPH_FIELDS},
                "para_5_close": paragraph,
            },
        )
        self.assertEqual(
            parse_provider_json(serialised).cover_paragraphs,
            parsed.cover_paragraphs,
        )

    def test_provider_parser_accepts_fenced_json_and_records_address_evidence(self) -> None:
        payload = json.dumps(draft(with_address=True).to_dict())
        parsed = parse_provider_json(f"```json\n{payload}\n```")
        self.assertTrue(parsed.address_verified)
        self.assertEqual(parsed.company_city, "10115 Berlin")
        self.assertEqual(parsed.address_source_url, "https://example.com/imprint")

    def test_provider_parser_rejects_extra_fields_and_drops_unverified_addresses(
        self,
    ) -> None:
        valid = draft().to_dict()
        with self.assertRaisesRegex(ValueError, "unexpected"):
            parse_provider_json({**valid, "cover_letter": "do not accept prose"})

        # An unverified address is dropped, not fatal: the letter simply omits
        # the block. Raising here failed the whole draft where the repair loop
        # could not reach it, losing an otherwise good application.
        unverified = draft().to_dict()
        unverified.update(
            {
                "company_address": "Example Street 1",
                "company_city": "10115 Berlin",
            }
        )
        dropped = parse_provider_json(unverified)
        self.assertIsNone(dropped.company_address)
        self.assertIsNone(dropped.company_city)
        self.assertIsNone(dropped.address_source_url)
        self.assertFalse(dropped.address_verified)

        # A verified address still survives intact.
        kept = parse_provider_json(draft(with_address=True).to_dict())
        self.assertEqual(kept.company_address, "Example Street 1")
        self.assertTrue(kept.address_verified)

        # A malformed source URL is still a hard error, not a silent drop.
        wrong_url = draft(with_address=True).to_dict()
        wrong_url["address_source_url"] = "example.com/imprint"
        with self.assertRaisesRegex(ValueError, "absolute http"):
            parse_provider_json(wrong_url)

    def test_diagnostics_may_quote_a_placeholder_the_advertisement_contains(self) -> None:
        """job_198's ad was an unfilled template; saying so must not fail the run."""

        risks = _draft_list(
            ["Advertisement is an unfilled template ([Job Title]); requirements unknown"],
            field="risks",
        )
        self.assertIn("[Job Title]", risks[0])

        # Fields that reach a document still reject placeholders outright.
        for field in ("specific_task_or_project", "cv_summary_role_title"):
            with self.subTest(field=field):
                with self.assertRaisesRegex(ValueError, "unresolved placeholder"):
                    _one_line("apply skills to [TARGET]", field=field, max_length=180)

    def test_a_correct_label_survives_its_own_about_us_section(self) -> None:
        """job_213 was labelled JPMorganChase and its About Us said J.P. Morgan."""

        posting = "\n".join(
            (
                "--- Page 1 ---",
                "Advisor Analyst",
                "Company: JPMorganChase",
                "Location: Frankfurt, Hesse, Germany",
                "Job description",
                "About Us",
                "",
                "--- Page 3 ---",
                "J.P. Morgan is a global leader in financial services.",
            )
        )
        # The page break must not become part of the name...
        self.assertEqual(employer_from_body(posting), "J.P. Morgan")
        # ...and two spellings of one firm leave the canonical label alone.
        self.assertEqual(parse_job_metadata(posting).company, "JPMorganChase")

    def test_an_intermediary_in_the_company_field_is_replaced_by_the_employer(self) -> None:
        """job_198 and job_199 were posted by FetchJobs.co on someone's behalf."""

        posting = "\n".join(
            (
                "--- Page 1 ---",
                "Data Scientist",
                "Company: FetchJobs.co",
                "Location: Germany",
                "Job description",
                "About The Company",
                "dm-drogerie markt GmbH + Co. KG is a leading retail company "
                "specializing in health and beauty products.",
            )
        )
        self.assertEqual(
            parse_job_metadata(posting).company, "dm-drogerie markt GmbH + Co. KG"
        )

        # An intermediary need not look like a domain: job_203 was labelled
        # "Sundayy" and the advertisement introduced itself as DIS AG.
        agency = posting.replace("Company: FetchJobs.co", "Company: Sundayy").replace(
            "dm-drogerie markt GmbH + Co. KG is a leading retail company "
            "specializing in health and beauty products.",
            "DIS AG is a leading organization committed to digital transformation.",
        )
        self.assertEqual(parse_job_metadata(agency).company, "DIS AG")

        # With no "About the company" section the label stands: real postings
        # carry no such block, so their label is never second-guessed.
        bare = posting.replace(
            "About The Company\ndm-drogerie markt GmbH + Co. KG is a leading retail "
            "company specializing in health and beauty products.",
            "We are hiring.",
        )
        self.assertEqual(parse_job_metadata(bare).company, "FetchJobs.co")

    def test_job_metadata_uses_clean_title_and_importer_labels(self) -> None:
        metadata = parse_job_metadata(job_text())
        self.assertEqual(metadata.title, "Data Scientist")
        self.assertEqual(metadata.company, "Acme & Co")
        self.assertEqual(metadata.location, "Berlin, Germany")

    def test_the_deterministic_fallback_is_the_profiles_mandatory_set(self) -> None:
        """Tier 1 is required on every CV, so it is the safe answer."""

        selected = select_cv_skills(self.skills_profiles, job_text("Anything at all"))
        mandatory = mandatory_skills_by_line(self.skills_profiles)
        self.assertEqual(selected.programming, mandatory["programming"])
        self.assertEqual(selected.methods, mandatory["methods"])
        self.assertEqual(selected.tools_platforms, mandatory["tools_platforms"])
        self.assertIn("Python", selected.programming)
        # Tier 3 never arrives by default.
        self.assertNotIn("Tableau", selected.tools_platforms)

    def test_cv_renderer_changes_only_skills_and_passes_inventory_validation(self) -> None:
        description = job_text("Python, SQL, machine learning, and Git")
        skills = select_cv_skills(self.skills_profiles, description)
        generated = render_cv(self.cv_template, skills)

        expected_fixed, expected_regions = parse_cv_regions(self.cv_template)
        actual_fixed, actual_regions = parse_cv_regions(generated)
        self.assertEqual(actual_fixed, expected_fixed)
        for region in CV_LOCKED_REGIONS:
            self.assertEqual(actual_regions[region], expected_regions[region])

        with tempfile.TemporaryDirectory() as temporary:
            tex_path = Path(temporary) / "tailored_cv.tex"
            tex_path.write_text(generated, encoding="utf-8")
            report = validate_cv_quality(
                tex_path=tex_path,
                job_description=description,
                cv_rules=CV_RULES.read_text(encoding="utf-8"),
                bullet_library=extract_docx_text(BULLET_LIBRARY),
                skills_profiles=self.skills_profiles,
                expected_job_title="Data Scientist",
            )
        findings = {finding.check_id: finding for finding in report.findings}
        self.assertEqual(findings["SKILLS_INVENTORY"].severity, Severity.PASS)
        self.assertEqual(findings["TIER3_SKILLS"].severity, Severity.PASS)

    def test_cover_renderer_fills_six_tokens_without_touching_fixed_comments(self) -> None:
        metadata = parse_job_metadata(job_text())
        generated = render_cover(self.cover_template, metadata, draft())
        template_fixed, _ = parse_cover_regions(self.cover_template)
        generated_fixed, regions = parse_cover_regions(generated)
        self.assertEqual(generated_fixed, template_fixed)
        self.assertIn("Acme \\& Co", regions["COVER_HEADER"])
        self.assertNotIn("Example Street", regions["COVER_HEADER"])
        self.assertNotIn("{{", "\n".join(regions.values()))
        self.assertIn("{{JOB-TITLE}}", generated_fixed[0])

    def test_all_outputs_are_rendered_locally_with_address_provenance(self) -> None:
        application = render_application_documents(
            cv_template=self.cv_template,
            cover_template=self.cover_template,
            skills_profiles=self.skills_profiles,
            job_description=job_text("Python forecasting and Git"),
            draft=draft(with_address=True),
        )
        self.assertEqual(
            set(application.output_files()),
            {"tailored_cv.tex", "cover_letter.tex", "change_log.md", "match_notes.md"},
        )
        self.assertTrue(all(application.output_files().values()))
        self.assertIn("Example Street 1", application.cover_letter_tex)
        self.assertIn("https://example.com/imprint", application.change_log_md)
        self.assertIn("## Address Evidence", application.match_notes_md)



class GuidedTailoringTests(unittest.TestCase):
    """The provider tailors SUMMARY, SKILLS, and the cover prose."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.cv_template = CV_TEMPLATE.read_text(encoding="utf-8")
        cls.cover_template = COVER_TEMPLATE.read_text(encoding="utf-8")
        cls.skills_profiles = extract_docx_text(SKILLS_PROFILES)
        cls.inventory = skill_inventory(cls.skills_profiles)
        cls.summary = template_summary_text(cls.cv_template)
        # The opening is fixed; the role only fills the {{JOB-TITLE}} slot.
        cls.summary_body = cls.summary
        cls.role_title = "Data Analyst"
        cls.paragraphs = cover_paragraph_sources(cls.cover_template)

    def _render(self, role_title: str, body: str) -> str:
        return render_cv(
            self.cv_template,
            skill_selection(("Python",), ("Machine Learning",), ("Git",)),
            summary_role_title=role_title,
            summary_body=body,
            skill_names=self.inventory,
        )

    def test_a_new_role_title_and_synonyms_are_accepted(self) -> None:
        # The opening is fixed prose now; only the slot retargets.
        self.assertIn("{{JOB-TITLE}}", self.summary_body)
        body = self.summary_body
        tailored = self._render(
            "Quantitative Analyst",
            body.replace("a focus on", "a concentration in"),
        )
        self.assertIn("Quantitative Analyst", tailored)
        self.assertIn("a concentration in", tailored)
        # The eighteen approved bullets are untouched by a summary edit.
        _, template_regions = parse_cv_regions(self.cv_template)
        _, tailored_regions = parse_cv_regions(tailored)
        for region in CV_LOCKED_REGIONS:
            self.assertEqual(tailored_regions[region], template_regions[region])

    def test_the_role_title_is_reduced_to_a_role_noun_phrase(self) -> None:
        """A posting title reads badly dropped into the summary's slot.

        job_192 produced "Quantitative Analyst - Modelling & Pricing"; the
        qualifier has to go, exactly as the cover letter already drops it.
        """

        for supplied, expected in (
            ("Quantitative Analyst - Modelling & Pricing", "Quantitative Analyst"),
            ("Senior Data Scientist (m/w/d)", "Data Scientist"),
            ("Data Analyst | Pricing Team", "Data Analyst"),
        ):
            with self.subTest(supplied=supplied):
                rendered = self._render(supplied, self.summary_body)
                self.assertIn("Seeking a " + expected + " position", rendered)
                self.assertNotIn("Pricing with", rendered)

    def test_trademark_marks_are_dropped_before_they_change_the_font(self) -> None:
        """job_220's employer is "tonies(R)"; the symbol pulled a fallback face
        into the PDF and failed the locked typography contract, and no repair
        could fix it because the company name is not a repairable field."""

        self.assertEqual(
            _latex_escape("tonies®", field="company", max_length=160), "tonies"
        )
        # NFKC turns U+2122 into "TM", so the strip has to happen first.
        self.assertEqual(
            _latex_escape("Acme™", field="company", max_length=160), "Acme"
        )
        self.assertEqual(_escape_prose("joining tonies® today"), "joining tonies today")
        # Accented characters are in the font and must survive untouched.
        self.assertEqual(
            _latex_escape("Łódź Straße GmbH", field="company", max_length=160),
            "Łódź Straße GmbH",
        )

    def test_html_entities_from_the_provider_are_decoded(self) -> None:
        """job_192 returned "Modelling &amp; Pricing"; the entity must not print."""

        # "& Reporting" trails the role noun, so the cleaner drops it; what
        # matters here is that the entity never reaches the CV as "amp;".
        rendered = self._render("Business &amp; Reporting Analyst", self.summary_body)
        self.assertIn(r"Seeking a Business \& Reporting Analyst position", rendered)
        self.assertNotIn("amp;", rendered)

    def test_every_guard_failure_is_reported_in_one_pass(self) -> None:
        """The repair budget is two, so one round must see every problem."""

        broken = dict(self.paragraphs)
        # An inserted sentence, which is what the live repair actually did. It
        # scored 0.91 similarity, so only the sentence-count guard rejects it.
        broken["para_4_motivation"] = broken["para_4_motivation"].replace(
            "The field is developing rapidly",
            "I also read papers on new architectures in my own time. "
            "The field is developing rapidly",
        )
        payload = draft_payload(
            cv_template_text=self.cv_template,
            cover_template_text=self.cover_template,
            cv_summary_body=self.summary_body.replace("{{JOB-TITLE}}", "Data Scientist"),
            cover_paragraphs=broken,
        )
        with self.assertRaises(ValueError) as caught:
            render_application_documents(
                cv_template=self.cv_template,
                cover_template=self.cover_template,
                skills_profiles=self.skills_profiles,
                job_description=job_text("Python"),
                draft=parse_provider_json(payload),
            )
        message = str(caught.exception)
        self.assertIn("cover_paragraphs.para_4_motivation", message)
        self.assertIn("cv_summary_body", message)

    def test_a_body_without_the_role_slot_is_rejected(self) -> None:
        """Losing the slot drops the advertised role from the CV entirely."""

        with self.assertRaisesRegex(ValueError, r"exactly once; found 0"):
            self._render(
                "Quantitative Analyst",
                self.summary_body.replace("{{JOB-TITLE}}", "Data Scientist"),
            )

    def test_rewriting_around_the_role_slot_is_rejected(self) -> None:
        """job_273 turned "a {{JOB-TITLE}} position" into "a role"."""

        with self.assertRaisesRegex(ValueError, "cv_summary_body"):
            self._render(
                "Quantitative Analyst",
                self.summary_body.replace("{{JOB-TITLE}} position", "role"),
            )

    def test_a_summary_that_drops_a_measured_claim_is_rejected(self) -> None:
        """Tested on the guard, not the installed text.

        The installed summary carries no figure to drop, so asserting through
        it would pass for the wrong reason and stop protecting numbers at all.
        """

        self.assertFalse(
            any(character.isdigit() for character in self.summary_body),
            "installed summary gained a figure; assert through it again",
        )
        with self.assertRaisesRegex(ValueError, "dropped protected content"):
            assert_claims_preserved(
                "with a benchmark beaten by 8.16% across 15 economies",
                "with a benchmark beaten by a wide margin across many economies",
                inventory=frozenset(),
                field="cv_summary_body",
            )

    def test_a_summary_that_drops_a_named_method_is_rejected(self) -> None:
        body = self.summary_body
        without_method = body.replace(
            "machine learning and deep learning",
            "quantitative techniques",
        )
        with self.assertRaisesRegex(ValueError, "dropped protected content"):
            self._render("Data Scientist", without_method)

    def test_a_wholesale_summary_rewrite_is_rejected(self) -> None:
        """Keeping every claim is not enough; the wording must survive too."""

        body = self.summary_body
        # Every protected term is still present, so only the similarity floor
        # can reject this.
        padded = body + " " + body.replace("{{JOB-TITLE}} ", "")
        with self.assertRaisesRegex(ValueError, "rewritten too heavily"):
            self._render("Data Scientist", padded)

    def test_provider_skills_must_come_from_the_approved_inventory(self) -> None:
        with self.assertRaisesRegex(ValueError, "not in the approved inventory"):
            resolve_cv_skills(
                skill_selection(("Python", "Rust"), ("machine learning",), ("Git",)),
                self.skills_profiles,
            )
        # A package belongs inside its language, and a child cannot stand alone.
        with self.assertRaisesRegex(ValueError, "not in the approved inventory"):
            resolve_cv_skills(
                skill_selection(("XGBoost",), ("machine learning",), ("Git",)),
                self.skills_profiles,
            )
        resolved = resolve_cv_skills(
            skill_selection(
                ("PYTHON", "Pandas"),
                ("machine learning (xgboost, lightgbm)",),
                ("power bi",),
            ),
            self.skills_profiles,
        )
        # Profile spelling wins over whatever case the provider returned.
        self.assertEqual(resolved.programming, ("Python", "pandas"))
        self.assertEqual(resolved.methods, ("machine learning (XGBoost, LightGBM)",))
        self.assertEqual(resolved.tools_platforms, ("Power BI",))

    def test_a_package_is_nested_in_its_language_not_listed_beside_it(self) -> None:
        """The profile nests packages; a bare package reads as a language."""

        groups = {
            group.name: group.children
            for group in _parse_skill_groups(self.skills_profiles)["methods"]
        }
        self.assertIn("XGBoost", groups["machine learning"])
        # An entry the profile writes without parentheses carries no children.
        self.assertEqual(groups["Git"], ())

        rendered = render_skills_region(
            resolve_cv_skills(
                skill_selection(
                    ("Python", "SQL"),
                    ("machine learning (XGBoost)", "deep learning (LSTM)"),
                    ("Git",),
                ),
                self.skills_profiles,
            )
        )
        self.assertIn("Python, SQL", rendered)
        # Listed entries are capitalised; nested package names are not.
        self.assertIn("Machine learning (XGBoost)", rendered)
        self.assertIn("Deep learning (LSTM)", rendered)

    def test_every_line_has_room_beyond_its_mandatory_skills(self) -> None:
        """job_221 could not add a tool the posting named without dropping one.

        tools_platforms capped at four against four always-include tools, so
        the mandatory guard and the vacancy were in direct conflict and no
        reply could satisfy both.
        """

        caps = AI_DRAFT_JSON_SCHEMA["properties"]["cv_skills"]["properties"]
        for line, required in mandatory_skills_by_line(self.skills_profiles).items():
            with self.subTest(line=line):
                self.assertGreaterEqual(
                    caps[line]["maxItems"] - len(required),
                    2,
                    f"{line} leaves no room for skills the posting asks for",
                )

    def test_the_parser_truncates_to_the_schema_cap(self) -> None:
        """A second hardcoded cap could silently drop a required skill."""

        caps = AI_DRAFT_JSON_SCHEMA["properties"]["cv_skills"]["properties"]
        parsed = _draft_skills(
            {
                "programming": [
                    "Python (pandas, NumPy, scikit-learn, TensorFlow/Keras)",
                    "R",
                    "SQL",
                ],
                "methods": ["machine learning (XGBoost, LightGBM)", "deep learning (LSTM)"],
                "tools_platforms": [
                    "LaTeX", "AI/LLM Tools (Codex, Claude Code)", "Git",
                    "Power BI", "Excel", "Tableau", "AWS", "Docker", "CUDA",
                ],
                "professional": [
                    "automation", "reporting", "stakeholder communication",
                    "cross-functional collaboration",
                ],
            }
        )
        self.assertEqual(
            len(parsed.tools_platforms), caps["tools_platforms"]["maxItems"]
        )
        # The always-include tools come first and survive the truncation.
        self.assertEqual(check_mandatory_skills(parsed, self.skills_profiles), [])

    def test_a_missing_mandatory_skill_is_caught(self) -> None:
        """job_197 shipped without AI/LLM Tools; the profile calls it mandatory."""

        complete = group_language_packages(
            select_cv_skills(self.skills_profiles, job_text("anything"))
        )
        self.assertEqual(check_mandatory_skills(complete, self.skills_profiles), [])

        without_ai_tools = skill_selection(
            programming=complete.programming,
            methods=complete.methods,
            tools_platforms=tuple(
                entry
                for entry in complete.tools_platforms
                if "AI/LLM Tools" not in entry
            ),
        )
        problems = check_mandatory_skills(without_ai_tools, self.skills_profiles)
        self.assertEqual(len(problems), 1)
        self.assertIn("cv_skills.tools_platforms", problems[0])
        self.assertIn("AI/LLM Tools", problems[0])

    def test_the_mandatory_check_reads_nested_packages(self) -> None:
        """pandas inside Python still counts as present."""

        nested = skill_selection(
            (
                "Python (pandas, NumPy, scikit-learn, TensorFlow/Keras)",
                "R",
                "SQL",
            ),
            ("machine learning (XGBoost, LightGBM)", "deep learning (LSTM)"),
            ("LaTeX", "AI/LLM Tools (Codex, Claude Code)", "Git", "Power BI"),
        )
        self.assertEqual(check_mandatory_skills(nested, self.skills_profiles), [])

    def test_two_skills_in_one_string_are_split(self) -> None:
        """A revision returned "Power BI, Tableau" as one entry and cost the
        whole tailored selection, because no inventory name has a comma."""

        parsed = _draft_skills(
            {
                "programming": ["SQL", "Python (pandas, NumPy)"],
                "methods": ["machine learning (XGBoost, LightGBM)"],
                "tools_platforms": ["Power BI, Tableau", "Git"],
                "professional": ["automation"],
            }
        )
        self.assertEqual(parsed.tools_platforms, ("Power BI", "Tableau", "Git"))
        # A comma inside parentheses still belongs to its entry.
        self.assertEqual(parsed.methods, ("machine learning (XGBoost, LightGBM)",))
        self.assertEqual(parsed.programming, ("SQL", "Python (pandas, NumPy)"))

    def test_listed_skills_are_capitalised_but_packages_keep_their_casing(self) -> None:
        """The profile writes methods in prose case; a CV list reads better capitalised."""

        rendered = render_skills_region(
            skill_selection(
                ("SQL", "Python (pandas, NumPy, scikit-learn)"),
                ("machine learning (XGBoost, LightGBM)", "feature engineering"),
                ("Power BI", "Git"),
            )
        )
        self.assertIn("Machine learning (XGBoost, LightGBM)", rendered)
        self.assertIn("Feature engineering", rendered)
        # Official package casing survives inside the parentheses.
        self.assertIn("Python (pandas, NumPy, scikit-learn)", rendered)
        self.assertNotIn("Pandas", rendered)
        self.assertNotIn("Scikit-learn", rendered)

    def test_a_nested_only_package_is_mandatory_and_accepted_either_way(self) -> None:
        """PostgreSQL rides with SQL, so it is required exactly as SQL is."""

        mandatory = mandatory_skills_by_line(self.skills_profiles)["programming"]
        self.assertIn("SQL (PostgreSQL)", mandatory)

        nested = skill_selection(
            (
                "Python (pandas, NumPy, scikit-learn, TensorFlow/Keras)",
                "R",
                "SQL (PostgreSQL)",
            ),
            ("machine learning (XGBoost, LightGBM)", "deep learning (LSTM)"),
            ("LaTeX", "AI/LLM Tools (Codex, Claude Code)", "Git", "Power BI"),
        )
        flat = skill_selection(
            (
                "Python", "pandas", "NumPy", "scikit-learn", "TensorFlow/Keras",
                "R", "SQL", "PostgreSQL",
            ),
            nested.methods,
            nested.tools_platforms,
        )
        for label, selection in (("nested", nested), ("flat", flat)):
            with self.subTest(form=label):
                resolved = group_language_packages(
                    resolve_cv_skills(selection, self.skills_profiles)
                )
                self.assertIn("SQL (PostgreSQL)", resolved.programming)
                self.assertEqual(
                    check_mandatory_skills(resolved, self.skills_profiles), []
                )

        # Dropping it is caught, because the profile makes it always-include.
        without = skill_selection(
            ("Python (pandas, NumPy, scikit-learn)", "R"),
            nested.methods,
            nested.tools_platforms,
        )
        problems = check_mandatory_skills(without, self.skills_profiles)
        self.assertTrue(any("SQL (PostgreSQL)" in p for p in problems))

    def test_packages_are_nested_inside_their_language(self) -> None:
        """A package beside its own language reads as a second language."""

        flat = skill_selection(
            ("SQL", "Python", "R", "pandas", "NumPy", "ggplot2"), ("A/B testing",), ("Git",)
        )
        self.assertEqual(
            group_language_packages(flat).programming,
            ("SQL", "Python (pandas, NumPy)", "R (ggplot2)"),
        )

        # The provider may nest them itself; both forms resolve identically.
        nested = resolve_cv_skills(
            skill_selection(("Python (pandas, NumPy)", "SQL"), ("A/B testing",), ("Git",)),
            self.skills_profiles,
        )
        self.assertEqual(
            group_language_packages(nested).programming, ("Python (pandas, NumPy)", "SQL")
        )

        # A package with no language of its own is left where it is.
        orphan = skill_selection(("pandas", "SQL"), ("A/B testing",), ("Git",))
        self.assertEqual(group_language_packages(orphan).programming, ("pandas", "SQL"))

    def test_a_restricted_package_is_dropped_before_it_can_be_nested(self) -> None:
        """PyTorch is Tier 3: the gate must see it while it is still top level."""

        resolved = resolve_cv_skills(
            skill_selection(("Python", "pandas", "PyTorch"), ("A/B testing",), ("Git",)),
            self.skills_profiles,
        )
        gated = drop_unrequested_tier_three(
            resolved, self.skills_profiles, job_text("Python and pandas only")
        )
        self.assertEqual(
            group_language_packages(gated).programming, ("Python (pandas)",)
        )

    def test_a_restricted_package_nested_by_the_provider_is_still_gated(self) -> None:
        """job_212 hid PyTorch inside Python, where a parent-only check missed it."""

        nested = skill_selection(
            ("Python (pandas, NumPy, PyTorch)", "SQL"),
            ("machine learning (XGBoost, LightGBM)",),
            ("Git",),
        )
        self.assertEqual(
            drop_unrequested_tier_three(
                nested, self.skills_profiles, job_text("Python and SQL")
            ).programming,
            ("Python (pandas, NumPy)", "SQL"),
        )
        # Named by the posting, it stays.
        self.assertIn(
            "PyTorch",
            drop_unrequested_tier_three(
                nested, self.skills_profiles, job_text("PyTorch experience required")
            ).programming[0],
        )
        # Losing every child leaves the language itself, not an empty pair.
        self.assertEqual(
            drop_unrequested_tier_three(
                skill_selection(("Python (PyTorch)",), ("machine learning",), ("Git",)),
                self.skills_profiles,
                job_text("Python only"),
            ).programming,
            ("Python",),
        )

    def test_a_qualified_tier_three_entry_is_still_gated(self) -> None:
        """job_199 failed on "exploratory data analysis (EDA)" slipping through."""

        listed = skill_selection(
            ("Python",), ("exploratory data analysis (EDA)", "A/B testing"), ("Git",)
        )
        self.assertEqual(
            drop_unrequested_tier_three(
                listed, self.skills_profiles, job_text("Python and SQL")
            ).methods,
            ("A/B testing",),
        )
        self.assertIn(
            "exploratory data analysis (EDA)",
            drop_unrequested_tier_three(
                listed,
                self.skills_profiles,
                job_text("exploratory data analysis is required"),
            ).methods,
        )

    def test_weakest_evidence_skills_need_the_posting_to_ask(self) -> None:
        """Tableau is Tier 3: the quality gate errors, so drop it before rendering.

        The role-relevance licence stops at the weakest evidence, which is the
        approved profile's own rule and an unrepairable ERROR downstream.
        """

        listed = skill_selection(
            ("Python (Statsmodels)",), ("Machine Learning",), ("Git", "Tableau")
        )
        silent = drop_unrequested_tier_three(
            listed, self.skills_profiles, job_text("Python and forecasting")
        )
        self.assertEqual(silent.tools_platforms, ("Git",))

        asked = drop_unrequested_tier_three(
            listed, self.skills_profiles, job_text("Build Tableau dashboards")
        )
        self.assertEqual(asked.tools_platforms, ("Git", "Tableau"))

        # Dropping must never leave a line bare.
        only_restricted = skill_selection(
            ("Python (Statsmodels)",), ("Machine Learning",), ("Tableau",)
        )
        kept = drop_unrequested_tier_three(
            only_restricted, self.skills_profiles, job_text("Python")
        )
        self.assertEqual(kept.tools_platforms, ("Tableau",))

    def test_unapproved_skills_fall_back_to_deterministic_selection(self) -> None:
        payload = draft_payload(cv_template_text=self.cv_template)
        payload["cv_skills"] = {
            "programming": ["Rust"],
            "methods": ["Blockchain"],
            "tools_platforms": ["Kubernetes"],
            "professional": ["automation"],
        }
        generated = render_application_documents(
            cv_template=self.cv_template,
            cover_template=self.cover_template,
            skills_profiles=self.skills_profiles,
            job_description=job_text("Python and forecasting"),
            draft=parse_provider_json(payload),
        )
        self.assertIn("deterministic fallback", generated.change_log_md)
        self.assertNotIn("Rust", generated.tailored_cv_tex)
        self.assertIn("Python", generated.tailored_cv_tex)

    def test_an_omitted_paragraph_means_unchanged(self) -> None:
        """Half of all paragraphs came back byte-identical; omitting them is free."""

        only_one = {
            "para_5_close": self.paragraphs["para_5_close"].replace(
                "would be excited to", "would be glad to"
            )
        }
        applied = apply_cover_paragraph_edits(
            self.cover_template, only_one, inventory=self.inventory
        )
        self.assertIn("would be glad to", applied)
        # The four omitted paragraphs are still exactly the template's.
        _fixed, regions = parse_cover_regions(applied)
        _tfixed, template_regions = parse_cover_regions(self.cover_template)
        for region in ("PARA_1_HOOK_THESIS", "PARA_2_IAB", "PARA_3_FIT", "PARA_4_MOTIVATION"):
            self.assertEqual(regions[region], template_regions[region])

        # Returning nothing at all is a valid answer.
        untouched = apply_cover_paragraph_edits(
            self.cover_template, {}, inventory=self.inventory
        )
        self.assertEqual(untouched, self.cover_template)

    def test_a_returned_paragraph_is_still_fully_guarded(self) -> None:
        """Omission is a shortcut for "unchanged", never a way past the guards."""

        with self.assertRaises(ValueError):
            apply_cover_paragraph_edits(
                self.cover_template,
                {"para_1_hook_thesis": "I like data and would suit this role."},
                inventory=self.inventory,
            )

    def test_a_cover_clarity_pass_is_accepted_but_a_rewrite_is_not(self) -> None:
        light = dict(self.paragraphs)
        light["para_5_close"] = light["para_5_close"].replace(
            "would be excited to", "would be glad to"
        )
        applied = apply_cover_paragraph_edits(
            self.cover_template, light, inventory=self.inventory
        )
        self.assertIn("would be glad to", applied)

        # Padding keeps the tokens, their surrounding words, and every claim,
        # so only the similarity floor can reject it.
        heavy = dict(self.paragraphs)
        heavy["para_5_close"] = self.paragraphs["para_5_close"].replace(
            "I would be excited",
            "I am writing to you today because I really would be excited",
        )
        with self.assertRaisesRegex(ValueError, "rewritten too heavily"):
            apply_cover_paragraph_edits(
                self.cover_template, heavy, inventory=self.inventory
            )

    def test_the_words_around_a_template_token_may_not_change(self) -> None:
        """Both failures from the first live run, as regressions.

        The approved cover validators key on these exact connectives, so a
        plausible-looking proofreading edit used to surface far downstream as
        "changed the required company-name sentence structure".
        """

        for label, field, mutate in (
            ("inserted word", "para_3_fit",
             lambda s: s.replace("At {{COMPANY-NAME}}", "At the {{COMPANY-NAME}}")),
            ("added comma and pronoun", "para_5_close",
             lambda s: s.replace("{{COMPANY-NAME}} and would", "{{COMPANY-NAME}}, and I would")),
            ("extra token", "para_1_hook_thesis",
             lambda s: s.replace("{{JOB-TITLE}} role", "{{JOB-TITLE}} role at {{COMPANY-NAME}}")),
        ):
            with self.subTest(label=label):
                edited = dict(self.paragraphs)
                edited[field] = mutate(self.paragraphs[field])
                self.assertNotEqual(edited[field], self.paragraphs[field])
                with self.assertRaises(ValueError) as caught:
                    apply_cover_paragraph_edits(
                        self.cover_template, edited, inventory=self.inventory
                    )
                self.assertIn(f"cover_paragraphs.{field}", str(caught.exception))

        # A paragraph rewritten past recognition is caught even when it keeps
        # the tokens, because the claims go with the wording.
        gutted = dict(self.paragraphs)
        gutted["para_2_iab"] = "I work at IAB on linked data every day."
        with self.assertRaises(ValueError):
            apply_cover_paragraph_edits(
                self.cover_template, gutted, inventory=self.inventory
            )

    def test_a_cover_edit_may_not_drop_a_template_token_or_a_number(self) -> None:
        dropped_token = dict(self.paragraphs)
        dropped_token["para_5_close"] = dropped_token["para_5_close"].replace(
            "{{COMPANY-NAME}}", "your company"
        )
        with self.assertRaisesRegex(ValueError, "must keep exactly the template tokens"):
            apply_cover_paragraph_edits(
                self.cover_template, dropped_token, inventory=self.inventory
            )

        dropped_number = dict(self.paragraphs)
        dropped_number["para_1_hook_thesis"] = dropped_number[
            "para_1_hook_thesis"
        ].replace("more than 27,000", "many")
        with self.assertRaisesRegex(ValueError, "dropped protected content"):
            apply_cover_paragraph_edits(
                self.cover_template, dropped_number, inventory=self.inventory
            )




class JdKeywordCoverageTests(unittest.TestCase):
    """Coverage is measured on the rendered documents, not the model's word."""

    def _report(self, keywords, *, cv_body: str, cover_body: str = ""):
        template, _ = valid_cv()
        # Swap the whole summary for the body under test, slot included: these
        # tests measure keyword coverage, not the role-slot contract.
        cv_tex = fill_regions(template, {"SKILLS": valid_skills()}).replace(
            "Recent graduate with supported quantitative experience. "
            "Seeking a {{JOB-TITLE}} position.",
            cv_body,
        )
        with tempfile.TemporaryDirectory() as temporary:
            tex_path = Path(temporary) / "tailored_cv.tex"
            tex_path.write_text(cv_tex, encoding="utf-8")
            return validate_cv_quality(
                tex_path=tex_path,
                job_description=job_text("Python forecasting"),
                cv_rules="rules",
                bullet_library="IAB1 [DA] Build reproducible Python analyses",
                skills_profiles=extract_docx_text(SKILLS_PROFILES),
                jd_keywords=keywords,
                cover_letter_tex=cover_body,
            )

    def _finding(self, report):
        return next(
            check for check in report.checks if check.check_id == "JD_KEYWORD_COVERAGE"
        )

    def test_keywords_are_counted_across_the_cv_and_the_cover_letter(self) -> None:
        finding = self._finding(
            self._report(
                ("forecasting", "hedging", "stakeholder"),
                cv_body="An analyst who does forecasting work.",
                cover_body=r"\noindent I have done hedging and stakeholder work.",
            )
        )
        self.assertIs(finding.severity, Severity.PASS)
        self.assertEqual(
            sorted(finding.evidence["covered_terms"]),
            ["forecasting", "hedging", "stakeholder"],
        )

    def test_uncovered_keywords_are_named_and_warned_about(self) -> None:
        finding = self._finding(
            self._report(
                ("forecasting", "derivatives", "meteorology"),
                cv_body="An analyst who does forecasting work.",
            )
        )
        self.assertIs(finding.severity, Severity.WARN)
        self.assertEqual(
            sorted(finding.evidence["missing_terms"]), ["derivatives", "meteorology"]
        )
        self.assertIn("1 of 3", finding.message)
        self.assertIn("target 40%", finding.message)

    def test_the_check_is_absent_when_no_keywords_were_supplied(self) -> None:
        report = self._report((), cv_body="An analyst.")
        self.assertNotIn(
            "JD_KEYWORD_COVERAGE", [check.check_id for check in report.checks]
        )



class ReviewVerdictTests(unittest.TestCase):
    """Agent B's reply is data the pipeline acts on, so parse it strictly."""

    def test_an_approval_carries_no_issues(self) -> None:
        verdict = parse_review_json({"approved": True, "issues": []})
        self.assertTrue(verdict.approved)
        self.assertEqual(verdict.fields, ())

    def test_a_fenced_reply_with_issues_is_parsed_and_scoped(self) -> None:
        verdict = parse_review_json(
            '```json\n{"approved": false, "issues": ['
            '{"field": "cv_summary_body", "problem": "clunky", "fix": "reword"},'
            '{"field": "cv_skills", "problem": "misses SQL", "fix": "add SQL"}'
            ']}\n```'
        )
        self.assertFalse(verdict.approved)
        self.assertEqual(verdict.fields, ("cv_summary_body", "cv_skills"))
        self.assertEqual(verdict.issues[1].fix, "add SQL")

    def test_a_contradictory_reply_is_read_as_not_approved(self) -> None:
        """approved=true alongside issues is resolved the safe way."""

        verdict = parse_review_json(
            {
                "approved": True,
                "issues": [
                    {"field": "cv_skills", "problem": "invented", "fix": "remove"}
                ],
            }
        )
        self.assertFalse(verdict.approved)

    def test_a_field_outside_the_reviewable_set_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "must be one of"):
            parse_review_json(
                {
                    "approved": False,
                    "issues": [
                        {"field": "fit", "problem": "x", "fix": "y"}
                    ],
                }
            )


if __name__ == "__main__":
    unittest.main()
