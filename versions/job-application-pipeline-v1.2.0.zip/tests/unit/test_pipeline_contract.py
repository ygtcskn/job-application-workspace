from __future__ import annotations

import json
import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from tests.support import ROOT, draft_payload, valid_cover, valid_cv

from job_application_pipeline import __main__ as cli
from job_application_pipeline.cv_quality import Severity
from job_application_pipeline.generation import (
    AI_DRAFT_JSON_SCHEMA,
    COVER_PARAGRAPH_FIELDS,
    parse_provider_json,
)
from job_application_pipeline.pipeline import (
    DRAFT_RESPONSE_NAME,
    EFFORT_LEVELS,
    USAGE_METRICS_NAME,
    ApplicationPipeline,
    PipelineError,
    _default_resolver,
    _reviewable_value,
    _skills_only_grew,
    _Heartbeat,
    format_duration,
    validate_effort,
    validate_model,
)
from job_application_pipeline.paths import Paths


def _valid_draft() -> dict[str, object]:
    return draft_payload(
        specific_task_or_project="building reproducible forecasting models",
        concrete_contribution="improving pricing analytics",
        fit=["Python and forecasting are relevant"],
        gaps=[],
        risks=[],
    )


class PipelineContractTests(unittest.TestCase):
    def test_only_claude_and_codex_are_provider_choices(self) -> None:
        pipeline = ApplicationPipeline(Paths())
        for invalid in ("openai", "auto", "gpt", ""):
            with self.subTest(provider=invalid):
                with self.assertRaisesRegex(ValueError, "claude.*codex"):
                    pipeline.run(invalid)  # type: ignore[arg-type]

    def test_claude_command_uses_inline_schema_and_never_path_prompts(self) -> None:
        command = self._provider_command("claude", "opus", "high")

        self.assertEqual(command[0], "claude.exe")
        self.assertIn("--print", command)
        self.assertEqual(command[command.index("--tools") + 1], "WebSearch,WebFetch")
        self.assertEqual(command[command.index("--disallowed-tools") + 1], "mcp__*")
        self.assertEqual(command[command.index("--output-format") + 1], "json")
        inline_schema = command[command.index("--json-schema") + 1]
        self.assertEqual(json.loads(inline_schema), AI_DRAFT_JSON_SCHEMA)
        self.assertEqual(command[command.index("--permission-mode") + 1], "dontAsk")
        self.assertIn("--no-session-persistence", command)
        self.assertEqual(command[command.index("--model") + 1], "opus")
        self.assertEqual(command[command.index("--effort") + 1], "high")
        self.assertNotIn("request.md", command)
        self.assertNotIn("ignored-output", command)

    def test_codex_command_uses_stdin_and_structured_output_files(self) -> None:
        command = self._provider_command("codex", "gpt-5.6-sol", "xhigh")

        self.assertEqual(command[0], "codex.exe")
        self.assertEqual(command[1:3], ["--ask-for-approval", "never"])
        self.assertLess(command.index("--search"), command.index("exec"))
        self.assertIn("--json", command)
        schema_path = command[command.index("--output-schema") + 1]
        response_path = command[command.index("--output-last-message") + 1]
        self.assertEqual(Path(schema_path), Path("schema.json").resolve())
        self.assertEqual(Path(response_path), Path("response.json").resolve())
        self.assertEqual(command[command.index("--sandbox") + 1], "read-only")
        self.assertIn("--skip-git-repo-check", command)
        self.assertEqual(command[command.index("--model") + 1], "gpt-5.6-sol")
        self.assertIn('model_reasoning_effort="xhigh"', command)
        self.assertEqual(command[-1], "-")
        self.assertNotIn("request.md", command)
        self.assertNotIn("ignored-output", command)

    def test_address_lookup_can_be_disabled_for_both_providers(self) -> None:
        claude = self._provider_command(
            "claude", None, None, address_lookup=False
        )
        self.assertEqual(claude[claude.index("--tools") + 1], "")

        codex = self._provider_command("codex", None, None, address_lookup=False)
        self.assertNotIn("--search", codex)
        self.assertEqual(codex[-1], "-")

    def test_omitted_model_and_effort_add_no_provider_overrides(self) -> None:
        for provider in ("claude", "codex"):
            with self.subTest(provider=provider):
                command = self._provider_command(provider, None, None)
                self.assertNotIn("--model", command)
                self.assertNotIn("--effort", command)
                self.assertFalse(
                    [item for item in command if "model_reasoning_effort" in item]
                )

    def test_effort_levels_are_validated_per_provider(self) -> None:
        for provider, levels in EFFORT_LEVELS.items():
            for level in levels:
                with self.subTest(provider=provider, effort=level):
                    self.assertEqual(validate_effort(provider, level), level)
            with self.subTest(provider=provider):
                self.assertIsNone(validate_effort(provider, None))

        self.assertEqual(validate_effort("claude", "max"), "max")
        self.assertEqual(validate_effort("codex", "minimal"), "minimal")
        with self.assertRaisesRegex(ValueError, "codex"):
            validate_effort("codex", "max")
        with self.assertRaisesRegex(ValueError, "claude"):
            validate_effort("claude", "minimal")

        for invalid in ("", "   ", "ultra", "high effort", "-high", "1"):
            with self.subTest(effort=repr(invalid)):
                with self.assertRaises(ValueError):
                    validate_effort("claude", invalid)

    def test_effort_case_and_padding_are_normalised(self) -> None:
        self.assertEqual(validate_effort("claude", "  XHigh "), "xhigh")
        command = self._provider_command("claude", None, "MAX")
        self.assertEqual(command[command.index("--effort") + 1], "max")

    def test_invalid_effort_is_rejected_before_layout_or_executable_checks(self) -> None:
        lookups: list[str] = []
        pipeline = ApplicationPipeline(
            Paths(), executable_resolver=lambda name: lookups.append(name) or name
        )
        with self.assertRaisesRegex(ValueError, "effort"):
            pipeline.run("codex", None, "max")
        self.assertEqual(lookups, [])

    @unittest.skipUnless(os.name == "nt", "PATHEXT resolution is Windows-specific")
    def test_resolver_prefers_a_launchable_variant_over_an_extensionless_shim(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            (directory / "fakecli").write_text("#!/bin/sh\n", encoding="utf-8")
            (directory / "fakecli.cmd").write_text("@echo off\n", encoding="utf-8")
            (directory / "onlyshim").write_text("#!/bin/sh\n", encoding="utf-8")
            (directory / "realtool.exe").write_bytes(b"MZ")
            environment = {"PATH": str(directory), "PATHEXT": ".COM;.EXE;.BAT;.CMD"}

            with patch.dict(os.environ, environment):
                shimmed = _default_resolver("fakecli")
                already_launchable = _default_resolver("realtool")
                explicit_suffix = _default_resolver("fakecli.cmd")
                without_sibling = _default_resolver("onlyshim")
                missing = _default_resolver("no-such-executable-here")

        self.assertIsNotNone(shimmed)
        self.assertEqual(Path(shimmed).name.casefold(), "fakecli.cmd")
        self.assertIsNotNone(already_launchable)
        self.assertEqual(Path(already_launchable).name.casefold(), "realtool.exe")
        self.assertIsNotNone(explicit_suffix)
        self.assertEqual(Path(explicit_suffix).name.casefold(), "fakecli.cmd")
        self.assertIsNone(without_sibling)
        self.assertIsNone(missing)

    def test_duration_formatting_is_compact_at_every_scale(self) -> None:
        self.assertEqual(format_duration(0), "0s")
        self.assertEqual(format_duration(9.7), "9s")
        self.assertEqual(format_duration(65), "1m 05s")
        self.assertEqual(format_duration(3725), "1h 02m 05s")
        self.assertEqual(format_duration(-5), "0s")

    def test_heartbeat_reports_until_the_step_finishes(self) -> None:
        lines: list[str] = []
        with _Heartbeat(lines.append, "claude", interval=0.05) as heartbeat:
            deadline = time.monotonic() + 2.0
            while len(lines) < 2 and time.monotonic() < deadline:
                time.sleep(0.02)
            elapsed = heartbeat.elapsed

        self.assertGreaterEqual(len(lines), 2)
        self.assertTrue(all("claude still running" in line for line in lines))
        self.assertGreater(elapsed, 0.0)
        settled = len(lines)
        time.sleep(0.2)
        self.assertEqual(len(lines), settled)

    def test_heartbeat_is_inert_without_a_reporter(self) -> None:
        with _Heartbeat(None, "codex", interval=0.01) as heartbeat:
            time.sleep(0.05)
            self.assertGreater(heartbeat.elapsed, 0.0)

    def test_reporting_failure_never_aborts_the_run(self) -> None:
        def hostile(_message: str) -> None:
            raise RuntimeError("console gone")

        pipeline = ApplicationPipeline(Paths(), progress=hostile)
        pipeline._report("this must not raise")  # noqa: SLF001

    def test_run_command_delegates_stdin_cwd_and_timeout(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            pipeline = ApplicationPipeline(
                Paths(project_root=root / "job_py"),
                provider_timeout_seconds=37,
            )
            completed = subprocess.CompletedProcess([], 0, stdout="ok")
            with patch(
                "job_application_pipeline.pipeline.run_command_with_timeout",
                return_value=completed,
            ) as runner:
                result = pipeline._run_command(  # noqa: SLF001
                    ["provider.exe", "--flag"],
                    input_text="compact prompt",
                    cwd=root,
                    timeout_seconds=12,
                )

        self.assertIs(result, completed)
        args, kwargs = runner.call_args
        self.assertEqual(args[0], ["provider.exe", "--flag"])
        self.assertEqual(kwargs["input_text"], "compact prompt")
        self.assertEqual(kwargs["cwd"], root.resolve())
        self.assertEqual(kwargs["timeout_seconds"], 12)
        self.assertFalse(kwargs["check"])

    def test_claude_provider_passes_request_on_stdin_and_normalises_response(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request = root / "application_request.md"
            request.write_text("compact prompt\nJOB LAST", encoding="utf-8")
            output = root / "output"
            log = root / "provider.log"
            lines: list[str] = []
            pipeline = ApplicationPipeline(
                Paths(project_root=root),
                progress=lines.append,
                provider_timeout_seconds=19,
            )
            envelope = json.dumps(
                {
                    "structured_output": _valid_draft(),
                    "usage": {"input_tokens": 11, "output_tokens": 3},
                }
            )
            completed = subprocess.CompletedProcess([], 0, stdout=envelope)

            with patch.object(
                pipeline, "_run_command", return_value=completed
            ) as command_runner:
                pipeline._run_provider(  # noqa: SLF001
                    "claude",
                    root / "claude.exe",
                    request,
                    output,
                    log,
                )

            _, kwargs = command_runner.call_args
            invoked = command_runner.call_args.args[0]
            self.assertEqual(kwargs["input_text"], "compact prompt\nJOB LAST")
            self.assertEqual(kwargs["timeout_seconds"], 19)
            self.assertNotEqual(kwargs["cwd"], root.resolve())
            self.assertIn("--json-schema", invoked)
            self.assertNotIn(str(request.resolve()), invoked)
            # The response is written in normalised, schema-conformant form.
            self.assertEqual(
                json.loads((root / DRAFT_RESPONSE_NAME).read_text(encoding="utf-8")),
                parse_provider_json(_valid_draft()).to_dict(),
            )
            self.assertEqual(log.read_text(encoding="utf-8"), envelope)
            usage = json.loads((root / USAGE_METRICS_NAME).read_text(encoding="utf-8"))
            self.assertEqual(usage["input_tokens"], 11)
            self.assertEqual(usage["output_tokens"], 3)
            self.assertEqual(usage["calls"], 1)
            self.assertTrue(any("claude finished in" in line for line in lines))

    def test_codex_provider_reads_final_response_from_isolated_output_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request = root / "application_request.md"
            request.write_text("compact prompt", encoding="utf-8")
            pipeline = ApplicationPipeline(Paths(project_root=root))
            provider_draft = _valid_draft()
            provider_draft["cover_paragraphs"] = {
                name: None for name in COVER_PARAGRAPH_FIELDS
            }

            def invoke(command: list[str], **_kwargs: object):
                response = Path(command[command.index("--output-last-message") + 1])
                response.write_text(json.dumps(provider_draft), encoding="utf-8")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    stdout=json.dumps(
                        {"usage": {"input_tokens": 7, "output_tokens": 2}}
                    ),
                )

            with patch.object(pipeline, "_run_command", side_effect=invoke) as runner:
                pipeline._run_provider(  # noqa: SLF001
                    "codex",
                    root / "codex.exe",
                    request,
                    root / "output",
                    root / "provider.log",
                )

            invoked = runner.call_args.args[0]
            self.assertEqual(invoked[-1], "-")
            self.assertEqual(runner.call_args.kwargs["input_text"], "compact prompt")
            # The response is written in normalised, schema-conformant form.
            stored = json.loads(
                (root / DRAFT_RESPONSE_NAME).read_text(encoding="utf-8")
            )
            self.assertEqual(stored, parse_provider_json(provider_draft).to_dict())
            self.assertEqual(
                stored["cover_paragraphs"],
                {name: None for name in COVER_PARAGRAPH_FIELDS},
            )
            self.assertEqual(
                set(stored["cv_skills"]),
                set(
                    AI_DRAFT_JSON_SCHEMA["properties"]["cv_skills"]["properties"]
                ),
            )
            usage = json.loads((root / USAGE_METRICS_NAME).read_text(encoding="utf-8"))
            self.assertEqual(usage["total_tokens"], 9)

    def test_reviewable_cover_paragraphs_hide_unchanged_null_values(self) -> None:
        payload = _valid_draft()
        changed = payload["cover_paragraphs"]["para_5_close"]
        payload["cover_paragraphs"] = {
            **{name: None for name in COVER_PARAGRAPH_FIELDS},
            "para_5_close": changed,
        }

        self.assertEqual(
            _reviewable_value(parse_provider_json(payload), "cover_paragraphs"),
            {"para_5_close": changed},
        )

    def test_claude_provider_rejects_an_unstructured_json_envelope(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request = root / "application_request.md"
            request.write_text("prompt", encoding="utf-8")
            pipeline = ApplicationPipeline(Paths(project_root=root))
            completed = subprocess.CompletedProcess(
                [], 0, stdout=json.dumps({"result": _valid_draft()})
            )

            with patch.object(pipeline, "_run_command", return_value=completed):
                with self.assertRaisesRegex(PipelineError, "structured_output"):
                    pipeline._run_provider(  # noqa: SLF001
                        "claude",
                        root / "claude.exe",
                        request,
                        root / "output",
                        root / "provider.log",
                    )

    def test_model_identifier_validation(self) -> None:
        accepted = (
            "gpt-5.6",
            "provider/model:v1",
            "claude_opus-4.1[latest]",
            "a" * 256,
        )
        for model in accepted:
            with self.subTest(model=model):
                self.assertEqual(validate_model(model), model)
        self.assertIsNone(validate_model(None))

        rejected = (
            "",
            "-starts-like-an-option",
            "contains space",
            "contains\ttab",
            "contains\nnewline",
            "contains\x00control",
            "model@vendor",
            "a" * 257,
        )
        for model in rejected:
            with self.subTest(model=repr(model)):
                with self.assertRaises(ValueError):
                    validate_model(model)

    def test_python_cli_forwards_default_controls(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(["codex"]), 0)

        pipeline_run.assert_called_once_with(
            "codex",
            None,
            None,
            fresh=False,
            job=None,
            limit=None,
            dry_run=False,
            estimate_tokens=False,
            token_budget=None,
            max_ai_repairs=None,
            continue_on_job_error=False,
            address_lookup=True,
            review=True,
            provider_timeout_seconds=1200.0,
            latex_timeout_seconds=120.0,
            progress=cli.emit,
        )

    def test_python_cli_forwards_v12_runtime_and_token_controls(self) -> None:
        summary = SimpleNamespace(processed=(), skipped=())
        argv = [
            "claude",
            "--model",
            "opus",
            "--effort",
            "max",
            "--fresh",
            "--job",
            "191",
            "--limit",
            "2",
            "--dry-run",
            "--estimate-tokens",
            "--token-budget",
            "9000",
            "--max-ai-repairs",
            "0",
            "--continue-on-job-error",
            "--provider-timeout",
            "15",
            "--latex-timeout",
            "25",
            "--no-address-lookup",
            "--no-review",
            "--quiet",
        ]
        with patch.object(cli, "run", return_value=summary) as pipeline_run:
            self.assertEqual(cli.main(argv), 0)

        pipeline_run.assert_called_once_with(
            "claude",
            "opus",
            "max",
            fresh=True,
            job="191",
            limit=2,
            dry_run=True,
            estimate_tokens=True,
            token_budget=9000,
            max_ai_repairs=0,
            continue_on_job_error=True,
            address_lookup=False,
            review=False,
            provider_timeout_seconds=15.0,
            latex_timeout_seconds=25.0,
            progress=None,
        )

    def test_python_cli_returns_failure_when_any_job_failed(self) -> None:
        summary = SimpleNamespace(
            processed=(),
            skipped=(),
            failed=(SimpleNamespace(job_ad=Path("job.pdf"), message="bad ad"),),
        )
        with patch.object(cli, "run", return_value=summary):
            self.assertEqual(cli.main(["codex", "--quiet"]), 1)

    def test_powershell_runner_forwards_v12_controls(self) -> None:
        script = (ROOT / "run.ps1").read_text(encoding="utf-8")
        expected_fragments = (
            "[switch] $Fresh",
            "[string] $Job",
            "[int] $Limit",
            "[switch] $DryRun",
            "[switch] $EstimateTokens",
            "[int] $TokenBudget",
            "[int] $MaxAiRepairs",
            "[switch] $ContinueOnJobError",
            "[double] $ProviderTimeout = 1200",
            "[double] $LatexTimeout = 120",
            "[switch] $NoReview",
            "[switch] $NoAddressLookup",
            "[switch] $Version",
            '$PipelineArguments += "--fresh"',
            '@("--job", $Job)',
            '@("--limit", [string] $Limit)',
            '"--dry-run"',
            '"--estimate-tokens"',
            '@("--token-budget", [string] $TokenBudget)',
            '@("--max-ai-repairs", [string] $MaxAiRepairs)',
            '"--continue-on-job-error"',
            '@("--provider-timeout", [string] $ProviderTimeout)',
            '@("--latex-timeout", [string] $LatexTimeout)',
            '"--no-review"',
            '"--no-address-lookup"',
            '$("-m", "job_application_pipeline", "--version")',
        )
        # The version fragment has an array-literal spelling in PowerShell;
        # check it separately to keep this list focused on forwarding switches.
        for fragment in expected_fragments[:-1]:
            with self.subTest(fragment=fragment):
                self.assertIn(fragment, script)
        self.assertIn(
            '$PipelineArguments = @("-m", "job_application_pipeline", "--version")',
            script,
        )
        self.assertIn('$PSBoundParameters.ContainsKey("Model")', script)
        self.assertIn('@("--model", $Model)', script)
        self.assertIn('$PSBoundParameters.ContainsKey("Effort")', script)
        self.assertIn('@("--effort", $Effort)', script)

    def test_progress_survives_a_console_that_cannot_encode_the_message(self) -> None:
        written: list[str] = []

        class NarrowStream:
            encoding = "cp1252"

            def write(self, text: str) -> int:
                text.encode("cp1252")
                written.append(text)
                return len(text)

            def flush(self) -> None:
                return None

        with patch.object(cli.sys, "stdout", NarrowStream()):
            cli.emit("Eruygur Akademi ve Danışmanlık")

        self.assertEqual(len(written), 1)
        self.assertIn("Eruygur Akademi ve Dan", written[0])

    def test_python_cli_reports_an_unsupported_effort_before_filesystem_work(self) -> None:
        # ApplicationPipeline validates this pairing before layout, executable,
        # lock, or artifact work; invoking the real facade is therefore safe.
        self.assertEqual(cli.main(["codex", "--effort", "max"]), 1)

    def test_invalid_model_is_rejected_before_layout_or_executable_checks(self) -> None:
        lookups: list[str] = []
        pipeline = ApplicationPipeline(
            Paths(), executable_resolver=lambda name: lookups.append(name) or name
        )
        with self.assertRaisesRegex(ValueError, "model"):
            pipeline.run("claude", "invalid model")
        self.assertEqual(lookups, [])

    def test_all_four_generation_outputs_are_required(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            _template, generated_cv = valid_cv()
            _cover_template, generated_cover = valid_cover()
            (output / "tailored_cv.tex").write_text(generated_cv, encoding="utf-8")
            (output / "cover_letter.tex").write_text(generated_cover, encoding="utf-8")
            (output / "change_log.md").write_text("changes", encoding="utf-8")
            pipeline = ApplicationPipeline(Paths())

            with self.assertRaisesRegex(PipelineError, "match_notes.md"):
                pipeline._assert_fresh_outputs(output)  # noqa: SLF001

            (output / "match_notes.md").write_text("notes", encoding="utf-8")
            pipeline._assert_fresh_outputs(output)  # noqa: SLF001

    def test_cover_pdf_must_have_exactly_one_page(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            cover_pdf = Path(temporary) / "cover.pdf"
            cover_pdf.write_bytes(b"PDF fixture")
            pipeline = ApplicationPipeline(Paths())

            one_page = _FakeInspectedPdf(page_count=1)
            with patch.dict(
                "sys.modules",
                {"fitz": SimpleNamespace(open=lambda _path: one_page)},
            ):
                pipeline._assert_one_page(cover_pdf)  # noqa: SLF001
            self.assertTrue(one_page.closed)

            two_pages = _FakeInspectedPdf(page_count=2)
            with patch.dict(
                "sys.modules",
                {"fitz": SimpleNamespace(open=lambda _path: two_pages)},
            ):
                with self.assertRaisesRegex(PipelineError, "exactly one page; got 2"):
                    pipeline._assert_one_page(cover_pdf)  # noqa: SLF001
            self.assertTrue(two_pages.closed)

    def test_cover_postcompile_checks_pdf_text_and_overfull_layout(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cover_pdf = root / "cover.pdf"
            cover_pdf.write_bytes(b"PDF fixture")
            log = root / "cover.log"
            pipeline = ApplicationPipeline(Paths())

            log.write_text("clean LaTeX log\n", encoding="utf-8")
            clean_pdf = _FakeTextPdf("Dear Hiring Team,\nKind regards,\nYigit Coskun")
            with patch.dict(
                "sys.modules", {"fitz": SimpleNamespace(open=lambda _path: clean_pdf)}
            ):
                clean = pipeline._cover_postcompile_findings(  # noqa: SLF001
                    cover_pdf=cover_pdf, log_path=log
                )
            self.assertTrue(clean_pdf.closed)
            self.assertEqual(
                [finding.severity for finding in clean],
                [Severity.PASS, Severity.PASS],
            )

            log.write_text("Overfull \\hbox (4.0pt too wide)\n", encoding="utf-8")
            bad_pdf = _FakeTextPdf("body without the required closing")
            with patch.dict(
                "sys.modules", {"fitz": SimpleNamespace(open=lambda _path: bad_pdf)}
            ):
                bad = pipeline._cover_postcompile_findings(  # noqa: SLF001
                    cover_pdf=cover_pdf, log_path=log
                )
            self.assertEqual(
                [finding.severity for finding in bad],
                [Severity.ERROR, Severity.ERROR],
            )

    def test_latex_compilation_skips_an_unnecessary_second_pass(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            tex = root / "document.tex"
            tex.write_text("tex", encoding="utf-8")
            build = root / "build"
            build.mkdir()
            pipeline = ApplicationPipeline(Paths(project_root=root))

            def compile_once(command: list[str], **_kwargs: object):
                (build / "document.pdf").write_bytes(b"PDF")
                return subprocess.CompletedProcess(command, 0, stdout="clean log")

            with patch.object(
                pipeline, "_run_command", side_effect=compile_once
            ) as runner:
                result = pipeline._compile_latex(  # noqa: SLF001
                    tex, build, root / "pdflatex.exe", root / "command.log"
                )

            self.assertEqual(result, build / "document.pdf")
            self.assertEqual(runner.call_count, 1)
            self.assertEqual(runner.call_args.kwargs["timeout_seconds"], 120.0)
            self.assertNotIn(
                "pass 2", (root / "command.log").read_text(encoding="utf-8")
            )

    def test_latex_compilation_reruns_only_when_the_log_requests_it(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            tex = root / "document.tex"
            tex.write_text("tex", encoding="utf-8")
            build = root / "build"
            build.mkdir()
            pipeline = ApplicationPipeline(Paths(project_root=root))
            outputs = iter(
                (
                    "LaTeX Warning: Label(s) may have changed. Rerun to get cross-references right.",
                    "clean second pass",
                )
            )

            def compile_pass(command: list[str], **_kwargs: object):
                (build / "document.pdf").write_bytes(b"PDF")
                return subprocess.CompletedProcess(command, 0, stdout=next(outputs))

            with patch.object(
                pipeline, "_run_command", side_effect=compile_pass
            ) as runner:
                pipeline._compile_latex(  # noqa: SLF001
                    tex, build, root / "pdflatex.exe", root / "command.log"
                )

            self.assertEqual(runner.call_count, 2)
            self.assertIn(
                "pass 2", (root / "command.log").read_text(encoding="utf-8")
            )

    def test_the_reviewer_is_shown_the_cv_evidence_it_judges_against(self) -> None:
        """It cannot call a cited project invented if it can see the bullets.

        The PARA_3 fields carry no similarity guard, so this reviewer is their
        main check. Given only the summary it rejected a correctly cited NOSI
        experiment as unsupported and pushed the writer back to the summary,
        which flattened every letter onto the same two examples.
        """

        import inspect

        from job_application_pipeline import pipeline as pipeline_module

        source = inspect.getsource(pipeline_module.ApplicationPipeline._run_reviewer)
        approved = source[source.index('"APPROVED_SOURCES"') :]
        approved = approved[: approved.index('"TAILORED_DRAFT"')]
        for key in ("SKILLS_INVENTORY", "CV_SUMMARY", "CV_EVIDENCE"):
            with self.subTest(key=key):
                self.assertIn(key, approved)

    def test_a_review_may_add_skills_but_never_drop_them(self) -> None:
        """The reviewer's skills remit is additive; a drop is a regression."""

        before = {
            "programming": ["Python (pandas)", "SQL"],
            "tools_platforms": ["Git", "LaTeX"],
            "professional": ["automation"],
            "languages": "Turkish (Native), English (Fluent), German (Intermediate)",
        }
        self.assertTrue(
            _skills_only_grew(
                before, {**before, "programming": ["Python (pandas)", "SQL", "R"]}
            )
        )
        # Nesting a package that was already listed is not a drop.
        self.assertTrue(
            _skills_only_grew(before, {**before, "programming": ["Python", "pandas", "SQL"]})
        )
        self.assertFalse(
            _skills_only_grew(before, {**before, "tools_platforms": ["Git"]})
        )

    @staticmethod
    def _provider_command(
        provider: str,
        model: str | None,
        effort: str | None,
        *,
        address_lookup: bool = True,
    ) -> list[str]:
        pipeline = ApplicationPipeline(Paths())
        return pipeline._provider_command(  # noqa: SLF001 - command contract
            provider,  # type: ignore[arg-type]
            Path(f"{provider}.exe"),
            Path("request.md"),
            Path("ignored-output"),
            model,
            effort,
            schema_path=Path("schema.json"),
            response_path=Path("response.json"),
            address_lookup=address_lookup,
        )


class _FakeInspectedPdf:
    def __init__(self, *, page_count: int) -> None:
        self.page_count = page_count
        self.closed = False

    def close(self) -> None:
        self.closed = True


class _FakeTextPage:
    def __init__(self, text: str) -> None:
        self.text = text

    def get_text(self, mode: str, *, sort: bool) -> str:
        if mode != "text" or not sort:
            raise AssertionError("cover PDF extraction must request sorted text")
        return self.text


class _FakeTextPdf:
    def __init__(self, text: str) -> None:
        self.pages = (_FakeTextPage(text),)
        self.closed = False

    def __iter__(self):
        return iter(self.pages)

    def close(self) -> None:
        self.closed = True


if __name__ == "__main__":
    unittest.main()
