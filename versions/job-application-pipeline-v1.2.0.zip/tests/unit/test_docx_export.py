from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
import zipfile
from datetime import date
from pathlib import Path

from tests.support import ROOT

from job_application_pipeline.docx_export import (
    DOCX_FONT,
    apply_house_styles,
    apply_page_setup,
    prepare_for_pandoc,
    restyle_document_xml,
    set_core_properties,
)


CV_TEMPLATE = (ROOT / "templates" / "cv" / "yigit_coskun_empty.tex").read_text(
    encoding="utf-8"
)
COVER_TEMPLATE = (
    ROOT / "templates" / "cover_letter" / "yigit_coskun_cover_letter.tex"
).read_text(encoding="utf-8")


class PrepareForPandocTests(unittest.TestCase):
    def test_installed_cv_is_flattened_and_its_name_becomes_the_title(self) -> None:
        prepared, title = prepare_for_pandoc(CV_TEMPLATE)

        # The wrapper itemize nests every bullet to level two and indents the
        # whole page; the tabular* becomes a too-narrow two-column table.
        self.assertIn(r"\renewcommand{\resumeSubHeadingListStart}{}", prepared)
        self.assertIn(r"\renewcommand{\resumeSubheading}[4]", prepared)
        self.assertLess(
            prepared.index(r"\renewcommand{\resumeSubheading}"),
            prepared.index(r"\begin{document}"),
        )
        self.assertEqual(title, "Yigit Coskun")
        self.assertNotIn(r"\LARGE Yigit Coskun", prepared)

    def test_a_source_without_the_cv_macros_is_left_alone(self) -> None:
        """The cover letter has its own heading and no presentation macros."""

        prepared, title = prepare_for_pandoc(COVER_TEMPLATE, today=date(2026, 9, 7))

        self.assertNotIn(r"\renewcommand{\resumeSubheading}", prepared)
        self.assertIsNone(title)

    def test_today_becomes_a_written_date(self) -> None:
        prepared, _ = prepare_for_pandoc(COVER_TEMPLATE, today=date(2026, 9, 7))

        # A letter reads "7 September 2026", never an ISO stamp.
        self.assertIn("7 September 2026", prepared)
        self.assertNotIn(r"\today", prepared)

    def test_a_source_without_begin_document_is_rejected(self) -> None:
        broken = "\n".join(
            (
                r"\resumeSubHeadingListStart",
                r"\resumeSubheading{a}{b}{c}{d}",
                r"\resumeItemPlain{x}",
            )
        )
        with self.assertRaisesRegex(ValueError, r"begin\{document\}"):
            prepare_for_pandoc(broken)


class RestyleTests(unittest.TestCase):
    def test_hyperlink_is_blackened_whatever_the_attribute_order(self) -> None:
        """The converter writes <w:color>'s attributes in either order."""

        for colour in (
            '<w:color w:val="4F81BD" w:themeColor="accent1" />',
            '<w:color w:themeColor="accent1" w:val="4F81BD" />',
        ):
            with self.subTest(colour=colour):
                xml = (
                    '<w:styles><w:style w:type="character" w:styleId="Hyperlink">'
                    "<w:rPr>" + colour + "</w:rPr></w:style></w:styles>"
                )
                styled = restyle_document_xml(xml)
                self.assertNotIn("4F81BD", styled)
                self.assertIn('<w:color w:val="000000" />', styled)

    def test_section_headings_become_black_ruled_small_caps(self) -> None:
        xml = (
            '<w:styles><w:style w:type="paragraph" w:styleId="Heading1">'
            '<w:pPr><w:spacing w:before="360" w:after="80" /></w:pPr>'
            '<w:rPr><w:color w:val="0F4761" w:themeColor="accent1" />'
            '<w:sz w:val="40" /></w:rPr></w:style></w:styles>'
        )
        styled = restyle_document_xml(xml)

        self.assertIn("<w:smallCaps />", styled)
        self.assertIn('<w:color w:val="000000" />', styled)
        self.assertNotIn("0F4761", styled)
        # The rule under the heading stands in for the CV's \titlerule.
        self.assertIn("<w:bottom", styled)

    def test_an_absent_style_is_skipped_rather_than_failing(self) -> None:
        self.assertEqual(
            restyle_document_xml("<w:styles></w:styles>"), "<w:styles></w:styles>"
        )

    def test_the_body_font_is_a_widely_installed_one(self) -> None:
        """An applicant tracking system should not have to substitute."""

        self.assertIn(
            DOCX_FONT,
            {"Calibri", "Arial", "Georgia", "Cambria", "Verdana", "Helvetica"},
        )
        styled = restyle_document_xml(
            '<w:styles><w:docDefaults><w:rPrDefault><w:rPr>'
            '<w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi" />'
            '<w:sz w:val="24" /><w:szCs w:val="24" />'
            '<w:lang w:val="en-US" w:eastAsia="zh-CN" />'
            "</w:rPr></w:rPrDefault></w:docDefaults></w:styles>"
        )
        self.assertIn(f'w:ascii="{DOCX_FONT}"', styled)
        self.assertNotIn("minorHAnsi", styled)
        self.assertIn('w:val="en-GB"', styled)


class PageSetupTests(unittest.TestCase):
    def test_an_empty_section_gains_a4_and_margins(self) -> None:
        setup = apply_page_setup(
            "<w:body><w:sectPr><w:footnotePr /></w:sectPr></w:body>"
        )

        # A4 in twips. Without this the file inherits US Letter.
        self.assertIn('w:w="11906"', setup)
        self.assertIn('w:h="16838"', setup)
        self.assertIn("<w:pgMar", setup)
        # Existing section content is kept, not replaced.
        self.assertIn("<w:footnotePr />", setup)

    def test_an_existing_page_size_is_replaced_not_duplicated(self) -> None:
        setup = apply_page_setup(
            '<w:body><w:sectPr><w:pgSz w:w="12240" w:h="15840" />'
            '<w:pgMar w:top="1440" /></w:sectPr></w:body>'
        )

        self.assertEqual(setup.count("<w:pgSz"), 1)
        self.assertEqual(setup.count("<w:pgMar"), 1)
        self.assertNotIn('w:w="12240"', setup)

    def test_a_document_without_a_section_gains_one(self) -> None:
        setup = apply_page_setup("<w:body><w:p /></w:body>")

        self.assertIn("<w:sectPr>", setup)
        self.assertIn('w:w="11906"', setup)


class CorePropertiesTests(unittest.TestCase):
    def test_title_and_author_are_filled_and_escaped(self) -> None:
        core = set_core_properties(
            "<cp:coreProperties><dc:title></dc:title>"
            "<dc:creator></dc:creator></cp:coreProperties>",
            title="Smith & Sons",
            author="Smith & Sons",
        )

        self.assertIn("<dc:title>Smith &amp; Sons</dc:title>", core)
        self.assertIn("<dc:creator>Smith &amp; Sons</dc:creator>", core)

    def test_absent_tags_are_added(self) -> None:
        core = set_core_properties(
            "<cp:coreProperties></cp:coreProperties>",
            title="Yigit Coskun",
            author="Yigit Coskun",
        )

        self.assertIn("<dc:title>Yigit Coskun</dc:title>", core)
        self.assertIn("<dc:creator>Yigit Coskun</dc:creator>", core)


@unittest.skipUnless(shutil.which("pandoc"), "pandoc is not installed")
class RealConversionTests(unittest.TestCase):
    """The only test that inspects a genuinely converted file."""

    @classmethod
    def setUpClass(cls) -> None:
        cls._temporary = tempfile.TemporaryDirectory()
        work = Path(cls._temporary.name)
        prepared, title = prepare_for_pandoc(CV_TEMPLATE, today=date(2026, 9, 7))
        source = work / "cv.tex"
        source.write_text(prepared, encoding="utf-8", newline="\n")
        cls.docx = work / "cv.docx"
        subprocess.run(
            [
                shutil.which("pandoc"),
                "--from=latex",
                "--to=docx",
                f"--output={cls.docx}",
                f"--metadata=title:{title}",
                str(source),
            ],
            check=True,
            capture_output=True,
        )
        apply_house_styles(cls.docx, scratch_dir=work, title=title)
        cls.archive = zipfile.ZipFile(cls.docx)
        cls.document = cls.archive.read("word/document.xml").decode("utf-8")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.archive.close()
        cls._temporary.cleanup()

    def test_the_converted_cv_parses_as_an_ats_would_want(self) -> None:
        # Tables, text boxes, and columns are what break applicant tracking
        # systems; the flattening exists to keep all three out.
        self.assertEqual(self.document.count("<w:tbl>"), 0)
        self.assertNotIn("txbxContent", self.document)
        self.assertFalse(
            [n for n in self.archive.namelist() if "header" in n or "footer" in n]
        )
        # Bullets must be real list items, not typed-in dashes.
        self.assertGreaterEqual(self.document.count("<w:numPr>"), 15)
        self.assertIn('w:w="11906"', self.document)  # A4, not US Letter
        self.assertIn("<w:pgMar", self.document)

    def test_every_section_and_the_contact_line_survive(self) -> None:
        from job_application_pipeline.documents import extract_docx_text

        text = extract_docx_text(self.docx)
        for section in (
            "Summary",
            "Education",
            "Work Experience",
            "Projects",
            "Publications",
            "Certifications",
            "Skills",
        ):
            with self.subTest(section=section):
                self.assertIn(section, text)
        for detail in ("contact@yigitcoskun.com", "+49 176 45819490", "8.16"):
            with self.subTest(detail=detail):
                self.assertIn(detail, text)


if __name__ == "__main__":
    unittest.main()
