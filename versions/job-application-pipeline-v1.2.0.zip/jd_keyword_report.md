# What the last 100 postings actually ask for

A frequency analysis of `job_description_172` .. `job_description_271`, read as
the advice suggests: nouns for the keywords an ATS scans, verbs for what the
employer expects you to *do*.

**Corpus:** 100 advertisements — **47 German, 53 English**. Counts are the
number of advertisements containing a term at least once, so "50" means half of
all postings. Matching is regex over the extracted PDF text, tolerant of German
and English spellings.

---

## The finding that matters most

Four terms your CV and skills inventory lean on appear in **zero** of the 100
postings:

| Term | Postings |
| --- | --- |
| `regression` | **0** |
| `time series` / `Zeitreihen` | **0** |
| `hypothesis testing` | **0** |
| `causal inference` | **0** |

These are not rare — they are absent. Meanwhile `forecasting` appears in 24 and
`experiment` in 16. Employers in this sample are not asking for classical
econometric method names; they ask for the outcome (a forecast, an experiment)
and for the business-facing work around it.

Your Tier 2/3 inventory is heavy with the vocabulary nobody searches for:
`ARIMA and VAR`, `Diebold-Mariano testing`, `out-of-sample analysis`, `LASSO`,
`random forest`, `Dynare`, `SHAP`, `time-series analysis` — all at 0–1.

---

## Tools and technologies

| Postings | % | Term |
| --- | --- | --- |
| 50 | 50% | **Python** |
| 49 | 49% | **SQL** |
| 30 | 30% | **Power BI** |
| 28 | 28% | **Excel** |
| 13 | 13% | Tableau |
| 12 | 12% | R |
| 11 | 11% | AWS |
| 11 | 11% | **SAP** |
| 7 | 7% | PyTorch · Azure · Git |
| 6 | 6% | Looker · TensorFlow · Databricks |
| 5 | 5% | pandas · scikit-learn |
| 4 | 4% | NumPy · Spark · dbt · Snowflake · Google Analytics · Looker Studio |

Python and SQL are the price of entry. **Power BI and Excel together outrank
every ML library combined** — 58 postings mention one of them.

`R` is measured conservatively (only where it appears as a standalone token
beside another language) so the true figure is somewhat higher, but the shape
holds: R is asked for roughly a quarter as often as Python, while sitting in
your Tier 1 "always include" set.

---

## Concepts and methods

| Postings | % | Term |
| --- | --- | --- |
| 49 | 49% | **AI / KI** |
| 39 | 39% | **stakeholder management** |
| 37 | 37% | **reporting** |
| 30 | 30% | optimisation |
| 30 | 30% | **dashboards** |
| 29 | 29% | statistics |
| 28 | 28% | **forecasting** |
| 22 | 22% | cross-functional |
| 20 | 20% | machine learning |
| 18 | 18% | **KPIs** |
| 16 | 16% | **experimentation** |
| 16 | 16% | data visualisation |
| 14 | 14% | data modelling |
| 13 | 13% | data quality |
| 10 | 10% | LLM / GenAI · ETL / pipelines · agile / Scrum · governance |
| 8 | 8% | simulation |
| 5 | 5% | NLP · A/B testing · GDPR / DSGVO |

Read the top of that table again: **stakeholder, reporting, dashboards and KPIs
beat machine learning.** Four of the five most-requested concepts are about
communicating results, not producing them.

`AI / KI` at 49% is measured case-sensitively, so it is genuine — but it is
mostly ambient ("AI-driven", "KI-gestützt") rather than a hard requirement.

---

## Verbs — what they expect you to do

**English postings**

| Postings | Verb |
| --- | --- |
| 51 | analyse |
| 49 | support |
| 49 | report |
| 36 | build |
| 32 | develop |
| 31 | model |
| 27 | create · ensure |
| 25 | collaborate |
| 24 | design · forecast |
| 23 | monitor · improve |
| 22 | test · identify |

**German postings**

| Postings | Verb |
| --- | --- |
| 35 | entwickeln |
| 31 | unterstützen |
| 27 | gestalten |
| 25 | verantworten |
| 23 | analysieren |
| 21 | optimieren · automatisieren |
| 20 | erstellen |
| 13 | begleiten · beraten |

`support` / `unterstützen` and `report` sitting at the very top alongside
`analyse` is the same story the nouns tell: these are service-and-communication
roles with analysis inside them, not research roles.

---

## Gap 1 — asked for often, missing from your inventory

These are the cheap wins, because **you already have the evidence for most of
them** — they simply have no inventory entry, so the pipeline can never surface
them on a CV.

| Postings | Term | Evidence you already hold |
| --- | --- | --- |
| 39 | stakeholder management | NOSI: "present findings to senior researchers" |
| 37 | reporting | IAB: "produce tables and visualisations", co-authored report |
| 30 | dashboards | — (Power BI is in inventory; dashboards is not) |
| 22 | cross-functional | IAB: two departments |
| 18 | KPIs | — |
| 16 | experimentation | NOSI: randomised 2x2 field experiment |
| 10 | ETL / data pipelines | Thesis: automated collection and preprocessing pipeline |
| 6 | TensorFlow | Thesis: "mixed-frequency LSTM in TensorFlow/Keras" |
| 13 | data quality | IAB: "prepare, validate" |

`TensorFlow` is the clearest omission: it is named in your CV summary and your
thesis bullet, but it is not an inventory term, so it can never appear in the
Skills block.

**Not held** — these are learning signals, not CV edits: SAP (11), Azure (7),
Databricks (6), Looker (6), dbt (4), Snowflake (4), governance (10),
GDPR/DSGVO (5).

---

## Gap 2 — in your inventory, nobody asks

| Tier | Postings | Skill |
| --- | --- | --- |
| **1** | **0** | **LaTeX** |
| 2 | 0 | CUDA · ARIMA and VAR · Matplotlib · ggplot2 · hypothesis testing |
| 2 | 1 | Docker |
| 3 | 0 | mathematics · SHAP · Diebold-Mariano testing · out-of-sample analysis · random forest · LASSO · Dynare · web scraping · time-series analysis · EDA |
| 3 | 1 | MATLAB |

`LaTeX` is Tier 1 — always included on every CV — and appears in **zero** of 100
postings. It occupies a slot in the four-line Skills block on every application.

Tier 3 entries are already gated behind an explicit mention, so the zeros there
cost nothing. Tier 1 and Tier 2 zeros cost space on every CV.

---

## What I would change

**Add to the inventory** (evidence already exists, currently unreachable):
`TensorFlow/Keras`, `dashboards`, `KPI reporting`, `stakeholder communication`,
`experimental design / A-B testing`, `data pipelines (ETL)`, `data quality`.

**Reconsider Tier 1.** LaTeX at 0/100 does not earn an always-include slot.
Power BI, Python, SQL do.

**Reconsider Tier 2.** `ARIMA and VAR`, `hypothesis testing`, `Matplotlib` and
`ggplot2` are all 0 — they would serve better in Tier 3, where they appear only
when a posting names them.

**Worth learning, by demand:** SAP (11), Azure (7), Databricks (6), Looker (6).
SAP is the notable one — it is as common as AWS in this sample and is a German
market signal rather than a data-science one.

---

## Caveats

Counts are presence-per-advertisement, not mentions. Regex matching approximates
meaning: `optimisation` catches "Prozessoptimierung" as well as mathematical
optimisation, and `AI / KI` catches ambient marketing language. `R` is
undercounted by design. The corpus is what you chose to import, so it reflects
your own search filters as much as the market.

Regenerate after importing more postings with the scripts in the session
scratchpad (`jd_keywords.py`, `gap.py`).
