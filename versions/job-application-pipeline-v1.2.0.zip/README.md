# Job Application Pipeline

Current release: **1.2.0**. Run `.\run.ps1 -Version` (PowerShell) or
`python -m job_application_pipeline --version` to print the installed pipeline
version.

This project imports selected public LinkedIn job pages into the sibling
`Job_ad` folder, then turns the reviewed job PDFs into evidence-grounded English
CV and cover-letter pairs. Application generation supports exactly two
providers: Claude CLI and Codex CLI. Successful document pairs are validated,
compiled, and archived under the sibling `CVs` folder.

The LinkedIn importer in `desc/` is Stage 1 of this workflow. Finding and
ranking postings happens before it, in the sibling `job_fetch` project, which
writes a shortlist this importer can read.

## Current status

The CV and cover-letter source packs are installed. Stage 2 can run once its
external job-ad folder and required CLI/LaTeX executables are available. The
approved cover-letter pack is:

```text
data/reference/cover_letter/COVER_LETTER_RULES.md
templates/cover_letter/yigit_coskun_cover_letter.tex
templates/cover_letter/yigit_coskun_cover_letter.pdf  # locked typography baseline
```

The cover rules use the same current skills profiles and bullet library as
evidence companions. There is no separate legacy cover profile and cover
material can never become CV evidence.

## How the system works

```mermaid
flowchart LR
    A[desc/linkedin_urls.txt] --> B[create_job_descriptions.ps1]
    B --> C[Public LinkedIn pages<br/>via Playwright]
    C --> D[Extracted text PDF]
    D --> E[../Job_ad/job_description_X.pdf]
    E --> F[Manual inspection]
    F --> G[run.ps1<br/>selection, budget and runtime controls]
    H[Approved CV and<br/>cover-letter sources] --> G
    G --> K[Build compact request:<br/>stable rules + one job ad]
    K -->|claude| I[Claude CLI<br/>strict 9-field JSON]
    K -->|codex| J[Codex CLI<br/>strict 9-field JSON]
    I --> V[Validate JSON schema]
    J --> V
    V --> W[Select approved Skills and<br/>render all files locally]
    W --> L[pdflatex + one-page cover check]
    L --> M[CV + cover structural, typography,<br/>PDF, ATS, provenance + JD checks]
    M --> N[JSON + XLSX validation report]
    N --> O{Validation verdict}
    O -->|Repairable ERROR| P[Send failed checks and only<br/>allowed draft fields to provider]
    P --> S[Validate draft and rerender locally]
    S --> L
    O -->|Only late CL page or typography ERROR<br/>after the general budget| U[One reserved CL repair:<br/>change allowed draft wording only]
    U --> L
    O -->|ERROR after allowed repair budget| T[Block archive and manifest;<br/>retain .artifacts/job_N]
    O -->|PASS or WARN| Q[Atomic archive: ../CVs/job_N]
    Q --> R[Write checksum sentinel<br/>and update manifest]
```

A v1.2 archive is complete only when its `.complete.json` sentinel matches the
pipeline version, job-ad hash, versioned source-bundle hash, exact required file
set, file sizes, and SHA-256 checksums. A source, template, rule, prompt, job ad,
or pipeline-version change therefore schedules a rebuild instead of silently
reusing stale output. Archives created before v1.2 have no sentinel; for
backwards compatibility, a numbered legacy archive is skipped only when both
canonical PDFs exist and are non-empty. Delete a legacy folder to force its
migration to the stronger v1.2 completion contract.

## Project layout

```text
job_py/
├── create_job_descriptions.ps1      # Stage 1 importer entry point
├── run.ps1                          # Stage 2 application entry point
├── pyproject.toml
├── requirements.txt
├── src/job_application_pipeline/  # extraction, prompts, validation, orchestration
├── config/prompts/                 # provider request template
├── data/reference/
│   ├── cv/                         # CV rules and approved evidence libraries
│   └── cover_letter/               # approved cover-letter rules
├── templates/
│   ├── cv/
│   └── cover_letter/
├── versions/                       # preserved code-and-configuration snapshots
├── tests/
└── desc/                           # Stage 1 LinkedIn importer implementation

../Job_ad/                          # source postings; outside this project
../CVs/                             # final PDFs and manifest; outside this project
../job_fetch/                       # discovery and ranking; separate project
```

Runtime files are created under `.artifacts/`, including the disposable
`.artifacts/linkedin_imports` staging PDFs. Requests, review notes, and the
source job ad are copied into each final `CVs/job_N` audit folder.

## Source authority

The CV may use only:

- `data/reference/cv/CV_RULES.md`
- `data/reference/cv/bullet_library.docx`
- `data/reference/cv/skills_profiles.docx`
- `templates/cv/yigit_coskun_empty.tex`

The CV is fixed to the S-DS Data Scientist summary and 18 approved, unique
bullets in the template. The requested duplicate `I2b` identifier resolves to
the one approved `I2b` bullet; it is not duplicated. The fixed sequence is:

- FAU: `E1b`, `E3b`, `E2-EDU`, `E5a`
- Istanbul University: one bullet condensing `B1` and `B2`
- IAB: `I1a`, `I2b`, `I3a`
- Ziraat Bank: `Z1a`
- Master's Thesis: `P1a`, `P1b`, `P2a`, `P3a`
- NOSI: `N1a`, `N2a`, `N3a`
- Publication: `PB3`, `PB4`

The eighteen approved bullets never change. `SUMMARY` and the four-line
`SKILLS` region adapt to the job advertisement, and the provider proposes both
under guards the pipeline enforces locally; Languages remains fixed. The bullet
library remains the provenance record for the fixed claims and an evidence
companion for the cover letter.

The provider still writes no LaTeX or Markdown. It returns a strict JSON draft
that the pipeline validates and renders from: the five cover PARA_3 slots
(`specific_task_or_project`, `relevant_experience`, `related_activity`,
`concrete_contribution`, `company_domain`), the three address fields plus
`address_verified`, the diagnostic `fit`, `gaps`, and `risks` lists, and the
tailoring fields below. Unsupported requirements remain gaps or risks; they
cannot become candidate evidence.

The PARA_3 slots are the one place the provider writes free prose rather than
editing approved wording, so they carry no similarity or claim-preservation
guard. What constrains them is the schema length cap, the blocked-claim scan,
and the prompt's instruction to draw only on the approved paragraphs. Read them
in `match_notes.md` before sending an application.

### What the provider may tailor, and what stops it

| Field | Allowed | Enforced by |
| --- | --- | --- |
| `cv_skills` | Choose the skills the posting asks for | Every name must match the approved inventory exactly; over-long lines are truncated to 7/6/4. An unapproved name is a repair trigger, and a failed repair falls back to deterministic selection rather than shipping an empty line. |
| `cv_summary_role_title` | Replace the role title outright | Free text, escaped and length-capped. The pipeline splits the template's own title off at `" with "`, so a retitled summary cannot keep the old role word. |
| `cv_summary_body` | Substitute synonyms that echo the posting | Every number and every named method, tool, or institution must survive verbatim, and the body must stay at least 80% similar to the approved wording. |
| `cover_paragraphs` | Correct grammar, awkward phrasing, and clarity | Each of the five paragraphs must keep the template's `{{TOKEN}}` slots, keep every number and name, and stay at least 90% similar. LaTeX in a reply is rejected. |
| `jd_keywords` | Name 20-25 terms the posting asks for | Coverage is then measured deterministically against the rendered CV and cover letter, never against the provider's own account of what it did. |

A protected term is any number, any token carrying a capital letter after its
first (`XGBoost`, `LSTM`, `IAB`), and any approved skill name matched as a whole
phrase. Ordinary prose stays unprotected, which is what leaves room for synonym
substitution while the claims stay fixed.

The cover letter may use only its approved rules, the current CV bullet library
and skills profiles as evidence companions, its template, and the job
description. Cover-letter material can never become CV evidence. The job
advertisement guides relevance and supplies employer/role details; it cannot
create candidate experience.

The single exception is the employer's postal address. LinkedIn postings carry
a city but no street address, so the provider may look one up online and use a
reliable published business address for `{{COMPANY-ADDRESS}}` and
`{{COMPANY-CITY}}`. If none is found, both lines are deleted. An address is the
only detail permitted from outside the approved sources, it never becomes
evidence about the candidate, and nothing else on either document may be
changed because of a fetched page.

To make that possible each provider is granted a narrow web capability unless
`-NoAddressLookup`/`--no-address-lookup` is selected:

| Provider | Granted | Not granted |
| --- | --- | --- |
| `claude` | `--tools WebSearch,WebFetch` | all other tools and MCP tools |
| `codex` | `--search` | write access (`--sandbox read-only`) |

Both providers receive the request through standard input rather than a command
line argument. Their working directory is an isolated temporary directory, so
the job ad cannot instruct the provider to inspect or edit project files. With
address lookup disabled, Claude receives an empty tool allowlist and Codex is
started without search.

## Setup

Requirements:

- Windows PowerShell
- Python 3.11 or newer
- MiKTeX or another distribution that provides `pdflatex`
- Pandoc, for the DOCX copy of each finished document
- Claude CLI or Codex CLI
- Microsoft Edge, or a Playwright-managed Chromium installation, for Stage 1
- PyMuPDF for PDF inspection and `openpyxl` for validation workbooks; both are
  installed from `requirements.txt`

Install the Python dependencies for both stages:

```powershell
python -m pip install -r .\requirements.txt
```

The root wrappers use a working `.venv\Scripts\python.exe` when available and
fall back to `python` from `PATH`. Stage 1 uses Microsoft Edge by default; see
[desc/README.md](desc/README.md) for browser troubleshooting and the advanced
direct CLI.

Stage 2 uses PyMuPDF for PDF text and page inspection. Font checks are part of
the declared validator and report an inspection failure explicitly; the
pipeline does not silently skip them because of an undeclared Poppler command.

## Run

The workflow has exactly two stages.

### Stage 1: Create and inspect job descriptions

Add one public LinkedIn job-view URL per line to `desc/linkedin_urls.txt`, then
run the importer. The sibling `job_fetch` project can produce that URL list for
you; see [desc/README.md](desc/README.md).

```powershell
.\create_job_descriptions.ps1
```

The importer visits public pages one at a time through Playwright, creates
text-based staging PDFs under `.artifacts/linkedin_imports`, and archives new
postings as `../Job_ad/job_description_X.pdf`. It selects one number above the
highest number in the cache, final folder, or import ledger. Existing legacy
company-named PDFs are preserved. Inspect the new PDFs before continuing.

Stage 1 and Stage 2 are intentionally independent. A failure for one URL does
not remove PDFs already committed for other URLs, and the ledger prevents a
successful URL from being imported again by default. Failed or incomplete pages
leave no partial staging or archive PDF. The wrapper never starts CV generation,
so you can fix the URL list and retry Stage 1 or proceed later with only the
reviewed PDFs.

### Stage 2: Generate applications

After inspecting `../Job_ad`, choose Claude or Codex and, optionally, its model
and reasoning effort:

```powershell
.\run.ps1 claude -Model opus -Effort max
.\run.ps1 codex -Model gpt-5.6-sol -Effort xhigh
```

For the setup shown in this repository, the normal command is:

```powershell
.\run.ps1 codex -Model gpt-5.6-sol -Effort high
```

Run it from the `job_py` folder. The pipeline decides whether a retained
provider response matches the exact compact request. Use `-Fresh` only when you
intend to bypass that response cache.

Both options are independent. Omit either one to use the selected CLI's
configured default:

```powershell
.\run.ps1 claude
.\run.ps1 codex -Effort high
```

Plan and control a run before spending model tokens:

```powershell
# Print the active release.
.\run.ps1 -Version

# Read-only plan for one numbered ad; no executable lookup or filesystem write.
.\run.ps1 codex -Job 191 -DryRun

# Read-only compact-input estimate for at most three pending ads.
.\run.ps1 codex -Limit 3 -EstimateTokens

# Refuse the selected batch if its estimated input exceeds 12,000 tokens.
.\run.ps1 codex -Limit 3 -TokenBudget 12000

# Process independent job-content failures and report them at the end.
.\run.ps1 codex -ContinueOnJobError

# Disable AI repair and employer-address web search.
.\run.ps1 codex -MaxAiRepairs 0 -NoAddressLookup

# Override wall-clock limits in seconds.
.\run.ps1 codex -ProviderTimeout 900 -LatexTimeout 90
```

Stage 2 starts where the last finished application left off. The newest
structurally complete `CVs/job_X` is the watermark, and work resumes at
`job_description_X+1`; earlier advertisements stay in `Job_ad` untouched. An
unfinished folder — missing PDFs, missing reports, missing sentinel — does not
raise the watermark, so an interrupted job is still rebuilt under its own
number. To rebuild a finished application, delete its `CVs/job_X` folder first.

The Stage 2 controls are:

| PowerShell | Python module | Effect |
| --- | --- | --- |
| `-Job <value>` | `--job <value>` | Select one job by number, stem, or PDF filename. |
| `-Limit <n>` | `--limit <n>` | Take at most `n` pending jobs after completion filtering. |
| `-NoReview` | `--no-review` | Skip the reviewer agent. Halves provider calls per job, at the cost of the second opinion on fit, keywords, and clarity. |
| `-DryRun` | `--dry-run` | Produce a read-only plan without lock, artifacts, executable lookup, provider call, compilation, or manifest write. |
| `-EstimateTokens` | `--estimate-tokens` | Produce the same read-only plan with estimated compact input tokens. |
| `-TokenBudget <n>` | `--token-budget <n>` | Abort before provider calls when the selected requests exceed the estimated input-token budget. |
| `-MaxAiRepairs <n>` | `--max-ai-repairs <n>` | Bound structured provider repair calls per job; `0` disables them. |
| `-ContinueOnJobError` | `--continue-on-job-error` | Continue after isolated generated-content/job failures; fatal dependency, lock, source-mutation, and runtime failures still stop the batch. |
| `-ProviderTimeout <s>` | `--provider-timeout <s>` | Set the provider process-tree timeout; default `1200`. |
| `-LatexTimeout <s>` | `--latex-timeout <s>` | Set the timeout for each `pdflatex` pass; default `120`. |
| `-NoAddressLookup` | `--no-address-lookup` | Disable provider web tools; address fields must be null when the provider cannot independently verify them. |
| `-Fresh` | `--fresh` | Ignore a matching retained initial provider response. |
| `-Quiet` | `--quiet` | Suppress step-level progress. |

`-DryRun` and `-EstimateTokens` are intentionally non-mutating. A token budget
may also be applied to a live run; it gates the whole selected batch before the
first provider call. Token counts are conservative character-based estimates,
not provider billing totals.

`-Model` is passed to the CLI verbatim and is only checked for a safe character
set, so any identifier the CLI understands is accepted. `-Effort` is checked
against the level vocabulary of the chosen provider:

| Provider | Accepted `-Effort` levels | How it is passed |
| --- | --- | --- |
| `claude` | `low`, `medium`, `high`, `xhigh`, `max` | `--effort <level>` |
| `codex` | `minimal`, `low`, `medium`, `high`, `xhigh` | `--config model_reasoning_effort="<level>"` |

The vocabularies overlap but are not interchangeable: `max` is Claude-only and
`minimal` is Codex-only. Neither CLI fails on an unrecognised level of its own
accord — Claude warns and silently falls back to its default, and Codex forwards
the value as-is — so the pipeline rejects a mismatched or misspelt level up
front, before any job ad is read or any executable is resolved. Levels are
matched without regard to case or surrounding whitespace.

The model and effort options apply only to jobs processed in that run; an
already-complete job/source pair remains skipped. Both providers always create
an English CV and English cover letter. There are no CV-only, German, OpenAI
API, auto-fallback, or compilation-mode switches.

### Token economy in v1.2

The model receives a compact, stable instruction prefix followed by only the
current job advertisement. The CV template, cover template, rule documents,
bullet library, skills profiles, existing generated files, paths, and report
formats are no longer repeated in every provider prompt. A strict output schema
limits the response to nine small fields; all document prose and audit files are
rendered locally. Keeping the stable instructions first and the changing job ad
last also makes provider-side prefix caching possible where supported.

Repairs follow the same rule: they include only failed check identifiers and
messages, a short job excerpt, the approved sources, the current draft, and the fields that
may change. They never resend PDFs, spreadsheets, the full source pack, or all
four rendered outputs. Together with `--job`, `--limit`, read-only estimation,
the preflight token budget, retained-response reuse, and a configurable repair
cap, this makes model use explicit and bounded.

### Watching a run

Stage 2 reports each step to the console as it happens, so a long run is
visibly alive:

```text
5 job ad(s) found: 5 to process, 0 already complete.
Provider: claude (model=fable, effort=max)

[1/5] job_description_115.pdf -> job_115
   1/8 request built (compact job-specific payload)
   2/8 running claude; structured output is captured, so this step is silent until it finishes
      claude still running (30s)
      claude still running (1m 00s)
      claude finished in 1m 18s
   3/8 provider draft validated and four files rendered locally; validating LaTeX
   4/8 reviewer approved the draft
   5/8 compiling CV -> yigit_coskun_CV.pdf
   6/8 compiling cover letter -> yigit_coskun_cover_letter.pdf
   7/8 converting -> yigit_coskun_CV.docx, yigit_coskun_cover_letter.docx
   8/8 archived -> ..\CVs\job_115  [READY: 41 pass, 0 warn, 0 error]
       yigit_coskun_CV.pdf
       yigit_coskun_cover_letter.pdf
       yigit_coskun_CV.docx
       yigit_coskun_cover_letter.docx
       done in 1m 46s
```

The provider stage is normally the long one. Both CLIs are invoked with
captured output so an audit log can be written to
`.artifacts/job_N/provider.log`; the periodic "still running" notice
distinguishes a working provider from a stalled one. The configured provider
timeout terminates the whole child process tree rather than leaving an orphaned
CLI process. Pass `-Quiet` or `--quiet` to print only the closing summary.
Progress reporting never aborts a run: a console that cannot encode a character
falls back to a replacement rather than failing.

Stage 2 checks every top-level PDF in `../Job_ad`, but gives numbered files
priority in ascending order: `job_description_57.pdf` is considered before
`job_description_58.pdf`. Legacy company-named PDFs remain supported and follow
the numbered files, newest first. Only the top level is scanned, so PDFs kept in
a subfolder such as `../Job_ad/old/` are ignored.

### Numbering

A numbered job ad and the application built from it always share a number.
`job_description_117.pdf` is archived as `../CVs/job_117`, whatever else is in
the folder and however many times it is regenerated. The number comes from the
file name, not from a counter, so the two never drift apart.

A folder whose v1.2 completion sentinel is absent, malformed, stale, or fails
an artifact checksum is rebuilt and replaced wholesale rather than merged into.
The previous folder is moved aside first and deleted only once the manifest
commits, so an interrupted run never loses both copies. A pipeline-wide
`.artifacts/.pipeline.lock` prevents concurrent writers; a dead stale lock can
be recovered, while a live owner is never displaced merely because its lock is
old.

Only a legacy company-named ad, which carries no number, is given the next free
number instead: the highest number across the manifest, the `../CVs/job_N`
folders, and any `CV<N>`/`CL<N>` PDFs, plus one.

Stage 1 uses the same sequence, so an import continues from the newest completed
application. `next_job_number` takes the highest number across the staging
cache, `../Job_ad`, the import ledger, **and** the `../CVs/job_N` folders. That
last one matters when job ads are deleted: with `../CVs/job_116` present and
`../Job_ad` emptied, the next import is `job_description_117.pdf`, not
`job_description_1.pdf` overwriting an application that already exists. Numbers
are never reused, so deleting an ad leaves a gap rather than causing a
collision. The pipeline does not depend on a cursor text file. Instead,
`desc/job_sources.csv` records imported LinkedIn sources and
`../CVs/application_manifest.csv` records completed application pairs by job and
source-bundle hashes. For legacy company-named ads and incomplete numbered work,
this safely resumes older gaps, detects replaced PDFs, and reprocesses a posting
when approved rules, templates, prompt, job ad, source bundle, or pipeline
version changes. The v1.2 sentinel is authoritative for newly produced
archives; the two-PDF legacy fallback exists only to avoid rebuilding every
pre-v1.2 numbered archive immediately.

The first heading in each numbered job PDF is cleaned deterministically before
the provider request is built. Work-mode text, gender markers, dash suffixes,
unearned seniority, and engagement types are removed, so `Data Analyst
(Remote)`, `Data Analyst (x m d)`, `Data Analyst Internships`, and `Working
Student Data Analyst` all become `Data Analyst`.

That clean title is given to Claude or Codex. If a posting still carries a
qualifier the cleaner does not recognise, the provider may drop trailing words
from it, so `Data Analyst Summer Programme` may be used as `Data Analyst`.
Cover-letter validation accepts the clean title or a leading part of it, and
rejects anything that adds, reorders, or substitutes a word: the provider can
shorten a title but can never introduce a seniority or specialism the posting
did not give.

Each completed application is stored as:

```text
../CVs/job_N/
├── .complete.json
├── yigit_coskun_CV.pdf
├── yigit_coskun_cover_letter.pdf
├── yigit_coskun_CV.docx
├── yigit_coskun_cover_letter.docx
├── job_ad.pdf
├── application_request.md
├── provider.log
├── application_draft.schema.json
├── draft_response.json
├── change_log.md
├── match_notes.md
├── tailored_cv.tex
├── cover_letter.tex
├── usage.json
├── validation.json
└── validation.xlsx
```

Both documents also ship as DOCX. Pandoc converts them from the same validated
`.tex` the PDFs are compiled from, never from the compiled PDF, so the DOCX
carries real headings, lists, and paragraphs rather than a page image's
text boxes. The PDF remains the document of record: it is what the validators
measured, and the DOCX is a convenience copy for employers and applicant
tracking systems that will not accept a PDF.

`docx_export.py` does two things a plain conversion does not. It flattens the
CV's presentation macros first, because they convert badly rather than
incorrectly: `\resumeSubHeadingListStart` wraps the document in an `itemize`,
which nests every bullet to level two and indents the page, and
`\resumeSubheading` lays entry headers out in a `tabular*`, which becomes a
two-column table too narrow for a long institution name. It then restyles the
result to the CV's own look — black letter-spaced small-caps headings over a
rule, and links that print black as they do in the PDF.

The DOCX is built to parse cleanly: no tables, text boxes, columns, images, or
header/footer content; contact details in the document body; real outline
headings and real list items; explicit A4 page size, since a converted file
otherwise inherits US Letter. The body font is Calibri — set once as
`DOCX_FONT`, and worth keeping to fonts a parser is certain to have (Arial,
Georgia, Cambria, Verdana are the other safe swaps).

The DOCX pair is deliberately outside the `.complete.json` contract. That file
set is also the test behind the resume watermark, so adding a name to it would
declare every archive built before that name existed unfinished and rebuild the
whole back catalogue at provider cost. Conversion still has to succeed for the
run to reach the archive step; the pair is simply not checksum-verified on
resume.

The existing `../CVs/application_manifest.csv` is preserved and extended. Old
rows remain intact; new rows record the job hash, source-bundle hash, provider,
explicit model and effort when supplied, document number, and both output paths.
A manifest written before the current columns existed gains `SourceHash`,
`Model`, `Effort`, and `PipelineVersion` automatically with empty values for old
rows. New rows use `Status=Ready` and record version `1.2.0`. Provider, model,
effort, pipeline version, and source hashes are also recorded in the validation
reports. Optional build logs and `repair_request_N.md`/
`provider_repair_N.log` files are retained when they exist.

`usage.json` normalises any usage reported by the provider into input, cached
input, output, reasoning, and total token counts plus call count, provider,
parser source, and pipeline version. Providers do not always expose every
counter; unavailable values remain `null` rather than being guessed. This file
is an after-the-call billing/audit signal, while `--estimate-tokens` is the
before-the-call planning signal.

## Validation and safety

Before an application is archived, the pipeline requires all of the following:

- one schema-valid provider draft, followed by four non-empty files
  rendered locally from the captured source bundle and job snapshot
- the CV retains nine ordered validation regions. The first eight bodies -- the
  S-DS summary and seven bullet containers, including single-bullet Ziraat -- must match
  the template exactly; only `SUMMARY` and `SKILLS` may differ. Harmless whitespace beside a
  marker may be reported as `WARN`, but any difference inside a protected body
  blocks the application
- the fixed Summary and bullet lists, and the adaptive four-line Skills body,
  follow their LaTeX grammar
- every displayed technical skill resolves to the approved inventory or an
  explicitly supported profile phrase; invented frameworks are blocking, and
  Skills cannot contain placeholders or typography/layout commands
- explicitly excluded CV tools are absent (Spark, PySpark, and Kubernetes;
  Power BI is an ordinary inventory tool and may be used freely, as is
  dashboard/BI wording)
- the cover retains exactly seven ordered edit regions and unchanged fixed content.
  Its header command scaffold, candidate details, column widths, and other layout
  structure must match the template; editable text cannot introduce font, size,
  spacing, margin, geometry, or page-break commands
- all cover regions are populated; tokens are resolved consistently; title and
  company values agree across the letter; fixed evidence is unchanged
- the employer address block is accepted either way: independently verified
  with a direct source URL, or with both lines deleted when no reliable address
  exists. The company name is still cross-checked across the header and two paragraphs
- the cover uses English salutation/closing, British spelling, escaped LaTeX,
  and none of the blocked claims or removed wording. The job title and company
  name are exempt from the claim and British-spelling scans: they are proper
  nouns quoted from the posting, so a `Data Visualization Analyst` role keeps
  its American spelling and a `Big Data Engineer` role is not read as a claim
- both LaTeX documents compile successfully into `yigit_coskun_CV.pdf` and
  `yigit_coskun_cover_letter.pdf`
- the compiled cover letter has exactly one page, extractable greeting/closing
  text, and no overfull layout boxes
- the compiled cover letter uses the same visible font families, font sizes, and
  page dimensions as the locked approved template PDF
- the compiled CV is assessed for structural, ATS, bullet-provenance,
  skills-inventory, house-style, and job-description checks

For every application pair, the validation stage writes `validation.json`
and `validation.xlsx` as the combined CV-and-cover audit record. Its checks
include explicit
`CV_TEMPLATE_CONTRACT`, `COVER_TEMPLATE_CONTRACT`, `COVER_COMPILE`,
`COVER_PAGE_COUNT`, `COVER_TYPOGRAPHY_CONTRACT`, `COVER_PDF_TEXT`, and
`COVER_LAYOUT_WARNINGS` results in addition to CV ATS, provenance, and
job-description checks. Validation statuses have these effects:

- A repairable `ERROR` starts a bounded structured repair cycle. The same
  provider receives only the failed check IDs/messages, the current compact
  draft, a short job-ad excerpt, and the exact draft fields that check permits
  it to change. It does not receive the original full request, PDFs, XLSX
  report, LaTeX, or Markdown outputs. The returned object must still satisfy the
  full schema, and changing a field outside the allowlist is
  rejected. The pipeline then rerenders locally and reruns validation from the
  beginning.
- `--max-ai-repairs`/`-MaxAiRepairs` sets the general per-job repair budget;
  zero disables repairs. When the general budget is positive, the existing
  one-attempt reserved slot remains available only for late cover-letter page,
  PDF-text, layout, or typography failures. CV content, unknown checks,
  provider launch, configuration, dependency, and source-mutation failures are
  not AI-repair surfaces. Fixed CV summary and bullets are never repairable.
- Every repair is written to the normal `Checks` sheet and the dedicated
  `Repairs` sheet in `validation.xlsx`, as well as `validation.json`. The audit
  records the triggering checks, allowed and changed fields,
  provider/model/effort, repair request, and provider log. Successful archives
  also retain `repair_request_N.md` and `provider_repair_N.log`.
- If the applicable repair budget is exhausted, `AI_REPAIR_EXHAUSTED` remains an `ERROR`, so
  `../CVs/job_N` and its manifest row are blocked. Reports, generated sources,
  provider logs, repair logs, and build logs remain under `.artifacts/job_N`.
  Configuration, dependency, validator-runtime, report-writing, and provider
  launch failures stop immediately because changing document text cannot repair
  them.
- A later run reuses a retained structured response only when its compact
  request matches exactly. Change a relevant prompt or posting and the request
  differs, so the provider is called again. `-Fresh` forces that initial call;
  repairing one job does not disable `-Fresh` for the rest of the batch.
- Once the archive and manifest are committed, a transient Windows sharing lock
  on the disposable artifact directory cannot turn that success into a pipeline
  failure. Cleanup is reported as deferred and retried automatically on later
  runs; other filesystem errors and unsafe cleanup paths still fail normally.
- `WARN` is visible in both reports but permits the complete CV/cover-letter pair
  and its reports to be archived atomically.
- `PASS` requires no manual action, although the final documents should still be
  reviewed before submission.

The JD tailoring and coverage percentages are diagnostic, non-blocking signals.
Tailoring asks how many posting terms supported by the candidate inventory are
surfaced on the CV. Because summary and bullets are fixed, job-specific changes
to that score now come only from Skills. Coverage also includes detected posting
terms that may be unsupported. A lower score never authorises changing fixed
prose or adding an unverified claim and does not by itself block archival.

`CV_RULES.md`, the fixed CV template, the bullet provenance library, the skills
profiles, and the cover pack remain the sources of truth.

All reference files and every selected job PDF are captured once before work
starts and byte-checked before commit. If any captured input changes while the
run is active, the application attempt fails before archival and leaves the new
external bytes untouched; it does not overwrite a legitimate concurrent edit
with an old snapshot. Nothing is added to the manifest unless both PDFs, the
completion sentinel, and every blocking validation gate pass.

Stage 1 accesses only public LinkedIn job-view pages. It does not log in, solve
CAPTCHAs, rotate proxies, or bypass access controls, and it spaces requests with
a configurable delay. Review LinkedIn's terms and the content owner's rights
before using browser automation; failed, blocked, expired, or incomplete pages
are reported rather than forced through the pipeline.

## Versions

The active application pipeline is **version 1.2.0**. The package version is
defined once in `src/job_application_pipeline/version.py`, exposed as
`job_application_pipeline.__version__`, published through the dynamic project
metadata, printed by both entry points, and recorded in manifests, validation
reports, completion sentinels, source-generation hashes, and usage metrics.

Version 1.1.0 introduced the fixed S-DS summary and approved 18-bullet
inventory, leaving Skills as the only job-adaptive CV region. Version 1.2.0
keeps that document contract and adds compact structured generation,
deterministic local rendering, token controls and metrics, timeouts and
process-tree cleanup, exclusive locking, captured-input mutation detection,
checksum-verified resume, and per-job batch failure handling.

The exact v1.0.0 and v1.1.0 code-and-configuration snapshots and their SHA-256
checksums are documented in [`versions/README.md`](versions/README.md). Mutable
job ledgers, URL queues, generated artifacts, environments, IDE files, and the
independent market analysis are excluded from those snapshots.

## Tests

Run the test suite from `job_py`:

```powershell
python -m unittest discover -s tests -v
python -m unittest discover -s desc\tests -v
```

The suite covers release metadata, extraction, compact prompt and strict schema
contracts, guarded Summary and Skills CV tailoring, both template validators,
captured-input protection, locks and process-tree timeouts, Claude/Codex command
paths, usage parsing, compilation, CV quality checks, cover
structure/page/PDF/layout checks, combined JSON/XLSX report rendering,
error-versus-warning gates, structured repair allowlists, failed-report
retention, sentinel checksum verification, archive atomicity, legacy resume
behaviour, LinkedIn URL/PDF handling, and the Stage 1-to-Stage 2 handoff.
