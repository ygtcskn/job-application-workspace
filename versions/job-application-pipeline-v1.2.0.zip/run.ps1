param(
    [Parameter(Position = 0)]
    [ValidateSet("claude", "codex")]
    [string] $Provider,

    [AllowEmptyString()]
    [string] $Model,

    [ValidateSet("minimal", "low", "medium", "high", "xhigh", "max")]
    [string] $Effort,

    [switch] $Fresh,

    [string] $Job,
    [int] $Limit,
    [switch] $DryRun,
    [switch] $EstimateTokens,
    [int] $TokenBudget,
    [int] $MaxAiRepairs,
    [switch] $ContinueOnJobError,
    [double] $ProviderTimeout = 1200,
    [double] $LatexTimeout = 120,
    [switch] $NoReview,
    [switch] $NoAddressLookup,
    [switch] $Quiet,
    [switch] $Version
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot
$PackageRoot = Join-Path $ProjectRoot "src"
$VirtualEnvironmentPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$PythonCandidates = @()
if (-not [string]::IsNullOrWhiteSpace($env:JOB_PIPELINE_PYTHON)) {
    $PythonCandidates += $env:JOB_PIPELINE_PYTHON
}
if (Test-Path -LiteralPath $VirtualEnvironmentPython -PathType Leaf) {
    $PythonCandidates += $VirtualEnvironmentPython
}
$SystemPython = Get-Command "python" -ErrorAction SilentlyContinue
if ($SystemPython) {
    $PythonCandidates += $SystemPython.Source
}

$PythonExe = $null
foreach ($Candidate in $PythonCandidates | Select-Object -Unique) {
    try {
        & $Candidate -c "import sys; raise SystemExit(0)" *> $null
        if ($LASTEXITCODE -eq 0) {
            $PythonExe = $Candidate
            break
        }
    }
    catch {
        continue
    }
}
if (-not $PythonExe) {
    throw "No working Python interpreter was found. Recreate .venv or install Python 3.11+."
}

$PreviousPythonPath = $env:PYTHONPATH
$PreviousPythonUtf8 = $env:PYTHONUTF8
$PreviousNoBytecode = $env:PYTHONDONTWRITEBYTECODE

try {
    $env:PYTHONPATH = if ([string]::IsNullOrWhiteSpace($PreviousPythonPath)) {
        $PackageRoot
    }
    else {
        "$PackageRoot$([System.IO.Path]::PathSeparator)$PreviousPythonPath"
    }
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"

    if ($Version) {
        $PipelineArguments = @("-m", "job_application_pipeline", "--version")
    }
    else {
        if ([string]::IsNullOrWhiteSpace($Provider)) {
            throw "Provider is required unless -Version is used."
        }
        $PipelineArguments = @("-m", "job_application_pipeline", $Provider)
    }
    if ($PSBoundParameters.ContainsKey("Model")) {
        $PipelineArguments += @("--model", $Model)
    }
    if ($PSBoundParameters.ContainsKey("Effort")) {
        $PipelineArguments += @("--effort", $Effort)
    }
    if ($Fresh) {
        $PipelineArguments += "--fresh"
    }
    if ($PSBoundParameters.ContainsKey("Job")) {
        $PipelineArguments += @("--job", $Job)
    }
    if ($PSBoundParameters.ContainsKey("Limit")) {
        $PipelineArguments += @("--limit", [string] $Limit)
    }
    if ($DryRun) { $PipelineArguments += "--dry-run" }
    if ($EstimateTokens) { $PipelineArguments += "--estimate-tokens" }
    if ($PSBoundParameters.ContainsKey("TokenBudget")) {
        $PipelineArguments += @("--token-budget", [string] $TokenBudget)
    }
    if ($PSBoundParameters.ContainsKey("MaxAiRepairs")) {
        $PipelineArguments += @("--max-ai-repairs", [string] $MaxAiRepairs)
    }
    if ($ContinueOnJobError) { $PipelineArguments += "--continue-on-job-error" }
    $PipelineArguments += @("--provider-timeout", [string] $ProviderTimeout)
    $PipelineArguments += @("--latex-timeout", [string] $LatexTimeout)
    if ($NoReview) { $PipelineArguments += "--no-review" }
    if ($NoAddressLookup) { $PipelineArguments += "--no-address-lookup" }
    if ($Quiet) { $PipelineArguments += "--quiet" }

    & $PythonExe @PipelineArguments
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}
finally {
    $env:PYTHONPATH = $PreviousPythonPath
    $env:PYTHONUTF8 = $PreviousPythonUtf8
    $env:PYTHONDONTWRITEBYTECODE = $PreviousNoBytecode
}
